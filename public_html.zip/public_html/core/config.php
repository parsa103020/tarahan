<?php
@session_start();
$model = new Model;

// $BASE_URL = getenv('BASE_URL');
define('URL', "https://tarahanbastan.ir/");
