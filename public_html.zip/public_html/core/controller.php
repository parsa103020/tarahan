<?php

class Controller
{
    protected $model;

    function __construct()
    {
        @session_start();
         

    }

    function view($viewUrl, $data = array(), $noIncludeHeader = '', $noIncludeFooter = '')
    {
        // Extract $data array to individual variables for use in views
        if (!empty($data)) {
            extract($data);
        }

        if ($noIncludeHeader == '') {
            require('header.php');
        }

        require('views/' . $viewUrl . '.php');

        if ($noIncludeFooter == '') {
            require('footer.php');
        }
    }


    function model($modelUrl)
    {
        require_once('models/model_' . $modelUrl . '.php');
        $classname = 'model_' . $modelUrl;
        $this->model = new $classname;
        return $this->model;
    }

}


?>