 <?php

class Model
{
    public $redis;
    public static $conn = null;

    function __construct()
    {
        @session_start();

        // Initialize database connection if not already connected
        if (self::$conn === null) {
            try {
                $host = 'localhost';
                $dbname = 'tarahanb_tarahan';
                $username = 'tarahanb_db@';
                $password = '12345qaz54321zaq';
                $charset = 'utf8mb4';

                $dsn = "mysql:host=$host;dbname=$dbname;charset=$charset";
                $options = [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                    PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4"
                ];

                self::$conn = new PDO($dsn, $username, $password, $options);
            } catch (PDOException $e) {
                // If database doesn't exist, connection will fail silently
                // The initial controller will create the database
                self::$conn = null;
            }
        }
    }

    //Data sanitizing


    public static function cleanInput($input)
    {
        $search = array(
            '@<script[^>]*?>.*?</script>@si', // Strip out javascript
            '@<[\/\!]*?[^<>]*?>@si', // Strip out HTML tags
            '@<style[^>]*?>.*?</style>@siU', // Strip style tags properly
            '@<![\s\S]*?--[ \t\n\r]*>@' // Strip multi-line comments
        );
        $output = preg_replace($search, '', $input);
        return $output;
    }

    public static function sanitize($input)
    {
        if (is_array($input)) {
            foreach ($input as $var => $val) {
                $output[$var] = Model::sanitize($val);
            }
        } else {
            /*if (get_magic_quotes_gpc()) {
                $input = stripslashes($input);
            }*/
            $input = Model::cleanInput($input);
            $output = addslashes($input);
        }
        return $output;
    }

    public static function getRealIpAddr()
    {
        if (!empty($_SERVER['HTTP_CLIENT_IP']))   //check ip from share internet
        {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))   //to check ip is pass from proxy
        {
            $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        } else {
            $ip = $_SERVER['REMOTE_ADDR'];
        }
        Model::sessionSet('ipClient', $ip);
        return $ip;
    }

    function doSelect($sql, $values = array(), $fetch = '', $fetchStyle = PDO::FETCH_ASSOC)
    {

        $stmt = self::$conn->prepare($sql);
        foreach ($values as $key => $value) {
            // Support both named (:param) and positional parameters
            if (is_string($key) && strpos($key, ':') === 0) {
                $stmt->bindValue($key, $value);
            } else {
                $stmt->bindValue($key + 1, $value);
            }
        }
        $stmt->execute();
        if ($fetch == '') {
            $result = $stmt->fetchAll($fetchStyle);
        } else {
            $result = $stmt->fetch($fetchStyle);
        }
        return $result;
    }

    function doQuery($sql, $values = array())
    {
        $stmt = self::$conn->prepare($sql);

        foreach ($values as $key => $value) {
            $stmt->bindValue($key + 1, $value);
        }
        $stmt->execute();
    }

    public static function sessionInit()
    {
        @session_start();
    }

    public static function sessionSet($name, $value)
    {
        $_SESSION[$name] = $value;
    }

    public static function sessionGet($name)
    {
        if (isset($_SESSION[$name])) {
            return $_SESSION[$name];
        } else {
            return false;
        }

    }

    public static function cookieSet($name, $value)
    {
        $expire = time() + 7776000;
        setrawcookie($name, $value, $expire);

    }









}