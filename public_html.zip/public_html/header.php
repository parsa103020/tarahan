<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <!-- Meta Tags -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <base href="https://tarahanbastan.ir/">

    <!-- Dynamic Meta Tags -->
    <title><?php echo isset($pageTitle) ? $pageTitle : 'طراحان باستان | با ما غیرممکن نیست'; ?></title>
    <meta name="description" content="<?php echo isset($pageDescription) ? $pageDescription : 'شرکت طراحان باستان - بیش از ۱۰ سال تجربه در تبلیغات و رویداد در همدان'; ?>">
    <meta name="keywords" content="<?php echo isset($pageKeywords) ? $pageKeywords : 'طراحان باستان، تبلیغات، همدان، رویداد، غرفه نمایشگاهی'; ?>">
    <meta name="author" content="شرکت آرین طراحان باستان">
    <meta name="robots" content="index, follow">
    <meta name="theme-color" content="#2D1810">
    <meta name="format-detection" content="telephone=no">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">

    <!-- Open Graph / Facebook -->
    <meta property="og:type" content="website">
    <meta property="og:url" content="<?php echo isset($_SERVER['REQUEST_URI']) ? (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https://' : 'http://') . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'] : URL; ?>">
    <meta property="og:title" content="<?php echo isset($pageTitle) ? $pageTitle : 'طراحان باستان | با ما غیرممکن نیست'; ?>">
    <meta property="og:description" content="<?php echo isset($pageDescription) ? $pageDescription : 'شرکت طراحان باستان - بیش از ۱۰ سال تجربه در تبلیغات و رویداد در همدان'; ?>">
    <meta property="og:image" content="<?php echo isset($ogImage) ? $ogImage : URL . 'public/assets/images/og-default.jpg'; ?>">
    <meta property="og:image:width" content="1200">
    <meta property="og:image:height" content="630">
    <meta property="og:image:alt" content="<?php echo isset($pageTitle) ? $pageTitle : 'طراحان باستان'; ?>">
    <meta property="og:site_name" content="طراحان باستان">
    <meta property="og:locale" content="fa_IR">

    <!-- Twitter -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:url" content="<?php echo isset($_SERVER['REQUEST_URI']) ? (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https://' : 'http://') . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'] : URL; ?>">
    <meta name="twitter:title" content="<?php echo isset($pageTitle) ? $pageTitle : 'طراحان باستان | با ما غیرممکن نیست'; ?>">
    <meta name="twitter:description" content="<?php echo isset($pageDescription) ? $pageDescription : 'شرکت طراحان باستان - بیش از ۱۰ سال تجربه در تبلیغات و رویداد در همدان'; ?>">
    <meta name="twitter:image" content="<?php echo isset($ogImage) ? $ogImage : URL . 'public/assets/images/og-default.jpg'; ?>">

    <!-- DNS Prefetch for external resources -->
    <link rel="dns-prefetch" href="//code.jquery.com">
    <link rel="dns-prefetch" href="//db.onlinewebfonts.com">

    <!-- Preconnect to Font CDN -->
    <link rel="preconnect" href="https://db.onlinewebfonts.com" crossorigin>

    <!-- Preload main font for better performance -->
    <link rel="preload" href="https://db.onlinewebfonts.com/t/7296ae79f6faca68798b00fbbbee4c22.woff2" as="font" type="font/woff2" crossorigin>

    <!-- Favicon -->
    <link rel="icon" type="image/svg+xml" href="<?= URL ?>public/assets/images/favicon.svg">
    <link rel="apple-touch-icon" href="<?= URL ?>public/assets/images/apple-touch-icon.png">

    <!-- Web App Manifest -->
    <link rel="manifest" href="<?= URL ?>site.webmanifest">

    <!-- Humans.txt -->
    <link rel="author" href="<?= URL ?>humans.txt">

    <!-- Canonical URL -->
    <link rel="canonical" href="<?php echo isset($_SERVER['REQUEST_URI']) ? (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https://' : 'http://') . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'] : URL; ?>">

    <!-- YekanBakh Font - All Weights from CDN -->
    <link href="https://db.onlinewebfonts.com/c/7296ae79f6faca68798b00fbbbee4c22?family=YekanBakh-Regular" rel="stylesheet">
    <link href="https://db.onlinewebfonts.com/c/41e49eab42867016423011dccc96c22a?family=YekanBakh-Bold" rel="stylesheet">
    <link href="https://db.onlinewebfonts.com/c/3231c6a7b3ba5a66dd21bfc6b461165e?family=YekanBakh-Heavy" rel="stylesheet">
    <link href="https://db.onlinewebfonts.com/c/e1d06869ee86ac98052a5a1788122235?family=YekanBakh-Fat" rel="stylesheet">
    <style>
    @font-face { font-family: 'YekanBakh'; src: url('https://db.onlinewebfonts.com/t/7296ae79f6faca68798b00fbbbee4c22.woff2') format('woff2'); font-weight: 400; font-style: normal; font-display: swap; }
    @font-face { font-family: 'YekanBakh'; src: url('https://db.onlinewebfonts.com/t/41e49eab42867016423011dccc96c22a.woff2') format('woff2'); font-weight: 700; font-style: normal; font-display: swap; }
    @font-face { font-family: 'YekanBakh'; src: url('https://db.onlinewebfonts.com/t/3231c6a7b3ba5a66dd21bfc6b461165e.woff2') format('woff2'); font-weight: 800; font-style: normal; font-display: swap; }
    @font-face { font-family: 'YekanBakh'; src: url('https://db.onlinewebfonts.com/t/e1d06869ee86ac98052a5a1788122235.woff2') format('woff2'); font-weight: 900; font-style: normal; font-display: swap; }
    </style>

    <!-- Common Styles -->
    <link rel="stylesheet" href="public/assets/css/common.css">

    <!-- Component Styles -->
    <link rel="stylesheet" href="public/assets/css/components/header.css">
    <link rel="stylesheet" href="public/assets/css/components/footer.css">
    <link rel="stylesheet" href="public/assets/css/components/buttons.css">
    <link rel="stylesheet" href="public/assets/css/components/hero.css">
    <link rel="stylesheet" href="public/assets/css/components/cards.css">
    <link rel="stylesheet" href="public/assets/css/components/faq.css">
    <link rel="stylesheet" href="public/assets/css/components/sections.css">

    <!-- Page Specific Styles -->
    <?php if (isset($pageCSS) && is_array($pageCSS)): ?>
        <?php foreach ($pageCSS as $css): ?>
            <link rel="stylesheet" href="public/assets/css/pages/<?php echo $css; ?>.css">
        <?php endforeach; ?>
    <?php endif; ?>

    <!-- Schema.org Structured Data - Organization -->
    <script type="application/ld+json">
    {
        "@context": "https://schema.org",
        "@type": "Organization",
        "name": "طراحان باستان",
        "alternateName": "آرین طراحان باستان",
        "url": "<?= URL ?>",
        "logo": "<?= URL ?>public/assets/images/logo.png",
        "description": "شرکت طراحان باستان - بیش از ۱۰ سال تجربه در تبلیغات و رویداد در همدان",
        "address": {
            "@type": "PostalAddress",
            "addressLocality": "همدان",
            "addressRegion": "همدان",
            "addressCountry": "IR"
        },
        "contactPoint": {
            "@type": "ContactPoint",
            "telephone": "+98-918-345-6789",
            "contactType": "customer service",
            "availableLanguage": "Persian"
        },
        "sameAs": [
            "https://instagram.com/tarahan_bastan",
            "https://t.me/tarahan_bastan"
        ]
    }
    </script>

    <!-- Schema.org - WebSite -->
    <script type="application/ld+json">
    {
        "@context": "https://schema.org",
        "@type": "WebSite",
        "name": "طراحان باستان",
        "url": "<?= URL ?>",
        "potentialAction": {
            "@type": "SearchAction",
            "target": "<?= URL ?>search?q={search_term_string}",
            "query-input": "required name=search_term_string"
        }
    }
    </script>
</head>
<body>
<!-- Skip Link for Accessibility -->
<a href="#main-content" class="skip-link">رفتن به محتوای اصلی</a>

<!-- Scroll Progress -->
<div class="scroll-progress">
    <div class="scroll-progress-bar"></div>
</div>

<!-- Header -->
<header class="header" id="header">
    <div class="header-container">
        <!-- Logo -->
        <a href="<?= URL ?>" class="logo" title="طراحان باستان - صفحه اصلی">
            <div class="logo-icon">ط</div>
            <div class="logo-text">
                <div class="logo-title">طراحان باستان</div>
                <div class="logo-subtitle">با ما غیرممکن نیست</div>
            </div>
        </a>

        <!-- Desktop Navigation -->
        <nav class="nav" role="navigation" aria-label="منوی اصلی">
            <a href="<?= URL ?>" class="nav-link">خانه</a>

            <div class="nav-item">
                <button type="button" class="nav-link" id="servicesDropdownBtn" aria-expanded="false" aria-haspopup="true" aria-controls="servicesDropdown">
                    خدمات
                    <svg class="dropdown-icon" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5" aria-hidden="true">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7" />
                    </svg>
                </button>
                <div class="dropdown" id="servicesDropdown" role="menu">
                    <a href="<?= URL ?>service/booth" class="dropdown-item" role="menuitem">
                        <svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" aria-hidden="true">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                        </svg>
                        غرفه نمایشگاهی
                    </a>
                    <a href="<?= URL ?>service/ads" class="dropdown-item" role="menuitem">
                        <svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" aria-hidden="true">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                        </svg>
                        تبلیغات محیطی
                    </a>
                    <a href="<?= URL ?>service/tandis" class="dropdown-item" role="menuitem">
                        <svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" aria-hidden="true">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
                        </svg>
                        تندیس و المان
                    </a>
                    <a href="<?= URL ?>service/event" class="dropdown-item" role="menuitem">
                        <svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" aria-hidden="true">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                        </svg>
                        برگزاری همایش
                    </a>
                    <a href="<?= URL ?>service/content" class="dropdown-item" role="menuitem">
                        <svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" aria-hidden="true">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
                        </svg>
                        تیزر و محتوا
                    </a>
                    <a href="<?= URL ?>service/print" class="dropdown-item" role="menuitem">
                        <svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" aria-hidden="true">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z" />
                        </svg>
                        چاپ افست و دیجیتال
                    </a>
                    <a href="<?= URL ?>service/idea" class="dropdown-item" role="menuitem">
                        <svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" aria-hidden="true">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
                        </svg>
                        ایده نو
                    </a>
                </div>
            </div>

            <a href="<?= URL ?>about" class="nav-link">درباره ما</a>
            <a href="<?= URL ?>article" class="nav-link">وبلاگ</a>
            <a href="<?= URL ?>contact" class="nav-link">تماس با ما</a>
        </nav>

        <!-- CTA Button -->
        <a href="<?= URL ?>contact" class="cta-button" title="تماس با ما">
            <svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5" aria-hidden="true">
                <path stroke-linecap="round" stroke-linejoin="round" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
            </svg>
            مشاوره رایگان
        </a>

        <!-- Mobile Menu Button -->
        <button class="mobile-menu-btn" id="mobileMenuBtn" aria-label="باز کردن منو" aria-expanded="false" aria-controls="mobileMenu">
            <span></span>
            <span></span>
            <span></span>
        </button>
    </div>
</header>

<!-- Mobile Menu -->
<div class="mobile-menu" id="mobileMenu" role="dialog" aria-modal="true" aria-label="منوی موبایل">
    <nav class="mobile-nav" role="navigation" aria-label="منوی اصلی موبایل">
        <a href="<?= URL ?>" class="mobile-nav-link">خانه</a>

        <div>
            <button type="button" class="mobile-nav-link" id="mobileServicesToggle" aria-expanded="false" aria-controls="mobileServicesDropdown">
                خدمات
                <svg width="20" height="20" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5" aria-hidden="true">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7" />
                </svg>
            </button>
            <div class="mobile-dropdown" id="mobileServicesDropdown" role="menu">
                <a href="<?= URL ?>service/booth" class="mobile-dropdown-item" role="menuitem">
                    <svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" aria-hidden="true">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                    </svg>
                    غرفه نمایشگاهی
                </a>
                <a href="<?= URL ?>service/ads" class="mobile-dropdown-item" role="menuitem">
                    <svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" aria-hidden="true">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                    </svg>
                    تبلیغات محیطی
                </a>
                <a href="<?= URL ?>service/tandis" class="mobile-dropdown-item" role="menuitem">
                    <svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" aria-hidden="true">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
                    </svg>
                    تندیس و المان
                </a>
                <a href="<?= URL ?>service/event" class="mobile-dropdown-item" role="menuitem">
                    <svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" aria-hidden="true">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                    </svg>
                    برگزاری همایش
                </a>
                <a href="<?= URL ?>service/content" class="mobile-dropdown-item" role="menuitem">
                    <svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" aria-hidden="true">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
                    </svg>
                    تیزر و محتوا
                </a>
                <a href="<?= URL ?>service/print" class="mobile-dropdown-item" role="menuitem">
                    <svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" aria-hidden="true">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z" />
                    </svg>
                    چاپ افست و دیجیتال
                </a>
                <a href="<?= URL ?>service/idea" class="mobile-dropdown-item" role="menuitem">
                    <svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" aria-hidden="true">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
                    </svg>
                    ایده نو
                </a>
            </div>
        </div>

        <a href="<?= URL ?>about" class="mobile-nav-link">درباره ما</a>
        <a href="<?= URL ?>article" class="mobile-nav-link">وبلاگ</a>
        <a href="<?= URL ?>contact" class="mobile-nav-link">تماس با ما</a>
    </nav>

    <a href="<?= URL ?>contact" class="cta-button mobile-cta">
        <svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5" aria-hidden="true">
            <path stroke-linecap="round" stroke-linejoin="round" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
        </svg>
        مشاوره رایگان
    </a>
</div>

<!-- Main Content Wrapper -->
<main id="main-content" role="main">
