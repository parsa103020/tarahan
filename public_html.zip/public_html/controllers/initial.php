<?php

/**
 * Initial Controller - Database Setup
 * این کنترلر فقط یکبار برای ساخت جداول و داده‌های اولیه اجرا می‌شود
 * URL: domain.com/initial/index
 */
class initial extends Controller
{
    function __construct()
    {
        parent::__construct();
    }

    /**
     * Main initialization - Creates all tables and inserts initial data
     */
    function index()
    {
        try {
            // ابتدا جداول را می‌سازیم
            $this->createTables();

            // سپس داده‌های اولیه را وارد می‌کنیم
            $this->insertSettings();
            $this->insertStats();
            $this->insertServices();
            $this->insertHomePageData();
            $this->insertAboutPageData();
            $this->insertContactPageData();
            $this->insertServicePagesData();

            echo "<div style='direction:rtl; font-family:Tahoma; padding:50px; background:#d4edda; color:#155724; text-align:center;'>";
            echo "<h1>✅ دیتابیس با موفقیت راه‌اندازی شد!</h1>";
            echo "<p>تمام جداول و داده‌های اولیه ایجاد شدند.</p>";
            echo "<p><a href='" . URL . "' style='color:#155724;'>بازگشت به سایت</a></p>";
            echo "<p style='margin-top:20px;'><a href='" . URL . "initial/reset' style='color:#721c24;'>⚠️ ریست کامل دیتابیس</a></p>";
            echo "</div>";

        } catch (Exception $e) {
            echo "<div style='direction:rtl; font-family:Tahoma; padding:50px; background:#f8d7da; color:#721c24; text-align:center;'>";
            echo "<h1>❌ خطا در راه‌اندازی</h1>";
            echo "<p>" . $e->getMessage() . "</p>";
            echo "</div>";
        }
    }

    /**
     * Reset database - Drops and recreates all tables
     */
    function reset()
    {
        try {
            $host = 'localhost';
            $dbname = 'tarahan';
            $username = 'root';
            $password = '';

            $pdo = new PDO("mysql:host=$host", $username, $password, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
            ]);

            // Drop and recreate database
            $pdo->exec("DROP DATABASE IF EXISTS `$dbname`");
            $pdo->exec("CREATE DATABASE `$dbname` CHARACTER SET utf8mb4 COLLATE utf8mb4_persian_ci");

            echo "<div style='direction:rtl; font-family:Tahoma; padding:50px; background:#fff3cd; color:#856404; text-align:center;'>";
            echo "<h1>🔄 دیتابیس ریست شد!</h1>";
            echo "<p>حالا برای ساخت جداول، <a href='" . URL . "initial' style='color:#856404; font-weight:bold;'>اینجا کلیک کنید</a></p>";
            echo "</div>";

        } catch (Exception $e) {
            echo "<div style='direction:rtl; font-family:Tahoma; padding:50px; background:#f8d7da; color:#721c24; text-align:center;'>";
            echo "<h1>❌ خطا در ریست</h1>";
            echo "<p>" . $e->getMessage() . "</p>";
            echo "</div>";
        }
    }

    /**
     * Create all database tables
     */
    private function createTables()
    {
        // First, create database if it doesn't exist
        $host = 'localhost';
        $dbname = 'tarahan';
        $username = 'root';
        $password = '';

        // Connect without database first to create it
        $pdo = new PDO("mysql:host=$host", $username, $password, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
        ]);
        $pdo->exec("CREATE DATABASE IF NOT EXISTS `$dbname` CHARACTER SET utf8mb4 COLLATE utf8mb4_persian_ci");
        $pdo = null;

        // Now connect to the database
        $dsn = "mysql:host=$host;dbname=$dbname;charset=utf8mb4";
        $conn = new PDO($dsn, $username, $password, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4"
        ]);

        // Store connection for later use
        Model::$conn = $conn;

        // =====================================================
        // جدول تنظیمات عمومی
        // =====================================================
        $conn->exec("CREATE TABLE IF NOT EXISTS settings (
            id INT AUTO_INCREMENT PRIMARY KEY,
            setting_key VARCHAR(100) UNIQUE NOT NULL,
            setting_value TEXT,
            setting_group VARCHAR(50) DEFAULT 'general',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci");

        // =====================================================
        // جدول آمار
        // =====================================================
        $conn->exec("CREATE TABLE IF NOT EXISTS stats (
            id INT AUTO_INCREMENT PRIMARY KEY,
            stat_key VARCHAR(50) NOT NULL,
            stat_value VARCHAR(50) NOT NULL,
            stat_suffix VARCHAR(20),
            stat_prefix VARCHAR(20),
            stat_label VARCHAR(100) NOT NULL,
            stat_icon VARCHAR(50),
            page VARCHAR(50) DEFAULT 'home',
            sort_order INT DEFAULT 0,
            is_active TINYINT(1) DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci");

        // =====================================================
        // جدول خدمات
        // =====================================================
        $conn->exec("CREATE TABLE IF NOT EXISTS services (
            id INT AUTO_INCREMENT PRIMARY KEY,
            slug VARCHAR(50) UNIQUE NOT NULL,
            title VARCHAR(100) NOT NULL,
            short_description VARCHAR(255),
            icon VARCHAR(50),
            hero_badge VARCHAR(100),
            hero_badge_icon VARCHAR(50),
            hero_title_line1 VARCHAR(100),
            hero_title_line2 VARCHAR(100),
            hero_subtitle TEXT,
            cta_primary_text VARCHAR(100),
            cta_primary_link VARCHAR(255),
            cta_secondary_text VARCHAR(100),
            cta_secondary_link VARCHAR(255),
            featured_project_title VARCHAR(200),
            featured_project_description TEXT,
            featured_project_image VARCHAR(255),
            cta_final_title VARCHAR(200),
            cta_final_subtitle TEXT,
            cta_final_button VARCHAR(100),
            sort_order INT DEFAULT 0,
            is_active TINYINT(1) DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci");

        // =====================================================
        // جدول ویژگی‌های خدمات
        // =====================================================
        $conn->exec("CREATE TABLE IF NOT EXISTS service_features (
            id INT AUTO_INCREMENT PRIMARY KEY,
            service_id INT NOT NULL,
            title VARCHAR(100) NOT NULL,
            description TEXT,
            icon VARCHAR(50),
            sort_order INT DEFAULT 0,
            is_active TINYINT(1) DEFAULT 1,
            FOREIGN KEY (service_id) REFERENCES services(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci");

        // =====================================================
        // جدول مراحل کار خدمات
        // =====================================================
        $conn->exec("CREATE TABLE IF NOT EXISTS service_process (
            id INT AUTO_INCREMENT PRIMARY KEY,
            service_id INT NOT NULL,
            step_number INT NOT NULL,
            title VARCHAR(100) NOT NULL,
            description TEXT,
            icon VARCHAR(50),
            sort_order INT DEFAULT 0,
            FOREIGN KEY (service_id) REFERENCES services(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci");

        // =====================================================
        // جدول سوالات متداول خدمات
        // =====================================================
        $conn->exec("CREATE TABLE IF NOT EXISTS service_faq (
            id INT AUTO_INCREMENT PRIMARY KEY,
            service_id INT NOT NULL,
            question VARCHAR(255) NOT NULL,
            answer TEXT NOT NULL,
            sort_order INT DEFAULT 0,
            is_active TINYINT(1) DEFAULT 1,
            FOREIGN KEY (service_id) REFERENCES services(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci");

        // =====================================================
        // جدول نظرات مشتریان
        // =====================================================
        $conn->exec("CREATE TABLE IF NOT EXISTS testimonials (
            id INT AUTO_INCREMENT PRIMARY KEY,
            service_id INT DEFAULT NULL,
            page VARCHAR(50) DEFAULT 'home',
            content TEXT NOT NULL,
            author_name VARCHAR(100) NOT NULL,
            author_position VARCHAR(100),
            author_avatar VARCHAR(255),
            rating INT DEFAULT 5,
            sort_order INT DEFAULT 0,
            is_active TINYINT(1) DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (service_id) REFERENCES services(id) ON DELETE SET NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci");

        // =====================================================
        // جدول نمونه کارها
        // =====================================================
        $conn->exec("CREATE TABLE IF NOT EXISTS portfolio (
            id INT AUTO_INCREMENT PRIMARY KEY,
            service_id INT DEFAULT NULL,
            title VARCHAR(200) NOT NULL,
            subtitle VARCHAR(255),
            description TEXT,
            image VARCHAR(255),
            link VARCHAR(255),
            sort_order INT DEFAULT 0,
            is_featured TINYINT(1) DEFAULT 0,
            is_active TINYINT(1) DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (service_id) REFERENCES services(id) ON DELETE SET NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci");

        // =====================================================
        // جدول تاریخچه شرکت (Timeline)
        // =====================================================
        $conn->exec("CREATE TABLE IF NOT EXISTS timeline (
            id INT AUTO_INCREMENT PRIMARY KEY,
            year VARCHAR(10) NOT NULL,
            title VARCHAR(100) NOT NULL,
            description TEXT,
            sort_order INT DEFAULT 0,
            is_active TINYINT(1) DEFAULT 1
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci");

        // =====================================================
        // جدول ارزش‌های شرکت
        // =====================================================
        $conn->exec("CREATE TABLE IF NOT EXISTS company_values (
            id INT AUTO_INCREMENT PRIMARY KEY,
            title VARCHAR(100) NOT NULL,
            description TEXT,
            icon VARCHAR(50),
            sort_order INT DEFAULT 0,
            is_active TINYINT(1) DEFAULT 1
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci");

        // =====================================================
        // جدول محتوای صفحات
        // =====================================================
        $conn->exec("CREATE TABLE IF NOT EXISTS page_content (
            id INT AUTO_INCREMENT PRIMARY KEY,
            page VARCHAR(50) NOT NULL,
            section VARCHAR(50) NOT NULL,
            content_key VARCHAR(100) NOT NULL,
            content_value TEXT,
            content_type VARCHAR(20) DEFAULT 'text',
            UNIQUE KEY unique_content (page, section, content_key)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci");

        // =====================================================
        // جدول مزایا (Why Us)
        // =====================================================
        $conn->exec("CREATE TABLE IF NOT EXISTS benefits (
            id INT AUTO_INCREMENT PRIMARY KEY,
            page VARCHAR(50) DEFAULT 'home',
            service_id INT DEFAULT NULL,
            number VARCHAR(10),
            title VARCHAR(100) NOT NULL,
            description TEXT,
            icon VARCHAR(50),
            sort_order INT DEFAULT 0,
            is_active TINYINT(1) DEFAULT 1,
            FOREIGN KEY (service_id) REFERENCES services(id) ON DELETE SET NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci");

        // =====================================================
        // جدول مراحل کار عمومی (Process)
        // =====================================================
        $conn->exec("CREATE TABLE IF NOT EXISTS process_steps (
            id INT AUTO_INCREMENT PRIMARY KEY,
            page VARCHAR(50) DEFAULT 'home',
            step_number INT NOT NULL,
            title VARCHAR(100) NOT NULL,
            description TEXT,
            icon VARCHAR(50),
            sort_order INT DEFAULT 0,
            is_active TINYINT(1) DEFAULT 1
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci");

        // =====================================================
        // جدول سوالات متداول عمومی
        // =====================================================
        $conn->exec("CREATE TABLE IF NOT EXISTS faq (
            id INT AUTO_INCREMENT PRIMARY KEY,
            page VARCHAR(50) DEFAULT 'contact',
            question VARCHAR(255) NOT NULL,
            answer TEXT NOT NULL,
            sort_order INT DEFAULT 0,
            is_active TINYINT(1) DEFAULT 1
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci");

        // =====================================================
        // جدول پیام‌های تماس
        // =====================================================
        $conn->exec("CREATE TABLE IF NOT EXISTS contact_messages (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100) NOT NULL,
            phone VARCHAR(20) NOT NULL,
            email VARCHAR(100),
            subject VARCHAR(200),
            message TEXT NOT NULL,
            is_read TINYINT(1) DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci");

        // =====================================================
        // جدول آمار خدمات
        // =====================================================
        $conn->exec("CREATE TABLE IF NOT EXISTS service_stats (
            id INT AUTO_INCREMENT PRIMARY KEY,
            service_id INT NOT NULL,
            stat_value VARCHAR(50) NOT NULL,
            stat_label VARCHAR(100) NOT NULL,
            sort_order INT DEFAULT 0,
            FOREIGN KEY (service_id) REFERENCES services(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci");

        // =====================================================
        // جدول زیرخدمات (Sub-services)
        // =====================================================
        $conn->exec("CREATE TABLE IF NOT EXISTS service_items (
            id INT AUTO_INCREMENT PRIMARY KEY,
            service_id INT NOT NULL,
            title VARCHAR(100) NOT NULL,
            description TEXT,
            icon VARCHAR(50),
            features TEXT,
            cta_text VARCHAR(100),
            sort_order INT DEFAULT 0,
            is_active TINYINT(1) DEFAULT 1,
            FOREIGN KEY (service_id) REFERENCES services(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci");

        // =====================================================
        // جدول موقعیت‌ها (برای تبلیغات محیطی)
        // =====================================================
        $conn->exec("CREATE TABLE IF NOT EXISTS locations (
            id INT AUTO_INCREMENT PRIMARY KEY,
            service_id INT NOT NULL,
            name VARCHAR(100) NOT NULL,
            sort_order INT DEFAULT 0,
            is_active TINYINT(1) DEFAULT 1,
            FOREIGN KEY (service_id) REFERENCES services(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci");

        // =====================================================
        // جدول پکیج‌ها (برای ایده نو)
        // =====================================================
        $conn->exec("CREATE TABLE IF NOT EXISTS packages (
            id INT AUTO_INCREMENT PRIMARY KEY,
            service_id INT NOT NULL,
            title VARCHAR(100) NOT NULL,
            subtitle VARCHAR(100),
            description TEXT,
            cta_text VARCHAR(100),
            is_popular TINYINT(1) DEFAULT 0,
            sort_order INT DEFAULT 0,
            is_active TINYINT(1) DEFAULT 1,
            FOREIGN KEY (service_id) REFERENCES services(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci");

        // =====================================================
        // جدول تجهیزات (برای تیزر و محتوا)
        // =====================================================
        $conn->exec("CREATE TABLE IF NOT EXISTS equipment (
            id INT AUTO_INCREMENT PRIMARY KEY,
            service_id INT NOT NULL,
            name VARCHAR(100) NOT NULL,
            sort_order INT DEFAULT 0,
            FOREIGN KEY (service_id) REFERENCES services(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci");

        // =====================================================
        // جدول انواع کاغذ (برای چاپ)
        // =====================================================
        $conn->exec("CREATE TABLE IF NOT EXISTS paper_types (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(50) NOT NULL,
            description VARCHAR(255),
            sort_order INT DEFAULT 0
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci");

        // =====================================================
        // جدول ادمین‌ها
        // =====================================================
        $conn->exec("CREATE TABLE IF NOT EXISTS admins (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(50) UNIQUE NOT NULL,
            password VARCHAR(255) NOT NULL,
            name VARCHAR(100) NOT NULL,
            email VARCHAR(100),
            role VARCHAR(50) DEFAULT 'admin',
            is_active TINYINT(1) DEFAULT 1,
            last_login TIMESTAMP NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci");

        // اضافه کردن ادمین پیش‌فرض
        $defaultPassword = password_hash('admin123', PASSWORD_DEFAULT);
        $conn->exec("INSERT IGNORE INTO admins (username, password, name, email, role)
                     VALUES ('admin', '$defaultPassword', 'مدیر سایت', 'admin@tarahanbastan.ir', 'superadmin')");

        // =====================================================
        // جدول مقالات (وبلاگ)
        // =====================================================
        $conn->exec("CREATE TABLE IF NOT EXISTS articles (
            id INT AUTO_INCREMENT PRIMARY KEY,
            title VARCHAR(255) NOT NULL,
            slug VARCHAR(255) NOT NULL UNIQUE,
            excerpt TEXT,
            content LONGTEXT NOT NULL,
            featured_image VARCHAR(500),
            meta_title VARCHAR(255),
            meta_description TEXT,
            meta_keywords VARCHAR(500),
            status ENUM('draft', 'published') DEFAULT 'draft',
            views INT DEFAULT 0,
            reading_time INT DEFAULT 5,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            published_at TIMESTAMP NULL,
            INDEX idx_slug (slug),
            INDEX idx_status (status),
            INDEX idx_published_at (published_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci");

        // =====================================================
        // فیلدهای اضافی برای سیستم AI
        // =====================================================
        // چک کردن و اضافه کردن فیلدها اگر وجود ندارند
        $columns = $conn->query("SHOW COLUMNS FROM articles")->fetchAll(PDO::FETCH_COLUMN);

        if (!in_array('service_code', $columns)) {
            $conn->exec("ALTER TABLE articles ADD COLUMN service_code VARCHAR(50) NULL AFTER reading_time");
        }
        if (!in_array('is_ai_generated', $columns)) {
            $conn->exec("ALTER TABLE articles ADD COLUMN is_ai_generated TINYINT(1) DEFAULT 0 AFTER service_code");
        }
        if (!in_array('schema_markup', $columns)) {
            $conn->exec("ALTER TABLE articles ADD COLUMN schema_markup TEXT NULL AFTER meta_keywords");
        }
        if (!in_array('quality_score', $columns)) {
            $conn->exec("ALTER TABLE articles ADD COLUMN quality_score INT DEFAULT 0 AFTER is_ai_generated");
        }

        // ایندکس‌ها
        try {
            $conn->exec("CREATE INDEX idx_service_code ON articles(service_code)");
        } catch (Exception $e) {}
        try {
            $conn->exec("CREATE INDEX idx_ai_generated ON articles(is_ai_generated)");
        } catch (Exception $e) {}

        // =====================================================
        // جدول موضوعات مقالات AI
        // =====================================================
        $conn->exec("CREATE TABLE IF NOT EXISTS ai_article_topics (
            id INT AUTO_INCREMENT PRIMARY KEY,
            service_code VARCHAR(50) NOT NULL,
            topic_title VARCHAR(500) NOT NULL,
            primary_keyword VARCHAR(200) NULL,
            is_used TINYINT(1) DEFAULT 0,
            used_at TIMESTAMP NULL,
            article_id INT NULL,
            priority INT DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_service (service_code),
            INDEX idx_used (is_used),
            INDEX idx_priority (priority)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci");

        // اضافه کردن ستون primary_keyword اگر وجود ندارد
        try {
            $topicCols = $conn->query("SHOW COLUMNS FROM ai_article_topics")->fetchAll(PDO::FETCH_COLUMN);
            if (!in_array('primary_keyword', $topicCols)) {
                $conn->exec("ALTER TABLE ai_article_topics ADD COLUMN primary_keyword VARCHAR(200) NULL AFTER topic_title");
            }
        } catch (Exception $e) {}

        // =====================================================
        // جدول لاگ تولید مقالات AI
        // =====================================================
        $conn->exec("CREATE TABLE IF NOT EXISTS ai_generation_logs (
            id INT AUTO_INCREMENT PRIMARY KEY,
            article_id INT NULL,
            service_code VARCHAR(50) NOT NULL,
            topic VARCHAR(500) NOT NULL,
            api_key_index INT DEFAULT 0,
            tokens_input INT DEFAULT 0,
            tokens_output INT DEFAULT 0,
            generation_time_ms INT DEFAULT 0,
            status ENUM('started', 'content_generated', 'image_generated', 'validated', 'published', 'failed') DEFAULT 'started',
            validation_result VARCHAR(50) NULL,
            error_message TEXT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            completed_at TIMESTAMP NULL,
            INDEX idx_status (status),
            INDEX idx_created (created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci");

        // =====================================================
        // جدول تگ‌های مقالات
        // =====================================================
        $conn->exec("CREATE TABLE IF NOT EXISTS article_tags (
            id INT AUTO_INCREMENT PRIMARY KEY,
            article_id INT NOT NULL,
            tag VARCHAR(100) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_article (article_id),
            INDEX idx_tag (tag)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci");

        // =====================================================
        // جدول قفل‌های Workflow (برای جلوگیری از اجرای همزمان)
        // =====================================================
        $conn->exec("CREATE TABLE IF NOT EXISTS ai_workflow_locks (
            id INT AUTO_INCREMENT PRIMARY KEY,
            workflow_id VARCHAR(100) NOT NULL UNIQUE,
            process_id VARCHAR(100) NOT NULL,
            locked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            expires_at TIMESTAMP NULL,
            INDEX idx_workflow (workflow_id),
            INDEX idx_expires (expires_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci");

        // =====================================================
        // جدول وضعیت Workflow (برای ذخیره state و امکان resume)
        // =====================================================
        $conn->exec("CREATE TABLE IF NOT EXISTS ai_workflow_states (
            id INT AUTO_INCREMENT PRIMARY KEY,
            topic_id INT NULL,
            state VARCHAR(50) NOT NULL DEFAULT 'pending',
            data JSON NULL,
            error_message TEXT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_state (state),
            INDEX idx_topic (topic_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci");

        // =====================================================
        // درج موضوعات پیش‌فرض برای هر خدمت
        // =====================================================
        $topics = [
            'booth' => [
                'انواع غرفه‌های نمایشگاهی و کاربردهای آنها',
                'نکات طلایی طراحی غرفه نمایشگاهی جذاب',
                'هزینه ساخت غرفه نمایشگاهی در سال ۱۴۰۳',
                'مراحل ساخت غرفه از طراحی تا نصب',
                'اشتباهات رایج در طراحی غرفه نمایشگاهی',
                'متریال‌های مدرن در ساخت غرفه',
                'نورپردازی حرفه‌ای غرفه نمایشگاهی',
                'غرفه‌های ماژولار در مقابل غرفه‌های سفارشی',
                'تجهیزات ضروری یک غرفه نمایشگاهی',
                'چگونه در نمایشگاه بدرخشیم',
            ],
            'ads' => [
                'سایزهای استاندارد بنر تبلیغاتی',
                'انواع بیلبورد و کاربردهای آنها',
                'تابلوهای LED در مقابل تابلوهای استاتیک',
                'محاسبه ROI تبلیغات محیطی',
                'بهترین مکان‌ها برای نصب بیلبورد در همدان',
                'طراحی بنر تبلیغاتی تاثیرگذار',
                'تبلیغات محیطی در همدان',
                'مقایسه تبلیغات محیطی و دیجیتال',
                'قوانین نصب تابلو تبلیغاتی در ایران',
                'ترندهای تبلیغات محیطی در سال ۱۴۰۳',
            ],
            'tandis' => [
                'انواع تندیس و کاربردهای آنها در تبلیغات',
                'متریال‌های ساخت تندیس حرفه‌ای',
                'المان‌های شهری و تاثیر آنها بر برندینگ',
                'مراحل ساخت یک تندیس تبلیغاتی',
                'تندیس‌های فایبرگلاس در مقابل فلزی',
                'نگهداری و مراقبت از تندیس‌های محیطی',
                'طراحی المان برای برند و شرکت',
                'تندیس‌های ماسکوت شرکتی',
                'ایده‌های خلاقانه المان شهری',
                'استانداردهای ساخت تندیس در ایران',
            ],
            'event' => [
                'چک‌لیست برگزاری همایش موفق',
                'تجهیزات ضروری برگزاری رویداد',
                'مدیریت بودجه همایش و رویداد',
                'انواع چیدمان سالن همایش',
                'تکنولوژی در برگزاری رویداد مدرن',
                'بازاریابی رویداد و جذب مخاطب',
                'اشتباهات رایج در برگزاری همایش',
                'سنجش موفقیت رویداد و همایش',
                'همایش‌های هیبریدی در عصر دیجیتال',
                'انتخاب سالن مناسب همایش در همدان',
            ],
            'content' => [
                'اصول ساخت تیزر تبلیغاتی حرفه‌ای',
                'انواع ویدیوی تبلیغاتی و کاربردهای آنها',
                'تولید محتوا برای شبکه‌های اجتماعی',
                'تفاوت تیزر ۱۵ و ۳۰ ثانیه‌ای',
                'موشن گرافیک در مقابل فیلم واقعی',
                'سناریونویسی تیزر تبلیغاتی',
                'هزینه ساخت تیزر در سال ۱۴۰۳',
                'انتخاب موسیقی مناسب تیزر تبلیغاتی',
                'ویدیو مارکتینگ چیست و چرا مهم است',
                'تولید محتوای UGC برای برندها',
            ],
            'print' => [
                'تفاوت چاپ افست و دیجیتال',
                'سایزهای استاندارد کاغذ A0 تا A6',
                'انواع کاغذ و کاربردهای آنها در چاپ',
                'چاپ UV چیست و چه مزایایی دارد',
                'کیفیت DPI در چاپ حرفه‌ای',
                'انتخاب رنگ CMYK در مقابل RGB',
                'لمینت و سلفون در چاپ حرفه‌ای',
                'چاپ فلکسی و بنر با کیفیت',
                'چاپ روی انواع متریال مختلف',
                'طراحی فایل آماده چاپ حرفه‌ای',
            ],
            'idea' => [
                'مشاوره برندینگ چیست و چرا نیاز دارید',
                'چگونه ایده تبلیغاتی خلاق بسازیم',
                'استراتژی تبلیغات موثر برای کسب‌وکار',
                'تفکر خلاق در تبلیغات مدرن',
                'تحلیل رقبا در تبلیغات',
                'برنامه‌ریزی کمپین تبلیغاتی موفق',
                'خلاقیت در مقابل کپی‌کاری در تبلیغات',
                'روندهای تبلیغات در سال ۱۴۰۳',
                'هویت بصری برند چیست',
                'پیام برند و اهمیت آن',
            ],
        ];

        // درج موضوعات
        $insertStmt = $conn->prepare("INSERT IGNORE INTO ai_article_topics (service_code, topic_title, priority) VALUES (?, ?, ?)");
        foreach ($topics as $serviceCode => $serviceTopics) {
            foreach ($serviceTopics as $priority => $topic) {
                $insertStmt->execute([$serviceCode, $topic, $priority]);
            }
        }

        // درج مقالات نمونه
        $conn->exec("INSERT IGNORE INTO articles (title, slug, excerpt, content, meta_title, meta_description, status, reading_time, published_at) VALUES
            ('راهنمای جامع طراحی غرفه نمایشگاهی', 'booth-design-guide',
            'در این مقاله به بررسی اصول و نکات کلیدی طراحی غرفه نمایشگاهی موفق می‌پردازیم و راهکارهای عملی برای جلب توجه بازدیدکنندگان ارائه می‌دهیم.',
            '<h2>مقدمه</h2><p>طراحی غرفه نمایشگاهی یکی از مهم‌ترین عوامل موفقیت در نمایشگاه‌ها است. یک غرفه حرفه‌ای می‌تواند تفاوت بین موفقیت و شکست کسب‌وکار شما در نمایشگاه باشد.</p><h2>اصول طراحی غرفه</h2><p>برای طراحی یک غرفه موفق باید به نکات زیر توجه کنید:</p><ul><li><strong>جذابیت بصری:</strong> غرفه باید از فاصله دور هم قابل تشخیص و جذاب باشد.</li><li><strong>هویت برند:</strong> رنگ‌ها، لوگو و پیام‌های شما باید واضح و یکپارچه باشند.</li><li><strong>فضای تعامل:</strong> باید فضایی برای صحبت با مشتریان وجود داشته باشد.</li></ul><h2>نتیجه‌گیری</h2><p>با رعایت این نکات می‌توانید غرفه‌ای حرفه‌ای و تاثیرگذار داشته باشید.</p>',
            'راهنمای طراحی غرفه نمایشگاهی | طراحان باستان',
            'آموزش کامل طراحی غرفه نمایشگاهی با نکات حرفه‌ای از تیم طراحان باستان',
            'published', 5, NOW()),

            ('تاثیر تبلیغات محیطی بر برندینگ', 'environmental-advertising-impact',
            'تبلیغات محیطی یکی از قدرتمندترین ابزارهای برندسازی است که در این مقاله به بررسی تاثیر آن بر ذهن مخاطب می‌پردازیم.',
            '<h2>تبلیغات محیطی چیست؟</h2><p>تبلیغات محیطی شامل بیلبورد، بنر، استند و سایر رسانه‌های محیطی است که در فضای عمومی نصب می‌شوند و روزانه توسط هزاران نفر دیده می‌شوند.</p><h2>مزایای تبلیغات محیطی</h2><ul><li>دسترسی به مخاطبان گسترده</li><li>تاثیر بصری قوی</li><li>تکرار پیام به صورت مداوم</li><li>افزایش آگاهی از برند</li></ul><h2>انتخاب مکان مناسب</h2><p>انتخاب مکان مناسب برای تبلیغات محیطی بسیار مهم است. مکان‌های پرتردد مانند بزرگراه‌ها، میادین اصلی و مراکز خرید بهترین گزینه‌ها هستند.</p>',
            'تاثیر تبلیغات محیطی بر برند | طراحان باستان',
            'بررسی تاثیر تبلیغات محیطی بر قدرت برند و آگاهی مخاطبان',
            'published', 4, NOW()),

            ('نکات برگزاری یک همایش موفق', 'successful-event-tips',
            'برگزاری همایش نیازمند برنامه‌ریزی دقیق و توجه به جزئیات است. در این مقاله نکات کلیدی را بررسی می‌کنیم.',
            '<h2>برنامه‌ریزی اولیه</h2><p>قبل از هر چیز باید اهداف همایش را مشخص کنید. آیا هدف آموزش است؟ معرفی محصول؟ یا شبکه‌سازی؟</p><h2>انتخاب مکان</h2><p>مکان برگزاری باید متناسب با تعداد شرکت‌کنندگان و نوع برنامه باشد. به امکانات فنی، پارکینگ و دسترسی توجه کنید.</p><h2>تبلیغات و دعوت</h2><p>از کانال‌های مختلف مثل ایمیل، شبکه‌های اجتماعی و تماس تلفنی برای دعوت استفاده کنید.</p><h2>روز برگزاری</h2><p>همه چیز را از قبل چک کنید: صدا، تصویر، پذیرایی و برنامه زمانی.</p>',
            'نکات برگزاری همایش موفق | طراحان باستان',
            'راهنمای کامل برگزاری همایش و رویداد موفق از تیم طراحان باستان',
            'published', 6, NOW())
        ");
    }

    /**
     * Insert general settings
     */
    private function insertSettings()
    {
        $conn = Model::$conn;

        $settings = [
            // اطلاعات برند
            ['brand_name', 'طراحان باستان', 'brand'],
            ['brand_full_name', 'آرین طراحان باستان', 'brand'],
            ['brand_slogan', 'با ما غیرممکن وجود نداره', 'brand'],
            ['brand_location', 'همدان', 'brand'],
            ['brand_industry', 'تبلیغات و رویداد', 'brand'],

            // اطلاعات تماس
            ['phone_mobile', '09183333368', 'contact'],
            ['phone_landline', '08138284242', 'contact'],
            ['email', 'info@tarahanbastan.ir', 'contact'],
            ['address', 'همدان، بلوار شهید مدنی، ساختمان پارسیان، طبقه ۳', 'contact'],
            ['postal_code', '۱۲۳۴۵۶۷۸۹۰', 'contact'],

            // ساعات کاری
            ['working_days', 'شنبه تا پنجشنبه', 'hours'],
            ['working_hours', '۹ صبح الی ۶ عصر', 'hours'],
            ['support_hours', 'تا ساعت ۱۰ شب', 'hours'],

            // شبکه‌های اجتماعی
            ['instagram', 'https://instagram.com/tarahanbastan', 'social'],
            ['telegram', 'https://t.me/tarahanbastan', 'social'],
            ['whatsapp', 'https://wa.me/989183333368', 'social'],
            ['linkedin', '#', 'social'],

            // نقشه
            ['map_embed', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3280.169627766784!2d48.512345!3d34.798765!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMzTCsDQ3JzU1LjUiTiA0OMKwMzAnNDQuNCJF!5e0!3m2!1sen!2sir!4v1600000000000!5m2!1sen!2sir', 'map'],
            ['map_lat', '34.798765', 'map'],
            ['map_lng', '48.512345', 'map'],

            // SEO
            ['meta_title_suffix', ' | طراحان باستان', 'seo'],
            ['meta_keywords', 'طراحان باستان، تبلیغات، همدان، غرفه نمایشگاهی، تبلیغات محیطی', 'seo'],
        ];

        $stmt = $conn->prepare("INSERT IGNORE INTO settings (setting_key, setting_value, setting_group) VALUES (?, ?, ?)");

        foreach ($settings as $setting) {
            $stmt->execute($setting);
        }
    }

    /**
     * Insert stats data
     */
    private function insertStats()
    {
        $conn = Model::$conn;

        // SVG Icons
        $icons = [
            'check-circle' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>',
            'users' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>',
            'layers' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="12 2 2 7 12 12 22 7 12 2"/><polyline points="2 17 12 22 22 17"/><polyline points="2 12 12 17 22 12"/></svg>',
            'clock' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>',
            'star' => '<svg viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>',
            'heart' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>',
            'award' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="8" r="7"/><polyline points="8.21 13.89 7 23 12 20 17 23 15.79 13.88"/></svg>',
        ];

        // آمار صفحه اصلی
        $homeStats = [
            ['quality', '100', '%', null, 'تضمین کیفیت', $icons['check-circle'], 'home', 1],
            ['satisfaction', '100', '%', null, 'رضایت مشتری', $icons['users'], 'home', 2],
            ['projects', '500', null, '+', 'پروژه موفق', $icons['layers'], 'home', 3],
            ['experience', '10', null, '+', 'سال تجربه', $icons['clock'], 'home', 4],
        ];

        // آمار صفحه درباره ما
        $aboutStats = [
            ['experience', '10', null, '+', 'سال تجربه درخشان', $icons['clock'], 'about', 1],
            ['projects', '500', null, '+', 'پروژه موفق', $icons['layers'], 'about', 2],
            ['customers', '200', null, '+', 'مشتری وفادار', $icons['users'], 'about', 3],
            ['team', '25', null, '+', 'متخصص خلاق', $icons['star'], 'about', 4],
        ];

        $stmt = $conn->prepare("INSERT INTO stats (stat_key, stat_value, stat_suffix, stat_prefix, stat_label, stat_icon, page, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");

        foreach (array_merge($homeStats, $aboutStats) as $stat) {
            $stmt->execute($stat);
        }
    }

    /**
     * Insert services data
     */
    private function insertServices()
    {
        $conn = Model::$conn;

        $services = [
            [
                'booth', 'غرفه نمایشگاهی', 'طراحی و ساخت غرفه‌های حرفه‌ای', 'booth',
                'خالق فضاهای نمایشگاهی مدرن', '✨',
                'صحنه درخشش،', 'امپراطوری برند شما',
                'ما معماری را با مارکتینگ ترکیب می‌کنیم تا غرفه‌ای بسازیم که نه تنها دیده شود، بلکه در ذهن مخاطب حک شود. از کانسپت تا اجرا، با استانداردهای جهانی.',
                'مشاوره رایگان ساخت', '/contact', 'دیدن نمونه کارها', '#portfolio',
                'غرفه پتروشیمی خلیج فارس', 'غرفه‌ای ۱۵۰ متری با طراحی مینیمال و نورپردازی LED که در نمایشگاه نفت و گاز تهران توجه همه را جلب کرد.', 'public/images/portfolio/booth1.jpg',
                'نمایشگاه بعدی نزدیک است!', 'فرصت را از دست ندهید. همین حالا برای رزرو وقت طراحی اقدام کنید.', 'دریافت مشاوره و قیمت',
                1
            ],
            [
                'ads', 'تبلیغات محیطی', 'بنر، بیلبورد، بالابر و اسپیس', 'ads',
                'قدرتمندترین رسانه محیطی شهر', '🔥',
                'دیده شدن،', 'حق برند شماست!',
                'با بیلبوردها و سازه‌های تبلیغاتی طراحان باستان، در بهترین نقاط شهر بدرخشید. ما صدای برند شما را به گوش میلیون‌ها نفر می‌رسانیم.',
                'رزرو تابلو تبلیغاتی', '/contact', 'مشاهده پلن‌ها', '#services',
                'کمپین بیلبوردی بانک ملت', 'اجرای همزمان ۲۰ بیلبورد در سطح شهر همدان با طراحی یکپارچه و چاپ لارج فرمت.', 'public/images/portfolio/ads1.jpg',
                'آماده‌اید شهر را تسخیر کنید؟', 'با تبلیغات محیطی، برند شما را به همه نشان می‌دهیم.', 'همین حالا شروع کنید',
                2
            ],
            [
                'tandis', 'تندیس و المان', 'ساخت تندیس و المان‌های شهری', 'star',
                'نماد جاودانگی و افتخار', '🏆',
                'روایتگر داستان اقتدار', 'با زبان هنر و فلز',
                'طراحی و ساخت تخصصی تندیس‌های یادبود، نشان‌های افتخار و المان‌های شهری فاخر. جایی که هنر دست و دقت مهندسی برای خلق اثری ماندگار به هم می‌رسند.',
                'سفارش طراحی اختصاصی', '/contact', 'مشاهده نمونه آثار', '#portfolio',
                'تندیس ملی سیمرغ زرین همدان', 'این شاهکار هنری تلفیقی از اسطوره‌های باستانی و تکنیک‌های مدرن ریخته‌گری است.', 'public/images/hamedan2018.jpg',
                'ایده‌ای در ذهن دارید؟', 'همین حالا با مشاوران هنری ما تماس بگیرید تا ایده شما را به یک اثر ماندگار تبدیل کنیم.', 'شروع مشاوره رایگان',
                3
            ],
            [
                'event', 'برگزاری همایش', 'مدیریت و اجرای رویدادها', 'calendar',
                'Premium Events Production', '✨',
                'خلق حماسه‌ای ماندگار', 'در رویدادهای شما',
                'ما فقط همایش برگزار نمی‌کنیم؛ ما تجربه می‌سازیم. تیمی متخصص برای تبدیل ایده‌های جسورانه شما به واقعیتی خیره‌کننده، با دقتی وسواس‌گونه.',
                'شروع همکاری', '/contact', 'نمونه کارها', '#portfolio',
                'همایش بین‌المللی همدان ۲۰۱۸', 'پروژه‌ای که تنها ۴۵ روز زمان داشت و هیچ پیمانکاری ریسک آن را نمی‌پذیرفت. طراحان باستان با بسیج ۱۰۰ نفر نیروی متخصص، میزبان شایسته‌ای برای نمایندگان ۱۵ کشور جهان بود.', 'public/images/hamedan2018.jpg',
                'آماده درخشش هستید؟', 'زمان آن رسیده که برند خود را با شکوهی که شایسته آن است به نمایش بگذارید.', 'رزرو وقت مشاوره',
                4
            ],
            [
                'content', 'تیزر و محتوا', 'تولید محتوای ویدیویی', 'video',
                'استودیو تولید محتوا طراحان باستان', '🎬',
                'داستان برند شما،', 'روایت طلایی',
                'ما صدای شما را به تصویر می‌کشیم. ساخت تیزرهای تبلیغاتی، موشن گرافیک و عکاسی صنعتی با استانداردهای جهانی و نگاهی خلاقانه.',
                'شروع پروژه جدید', '/contact', 'نمونه کارها', '#portfolio',
                'مستند میراث کهن', 'این پروژه با هدف معرفی جاذبه‌های گردشگری استان همدان به سفارش سازمان میراث فرهنگی تولید شد.', 'public/images/hamedan2018.jpg',
                'وقت دیده شدن است!', 'همین حالا تماس بگیرید تا ایده‌های شما را به تصویر بکشیم. مشاوره کاملاً رایگان است.', 'شروع همکاری',
                5
            ],
            [
                'print', 'چاپ افست و دیجیتال', 'خدمات چاپ حرفه‌ای', 'printer',
                'چاپ آفست و دیجیتال حرفه‌ای', '🖨️',
                'کیفیتی که', 'لمس می‌شود',
                'ارائه خدمات جامع چاپ با بالاترین استاندارد رنگ و کاغذ. از کارت ویزیت شخصی تا تیراژهای میلیونی صنعتی.',
                'ثبت سفارش آنلاین', '/contact', '', '',
                'کاتالوگ صنعتی گروه مپنا', 'چاپ ۵۰۰۰ نسخه کاتالوگ ۴۸ صفحه‌ای با صحافی PUR و جلد سلفون مات.', 'public/images/portfolio/print1.jpg',
                'پروژه چاپی دارید؟', 'همین حالا استعلام قیمت بگیرید و کیفیت را تجربه کنید.', 'دریافت قیمت',
                6
            ],
            [
                'idea', 'ایده نو', 'مشاوره و ایده‌پردازی', 'lightbulb',
                'مشاوره تخصصی و ایده‌پردازی', '⚡',
                'هر ایده، آغاز یک', 'امپراطوری است',
                'ما اینجا نیستیم تا فقط به شما ایده بدهیم. ما اینجا هستیم تا ساختار ذهنی کسب‌وکار شما را بازطراحی کنیم. از جرقه اولیه تا فتح کامل بازار، با نقشه‌ای که با طلا ترسیم شده است.',
                'دریافت نقشه گنج', '/contact', '', '',
                null, null, null,
                'آماده فتح قله هستید؟', 'زمان منتظر تصمیم‌گیری نمی‌ماند. رقبا در حال حرکت هستند. همین امروز استراتژی پیروزی خود را دریافت کنید.', 'تماس: 0918-333-3368',
                7
            ],
        ];

        $stmt = $conn->prepare("INSERT INTO services (
            slug, title, short_description, icon,
            hero_badge, hero_badge_icon, hero_title_line1, hero_title_line2, hero_subtitle,
            cta_primary_text, cta_primary_link, cta_secondary_text, cta_secondary_link,
            featured_project_title, featured_project_description, featured_project_image,
            cta_final_title, cta_final_subtitle, cta_final_button,
            sort_order
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

        foreach ($services as $service) {
            $stmt->execute($service);
        }
    }

    /**
     * Insert home page specific data
     */
    private function insertHomePageData()
    {
        $conn = Model::$conn;

        // محتوای Hero صفحه اصلی
        $heroContent = [
            ['home', 'hero', 'badge_icon', 'star'],
            ['home', 'hero', 'badge', 'بیش از ۱۰ سال تجربه در همدان'],
            ['home', 'hero', 'title_line1', 'وقتی پروژه شما'],
            ['home', 'hero', 'title_line2', 'چالش‌برانگیز است'],
            ['home', 'hero', 'subtitle', 'ما کنار شما می‌ایستیم'],
            ['home', 'hero', 'description', 'از ایده تا اجرا، طراحان باستان همه چیز را برای موفقیت پروژه‌های تبلیغاتی و رویدادی شما انجام می‌دهد. چون برای ما، غیرممکن وجود نداره.'],
            ['home', 'hero', 'cta_primary_text', 'با ما تماس بگیرید'],
            ['home', 'hero', 'cta_primary_link', '/contact'],
            ['home', 'hero', 'cta_secondary_text', 'خدمات ما را ببینید'],
            ['home', 'hero', 'cta_secondary_link', '#services'],

            // پروژه ویژه
            ['home', 'featured', 'tag', 'پروژه ملی'],
            ['home', 'featured', 'title', 'همایش بین‌المللی همدان 2018 پایتخت تاریخی خاورمیانه'],
            ['home', 'featured', 'description', 'زمانی که تنها 45 روز فرصت بود و سه پیمانکار قبلی گفته بودند "غیرممکن است"، طراحان باستان پذیرفت. نتیجه؟ برگزاری موفق همایش بین‌المللی با حضور نمایندگان 15 کشور خاورمیانه.'],
            ['home', 'featured', 'image', 'public/images/hamedan2018.jpg'],
            ['home', 'featured', 'quote', 'انگار یک سال آماده‌سازی کردیم. این همراهی تیمی بود که گفت غیرممکن وجود نداره.'],
            ['home', 'featured', 'quote_author', 'مدیر اجرایی همایش'],

            // CTA نهایی
            ['home', 'cta', 'title', 'آماده برای شروع پروژه موفق بعدی؟'],
            ['home', 'cta', 'subtitle', 'فقط یک تماس تا موفقیت فاصله دارید'],
        ];

        $stmt = $conn->prepare("INSERT IGNORE INTO page_content (page, section, content_key, content_value) VALUES (?, ?, ?, ?)");
        foreach ($heroContent as $content) {
            $stmt->execute($content);
        }

        // SVG Icons
        $icons = [
            'shield-check' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><polyline points="9 12 11 14 15 10"/></svg>',
            'star' => '<svg viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>',
            'lightning' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>',
            'check-circle' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>',
            'phone' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>',
            'document' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/></svg>',
            'design' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 19l7-7 3 3-7 7-3-3z"/><path d="M18 13l-1.5-7.5L2 2l3.5 14.5L13 18l5-5z"/><path d="M2 2l7.586 7.586"/><circle cx="11" cy="11" r="2"/></svg>',
            'settings' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>',
            'truck' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="1" y="3" width="15" height="13"/><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/></svg>',
        ];

        // مزایا (Why Us)
        $benefits = [
            ['home', null, '۱', 'همه چیز زیر یک سقف', 'از ایده اولیه تا اجرای نهایی، دیگر نیازی به هماهنگی با چند پیمانکار ندارید.', $icons['shield-check'], 1],
            ['home', null, '۲', 'بیش از ۱۰ سال تجربه', 'انجام موفق صدها پروژه چالش‌برانگیز برای سازمان‌ها و برندهای بزرگ.', $icons['star'], 2],
            ['home', null, '۳', 'پروژه‌های فوری', 'وقتی زمان کم است، ما با شما می‌ایستیم و پروژه را به موقع تحویل می‌دهیم.', $icons['lightning'], 3],
            ['home', null, '۴', 'کیفیت تضمین‌شده', 'استفاده از بهترین مواد و تکنولوژی روز دنیا با QC مرحله‌ای.', $icons['check-circle'], 4],
        ];

        $stmt = $conn->prepare("INSERT INTO benefits (page, service_id, number, title, description, icon, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?)");
        foreach ($benefits as $benefit) {
            $stmt->execute($benefit);
        }

        // نظرات مشتریان صفحه اصلی
        $testimonials = [
            [null, 'home', 'تیم حرفه‌ای با تجربه بالا. از مشاوره اولیه تا اجرای نهایی، همه مراحل با دقت و وقت‌شناسی انجام شد. واقعاً توصیه می‌کنم.', 'محمد کریمی', 'مدیر روابط عمومی سازمان فرهنگی', 'م', 5, 1],
            [null, 'home', 'کیفیت کار و توجه به جزئیات فوق‌العاده بود. از طراحی غرفه تا نصب، همه چیز عالی پیش رفت. حتماً دوباره با این تیم کار می‌کنم.', 'زهرا رضایی', 'مدیرعامل شرکت صنایع غذایی سحر', 'ز', 5, 2],
            [null, 'home', 'طراحان باستان واقعاً همراه ما بود. پروژه‌ای که دیگران گفته بودند ۳ ماه طول می‌کشه رو در ۱.۵ ماه با کیفیت عالی تحویل دادند.', 'علی احمدی', 'مدیر بازاریابی شرکت تکنولوژی پارس', 'ع', 5, 3],
        ];

        $stmt = $conn->prepare("INSERT INTO testimonials (service_id, page, content, author_name, author_position, author_avatar, rating, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        foreach ($testimonials as $testimonial) {
            $stmt->execute($testimonial);
        }

        // مراحل کار صفحه اصلی
        $processSteps = [
            ['home', 1, 'تماس و مشاوره', 'تماس بگیرید، نیازتون رو بشنویم', $icons['phone'], 1],
            ['home', 2, 'تحلیل و پیشنهاد', 'تحلیل پروژه و ارائه پیشنهاد', $icons['document'], 2],
            ['home', 3, 'طراحی و تایید', 'طراحی و دریافت تایید شما', $icons['design'], 3],
            ['home', 4, 'تولید و اجرا', 'شروع تولید با QC مرحله‌ای', $icons['settings'], 4],
            ['home', 5, 'نصب و راه‌اندازی', 'نصب حرفه‌ای در محل', $icons['truck'], 5],
            ['home', 6, 'پشتیبانی', 'پشتیبانی بعد از تحویل', $icons['check-circle'], 6],
        ];

        $stmt = $conn->prepare("INSERT INTO process_steps (page, step_number, title, description, icon, sort_order) VALUES (?, ?, ?, ?, ?, ?)");
        foreach ($processSteps as $step) {
            $stmt->execute($step);
        }
    }

    /**
     * Insert about page data
     */
    private function insertAboutPageData()
    {
        $conn = Model::$conn;

        // محتوای صفحه درباره ما
        $aboutContent = [
            ['about', 'hero', 'badge_icon', '⭐'],
            ['about', 'hero', 'badge_text', 'بیش از یک دهه تجربه'],
            ['about', 'hero', 'title_line1', 'ما داستان شما را'],
            ['about', 'hero', 'title_highlight', 'جاودانه'],
            ['about', 'hero', 'title_line3', 'می‌کنیم'],
            ['about', 'hero', 'description', 'از سال ۱۳۹۲، طراحان باستان نه فقط یک شرکت تبلیغاتی، بلکه خالق هویت‌های ماندگار بوده است. ما معتقدیم هر کسب‌وکار، امپراطوری بالقوه‌ای است که نیاز به معماری درست دارد.'],

            // وعده برند
            ['about', 'manifesto', 'icon', '👑'],
            ['about', 'manifesto', 'title', 'وعده طراحان باستان'],
            ['about', 'manifesto', 'content', 'ما متعهدیم که با تمام توان در کنار شما باشیم. از اولین جلسه مشاوره تا تحویل نهایی پروژه، ما شریک رویاهای شما هستیم. موفقیت شما، تنها معیار سنجش موفقیت ماست.'],

            // CTA
            ['about', 'cta', 'title', 'آماده خلق یک شاهکار هستید؟'],
            ['about', 'cta', 'description', 'یک تماس ساده می‌تواند آغازگر بزرگترین تغییر در کسب‌وکار شما باشد.'],
        ];

        $stmt = $conn->prepare("INSERT IGNORE INTO page_content (page, section, content_key, content_value) VALUES (?, ?, ?, ?)");
        foreach ($aboutContent as $content) {
            $stmt->execute($content);
        }

        // تاریخچه شرکت
        $timeline = [
            ['1392', 'تولد یک رویا', 'با یک تیم کوچک اما قلبی بزرگ شروع کردیم. هدف ساده بود: تغییر استاندارد تبلیغات در همدان.', 1],
            ['1395', 'توسعه قلمرو', 'افتتاح دفتر مرکزی جدید و ورود به حوزه‌های چاپ دیجیتال و برندسازی تخصصی.', 2],
            ['1398', 'عصر دیجیتال', 'راه‌اندازی دپارتمان تخصصی دیجیتال مارکتینگ و تولید محتوای ویدیویی حرفه‌ای.', 3],
            ['1402', 'رهبری بازار', 'تبدیل شدن به بزرگترین هاب خلاقیت و تبلیغات در غرب کشور با بیش از ۵۰۰ پروژه موفق.', 4],
        ];

        $stmt = $conn->prepare("INSERT INTO timeline (year, title, description, sort_order) VALUES (?, ?, ?, ?)");
        foreach ($timeline as $item) {
            $stmt->execute($item);
        }

        // ارزش‌های شرکت
        $values = [
            ['کیفیت مطلق', 'ما سازش نمی‌کنیم. یا بهترین کار را ارائه می‌دهیم یا اصلا ارائه نمی‌دهیم.', 'check-circle', 1],
            ['تعهد زمانی', 'زمان شما، سرمایه شماست. ما به ثانیه‌ها احترام می‌گذاریم.', 'clock', 2],
            ['خلاقیت جسورانه', 'ما از راه‌های تکراری متنفریم. هر پروژه، یک اثر هنری منحصر‌به‌فرد است.', 'lightning', 3],
            ['پشتیبانی کامل', 'ما فقط مجری نیستیم، شریک تجاری شما هستیم تا لحظه رسیدن به هدف.', 'support', 4],
        ];

        $stmt = $conn->prepare("INSERT INTO company_values (title, description, icon, sort_order) VALUES (?, ?, ?, ?)");
        foreach ($values as $value) {
            $stmt->execute($value);
        }
    }

    /**
     * Insert contact page data
     */
    private function insertContactPageData()
    {
        $conn = Model::$conn;

        // محتوای صفحه تماس
        $contactContent = [
            ['contact', 'hero', 'badge', '⚡ Ready for Action'],
            ['contact', 'hero', 'title', 'ارتباط با قهرمانان'],
            ['contact', 'hero', 'title_highlight', 'قهرمانان'],
            ['contact', 'hero', 'subtitle', 'آغاز یک تحول بزرگ'],
            ['contact', 'hero', 'description', 'ما آماده‌ایم تا به سوالات شما پاسخ دهیم و ایده‌هایتان را به واقعیت تبدیل کنیم. همین حالا خطوط ارتباطی باز است.'],

            // فرم
            ['contact', 'form', 'title', 'شروع یک پروژه جدید'],
            ['contact', 'form', 'description', 'فرم زیر را پر کنید، ما عاشق خواندن پیام‌های شما هستیم.'],
            ['contact', 'form', 'submit_text', 'ارسال پیام با سرعت نور 🚀'],
        ];

        $stmt = $conn->prepare("INSERT IGNORE INTO page_content (page, section, content_key, content_value) VALUES (?, ?, ?, ?)");
        foreach ($contactContent as $content) {
            $stmt->execute($content);
        }

        // FAQ صفحه تماس
        $faqs = [
            ['contact', 'آیا مشاوره حضوری دارید؟', 'بله، دفتر ما در همدان میزبان شماست. البته برای احترام به زمان شما، پیشنهاد می‌کنیم قبل از تشریف‌فرمایی هماهنگ کنید.', 1],
            ['contact', 'ساعات کاری شرکت چگونه است؟', 'تیم ما از شنبه تا پنجشنبه، ساعت ۹ صبح الی ۶ عصر در دفتر حضور دارند. پشتیبانی آنلاین معمولاً تا ساعت ۱۰ شب فعال است.', 2],
            ['contact', 'پروژه‌ها چقدر زمان می‌برند؟', 'بسته به نوع پروژه متفاوت است. طراحی لوگو حدود ۱۰ روز، سایت ۲۰ روز و کمپین‌ها بسته به استراتژی متغیر هستند. در جلسه اول زمان دقیق اعلام می‌شود.', 3],
        ];

        $stmt = $conn->prepare("INSERT INTO faq (page, question, answer, sort_order) VALUES (?, ?, ?, ?)");
        foreach ($faqs as $faq) {
            $stmt->execute($faq);
        }
    }

    /**
     * Insert service pages data (features, process, faq, etc.)
     */
    private function insertServicePagesData()
    {
        $conn = Model::$conn;

        // گرفتن ID خدمات (slug => id)
        $stmt = $conn->query("SELECT slug, id FROM services");
        $services = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

        // =====================================================
        // غرفه نمایشگاهی (booth)
        // =====================================================
        $boothId = $services['booth'];

        // آمار
        $boothStats = [
            [$boothId, '+۳۰۰', 'غرفه اجرا شده', 1],
            [$boothId, '۱۲', 'سال تجربه تخصصی', 2],
            [$boothId, '۹۸٪', 'رضایت مشتریان', 3],
            [$boothId, 'A+', 'گرید نمایشگاهی', 4],
        ];
        $stmt = $conn->prepare("INSERT INTO service_stats (service_id, stat_value, stat_label, sort_order) VALUES (?, ?, ?, ?)");
        foreach ($boothStats as $stat) { $stmt->execute($stat); }

        // ویژگی‌ها
        $boothFeatures = [
            [$boothId, 'سرعت عمل بی‌نظیر', 'تحویل پروژه دقیقا سر وقت، بدون حتی یک ساعت تاخیر. ما ارزش زمان شما در نمایشگاه را می‌دانیم.', '⏱', 1],
            [$boothId, 'متریال درجه یک', 'استفاده از بهترین چوب، رنگ و سازه‌های مدولار که جلوه‌ای لوکس و حرفه‌ای به برند شما می‌دهد.', '💎', 2],
            [$boothId, 'خلاقیت در طراحی', 'تیم معماری ما طرح‌هایی خلق می‌کند که در شلوغی نمایشگاه، نگاه‌ها را به سمت شما می‌چرخاند.', '💡', 3],
        ];
        $stmt = $conn->prepare("INSERT INTO service_features (service_id, title, description, icon, sort_order) VALUES (?, ?, ?, ?, ?)");
        foreach ($boothFeatures as $feature) { $stmt->execute($feature); }

        // زیرخدمات
        $boothItems = [
            [$boothId, 'غرفه‌سازی چوبی (Custom)', 'اوج هنر و معماری. مناسب برای برندهایی که می‌خواهند متمایز و خاص باشند.', '🏗️', 'طراحی فرم‌های پیچیده و خاص|رنگ‌آمیزی و نورپردازی دکوراتیو|بدون محدودیت در اجرا', null, 1],
            [$boothId, 'سازه ماکسیما (Maxima)', 'مدرن، سریع و اقتصادی. ترکیبی هوشمندانه از سرعت اجرا و زیبایی بصری.', '🧩', 'نصب بسیار سریع|ساختار مدولار و منظم|قابلیت استفاده از لایت‌باکس', null, 2],
            [$boothId, 'تجهیزات نمایشگاهی', 'تامین صفر تا صد ملزومات. از مبلمان VIP تا نمایشگرهای LED غول‌پیکر.', '🛋️', 'اجاره مبلمان و میز کانتر|سیستم‌های صوتی و تصویری|کف‌سازی و گل‌آرایی', null, 3],
        ];
        $stmt = $conn->prepare("INSERT INTO service_items (service_id, title, description, icon, features, cta_text, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?)");
        foreach ($boothItems as $item) { $stmt->execute($item); }

        // مراحل کار
        $boothProcess = [
            [$boothId, 1, 'مشاوره و نیازسنجی', 'بررسی اهداف، بودجه و مساحت غرفه شما برای ارائه بهترین راهکار.', null, 1],
            [$boothId, 2, 'طراحی سه بعدی (3D)', 'ارائه طرح‌های اولیه و رندرهای واقع‌گرایانه برای تصور دقیق نهایی.', null, 2],
            [$boothId, 3, 'ساخت و پیش‌تولید', 'ساخت قطعات در کارخانه مجهز ما با دقت بالا و متریال مرغوب.', null, 3],
            [$boothId, 4, 'نصب و تحویل', 'مونتاژ نهایی در سالن نمایشگاه و تحویل به موقع قبل از افتتاحیه.', null, 4],
        ];
        $stmt = $conn->prepare("INSERT INTO service_process (service_id, step_number, title, description, icon, sort_order) VALUES (?, ?, ?, ?, ?, ?)");
        foreach ($boothProcess as $process) { $stmt->execute($process); }

        // سوالات متداول
        $boothFaq = [
            [$boothId, 'حداقل زمان مورد نیاز برای سفارش غرفه چقدر است؟', 'بهترین زمان ۲۰ روز قبل از نمایشگاه است، اما برای پروژه‌های فورس‌ماژور تا ۱۰ روز هم امکان‌پذیر است.', 1],
            [$boothId, 'آیا تجهیزات داخل غرفه هم تامین می‌کنید؟', 'بله، تمام تجهیزات شامل مبلمان، یخچال، آبسردکن، نمایشگر و... توسط ما تامین می‌شود.', 2],
            [$boothId, 'هزینه طراحی چقدر است؟', 'در صورت عقد قرارداد ساخت، هزینه طراحی کاملا رایگان خواهد بود.', 3],
        ];
        $stmt = $conn->prepare("INSERT INTO service_faq (service_id, question, answer, sort_order) VALUES (?, ?, ?, ?)");
        foreach ($boothFaq as $faq) { $stmt->execute($faq); }

        // نظرات مشتریان
        $boothTestimonials = [
            [$boothId, 'booth', 'سرعت عمل تیم طراحان باستان باورنکردنی بود. غرفه ما دقیقا طبق طرح سه بعدی و سر وقت تحویل داده شد.', 'مهندس رضایی', 'مدیر مارکتینگ گروه مپنا', null, 5, 1],
            [$boothId, 'booth', 'کیفیت ساخت و جزئیات اجرایی بسیار بالا بود. قطعا در نمایشگاه‌های بعدی هم با شما همکاری خواهیم کرد.', 'خانم کریمی', 'مدیر روابط عمومی کاله', null, 5, 2],
            [$boothId, 'booth', 'خلاقیت در طراحی باعث شد غرفه ما متمایزترین غرفه سالن باشد. ممنون از انرژی خوب تیم شما.', 'آقای محمدی', 'مدیر عامل استارتاپ فین‌تک', null, 5, 3],
        ];
        $stmt = $conn->prepare("INSERT INTO testimonials (service_id, page, content, author_name, author_position, author_avatar, rating, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        foreach ($boothTestimonials as $testimonial) { $stmt->execute($testimonial); }

        // نمونه کارها
        $boothPortfolio = [
            [$boothId, 'غرفه پتروشیمی خلیج فارس', 'نمایشگاه نفت و گاز ۱۴۰۲', null, 'public/images/portfolio/booth1.jpg', null, 1, 0],
            [$boothId, 'غرفه کرمان موتور', 'نمایشگاه خودرو اصفهان', null, 'public/images/portfolio/booth2.jpg', null, 2, 0],
            [$boothId, 'غرفه داروسازی عبیدی', 'نمایشگاه ایران فارما', null, 'public/images/portfolio/booth3.jpg', null, 3, 0],
        ];
        $stmt = $conn->prepare("INSERT INTO portfolio (service_id, title, subtitle, description, image, link, sort_order, is_featured) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        foreach ($boothPortfolio as $item) { $stmt->execute($item); }

        // =====================================================
        // تبلیغات محیطی (ads)
        // =====================================================
        $adsId = $services['ads'];

        // زیرخدمات
        $adsItems = [
            [$adsId, 'بیلبوردهای غول‌پیکر', 'تسلط بر بزرگراه‌ها و میادین اصلی شهر. سازه‌های عظیم با نورپردازی خیره‌کننده که اعتبار برند شما را تضمین می‌کنند.', '💎', null, 'استعلام قیمت', 1],
            [$adsId, 'استرابورد مدرن', 'تبلیغات سریع و چابک در قلب محلات و خیابان‌های پرتردد. بهترین گزینه برای کمپین‌های فروش و معرفی محصول جدید.', '🚀', null, 'مشاهده موقعیت‌ها', 2],
            [$adsId, 'چاپ لارج فرمت', 'کیفیت چاپ بی‌نظیر با دستگاه‌های صنعتی. رنگ‌های زنده و ماندگار که حتی زیر نور مستقیم خورشید هم نمی‌میرند.', '🎨', null, 'سفارش چاپ', 3],
        ];
        $stmt = $conn->prepare("INSERT INTO service_items (service_id, title, description, icon, features, cta_text, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?)");
        foreach ($adsItems as $item) { $stmt->execute($item); }

        // موقعیت‌ها
        $adsLocations = [
            [$adsId, 'میدان آرامگاه بوعلی', 1],
            [$adsId, 'چهارراه پژوهش', 2],
            [$adsId, 'بلوار ارم', 3],
            [$adsId, 'میدان بعثت', 4],
            [$adsId, 'خیابان سعیدیه', 5],
            [$adsId, 'ورودی تهران', 6],
            [$adsId, 'میدان امام', 7],
            [$adsId, 'شهرک مدنی', 8],
            [$adsId, 'بلوار چمران', 9],
        ];
        $stmt = $conn->prepare("INSERT INTO locations (service_id, name, sort_order) VALUES (?, ?, ?)");
        foreach ($adsLocations as $location) { $stmt->execute($location); }

        // =====================================================
        // تندیس و المان (tandis)
        // =====================================================
        $tandisId = $services['tandis'];

        // آمار
        $tandisStats = [
            [$tandisId, '+۱۵۰۰', 'تندیس ساخته شده', 1],
            [$tandisId, '۱۵', 'سال تجربه هنری', 2],
            [$tandisId, '۱۰۰٪', 'دست‌ساز و یونیک', 3],
            [$tandisId, '۵۰+', 'جشنواره ملی', 4],
        ];
        $stmt = $conn->prepare("INSERT INTO service_stats (service_id, stat_value, stat_label, sort_order) VALUES (?, ?, ?, ?)");
        foreach ($tandisStats as $stat) { $stmt->execute($stat); }

        // ویژگی‌ها
        $tandisFeatures = [
            [$tandisId, 'متریال خالص و ارزشمند', 'استفاده از برنج، برنز و آلیاژهای خاص که با گذشت زمان، ارزش و زیبایی خود را حفظ می‌کنند.', '💎', 1],
            [$tandisId, 'طراحی انحصاری', 'هر تندیس یک اثر هنری منحصر به فرد است که توسط اساتید مجسمه‌سازی طراحی می‌شود.', '🎨', 2],
            [$tandisId, 'دقت میکرونی', 'تلفیق هنر دست با تکنولوژی‌های نوین مثل برش لیزر و پرینت سه بعدی.', '⚙️', 3],
        ];
        $stmt = $conn->prepare("INSERT INTO service_features (service_id, title, description, icon, sort_order) VALUES (?, ?, ?, ?, ?)");
        foreach ($tandisFeatures as $feature) { $stmt->execute($feature); }

        // زیرخدمات
        $tandisItems = [
            [$tandisId, 'تندیس‌های جشنواره‌ای', 'طراحی و ساخت تندیس‌های زرین و کریستال برای رویدادهای ملی و همایش‌های بین‌المللی.', 'star', null, null, 1],
            [$tandisId, 'المان‌های شهری', 'ساخت سازه‌های حجمی و المان‌های میدانی عظیم که هویت بصری شهر را دگرگون می‌کنند.', 'building', null, null, 2],
            [$tandisId, 'سردیس و مجسمه', 'شبیه‌سازی دقیق چهره مشاهیر به روش رئال و انتزاعی با ماندگاری چند صد ساله.', 'user', null, null, 3],
        ];
        $stmt = $conn->prepare("INSERT INTO service_items (service_id, title, description, icon, features, cta_text, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?)");
        foreach ($tandisItems as $item) { $stmt->execute($item); }

        // مراحل کار
        $tandisProcess = [
            [$tandisId, 1, 'ایده‌پردازی و اسکچ', 'تبدیل مفاهیم ذهنی شما به طرح‌های دستی و هنری برای رسیدن به فرم ایده‌آل.', null, 1],
            [$tandisId, 2, 'مدل‌سازی سه بعدی', 'ساخت مدل کامپیوتری دقیق برای بررسی زوایا و جزئیات قبل از شروع ساخت فیزیکی.', null, 2],
            [$tandisId, 3, 'قالب‌گیری و ریخته‌گری', 'تولید قطعه با متریال‌های اصلی (برنز، برنج، رزین) با بالاترین کیفیت پرداخت.', null, 3],
            [$tandisId, 4, 'پتینه و بسته‌بندی', 'اعمال پوشش‌های محافظ و پتینه‌های هنری و تحویل در بسته‌بندی‌های نفیس چوبی.', null, 4],
        ];
        $stmt = $conn->prepare("INSERT INTO service_process (service_id, step_number, title, description, icon, sort_order) VALUES (?, ?, ?, ?, ?, ?)");
        foreach ($tandisProcess as $process) { $stmt->execute($process); }

        // سوالات متداول
        $tandisFaq = [
            [$tandisId, 'حداقل تیراژ سفارش تندیس چقدر است؟', 'برای تندیس‌های اختصاصی ریخته‌گری، حداقل سفارش ۱۰ عدد است. اما برای کارهای تک نسخه (مثل سردیس) سفارش تکی هم پذیرفته می‌شود.', 1],
            [$tandisId, 'زمان تحویل پروژه چقدر است؟', 'بسته به پیچیدگی طرح و تیراژ، بین ۱۰ تا ۴۵ روز کاری زمان می‌برد. پروژه‌های المان شهری زمان بیشتری نیاز دارند.', 2],
            [$tandisId, 'آیا امکان ساخت نمونه اولیه وجود دارد؟', 'بله، قبل از تولید انبوه، یک نمونه اولیه (پروتوتایپ) ساخته می‌شود و پس از تایید شما، تولید نهایی آغاز می‌گردد.', 3],
            [$tandisId, 'از چه متریال‌هایی استفاده می‌کنید؟', 'ما در ساخت تندیس از برنز، برنج، زاماک، پلکسی‌گلس، چوب‌های نفیس، سنگ و رزین اپوکسی استفاده می‌کنیم.', 4],
        ];
        $stmt = $conn->prepare("INSERT INTO service_faq (service_id, question, answer, sort_order) VALUES (?, ?, ?, ?)");
        foreach ($tandisFaq as $faq) { $stmt->execute($faq); }

        // نظرات مشتریان
        $tandisTestimonials = [
            [$tandisId, 'tandis', 'ظرافت تندیس‌های جشنواره سینما حقیقت فراتر از انتظار ما بود. جزئیات صورتک‌ها حیرت‌انگیز است.', 'استاد انتظامی', 'دبیر جشنواره', null, 5, 1],
            [$tandisId, 'tandis', 'المان میدان اصلی شهر که توسط تیم شما ساخته شد، به نماد جدید شهر ما تبدیل شده است.', 'دکتر شهبازی', 'شهردار منطقه ۱', null, 5, 2],
            [$tandisId, 'tandis', 'کیفیت متریال و سنگینی تندیس، حس بسیار ارزشمندی به برندگان جشنواره ما منتقل کرد.', 'مهندس صادقی', 'مدیر روابط عمومی', null, 5, 3],
        ];
        $stmt = $conn->prepare("INSERT INTO testimonials (service_id, page, content, author_name, author_position, author_avatar, rating, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        foreach ($tandisTestimonials as $testimonial) { $stmt->execute($testimonial); }

        // =====================================================
        // برگزاری همایش (event)
        // =====================================================
        $eventId = $services['event'];

        // ویژگی‌ها
        $eventFeatures = [
            [$eventId, 'مدیریت یکپارچه و چابک', 'حذف تمام واسطه‌ها. ما تیم طراحی، تیم ساخت، تیم فنی و تیم تشریفات را زیر یک سقف داریم.', '🚀', 1],
            [$eventId, 'متریال لوکس', 'استفاده از سازه‌های اسپیس‌فریم مهندسی شده و متریال‌های دکوراتیو وارداتی.', '💎', 2],
            [$eventId, 'خلاقیت بی‌پایان', 'طراحی‌هایی که کپی نیستند. هر رویداد هویت بصری منحصر به فرد خود را دارد.', '💡', 3],
            [$eventId, 'تضمین زمان تحویل', 'در صنعت برگزاری رویداد، یک دقیقه تاخیر یعنی فاجعه. ما با قرارداد رسمی، تحویل دقیق را تضمین می‌کنیم.', '🎯', 4],
        ];
        $stmt = $conn->prepare("INSERT INTO service_features (service_id, title, description, icon, sort_order) VALUES (?, ?, ?, ?, ?)");
        foreach ($eventFeatures as $feature) { $stmt->execute($feature); }

        // زیرخدمات
        $eventItems = [
            [$eventId, 'برگزاری همایش', 'از رزرو سالن و دعوت سخنرانان تا پذیرایی و صدور گواهی‌نامه. مدیریت صفر تا صد.', '🏛️', null, 'جزئیات بیشتر', 1],
            [$eventId, 'غرفه‌سازی', 'طراحی و ساخت غرفه‌های نمایشگاهی خاص با متریال چوب، فلز و شیشه.', '🏗️', null, 'مشاهده نمونه‌ها', 2],
            [$eventId, 'تولید مدیا', 'تیم فیلمبرداری حرفه‌ای، ساخت تیزر، پخش زنده و پوشش خبری رویداد.', '🎬', null, 'تجهیزات ما', 3],
        ];
        $stmt = $conn->prepare("INSERT INTO service_items (service_id, title, description, icon, features, cta_text, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?)");
        foreach ($eventItems as $item) { $stmt->execute($item); }

        // مراحل کار
        $eventProcess = [
            [$eventId, 1, 'استراتژی و سناریو', 'تعریف دقیق اهداف همایش و نوشتن سناریوی اجرایی لحظه به لحظه.', null, 1],
            [$eventId, 2, 'طراحی هویت بصری', 'طراحی لوگو، پوستر، دعوت‌نامه و دکوراسیون محیطی هماهنگ با برند.', null, 2],
            [$eventId, 3, 'اجرا و لجستیک', 'ساخت دکور، نصب تجهیزات صوتی تصویری و چیدمان سالن.', null, 3],
            [$eventId, 4, 'مدیریت روز رویداد', 'کارگردانی صحنه، مدیریت کنداکتور و پذیرایی از مهمانان.', null, 4],
        ];
        $stmt = $conn->prepare("INSERT INTO service_process (service_id, step_number, title, description, icon, sort_order) VALUES (?, ?, ?, ?, ?, ?)");
        foreach ($eventProcess as $process) { $stmt->execute($process); }

        // سوالات متداول
        $eventFaq = [
            [$eventId, 'هزینه برگزاری همایش چقدر است؟', 'هزینه بسته به تعداد مهمانان، محل برگزاری، نوع پذیرایی و تجهیزات مورد نیاز متغیر است. ما در جلسه مشاوره اولیه، بودجه شما را بررسی و بهترین پلن را پیشنهاد می‌دهیم.', 1],
            [$eventId, 'آیا خدمات شما شامل شهرستان‌ها هم می‌شود؟', 'بله، تیم اجرایی ما آمادگی سفر و اجرای پروژه در تمام نقاط کشور را دارد. هزینه‌های لجستیک به صورت جداگانه محاسبه می‌شود.', 2],
            [$eventId, 'حداقل زمان مورد نیاز برای هماهنگی چقدر است؟', 'برای همایش‌های کوچک حداقل ۲ هفته و برای همایش‌های بزرگ حداقل ۲ ماه زمان پیشنهاد می‌شود تا کیفیت اجرا تضمین گردد.', 3],
        ];
        $stmt = $conn->prepare("INSERT INTO service_faq (service_id, question, answer, sort_order) VALUES (?, ?, ?, ?)");
        foreach ($eventFaq as $faq) { $stmt->execute($faq); }

        // =====================================================
        // تیزر و محتوا (content)
        // =====================================================
        $contentId = $services['content'];

        // آمار
        $contentStats = [
            [$contentId, '+۵۰۰', 'دقیقه تیزر تولید شده', 1],
            [$contentId, '4K', 'کیفیت ضبط تصاویر', 2],
            [$contentId, '۱۰۰٪', 'تجهیزات اختصاصی', 3],
            [$contentId, '+۵۰', 'برند همکار', 4],
        ];
        $stmt = $conn->prepare("INSERT INTO service_stats (service_id, stat_value, stat_label, sort_order) VALUES (?, ?, ?, ?)");
        foreach ($contentStats as $stat) { $stmt->execute($stat); }

        // زیرخدمات
        $contentItems = [
            [$contentId, 'تیزر تبلیغاتی', 'سناریو‌نویسی خلاقانه و ساخت ویدیوهای تبلیغاتی با اثرگذاری بالا برای شبکه‌های اجتماعی و تلویزیون.', 'video', 'رئال|معرفی محصول', null, 1],
            [$contentId, 'موشن گرافیک', 'انیمیشن‌های گرافیکی جذاب برای توضیح فرآیندها یا معرفی خدمات پیچیده به زبانی ساده.', 'motion', 'دو بعدی|لوگو موشن', null, 2],
            [$contentId, 'عکاسی صنعتی', 'عکاسی حرفه‌ای از محصولات، خط تولید و فضای کسب‌وکار شما با نورپردازی استودیویی.', 'camera', '360 درجه|کاتالوگ', null, 3],
        ];
        $stmt = $conn->prepare("INSERT INTO service_items (service_id, title, description, icon, features, cta_text, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?)");
        foreach ($contentItems as $item) { $stmt->execute($item); }

        // مراحل کار
        $contentProcess = [
            [$contentId, 1, 'سناریو و ایده', 'نگارش متن و استوری‌بورد دقیق بر اساس هدف تبلیغات.', '💡', 1],
            [$contentId, 2, 'تصویربرداری', 'ضبط تصاویر با دوربین‌های سینمایی و تجهیزات نورپردازی.', '🎥', 2],
            [$contentId, 3, 'تدوین و صدا', 'مونتاژ، اصلاح رنگ، صداگذاری و افزودن جلوه‌های ویژه.', '💻', 3],
            [$contentId, 4, 'خروجی نهایی', 'تحویل فایل با فرمت‌های استاندارد وب و تلویزیون.', '🚀', 4],
        ];
        $stmt = $conn->prepare("INSERT INTO service_process (service_id, step_number, title, description, icon, sort_order) VALUES (?, ?, ?, ?, ?, ?)");
        foreach ($contentProcess as $process) { $stmt->execute($process); }

        // تجهیزات
        $contentEquipment = [
            [$contentId, 'Sony Alpha 7S III', 1],
            [$contentId, 'DJI Mavic 2 Pro', 2],
            [$contentId, 'Ronin RS2 Gimbal', 3],
            [$contentId, 'Godox Lighting', 4],
            [$contentId, 'Sennheiser Audio', 5],
            [$contentId, 'DaVinci Resolve', 6],
        ];
        $stmt = $conn->prepare("INSERT INTO equipment (service_id, name, sort_order) VALUES (?, ?, ?)");
        foreach ($contentEquipment as $equipment) { $stmt->execute($equipment); }

        // سوالات متداول
        $contentFaq = [
            [$contentId, 'هزینه ساخت تیزر تبلیغاتی چقدر است؟', 'هزینه بسته به سناریو، تعداد روزهای تصویربرداری، تجهیزات مورد نیاز و وجود بازیگر متغیر است. پس از مشاوره اولیه، پیش‌فاکتور دقیق صادر می‌شود.', 1],
            [$contentId, 'زمان تحویل پروژه چقدر طول می‌کشد؟', 'پروژه‌های ساده مثل عکاسی یا موشن‌گرافیک کوتاه معمولاً ۳ تا ۷ روز کاری، و پروژه‌های تصویربرداری سنگین بین ۱۰ تا ۲۰ روز زمان نیاز دارند.', 2],
            [$contentId, 'آیا سناریو را هم شما می‌نویسید؟', 'بله، تیم ایده‌پردازی ما بر اساس نیاز شما و تحلیل رقبا، چندین سناریوی پیشنهادی را ارائه می‌دهد تا بهترین گزینه را انتخاب کنید.', 3],
        ];
        $stmt = $conn->prepare("INSERT INTO service_faq (service_id, question, answer, sort_order) VALUES (?, ?, ?, ?)");
        foreach ($contentFaq as $faq) { $stmt->execute($faq); }

        // نظرات مشتریان
        $contentTestimonials = [
            [$contentId, 'content', 'تیزری که برای ما ساختید بازخورد فوق‌العاده‌ای در اینستاگرام داشت. ممنون از خلاقیت تیم خوبتون.', 'آقای حسینی', 'مدیر عامل شرکت تکنو', null, 5, 1],
            [$contentId, 'content', 'کیفیت عکاسی صنعتی از محصولات ما دقیقاً همون چیزی بود که برای کاتالوگ جدید نیاز داشتیم.', 'خانم راد', 'مدیر مارکتینگ', null, 5, 2],
            [$contentId, 'content', 'صبر و حوصله شما در پروسه تدوین و اعمال اصلاحات واقعاً جای تقدیر داره. نتیجه عالی شد.', 'مهندس نوری', 'سازمان میراث فرهنگی', null, 5, 3],
        ];
        $stmt = $conn->prepare("INSERT INTO testimonials (service_id, page, content, author_name, author_position, author_avatar, rating, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        foreach ($contentTestimonials as $testimonial) { $stmt->execute($testimonial); }

        // =====================================================
        // چاپ (print)
        // =====================================================
        $printId = $services['print'];

        // ویژگی‌ها
        $printFeatures = [
            [$printId, 'کیفیت تضمینی', 'استفاده از ماشین‌های چاپ هایدلبرگ آلمان برای دقت رنگ بی‌نظیر.', '💎', 1],
            [$printId, 'تحویل فوری', 'سرویس چاپ دیجیتال ۲۴ ساعته برای پروژه‌های اضطراری شما.', '⚡', 2],
            [$printId, 'تنوع کاغذ', 'بیش از ۵۰ نوع کاغذ گلاسه، تحریر، کرافت و فانتزی.', '📄', 3],
            [$printId, 'قیمت رقابتی', 'حذف واسطه‌ها و چاپ مستقیم در چاپخانه اختصاصی ما.', '💰', 4],
        ];
        $stmt = $conn->prepare("INSERT INTO service_features (service_id, title, description, icon, sort_order) VALUES (?, ?, ?, ?, ?)");
        foreach ($printFeatures as $feature) { $stmt->execute($feature); }

        // زیرخدمات
        $printItems = [
            [$printId, 'چاپ آفست', 'بهترین گزینه برای تیراژ بالا و کیفیت عالی.', '🖨️', 'کاتالوگ و بروشور|ست اداری و پاکت|پوستر و تراکت', null, 1],
            [$printId, 'چاپ دیجیتال', 'مناسب برای تیراژ کم و سرعت بالا.', '💻', 'کارت ویزیت فوری|منو رستوران|لیبل و استیکر', null, 2],
            [$printId, 'بسته‌بندی', 'طراحی و تولید جعبه‌های محصول اختصاصی.', '📦', 'جعبه مقوایی|هارد باکس|ساک دستی', null, 3],
        ];
        $stmt = $conn->prepare("INSERT INTO service_items (service_id, title, description, icon, features, cta_text, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?)");
        foreach ($printItems as $item) { $stmt->execute($item); }

        // مراحل کار
        $printProcess = [
            [$printId, 1, 'سفارش', 'ثبت جزئیات و ارسال فایل', null, 1],
            [$printId, 2, 'کنترل فایل', 'بررسی فنی و اصلاح رنگ', null, 2],
            [$printId, 3, 'لیتوگرافی', 'تهیه زینک (برای آفست)', null, 3],
            [$printId, 4, 'چاپ', 'اجرا با نظارت ناظر چاپ', null, 4],
            [$printId, 5, 'تکمیل', 'برش، صحافی و تحویل', null, 5],
        ];
        $stmt = $conn->prepare("INSERT INTO service_process (service_id, step_number, title, description, icon, sort_order) VALUES (?, ?, ?, ?, ?, ?)");
        foreach ($printProcess as $process) { $stmt->execute($process); }

        // انواع کاغذ
        $paperTypes = [
            ['گلاسه', 'براق و صیقلی، عالی برای عکس', 1],
            ['تحریر', 'مات و معمولی، مناسب نوشتن', 2],
            ['کتان', 'بافت‌دار و کلاسیک', 3],
            ['کرافت', 'قهوه‌ای و نوستالژیک', 4],
            ['ایندربرد', 'ضخیم، مناسب جعبه‌سازی', 5],
        ];
        $stmt = $conn->prepare("INSERT INTO paper_types (name, description, sort_order) VALUES (?, ?, ?)");
        foreach ($paperTypes as $paper) { $stmt->execute($paper); }

        // سوالات متداول
        $printFaq = [
            [$printId, 'فایل چاپی باید چه فرمتی داشته باشد؟', 'بهترین فرمت PDF با استاندارد رنگی CMYK و رزولوشن 300dpi است. حاشیه امن برش (Bleed) را فراموش نکنید.', 1],
            [$printId, 'تفاوت لمینت و سلفون چیست؟', 'لمینت ضخامت بیشتری دارد و استحکام کار را بالا می‌برد، اما سلفون نازک‌تر و ظریف‌تر است و برای کارهایی که باید تا شوند مناسب‌تر است.', 2],
            [$printId, 'حداقل تیراژ سفارش چقدر است؟', 'در چاپ دیجیتال حتی ۱ عدد هم امکان‌پذیر است. در چاپ افست معمولاً حداقل تیراژ ۱۰۰۰ عدد می‌باشد تا مقرون به صرفه باشد.', 3],
        ];
        $stmt = $conn->prepare("INSERT INTO service_faq (service_id, question, answer, sort_order) VALUES (?, ?, ?, ?)");
        foreach ($printFaq as $faq) { $stmt->execute($faq); }

        // =====================================================
        // ایده نو (idea)
        // =====================================================
        $ideaId = $services['idea'];

        // ویژگی‌ها
        $ideaFeatures = [
            [$ideaId, 'مهندسی خلاقیت', 'ما خلاقیت را به شانس واگذار نمی‌کنیم. ما از متدولوژی‌های مهندسی برای خلق ایده‌های پولساز استفاده می‌کنیم.', '🧠', 1],
            [$ideaId, 'تمرکز بر اجرا', 'زیباترین ایده اگر اجرا نشود، زباله است. ما ایده‌هایی می‌دهیم که با بودجه و امکانات شما همخوانی دارد.', '🎯', 2],
            [$ideaId, 'سودآوری قطعی', 'هدف نهایی، افزایش اعداد در حساب بانکی شماست. استراتژی ما مستقیماً روی ROI تمرکز دارد.', '💰', 3],
        ];
        $stmt = $conn->prepare("INSERT INTO service_features (service_id, title, description, icon, sort_order) VALUES (?, ?, ?, ?, ?)");
        foreach ($ideaFeatures as $feature) { $stmt->execute($feature); }

        // مراحل کار
        $ideaProcess = [
            [$ideaId, 1, 'کشف و استخراج', 'ما مثل باستان‌شناس، لایه‌های پنهان کسب‌وکار شما را کنار می‌زنیم تا گنجینه واقعی (مزیت رقابتی) را پیدا کنیم.', null, 1],
            [$ideaId, 2, 'رصد میدان نبرد', 'رقبا چه می‌کنند؟ مشتریان چه می‌خواهند؟ ما با داده‌های دقیق بازار برمی‌گردیم، نه با حدس و گمان.', null, 2],
            [$ideaId, 3, 'کیمیاگری (اتاق فکر)', 'ترکیب هنر و بیزنس. اینجا ایده‌های خام صیقل می‌خورند، چکش‌کاری می‌شوند و به شمش طلا تبدیل می‌شوند.', null, 3],
            [$ideaId, 4, 'طراحی نقشه گنج', 'یک برنامه عملیاتی (Action Plan) دقیق دریافت می‌کنید. کی، کجا، چطور و با چه بودجه‌ای باید حمله کنید.', null, 4],
            [$ideaId, 5, 'فتح پرچم', 'ما در زمان اجرا کنارتان هستیم. نظارت می‌کنیم تا استراتژی دقیقاً مثل نقشه پیاده شود و جشن پیروزی را بگیریم.', null, 5],
        ];
        $stmt = $conn->prepare("INSERT INTO service_process (service_id, step_number, title, description, icon, sort_order) VALUES (?, ?, ?, ?, ?, ?)");
        foreach ($ideaProcess as $process) { $stmt->execute($process); }

        // پکیج‌ها
        $ideaPackages = [
            [$ideaId, 'مشاوره ساعتی', 'VIP Session', 'برای حل یک چالش خاص و فوری', 'رزرو جلسه', 0, 1],
            [$ideaId, 'پکیج استراتژی', 'Full Blueprint', 'نقشه راه کامل + ۳ ایده خلاقانه + بودجه‌بندی', 'شروع همکاری', 1, 2],
            [$ideaId, 'رهبری بازار', 'Partner', 'ما دپارتمان مارکتینگ شما می‌شویم (صفر تا صد)', 'درخواست پروپوزال', 0, 3],
        ];
        $stmt = $conn->prepare("INSERT INTO packages (service_id, title, subtitle, description, cta_text, is_popular, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?)");
        foreach ($ideaPackages as $package) { $stmt->execute($package); }

        // سوالات متداول
        $ideaFaq = [
            [$ideaId, 'هزینه این سرمایه‌گذاری چقدر است؟', 'هزینه بر اساس مقیاس پروژه و اهداف شما متغیر است. اما نگران نباشید، جلسه اول نیازسنجی کاملاً رایگان است تا ما ابعاد کار را بررسی کنیم و بهترین پیشنهاد را بدهیم.', 1],
            [$ideaId, 'آیا تضمینی برای موفقیت وجود دارد؟', 'در دنیای بیزنس هیچ تضمین ۱۰۰ درصدی وجود ندارد، اما ما تضمین می‌کنیم که تمام استراتژی‌ها بر اساس داده‌های واقعی و تجربه ۱۰ ساله ما طراحی شوند که ریسک را به حداقل و شانس پیروزی را به حداکثر می‌رساند.', 2],
            [$ideaId, 'زمان‌بندی اجرا چگونه است؟', 'ما طرفدار "پیروزی‌های سریع" (Quick Wins) هستیم. معمولاً در ماه اول نتایج اولیه را می‌بینید، اما پروژه‌های برندینگ و تغییر پوزیشنینگ بین ۳ تا ۶ ماه زمان نیاز دارند.', 3],
        ];
        $stmt = $conn->prepare("INSERT INTO service_faq (service_id, question, answer, sort_order) VALUES (?, ?, ?, ?)");
        foreach ($ideaFaq as $faq) { $stmt->execute($faq); }
    }
}
