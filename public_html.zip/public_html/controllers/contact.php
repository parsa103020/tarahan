<?php

class contact extends Controller
{
    function __construct()
    {
        parent::__construct();
        $this->model('contact');
    }

    /**
     * Contact Us Main Page
     * Displays contact form, map, contact information
     */
    function index()
    {
        // Get all contact page data from model
        $contactData = $this->model->getAllContactData();

        $data = [
            'pageTitle' => 'تماس با ما | طراحان باستان',
            'pageDescription' => 'با تیم طراحان باستان در ارتباط باشید. راه‌های ارتباطی، آدرس دفتر و شماره تماس',
            'pageCSS' => ['contact'],
            'pageJS' => ['contact'],
            'showFooterCTA' => false,

            // Dynamic data from database
            'hero' => $contactData['hero'],
            'form' => $contactData['form'],
            'info' => $contactData['info'],
            'faq' => $contactData['faq'],
        ];

        $this->view('contact/index', $data);
    }

    /**
     * Handle contact form submission (AJAX)
     */
    function submit()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $result = $this->model->saveContactMessage($_POST);

            if ($result === true) {
                echo json_encode([
                    'success' => true,
                    'message' => 'پیام شما با موفقیت ارسال شد. به زودی با شما تماس خواهیم گرفت.'
                ]);
            } else {
                echo json_encode([
                    'success' => false,
                    'message' => $result
                ]);
            }
        }
    }
}
