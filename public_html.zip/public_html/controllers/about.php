<?php

class about extends Controller
{
    function __construct()
    {
        parent::__construct();
        $this->model('about');
    }

    /**
     * About Us Main Page
     * Displays company information, team, history, values
     */
    function index()
    {
        // Get all about page data from model
        $aboutData = $this->model->getAllAboutData();

        $data = [
            'pageTitle' => 'درباره ما | طراحان باستان',
            'pageDescription' => 'آشنایی با تیم طراحان باستان، تاریخچه، ارزش‌ها و دستاوردهای ما در زمینه خدمات تبلیغاتی و رویدادی',
            'pageCSS' => ['about'],
            'pageJS' => ['about'],
            'showFooterCTA' => true,

            // Dynamic data from database
            'hero' => $aboutData['hero'],
            'stats' => $aboutData['stats'],
            'timeline' => $aboutData['timeline'],
            'values' => $aboutData['values'],
            'manifesto' => $aboutData['manifesto'],
            'cta' => $aboutData['cta'],
        ];

        $this->view('about/index', $data);
    }
}
