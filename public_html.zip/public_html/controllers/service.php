<?php

class service extends Controller
{
    function __construct()
    {
        parent::__construct();
        $this->model('service');
    }

    /**
     * Service Main Page / All Services
     * Displays overview of all services
     */
    function index()
    {
        // Get all services for overview
        $services = $this->model->getAllServices();

        $data = [
            'pageTitle' => 'خدمات ما | طراحان باستان',
            'pageDescription' => 'خدمات تبلیغاتی و رویدادی طراحان باستان: غرفه نمایشگاهی، تبلیغات محیطی، تندیس و المان، برگزاری همایش، تیزر و محتوا، چاپ افست',
            'pageCSS' => ['service'],
            'pageJS' => ['service'],
            'showFooterCTA' => true,

            // Dynamic data
            'services' => $services,
        ];

        $this->view('service/index', $data);
    }

    /**
     * Generic method to load any service page
     * @param string $slug Service slug
     */
    private function loadServicePage($slug)
    {
        // Get full service data from model
        $serviceData = $this->model->getFullServiceData($slug);

        // If service not found, show 404
        if (!$serviceData) {
            header('HTTP/1.0 404 Not Found');
            $this->view('404');
            return;
        }

        $service = $serviceData['service'];

        $data = [
            'pageTitle' => $service['meta_title'] ?? $service['title'] . ' | طراحان باستان',
            'pageDescription' => $service['meta_description'] ?? $service['short_description'] ?? '',
            'pageCSS' => ['service-detail'],
            'pageJS' => ['service-detail'],
            'showFooterCTA' => true,
            'serviceType' => $slug,

            // Dynamic data from database
            'service' => $service,
            'stats' => $serviceData['stats'],
            'features' => $serviceData['features'],
            'items' => $serviceData['items'],
            'process' => $serviceData['process'],
            'faq' => $serviceData['faq'],
            'testimonials' => $serviceData['testimonials'],
            'portfolio' => $serviceData['portfolio'],
            'related' => $serviceData['related'],
        ];

        // Add service-specific data
        if (isset($serviceData['locations'])) {
            $data['locations'] = $serviceData['locations'];
        }
        if (isset($serviceData['packages'])) {
            $data['packages'] = $serviceData['packages'];
        }
        if (isset($serviceData['equipment'])) {
            $data['equipment'] = $serviceData['equipment'];
        }
        if (isset($serviceData['paper_types'])) {
            $data['paper_types'] = $serviceData['paper_types'];
        }

        $this->view('service/' . $slug, $data);
    }

    /**
     * Booth Design & Construction Service
     * غرفه نمایشگاهی
     */
    function booth()
    {
        $this->loadServicePage('booth');
    }

    /**
     * Environmental Advertising Service
     * تبلیغات محیطی
     */
    function ads()
    {
        $this->loadServicePage('ads');
    }

    /**
     * Trophy & Monument Service
     * تندیس و المان
     */
    function tandis()
    {
        $this->loadServicePage('tandis');
    }

    /**
     * Event Management Service
     * برگزاری همایش و رویداد
     */
    function event()
    {
        $this->loadServicePage('event');
    }

    /**
     * Content & Video Production Service
     * تیزر و محتوا
     */
    function content()
    {
        $this->loadServicePage('content');
    }

    /**
     * Offset Printing Service
     * چاپ افست
     */
    function print()
    {
        $this->loadServicePage('print');
    }

    /**
     * Creative Ideas & Consulting Service
     * ایده نو و مشاوره
     */
    function idea()
    {
        $this->loadServicePage('idea');
    }
}
