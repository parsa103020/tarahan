<?php

/**
 * Article Controller
 * کنترلر مقالات وبلاگ
 */
class article extends Controller
{
    function __construct()
    {
        parent::__construct();
        $this->model = $this->model('article');
    }

    /**
     * صفحه لیست مقالات
     */
    function index()
    {
        $page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
        $limit = 9;
        $offset = ($page - 1) * $limit;

        $data['articles'] = $this->model->getPublishedArticles($limit, $offset);
        $data['totalArticles'] = $this->model->countPublishedArticles();
        $data['totalPages'] = ceil($data['totalArticles'] / $limit);
        $data['currentPage'] = $page;

        $data['pageTitle'] = 'وبلاگ | طراحان باستان';
        $data['pageDescription'] = 'مقالات و آموزش‌های تخصصی در زمینه تبلیغات، غرفه‌سازی و برگزاری رویداد';
        $data['pageKeywords'] = 'وبلاگ طراحان باستان، مقالات تبلیغات، آموزش غرفه‌سازی، همدان';
        $data['pageCSS'] = ['article'];

        $this->view('article/index', $data);
    }

    /**
     * صفحه تک مقاله
     */
    function show($slug = '')
    {
        if (empty($slug)) {
            header('Location: ' . URL . 'article');
            exit;
        }

        $article = $this->model->getArticleBySlug($slug);

        if (!$article) {
            header('Location: ' . URL . '404');
            exit;
        }

        // افزایش بازدید
        $this->model->incrementViews($article['id']);

        // مقالات مرتبط
        $data['relatedArticles'] = $this->model->getRelatedArticles($article['id'], 3);

        $data['article'] = $article;
        $data['pageTitle'] = !empty($article['meta_title']) ? $article['meta_title'] : $article['title'] . ' | طراحان باستان';
        $data['pageDescription'] = !empty($article['meta_description']) ? $article['meta_description'] : $article['excerpt'];
        $data['pageKeywords'] = $article['meta_keywords'] ?? '';
        $data['pageCSS'] = ['article'];
        $data['ogImage'] = !empty($article['featured_image']) ? URL . $article['featured_image'] : null;

        $this->view('article/single', $data);
    }
}
