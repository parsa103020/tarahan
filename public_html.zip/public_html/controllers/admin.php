<?php

/**
 * Admin Controller - پنل مدیریت طراحان باستان
 * تمام عملیات مدیریتی سایت
 */
class admin extends Controller
{
    public $userId;

    function __construct()
    {
        parent::__construct();
        $this->model('admin');
        Model::sessionInit();

        // بررسی لاگین (به جز صفحات login و logout)
        $currentMethod = isset($_GET['url']) ? explode('/', $_GET['url'])[1] ?? '' : '';

        if (!in_array($currentMethod, ['login', 'doLogin', 'logout'])) {
            if (!isset($_SESSION['admin_login']) || $_SESSION['admin_login'] !== true) {
                header('Location: ' . URL . 'admin/login');
                exit;
            }
            $this->userId = $_SESSION['admin_id'] ?? null;
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // احراز هویت
    // ═══════════════════════════════════════════════════════════════════════════

    function login()
    {
        if (isset($_SESSION['admin_login']) && $_SESSION['admin_login'] === true) {
            header('Location: ' . URL . 'admin');
            exit;
        }
        $this->view('admin/login', [], true, true);
    }

    function doLogin()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            header('Location: ' . URL . 'admin/login');
            exit;
        }

        // Verify CSRF token
        $csrfToken = $_POST['csrf_token'] ?? '';
        if (!isset($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $csrfToken)) {
            echo json_encode(['success' => false, 'message' => 'درخواست نامعتبر است']);
            return;
        }

        $username = Model::sanitize($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';

        $result = $this->model->checkLogin($username, $password);

        if ($result) {
            // Regenerate session ID to prevent session fixation
            session_regenerate_id(true);

            $_SESSION['admin_login'] = true;
            $_SESSION['admin_id'] = $result['id'];
            $_SESSION['admin_name'] = $result['name'];
            $_SESSION['admin_role'] = $result['role'];

            // Regenerate CSRF token
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));

            echo json_encode(['success' => true, 'redirect' => URL . 'admin']);
        } else {
            echo json_encode(['success' => false, 'message' => 'نام کاربری یا رمز عبور اشتباه است']);
        }
    }

    function logout()
    {
        unset($_SESSION['admin_login']);
        unset($_SESSION['admin_id']);
        unset($_SESSION['admin_name']);
        unset($_SESSION['admin_role']);
        header('Location: ' . URL . 'admin/login');
        exit;
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // داشبورد
    // ═══════════════════════════════════════════════════════════════════════════

    function index()
    {
        $data = [
            'pageTitle' => 'داشبورد',
            'stats' => $this->model->getDashboardStats(),
            'recentMessages' => $this->model->getRecentMessages(5),
            'services' => $this->model->getAllServices(),
        ];
        $this->view('admin/index', $data, true, true);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // مدیریت تنظیمات
    // ═══════════════════════════════════════════════════════════════════════════

    function settings()
    {
        $data = [
            'pageTitle' => 'تنظیمات سایت',
            'settings' => $this->model->getAllSettings(),
        ];
        $this->view('admin/settings/index', $data, true, true);
    }

    function saveSettings()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            header('Location: ' . URL . 'admin/settings');
            exit;
        }

        $result = $this->model->saveSettings($_POST);
        echo json_encode(['success' => $result]);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // مدیریت خدمات
    // ═══════════════════════════════════════════════════════════════════════════

    function services()
    {
        $data = [
            'pageTitle' => 'مدیریت خدمات',
            'services' => $this->model->getAllServices(),
        ];
        $this->view('admin/services/index', $data, true, true);
    }

    function editService($id)
    {
        $service = $this->model->getServiceById($id);
        if (!$service) {
            header('Location: ' . URL . 'admin/services');
            exit;
        }

        $data = [
            'pageTitle' => 'ویرایش خدمت: ' . $service['title'],
            'service' => $service,
            'features' => $this->model->getServiceFeatures($id),
            'process' => $this->model->getServiceProcess($id),
            'faq' => $this->model->getServiceFAQ($id),
            'stats' => $this->model->getServiceStats($id),
            'items' => $this->model->getServiceItems($id),
        ];
        $this->view('admin/services/edit', $data, true, true);
    }

    function saveService($id)
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            header('Location: ' . URL . 'admin/services');
            exit;
        }

        $result = $this->model->saveService($id, $_POST);
        echo json_encode(['success' => $result]);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // مدیریت صفحه اصلی
    // ═══════════════════════════════════════════════════════════════════════════

    function home()
    {
        $data = [
            'pageTitle' => 'تنظیمات صفحه اصلی',
            'hero' => $this->model->getPageContent('home', 'hero'),
            'stats' => $this->model->getStats('home'),
            'testimonials' => $this->model->getTestimonials('home'),
            'process' => $this->model->getProcessSteps('home'),
            'cta' => $this->model->getPageContent('home', 'cta'),
        ];
        $this->view('admin/pages/home', $data, true, true);
    }

    function saveHome()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            header('Location: ' . URL . 'admin/home');
            exit;
        }

        $result = $this->model->saveHomeData($_POST);
        echo json_encode(['success' => $result]);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // مدیریت صفحه درباره ما
    // ═══════════════════════════════════════════════════════════════════════════

    function about()
    {
        $data = [
            'pageTitle' => 'تنظیمات صفحه درباره ما',
            'hero' => $this->model->getPageContent('about', 'hero'),
            'timeline' => $this->model->getTimeline(),
            'values' => $this->model->getValues(),
            'stats' => $this->model->getStats('about'),
            'manifesto' => $this->model->getPageContent('about', 'manifesto'),
            'cta' => $this->model->getPageContent('about', 'cta'),
        ];
        $this->view('admin/pages/about', $data, true, true);
    }

    function saveAbout()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            header('Location: ' . URL . 'admin/about');
            exit;
        }

        $result = $this->model->saveAboutData($_POST);
        echo json_encode(['success' => $result]);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // مدیریت صفحه تماس با ما
    // ═══════════════════════════════════════════════════════════════════════════

    function contact()
    {
        $data = [
            'pageTitle' => 'تنظیمات صفحه تماس',
            'hero' => $this->model->getPageContent('contact', 'hero'),
            'faq' => $this->model->getFAQ('contact'),
        ];
        $this->view('admin/pages/contact', $data, true, true);
    }

    function saveContact()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            header('Location: ' . URL . 'admin/contact');
            exit;
        }

        $result = $this->model->saveContactData($_POST);
        echo json_encode(['success' => $result]);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // مدیریت پیام‌های تماس
    // ═══════════════════════════════════════════════════════════════════════════

    function messages()
    {
        $data = [
            'pageTitle' => 'پیام‌های دریافتی',
            'messages' => $this->model->getAllMessages(),
        ];
        $this->view('admin/messages/index', $data, true, true);
    }

    function viewMessage($id)
    {
        $message = $this->model->getMessage($id);
        if (!$message) {
            header('Location: ' . URL . 'admin/messages');
            exit;
        }

        // علامت‌گذاری به عنوان خوانده شده
        $this->model->markMessageAsRead($id);

        $data = [
            'pageTitle' => 'مشاهده پیام',
            'message' => $message,
        ];
        $this->view('admin/messages/view', $data, true, true);
    }

    function deleteMessage($id)
    {
        $this->model->deleteMessage($id);
        echo json_encode(['success' => true]);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // مدیریت آمار و ارقام
    // ═══════════════════════════════════════════════════════════════════════════

    function stats()
    {
        $data = [
            'pageTitle' => 'مدیریت آمار و ارقام',
            'homeStats' => $this->model->getStats('home'),
            'aboutStats' => $this->model->getStats('about'),
        ];
        $this->view('admin/stats/index', $data, true, true);
    }

    function saveStat()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode(['success' => false, 'error' => 'Invalid request method']);
            exit;
        }

        $result = $this->model->saveStat($_POST);
        echo json_encode($result);
    }

    function deleteStat($id)
    {
        $result = $this->model->deleteStat($id);
        echo json_encode(['success' => $result]);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // مدیریت نظرات مشتریان
    // ═══════════════════════════════════════════════════════════════════════════

    function testimonials()
    {
        $data = [
            'pageTitle' => 'مدیریت نظرات مشتریان',
            'testimonials' => $this->model->getAllTestimonials(),
        ];
        $this->view('admin/testimonials/index', $data, true, true);
    }

    function saveTestimonial()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode(['success' => false]);
            exit;
        }

        $result = $this->model->saveTestimonial($_POST);
        echo json_encode(['success' => $result]);
    }

    function deleteTestimonial($id)
    {
        $result = $this->model->deleteTestimonial($id);
        echo json_encode(['success' => $result]);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // مدیریت تاریخچه (Timeline)
    // ═══════════════════════════════════════════════════════════════════════════

    function timeline()
    {
        $data = [
            'pageTitle' => 'مدیریت تاریخچه',
            'timeline' => $this->model->getTimeline(),
        ];
        $this->view('admin/timeline/index', $data, true, true);
    }

    function saveTimelineItem()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode(['success' => false]);
            exit;
        }

        $result = $this->model->saveTimelineItem($_POST);
        echo json_encode(['success' => $result]);
    }

    function deleteTimelineItem($id)
    {
        $result = $this->model->deleteTimelineItem($id);
        echo json_encode(['success' => $result]);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // مدیریت ارزش‌ها
    // ═══════════════════════════════════════════════════════════════════════════

    function values()
    {
        $data = [
            'pageTitle' => 'مدیریت ارزش‌ها',
            'values' => $this->model->getValues(),
        ];
        $this->view('admin/values/index', $data, true, true);
    }

    function saveValue()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode(['success' => false]);
            exit;
        }

        $result = $this->model->saveValue($_POST);
        echo json_encode(['success' => $result]);
    }

    function deleteValue($id)
    {
        $result = $this->model->deleteValue($id);
        echo json_encode(['success' => $result]);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // مدیریت FAQ
    // ═══════════════════════════════════════════════════════════════════════════

    function faq()
    {
        $data = [
            'pageTitle' => 'مدیریت سوالات متداول',
            'faqs' => $this->model->getAllFAQ(),
        ];
        $this->view('admin/faq/index', $data, true, true);
    }

    function saveFAQ()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode(['success' => false]);
            exit;
        }

        $result = $this->model->saveFAQ($_POST);
        echo json_encode(['success' => $result]);
    }

    function deleteFAQ($id)
    {
        $result = $this->model->deleteFAQ($id);
        echo json_encode(['success' => $result]);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // مدیریت فرآیند کار
    // ═══════════════════════════════════════════════════════════════════════════

    function process()
    {
        $data = [
            'pageTitle' => 'مدیریت فرآیند کار',
            'process' => $this->model->getProcessSteps('home'),
        ];
        $this->view('admin/process/index', $data, true, true);
    }

    function saveProcessStep()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode(['success' => false]);
            exit;
        }

        $result = $this->model->saveProcessStep($_POST);
        echo json_encode(['success' => $result]);
    }

    function deleteProcessStep($id)
    {
        $result = $this->model->deleteProcessStep($id);
        echo json_encode(['success' => $result]);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // مدیریت مقالات
    // ═══════════════════════════════════════════════════════════════════════════

    function articles()
    {
        $articleModel = $this->model('article');
        $data = [
            'pageTitle' => 'مقالات',
            'articles' => $articleModel->getAllArticles(),
        ];
        $this->view('admin/articles/index', $data, true, true);
    }

    function editArticle($id = null)
    {
        $articleModel = $this->model('article');
        $data = [
            'pageTitle' => $id ? 'ویرایش مقاله' : 'افزودن مقاله',
            'article' => $id ? $articleModel->getArticleById($id) : null,
        ];
        $this->view('admin/articles/edit', $data, true, true);
    }

    function saveArticle()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode(['success' => false]);
            return;
        }

        $articleModel = $this->model('article');

        $data = [
            'id' => $_POST['id'] ?? null,
            'title' => $_POST['title'] ?? '',
            'slug' => $_POST['slug'] ?? '',
            'excerpt' => $_POST['excerpt'] ?? '',
            'content' => $_POST['content'] ?? '',
            'featured_image' => $_POST['featured_image'] ?? null,
            'meta_title' => $_POST['meta_title'] ?? '',
            'meta_description' => $_POST['meta_description'] ?? '',
            'meta_keywords' => $_POST['meta_keywords'] ?? '',
            'status' => $_POST['status'] ?? 'draft',
        ];

        $result = $articleModel->saveArticle($data);
        echo json_encode(['success' => $result]);
    }

    function deleteArticle($id)
    {
        $articleModel = $this->model('article');
        $result = $articleModel->deleteArticle($id);
        echo json_encode(['success' => $result]);
    }

    function uploadImage()
    {
        if (!isset($_FILES['file'])) {
            echo json_encode(['error' => 'فایلی ارسال نشده']);
            return;
        }

        $file = $_FILES['file'];
        $category = $_POST['category'] ?? 'articles';
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];

        // بررسی نوع فایل
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mimeType = finfo_file($finfo, $file['tmp_name']);
        finfo_close($finfo);

        if (!in_array($mimeType, $allowedTypes)) {
            echo json_encode(['success' => false, 'error' => 'فرمت فایل مجاز نیست. فرمت‌های مجاز: JPG, PNG, GIF, WebP']);
            return;
        }

        // محدودیت سایز (5MB)
        if ($file['size'] > 5 * 1024 * 1024) {
            echo json_encode(['success' => false, 'error' => 'حجم فایل بیش از 5 مگابایت است']);
            return;
        }

        // تعیین پوشه بر اساس دسته
        $uploadDir = 'public/uploads/' . preg_replace('/[^a-z0-9_-]/i', '', $category) . '/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }

        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $fileName = time() . '_' . uniqid() . '.' . $ext;
        $filePath = $uploadDir . $fileName;

        if (move_uploaded_file($file['tmp_name'], $filePath)) {
            echo json_encode([
                'success' => true,
                'location' => URL . $filePath,
                'path' => $filePath,
                'filename' => $fileName
            ]);
        } else {
            echo json_encode(['success' => false, 'error' => 'خطا در آپلود فایل']);
        }
    }

    function deleteUploadedImage()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode(['success' => false, 'error' => 'درخواست نامعتبر']);
            return;
        }

        $path = $_POST['path'] ?? '';

        // فقط فایل‌های پوشه uploads رو حذف کن
        if (empty($path) || strpos($path, 'public/uploads/') !== 0) {
            echo json_encode(['success' => false, 'error' => 'مسیر نامعتبر']);
            return;
        }

        if (file_exists($path) && is_file($path)) {
            unlink($path);
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'error' => 'فایل یافت نشد']);
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // API Endpoints برای AJAX
    // ═══════════════════════════════════════════════════════════════════════════

    function getItem($table, $id)
    {
        $item = $this->model->getItemById($table, $id);
        echo json_encode($item);
    }

    // Debug endpoint to check table structure
    function debugTable($table = 'stats')
    {
        $allowedTables = ['stats', 'testimonials', 'timeline', 'company_values', 'faq', 'process_steps'];
        if (!in_array($table, $allowedTables)) {
            echo json_encode(['error' => 'Invalid table']);
            return;
        }

        try {
            $sql = "DESCRIBE $table";
            $stmt = $this->model::$conn->prepare($sql);
            $stmt->execute();
            $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode(['table' => $table, 'columns' => $columns]);
        } catch (Exception $e) {
            echo json_encode(['error' => $e->getMessage()]);
        }
    }
}
