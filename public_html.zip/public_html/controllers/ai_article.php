<?php

/**
 * AI Article Controller
 * کنترلر سیستم تولید مقاله خودکار
 *
 * @version 3.0.0
 */
class ai_article extends Controller
{
    function __construct()
    {
        parent::__construct();
        $this->model = $this->model('ai_article');
    }

    /**
     * Verify authentication token
     * Returns true if authenticated, otherwise sends error response and exits
     */
    private function requireAuth()
    {
        // Check Authorization header
        $headers = getallheaders();
        $token = $headers['Authorization'] ?? $headers['authorization'] ?? '';

        // Remove "Bearer " prefix if present
        if (stripos($token, 'Bearer ') === 0) {
            $token = substr($token, 7);
        }

        // Also check query parameter as fallback
        if (empty($token)) {
            $token = $_GET['token'] ?? $_POST['token'] ?? '';
        }

        if (!$this->model->verifyAuth($token)) {
            http_response_code(401);
            echo json_encode([
                'success' => false,
                'message' => 'احراز هویت نامعتبر. توکن صحیح را ارسال کنید.',
                'timestamp' => date('Y-m-d H:i:s')
            ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
            exit;
        }

        return true;
    }

    /**
     * Rate limiting check (per IP)
     */
    private function checkRateLimit($action = 'default', $maxRequests = 10, $windowSeconds = 60)
    {
        $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
        $cacheFile = dirname(__DIR__) . '/data/cache/rate_limit_' . md5($ip . $action) . '.json';

        $cacheDir = dirname($cacheFile);
        if (!is_dir($cacheDir)) {
            mkdir($cacheDir, 0755, true);
        }

        $now = time();
        $data = ['requests' => [], 'blocked_until' => 0];

        if (file_exists($cacheFile)) {
            $data = json_decode(file_get_contents($cacheFile), true) ?: $data;
        }

        // Check if blocked
        if (isset($data['blocked_until']) && $data['blocked_until'] > $now) {
            http_response_code(429);
            echo json_encode([
                'success' => false,
                'message' => 'تعداد درخواست‌ها بیش از حد مجاز است. لطفاً کمی صبر کنید.',
                'retry_after' => $data['blocked_until'] - $now,
                'timestamp' => date('Y-m-d H:i:s')
            ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
            exit;
        }

        // Clean old requests
        $data['requests'] = array_filter($data['requests'], function($time) use ($now, $windowSeconds) {
            return ($now - $time) < $windowSeconds;
        });

        // Check rate limit
        if (count($data['requests']) >= $maxRequests) {
            $data['blocked_until'] = $now + $windowSeconds;
            file_put_contents($cacheFile, json_encode($data), LOCK_EX);

            http_response_code(429);
            echo json_encode([
                'success' => false,
                'message' => 'تعداد درخواست‌ها بیش از حد مجاز است. لطفاً کمی صبر کنید.',
                'retry_after' => $windowSeconds,
                'timestamp' => date('Y-m-d H:i:s')
            ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
            exit;
        }

        // Add request
        $data['requests'][] = $now;
        file_put_contents($cacheFile, json_encode($data), LOCK_EX);

        return true;
    }

    /**
     * صفحه اصلی - نمایش وضعیت
     */
    function index()
    {
        $this->status();
    }

    /**
     * تولید مقاله جدید
     * این متد توسط cron job فراخوانی می‌شود
     *
     * Usage: curl -H "Authorization: Bearer YOUR_TOKEN" http://localhost/tarahan/ai_article/generate
     */
    function generate()
    {
        // تنظیم زمان اجرا
        set_time_limit(600); // 10 دقیقه

        // هدر JSON
        header('Content-Type: application/json; charset=utf-8');

        // Check authentication
        $this->requireAuth();

        // Rate limiting - 5 requests per hour for generate
        $this->checkRateLimit('generate', 5, 3600);

        try {
            // اجرای workflow
            $result = $this->model->runWorkflow();

            echo json_encode([
                'success' => $result['success'],
                'message' => $result['message'],
                'data' => $result['data'] ?? null,
                'timestamp' => date('Y-m-d H:i:s')
            ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);

        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode([
                'success' => false,
                'message' => 'خطای سیستمی: ' . $e->getMessage(),
                'timestamp' => date('Y-m-d H:i:s')
            ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        }

        exit;
    }

    /**
     * نمایش وضعیت سیستم
     */
    function status()
    {
        header('Content-Type: application/json; charset=utf-8');

        try {
            $status = $this->model->getSystemStatus();

            echo json_encode([
                'success' => true,
                'status' => $status,
                'timestamp' => date('Y-m-d H:i:s')
            ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);

        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode([
                'success' => false,
                'message' => 'خطا در دریافت وضعیت: ' . $e->getMessage()
            ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        }

        exit;
    }

    /**
     * نمایش لاگ‌های تولید
     */
    function logs($limit = 20)
    {
        header('Content-Type: application/json; charset=utf-8');

        try {
            $logs = $this->model->getGenerationLogs((int)$limit);

            echo json_encode([
                'success' => true,
                'count' => count($logs),
                'logs' => $logs,
                'timestamp' => date('Y-m-d H:i:s')
            ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);

        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode([
                'success' => false,
                'message' => 'خطا در دریافت لاگ‌ها: ' . $e->getMessage()
            ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        }

        exit;
    }

    /**
     * بررسی سلامت سیستم
     */
    function health()
    {
        header('Content-Type: application/json; charset=utf-8');

        try {
            $health = $this->model->healthCheck();

            $allHealthy = !in_array(false, array_column($health, 'status'));

            if (!$allHealthy) {
                http_response_code(503);
            }

            echo json_encode([
                'success' => $allHealthy,
                'health' => $health,
                'timestamp' => date('Y-m-d H:i:s')
            ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);

        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode([
                'success' => false,
                'message' => 'خطا در بررسی سلامت: ' . $e->getMessage()
            ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        }

        exit;
    }

    /**
     * تست اتصال API
     */
    function test()
    {
        header('Content-Type: application/json; charset=utf-8');

        try {
            $result = $this->model->testApiConnection();

            echo json_encode([
                'success' => $result['success'],
                'message' => $result['message'],
                'details' => $result['details'] ?? null,
                'timestamp' => date('Y-m-d H:i:s')
            ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);

        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode([
                'success' => false,
                'message' => 'خطا در تست API: ' . $e->getMessage()
            ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        }

        exit;
    }

    /**
     * لیست موضوعات
     */
    function topics($service = null)
    {
        header('Content-Type: application/json; charset=utf-8');

        try {
            $topics = $this->model->getTopics($service);

            echo json_encode([
                'success' => true,
                'count' => count($topics),
                'topics' => $topics,
                'timestamp' => date('Y-m-d H:i:s')
            ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);

        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode([
                'success' => false,
                'message' => 'خطا در دریافت موضوعات: ' . $e->getMessage()
            ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        }

        exit;
    }

    /**
     * آمار سرویس‌ها
     */
    function services()
    {
        header('Content-Type: application/json; charset=utf-8');

        try {
            $services = $this->model->getServicesStats();

            echo json_encode([
                'success' => true,
                'services' => $services,
                'timestamp' => date('Y-m-d H:i:s')
            ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);

        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode([
                'success' => false,
                'message' => 'خطا در دریافت آمار سرویس‌ها: ' . $e->getMessage()
            ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        }

        exit;
    }

    /**
     * ریست کردن یک موضوع استفاده‌شده
     */
    function resetTopic($topicId)
    {
        header('Content-Type: application/json; charset=utf-8');

        // Require authentication for topic management
        $this->requireAuth();
        $this->checkRateLimit('resetTopic', 20, 60);

        try {
            $result = $this->model->resetTopic((int)$topicId);

            echo json_encode([
                'success' => $result,
                'message' => $result ? 'موضوع ریست شد' : 'خطا در ریست موضوع',
                'timestamp' => date('Y-m-d H:i:s')
            ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);

        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode([
                'success' => false,
                'message' => 'خطا: ' . $e->getMessage()
            ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        }

        exit;
    }

    /**
     * افزودن موضوع جدید
     */
    function addTopic()
    {
        header('Content-Type: application/json; charset=utf-8');

        // Require authentication for topic management
        $this->requireAuth();
        $this->checkRateLimit('addTopic', 30, 60);

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            http_response_code(405);
            echo json_encode([
                'success' => false,
                'message' => 'فقط متد POST مجاز است'
            ], JSON_UNESCAPED_UNICODE);
            exit;
        }

        try {
            $serviceCode = $_POST['service_code'] ?? '';
            $title = $_POST['topic_title'] ?? '';
            $keyword = $_POST['primary_keyword'] ?? '';

            if (empty($serviceCode) || empty($title)) {
                throw new Exception('کد سرویس و عنوان موضوع الزامی است');
            }

            $result = $this->model->addTopic($serviceCode, $title, $keyword);

            echo json_encode([
                'success' => $result,
                'message' => $result ? 'موضوع اضافه شد' : 'خطا در افزودن موضوع',
                'timestamp' => date('Y-m-d H:i:s')
            ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);

        } catch (Exception $e) {
            http_response_code(400);
            echo json_encode([
                'success' => false,
                'message' => 'خطا: ' . $e->getMessage()
            ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        }

        exit;
    }

    /**
     * پاکسازی lock قدیمی
     */
    function unlock()
    {
        header('Content-Type: application/json; charset=utf-8');

        // Require authentication for system operations
        $this->requireAuth();
        $this->checkRateLimit('unlock', 10, 60);

        try {
            $result = $this->model->forceUnlock();

            echo json_encode([
                'success' => $result,
                'message' => $result ? 'قفل برداشته شد' : 'قفلی وجود نداشت',
                'timestamp' => date('Y-m-d H:i:s')
            ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);

        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode([
                'success' => false,
                'message' => 'خطا: ' . $e->getMessage()
            ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        }

        exit;
    }

    /**
     * تست تولید محتوا (بدون ذخیره)
     */
    function testGenerate($serviceCode = null)
    {
        set_time_limit(300);
        header('Content-Type: application/json; charset=utf-8');

        // Require authentication for testing
        $this->requireAuth();
        $this->checkRateLimit('testGenerate', 3, 3600); // 3 per hour

        try {
            $result = $this->model->testContentGeneration($serviceCode);

            echo json_encode([
                'success' => $result['success'],
                'message' => $result['message'],
                'preview' => $result['preview'] ?? null,
                'word_count' => $result['word_count'] ?? 0,
                'timestamp' => date('Y-m-d H:i:s')
            ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);

        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode([
                'success' => false,
                'message' => 'خطا در تست تولید: ' . $e->getMessage()
            ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        }

        exit;
    }

    /**
     * مشاهده یادداشت‌های سئو
     */
    function seoNotes()
    {
        header('Content-Type: text/plain; charset=utf-8');

        $notesFile = dirname(__DIR__) . '/data/seo_notes.md';

        if (file_exists($notesFile)) {
            echo file_get_contents($notesFile);
        } else {
            echo "فایل یادداشت‌های سئو یافت نشد.";
        }

        exit;
    }

    /**
     * مشاهده آخرین لاگ فایل
     */
    function logFile()
    {
        header('Content-Type: text/plain; charset=utf-8');

        $logDir = dirname(__DIR__) . '/data/logs';
        $today = date('Y-m-d');
        $logFile = $logDir . '/ai_article_' . $today . '.log';

        if (file_exists($logFile)) {
            // آخرین 100 خط
            $lines = file($logFile);
            $lastLines = array_slice($lines, -100);
            echo implode('', $lastLines);
        } else {
            echo "لاگ امروز یافت نشد.";
        }

        exit;
    }

    /**
     * بازسازی کامل sitemap
     * تمام مقالات منتشرشده را به sitemap اضافه می‌کند
     *
     * Usage: curl -H "Authorization: Bearer YOUR_TOKEN" http://localhost/tarahan/ai_article/regenerateSitemap
     */
    function regenerateSitemap()
    {
        header('Content-Type: application/json; charset=utf-8');

        // Require authentication
        $this->requireAuth();
        $this->checkRateLimit('regenerateSitemap', 5, 3600);

        try {
            $result = $this->model->regenerateSitemap();

            echo json_encode([
                'success' => $result['success'],
                'message' => 'Sitemap با موفقیت بازسازی شد',
                'data' => [
                    'articles_count' => $result['articles_count'],
                    'static_pages' => $result['static_pages']
                ],
                'timestamp' => date('Y-m-d H:i:s')
            ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);

        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode([
                'success' => false,
                'message' => 'خطا در بازسازی sitemap: ' . $e->getMessage()
            ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        }

        exit;
    }
}
