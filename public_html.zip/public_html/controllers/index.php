<?php

class index extends Controller
{
    function __construct()
    {
        parent::__construct();
        $this->model('index');
    }

    function index()
    {
        // Get all home page data from model
        $homeData = $this->model->getAllHomeData();

        $data = [
            'pageTitle' => 'طراحان باستان | خدمات تبلیغاتی و رویدادی در همدان',
            'pageDescription' => 'بیش از ۱۰ سال تجربه در ارائه خدمات تبلیغاتی و رویدادی. غرفه نمایشگاهی، تبلیغات محیطی، تندیس و المان، برگزاری همایش و...',
            'pageKeywords' => 'طراحان باستان, همدان, خدمات تبلیغاتی, غرفه نمایشگاهی, تبلیغات محیطی, برگزاری همایش',
            'pageCSS' => ['home'],
            'pageJS' => ['home'],
            'showFooterCTA' => false,

            // Dynamic data from database
            'hero' => $homeData['hero'],
            'stats' => $homeData['stats'],
            'services' => $homeData['services'],
            'featured' => $homeData['featured'],
            'benefits' => $homeData['benefits'],
            'testimonials' => $homeData['testimonials'],
            'process' => $homeData['process'],
            'cta' => $homeData['cta'],
        ];

        $this->view('index/index', $data);
    }
    
    function sw()
    {
        
        $data = [];
        $this->view('sw', $data);
    }
    
   
}
