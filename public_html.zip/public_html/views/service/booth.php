<?php
/**
 * TARAHAN BASTAN - BOOTH SERVICE PAGE
 * Heroic 3D Design v4.0
 * Note: Header/Footer loaded by controller
 */
?>

<style>
    /* ══════════════════════════════════════════════════════════════════════════════
       TARAHAN BASTAN - BOOTH SERVICE PAGE - HEROIC 3D v4.0 (FULL)
       طراحی کامل با تمام سکشن‌ها - تم قهرمان
       ══════════════════════════════════════════════════════════════════════════════ */

    :root {
        /* ═══ BRAND COLORS ═══ */
        --brand-brown: #2D1810;
        --brand-brown-dark: #1A0D08;
        --brand-gold: #D4A020;
        --brand-gold-bright: #FFD700;
        --brand-orange: #F58500;
        --brand-orange-hot: #FF4500;
        
        /* ═══ GRADIENTS ═══ */
        --gradient-hero: linear-gradient(135deg, #2D1810 0%, #4A2C1A 100%);
        --gradient-gold: linear-gradient(45deg, #D4A020, #F5C518, #FFD700, #D4A020);
        --gradient-fire: linear-gradient(45deg, #FF4500, #FF6B00, #FF9500);
        --gradient-glass: linear-gradient(145deg, rgba(255,255,255,0.9), rgba(255,255,255,0.6));
        --gradient-dark-glass: linear-gradient(145deg, rgba(45, 24, 16, 0.9), rgba(45, 24, 16, 0.7));
        
        /* ═══ DEPTH & SHADOWS ═══ */
        --shadow-card: 0 15px 35px rgba(45, 24, 16, 0.1);
        --shadow-float: 0 30px 60px rgba(45, 24, 16, 0.2);
        --shadow-text: 0 10px 20px rgba(0,0,0,0.15);
        --shadow-glow: 0 0 50px rgba(212, 160, 32, 0.3);
        --shadow-inner: inset 0 5px 15px rgba(0,0,0,0.05);
    }

    /* ═══ GLOBAL RESET & CURSOR FIX ═══ */
    * {
        box-sizing: border-box;
        cursor: auto !important;
    }
    
    a, button, .btn, .card-hover, .accordion-header, .gallery-item {
        cursor: pointer !important;
    }

    body {
        background: #FAF6F1;
        color: var(--brand-brown);
        font-family: 'YekanBakh', sans-serif;
        overflow-x: hidden;
        margin: 0;
        perspective: 1000px;
    }

    /* ══════════════════════════════════════════════════════════════════════════════
       1. HERO SECTION
       ══════════════════════════════════════════════════════════════════════════════ */
    .hero-section {
        min-height: 100vh;
        position: relative;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 140px 20px 100px;
        background: radial-gradient(circle at 50% 30%, #FFFEFB 0%, #F4EBE0 100%);
        overflow: hidden;
        transform-style: preserve-3d;
    }

    .hero-3d-bg {
        position: absolute;
        inset: 0;
        transform-style: preserve-3d;
        pointer-events: none;
    }
    
    .floating-shape {
        position: absolute;
        background: linear-gradient(135deg, rgba(255,255,255,0.8), rgba(255,255,255,0.2));
        border: 1px solid rgba(212, 160, 32, 0.2);
        backdrop-filter: blur(10px);
        box-shadow: var(--shadow-float);
        animation: float3D 10s ease-in-out infinite;
    }

    .shape-1 { width: 250px; height: 350px; top: 5%; left: -2%; transform: rotateY(20deg) rotateX(10deg); animation-delay: 0s; border-radius: 10px; }
    .shape-2 { width: 180px; height: 180px; bottom: 10%; right: 0%; transform: rotateY(-20deg) rotateX(10deg); animation-delay: 2s; border-radius: 20px; background: linear-gradient(135deg, rgba(212, 160, 32, 0.1), rgba(255, 255, 255, 0.4)); }
    .shape-3 { width: 120px; height: 120px; top: 25%; right: 18%; border-radius: 10px; animation-delay: 4s; background: var(--gradient-gold); opacity: 0.15; filter: blur(20px); }

    @keyframes float3D {
        0%, 100% { transform: translateY(0) rotateY(20deg) rotateX(10deg); }
        50% { transform: translateY(-30px) rotateY(25deg) rotateX(5deg); }
    }

    .hero-content {
        position: relative;
        z-index: 10;
        text-align: center;
        max-width: 1100px;
        transform: translateZ(50px);
    }

    .hero-badge {
        display: inline-flex;
        align-items: center;
        gap: 10px;
        padding: 12px 30px;
        background: white;
        border-radius: 50px;
        box-shadow: 0 10px 30px rgba(212, 160, 32, 0.2);
        margin-bottom: 30px;
        border: 2px solid var(--brand-gold);
        animation: popIn 0.8s cubic-bezier(0.175, 0.885, 0.32, 1.275);
    }
    .hero-badge span {
        font-weight: 900;
        background: var(--gradient-fire);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
        font-size: 1.1rem;
    }

    .hero-title {
        font-size: clamp(3.5rem, 8vw, 6rem);
        font-weight: 900;
        line-height: 1;
        margin-bottom: 30px;
        color: var(--brand-brown);
        text-shadow: 2px 2px 0px rgba(255,255,255,0.5), var(--shadow-text);
    }
    
    .hero-title .highlight {
        background: var(--gradient-gold);
        background-size: 200% auto;
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
        animation: shine 3s linear infinite;
        display: inline-block;
    }

    @keyframes shine {
        to { background-position: 200% center; }
    }

    .hero-desc {
        font-size: clamp(1.2rem, 2.5vw, 1.6rem);
        color: var(--text-secondary);
        max-width: 800px;
        margin: 0 auto 50px;
        font-weight: 500;
        line-height: 1.6;
        text-shadow: 0 2px 10px rgba(255,255,255,0.8);
    }

    .hero-actions {
        display: flex;
        justify-content: center;
        gap: 24px;
        perspective: 1000px;
    }

    .btn-hero {
        position: relative;
        padding: 22px 56px;
        border-radius: 60px;
        font-weight: 900;
        font-size: 1.3rem;
        text-decoration: none;
        transition: all 0.4s cubic-bezier(0.34, 1.56, 0.64, 1);
        overflow: hidden;
        display: inline-flex;
        align-items: center;
        gap: 15px;
    }

    .btn-primary {
        background: var(--gradient-fire);
        color: white;
        box-shadow: 0 20px 40px rgba(255, 69, 0, 0.3);
        border: 2px solid transparent;
    }
    .btn-primary::before {
        content: '';
        position: absolute;
        top: 0; left: -100%; width: 100%; height: 100%;
        background: linear-gradient(90deg, transparent, rgba(255,255,255,0.4), transparent);
        transition: 0.5s;
    }
    .btn-primary:hover::before { left: 100%; }
    .btn-primary:hover {
        transform: translateY(-8px) scale(1.05);
        box-shadow: 0 30px 60px rgba(255, 69, 0, 0.5);
    }

    .btn-secondary {
        background: white;
        color: var(--brand-brown);
        border: 2px solid var(--brand-gold);
        box-shadow: 0 10px 30px rgba(0,0,0,0.05);
    }
    .btn-secondary:hover {
        background: var(--brand-gold);
        color: white;
        transform: translateY(-8px) scale(1.05);
        box-shadow: 0 20px 50px rgba(212, 160, 32, 0.4);
    }

    /* ══════════════════════════════════════════════════════════════════════════════
       2. STATS STRIP - 3D FLOATING
       ══════════════════════════════════════════════════════════════════════════════ */
    .stats-container {
        max-width: 1200px;
        margin: -80px auto 100px;
        position: relative;
        z-index: 30;
        perspective: 1000px;
        padding: 0 20px;
    }

    .stats-bar {
        background: white;
        border-radius: 30px;
        box-shadow: var(--shadow-float);
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        padding: 40px;
        transform: rotateX(5deg);
        transition: 0.5s;
        border: 1px solid rgba(212, 160, 32, 0.1);
    }
    .stats-bar:hover {
        transform: rotateX(0deg) translateY(-10px);
        box-shadow: 0 40px 80px rgba(45, 24, 16, 0.15);
    }

    .stat-item {
        text-align: center;
        position: relative;
    }
    .stat-item:not(:last-child)::after {
        content: '';
        position: absolute;
        left: 0; top: 20%; bottom: 20%; width: 1px;
        background: linear-gradient(180deg, transparent, #eee, transparent);
    }

    .stat-num {
        font-size: 2.5rem;
        font-weight: 900;
        color: var(--brand-gold);
        display: block;
        margin-bottom: 5px;
        text-shadow: 0 2px 5px rgba(212, 160, 32, 0.2);
    }
    .stat-label {
        font-size: 1rem;
        font-weight: 700;
        color: var(--brand-brown-light);
    }

    /* ══════════════════════════════════════════════════════════════════════════════
       3. WHY US - 3D FEATURES
       ══════════════════════════════════════════════════════════════════════════════ */
    .section-why {
        padding: 100px 20px;
        background: #FBF7F1;
    }
    
    .section-head {
        text-align: center;
        margin-bottom: 80px;
    }
    .section-head h2 {
        font-size: 3rem;
        font-weight: 900;
        color: var(--brand-brown);
        margin-bottom: 15px;
    }
    .section-head p {
        font-size: 1.2rem;
        color: var(--text-body);
        max-width: 600px;
        margin: 0 auto;
    }

    .features-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
        gap: 40px;
        max-width: 1200px;
        margin: 0 auto;
    }

    .feature-box {
        background: white;
        padding: 40px;
        border-radius: 30px;
        box-shadow: var(--shadow-card);
        transition: 0.4s;
        border: 1px solid transparent;
        position: relative;
        overflow: hidden;
    }
    .feature-box:hover {
        transform: translateY(-10px);
        border-color: var(--brand-gold);
        box-shadow: var(--shadow-float);
    }
    
    .feature-icon {
        width: 70px;
        height: 70px;
        background: var(--gradient-gold);
        border-radius: 20px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 2rem;
        color: white;
        margin-bottom: 20px;
        box-shadow: 0 10px 20px rgba(212, 160, 32, 0.3);
    }

    .feature-box h3 { font-size: 1.5rem; font-weight: 800; margin-bottom: 15px; }
    .feature-box p { color: var(--text-secondary); line-height: 1.7; }

    /* ══════════════════════════════════════════════════════════════════════════════
       4. SERVICES (CARDS) - 3D FLIP EFFECT
       ══════════════════════════════════════════════════════════════════════════════ */
    .separator-wave {
        height: 100px;
        overflow: hidden;
        margin-top: -1px;
    }
    .separator-wave svg { fill: #FBF7F1; width: 100%; height: 100%; transform: rotate(180deg); }

    .section-services {
        background: var(--brand-brown-dark); /* Dark bg for contrast */
        padding: 100px 20px;
        color: white;
        position: relative;
    }
    .section-services .section-head h2 { color: white; }
    .section-services .section-head p { color: rgba(255,255,255,0.7); }

    .cards-container {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
        gap: 40px;
        max-width: 1400px;
        margin: 0 auto;
        perspective: 1500px;
    }

    .premium-card {
        background: var(--gradient-dark-glass);
        border-radius: 40px;
        padding: 50px 40px;
        position: relative;
        transition: all 0.6s cubic-bezier(0.23, 1, 0.32, 1);
        border: 1px solid rgba(255,255,255,0.1);
        box-shadow: 0 20px 50px rgba(0,0,0,0.3);
        transform-style: preserve-3d;
        backdrop-filter: blur(10px);
    }

    .premium-card:hover {
        transform: translateY(-20px) rotateX(5deg);
        box-shadow: 0 50px 100px rgba(0,0,0,0.5);
        border-color: var(--brand-gold);
        background: rgba(45, 24, 16, 1);
    }

    .card-icon-3d {
        font-size: 3.5rem;
        margin-bottom: 30px;
        transform: translateZ(30px);
        display: inline-block;
    }

    .premium-card h3 {
        font-size: 2rem;
        font-weight: 900;
        margin-bottom: 20px;
        color: var(--brand-gold);
        transform: translateZ(20px);
    }

    .premium-card p {
        font-size: 1.1rem;
        color: rgba(255,255,255,0.8);
        margin-bottom: 30px;
        transform: translateZ(10px);
    }

    .premium-card ul {
        list-style: none;
        padding: 0;
        margin-bottom: 30px;
        transform: translateZ(15px);
    }
    .premium-card ul li {
        margin-bottom: 10px;
        color: rgba(255,255,255,0.7);
    }
    .premium-card ul li::before { content: '✦'; color: var(--brand-gold); margin-left: 10px; }

    .card-link {
        display: inline-block;
        padding: 10px 25px;
        border: 1px solid var(--brand-gold);
        border-radius: 50px;
        color: var(--brand-gold);
        text-decoration: none;
        font-weight: 700;
        transform: translateZ(20px);
        transition: 0.3s;
    }
    .card-link:hover {
        background: var(--brand-gold);
        color: var(--brand-brown);
    }

    /* ══════════════════════════════════════════════════════════════════════════════
       5. PORTFOLIO - FLOATING GALLERY
       ══════════════════════════════════════════════════════════════════════════════ */
    .section-portfolio {
        padding: 120px 20px;
        background: #FAF6F1;
        overflow: hidden;
    }

    .gallery-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
        gap: 30px;
        max-width: 1400px;
        margin: 0 auto;
    }

    .gallery-item {
        height: 400px;
        border-radius: 30px;
        position: relative;
        overflow: hidden;
        cursor: pointer;
        box-shadow: var(--shadow-card);
        transition: 0.5s;
    }
    .gallery-item:hover {
        transform: scale(1.03) translateY(-10px);
        box-shadow: var(--shadow-float);
        z-index: 2;
    }

    .gallery-img {
        width: 100%;
        height: 100%;
        background: linear-gradient(135deg, #ddd, #eee); /* Placeholder */
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 5rem;
        color: rgba(0,0,0,0.1);
    }

    .gallery-overlay {
        position: absolute;
        inset: 0;
        background: linear-gradient(to top, rgba(0,0,0,0.8), transparent);
        display: flex;
        flex-direction: column;
        justify-content: flex-end;
        padding: 30px;
        opacity: 0;
        transition: 0.5s;
    }
    .gallery-item:hover .gallery-overlay { opacity: 1; }

    .gallery-overlay h3 { color: white; font-size: 1.5rem; margin-bottom: 5px; font-weight: 800; }
    .gallery-overlay p { color: var(--brand-gold); font-weight: 600; }

    /* ══════════════════════════════════════════════════════════════════════════════
       6. PROCESS TIMELINE
       ══════════════════════════════════════════════════════════════════════════════ */
    .section-process {
        padding: 100px 20px;
        background: white;
    }

    .timeline-wrap {
        max-width: 1000px;
        margin: 0 auto;
        position: relative;
    }
    .timeline-wrap::before {
        content: '';
        position: absolute;
        left: 50%; top: 0; bottom: 0; width: 2px;
        background: #eee;
        transform: translateX(-50%);
    }

    .timeline-row {
        display: flex;
        justify-content: space-between;
        margin-bottom: 60px;
        position: relative;
    }
    
    .timeline-content {
        width: 45%;
        background: #FAF6F1;
        padding: 30px;
        border-radius: 20px;
        position: relative;
        transition: 0.3s;
        border: 1px solid transparent;
    }
    .timeline-content:hover {
        border-color: var(--brand-gold);
        box-shadow: var(--shadow-card);
        transform: scale(1.02);
    }

    .timeline-row:nth-child(odd) { flex-direction: row-reverse; }
    .timeline-row:nth-child(odd) .timeline-content { text-align: right; }
    
    .step-marker {
        position: absolute;
        left: 50%; top: 50%;
        transform: translate(-50%, -50%);
        width: 50px; height: 50px;
        background: var(--gradient-fire);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-weight: 900;
        box-shadow: 0 0 0 5px white, 0 0 0 8px #eee;
        z-index: 2;
    }

    /* ══════════════════════════════════════════════════════════════════════════════
       7. TESTIMONIALS
       ══════════════════════════════════════════════════════════════════════════════ */
    .section-testimonials {
        padding: 100px 20px;
        background: radial-gradient(circle at center, #4A2C1A 0%, #2D1810 100%);
        color: white;
        text-align: center;
    }
    .section-testimonials .section-head p { color: rgba(255,255,255,0.6); }
    .section-testimonials .section-head h2 { color: white; }

    .testi-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
        gap: 40px;
        max-width: 1200px;
        margin: 0 auto;
    }

    .testi-card {
        background: rgba(255,255,255,0.05);
        padding: 40px 30px;
        border-radius: 30px;
        border: 1px solid rgba(255,255,255,0.1);
        backdrop-filter: blur(5px);
        transition: 0.4s;
    }
    .testi-card:hover {
        background: rgba(255,255,255,0.1);
        transform: translateY(-10px);
        box-shadow: 0 20px 40px rgba(0,0,0,0.3);
    }
    
    .testi-text { font-size: 1.1rem; font-style: italic; margin-bottom: 20px; color: #eee; }
    .testi-author { font-weight: 800; color: var(--brand-gold); }
    .testi-role { font-size: 0.9rem; color: rgba(255,255,255,0.5); }

    /* ══════════════════════════════════════════════════════════════════════════════
       8. FAQ
       ══════════════════════════════════════════════════════════════════════════════ */
    .section-faq {
        padding: 100px 20px;
        background: #fff;
    }

    .faq-wrap {
        max-width: 800px;
        margin: 0 auto;
    }

    .accordion-item {
        margin-bottom: 15px;
        border: 1px solid #eee;
        border-radius: 15px;
        overflow: hidden;
        transition: 0.3s;
    }
    .accordion-item:hover { box-shadow: var(--shadow-card); border-color: var(--brand-gold); }

    .accordion-header {
        background: #FAF6F1;
        padding: 20px 25px;
        font-weight: 800;
        display: flex;
        justify-content: space-between;
        align-items: center;
        color: var(--brand-brown);
    }
    .accordion-header::after {
        content: '+';
        font-size: 1.5rem;
        color: var(--brand-orange);
        transition: 0.3s;
    }
    
    /* Simple hover interaction for now, js can toggle class */
    .accordion-item:hover .accordion-header::after { transform: rotate(45deg); }
    
    .accordion-body {
        padding: 25px;
        color: var(--text-body);
        display: none; /* Would be toggled by JS */
        background: white;
    }
    .accordion-item:hover .accordion-body { display: block; animation: fadeIn 0.5s; }

    @keyframes fadeIn { from{opacity:0;transform:translateY(-10px);} to{opacity:1;transform:translateY(0);} }

    /* ══════════════════════════════════════════════════════════════════════════════
       9. CTA
       ══════════════════════════════════════════════════════════════════════════════ */
    .section-cta {
        padding: 100px 20px;
        background: #fff;
        margin-top: -50px;
        position: relative;
        z-index: 20;
    }
    
    .cta-container {
        max-width: 1000px;
        margin: 0 auto;
        background: var(--gradient-fire);
        border-radius: 50px;
        padding: 80px 40px;
        text-align: center;
        color: white;
        box-shadow: 0 40px 80px rgba(255, 69, 0, 0.4);
        position: relative;
        overflow: hidden;
        transform: translateY(0);
        transition: 0.5s;
    }
    .cta-container:hover { transform: scale(1.02) translateY(-5px); }
    
    .btn-white {
        background: white;
        color: var(--brand-orange-hot);
        padding: 20px 60px;
        border-radius: 50px;
        font-weight: 900;
        font-size: 1.4rem;
        text-decoration: none;
        display: inline-block;
        box-shadow: 0 15px 30px rgba(0,0,0,0.2);
        transition: 0.3s;
    }
    .btn-white:hover { transform: scale(1.05); box-shadow: 0 20px 50px rgba(0,0,0,0.3); }

    /* ══════════════════════════════════════════════════════════════════════════════
       RESPONSIVE
       ══════════════════════════════════════════════════════════════════════════════ */
    @media (max-width: 768px) {
        .stats-bar { grid-template-columns: 1fr 1fr; gap: 20px; }
        .stat-item::after { display: none; }
        .timeline-wrap::before { left: 20px; }
        .timeline-row, .timeline-row:nth-child(odd) { flex-direction: column; padding-left: 50px; }
        .timeline-content { width: 100%; text-align: right !important; }
        .step-marker { left: 20px; right: auto; transform: translate(-50%, -50%); }
    }
</style>

<!-- 1. HERO -->
<section class="hero-section">
    <div class="hero-3d-bg">
        <div class="floating-shape shape-1"></div>
        <div class="floating-shape shape-2"></div>
        <div class="floating-shape shape-3"></div>
    </div>
    <div class="hero-content">
        <div class="hero-badge">
            <span>✨ خالق فضاهای نمایشگاهی مدرن</span>
        </div>
        <h1 class="hero-title">
            صحنه درخشش، <br>
            <span class="highlight">امپراطوری برند شما</span>
        </h1>
        <p class="hero-desc">
            ما معماری را با مارکتینگ ترکیب می‌کنیم تا غرفه‌ای بسازیم که نه تنها دیده شود،
            بلکه در ذهن مخاطب حک شود. از کانسپت تا اجرا، با استانداردهای جهانی.
        </p>
        <div class="hero-actions">
            <a href="contact" class="btn-hero btn-primary">
                <span>مشاوره رایگان ساخت</span>
                <svg width="24" height="24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M13 7l5 5m0 0l-5 5m5-5H6" stroke-linecap="round" stroke-linejoin="round"/></svg>
            </a>
            <a href="#portfolio" class="btn-hero btn-secondary">
                <span>دیدن نمونه کارها</span>
            </a>
        </div>
    </div>
</section>

<!-- 2. STATS STRIP -->
<div class="stats-container">
    <div class="stats-bar">
        <div class="stat-item">
            <span class="stat-num">+۳۰۰</span>
            <span class="stat-label">غرفه اجرا شده</span>
        </div>
        <div class="stat-item">
            <span class="stat-num">۱۲</span>
            <span class="stat-label">سال تجربه تخصصی</span>
        </div>
        <div class="stat-item">
            <span class="stat-num">۹۸٪</span>
            <span class="stat-label">رضایت مشتریان</span>
        </div>
        <div class="stat-item">
            <span class="stat-num">A+</span>
            <span class="stat-label">گرید نمایشگاهی</span>
        </div>
    </div>
</div>

<!-- 3. WHY US -->
<section class="section-why">
    <div class="section-head">
        <h2>چرا طراحان باستان؟</h2>
        <p>تفاوت ما در جزئیات، سرعت و تعهد به کیفیت است</p>
    </div>
    <div class="features-grid">
        <div class="feature-box">
            <div class="feature-icon">⏱</div>
            <h3>سرعت عمل بی‌نظیر</h3>
            <p>تحویل پروژه دقیقا سر وقت، بدون حتی یک ساعت تاخیر. ما ارزش زمان شما در نمایشگاه را می‌دانیم.</p>
        </div>
        <div class="feature-box">
            <div class="feature-icon">💎</div>
            <h3>متریال درجه یک</h3>
            <p>استفاده از بهترین چوب، رنگ و سازه‌های مدولار که جلوه‌ای لوکس و حرفه‌ای به برند شما می‌دهد.</p>
        </div>
        <div class="feature-box">
            <div class="feature-icon">💡</div>
            <h3>خلاقیت در طراحی</h3>
            <p>تیم معماری ما طرح‌هایی خلق می‌کند که در شلوغی نمایشگاه، نگاه‌ها را به سمت شما می‌چرخاند.</p>
        </div>
    </div>
</section>

<!-- 4. SERVICES (3D FLIP CARDS) -->
<div class="separator-wave">
    <svg viewBox="0 0 1440 100" preserveAspectRatio="none">
        <path d="M0,0 C480,100 960,100 1440,0 L1440,100 L0,100 Z"></path>
    </svg>
</div>
<section class="section-services" id="services">
    <div class="section-head">
        <h2>خدمات تخصصی ما</h2>
        <p>پوشش کامل تمام نیازهای نمایشگاهی شما در یک پکیج</p>
    </div>
    <div class="cards-container">
        <div class="premium-card">
            <div class="card-icon-3d">🏗️</div>
            <h3>غرفه‌سازی چوبی (Custom)</h3>
            <p>اوج هنر و معماری. مناسب برای برندهایی که می‌خواهند متمایز و خاص باشند.</p>
            <ul>
                <li>طراحی فرم‌های پیچیده و خاص</li>
                <li>رنگ‌آمیزی و نورپردازی دکوراتیو</li>
                <li>بدون محدودیت در اجرا</li>
            </ul>
            <a href="contact" class="card-link">سفارش طراحی</a>
        </div>
        <div class="premium-card">
            <div class="card-icon-3d">🧩</div>
            <h3>سازه ماکسیما (Maxima)</h3>
            <p>مدرن، سریع و اقتصادی. ترکیبی هوشمندانه از سرعت اجرا و زیبایی بصری.</p>
            <ul>
                <li>نصب بسیار سریع</li>
                <li>ساختار مدولار و منظم</li>
                <li>قابلیت استفاده از لایت‌باکس</li>
            </ul>
            <a href="contact" class="card-link">سفارش طراحی</a>
        </div>
        <div class="premium-card">
            <div class="card-icon-3d">🛋️</div>
            <h3>تجهیزات نمایشگاهی</h3>
            <p>تامین صفر تا صد ملزومات. از مبلمان VIP تا نمایشگرهای LED غول‌پیکر.</p>
            <ul>
                <li>اجاره مبلمان و میز کانتر</li>
                <li>سیستم‌های صوتی و تصویری</li>
                <li>کف‌سازی و گل‌آرایی</li>
            </ul>
            <a href="contact" class="card-link">لیست تجهیزات</a>
        </div>
    </div>
</section>

<!-- 5. PORTFOLIO -->
<section class="section-portfolio" id="portfolio">
    <div class="section-head">
        <h2>آثار ماندگار ما</h2>
        <p>منتخبی از پروژه‌های اجرا شده در نمایشگاه‌های بین‌المللی</p>
    </div>
    <div class="gallery-grid">
        <div class="gallery-item">
            <div class="gallery-img">🏢</div>
            <div class="gallery-overlay">
                <h3>غرفه پتروشیمی خلیج فارس</h3>
                <p>نمایشگاه نفت و گاز ۱۴۰۲</p>
            </div>
        </div>
        <div class="gallery-item">
            <div class="gallery-img">🚗</div>
            <div class="gallery-overlay">
                <h3>غرفه کرمان موتور</h3>
                <p>نمایشگاه خودرو اصفهان</p>
            </div>
        </div>
        <div class="gallery-item">
            <div class="gallery-img">💊</div>
            <div class="gallery-overlay">
                <h3>غرفه داروسازی عبیدی</h3>
                <p>نمایشگاه ایران فارما</p>
            </div>
        </div>
    </div>
</section>

<!-- 6. PROCESS TIMELINE -->
<section class="section-process">
    <div class="section-head">
        <h2>مسیر پروژه</h2>
        <p>شفافیت در تمام مراحل، از قرارداد تا تحویل کلید</p>
    </div>
    <div class="timeline-wrap">
        <div class="timeline-row">
            <div class="step-marker">1</div>
            <div class="timeline-content">
                <h3>مشاوره و نیازسنجی</h3>
                <p>بررسی اهداف، بودجه و مساحت غرفه شما برای ارائه بهترین راهکار.</p>
            </div>
        </div>
        <div class="timeline-row">
            <div class="step-marker">2</div>
            <div class="timeline-content">
                <h3>طراحی سه بعدی (3D)</h3>
                <p>ارائه طرح‌های اولیه و رندرهای واقع‌گرایانه برای تصور دقیق نهایی.</p>
            </div>
        </div>
        <div class="timeline-row">
            <div class="step-marker">3</div>
            <div class="timeline-content">
                <h3>ساخت و پیش‌تولید</h3>
                <p>ساخت قطعات در کارخانه مجهز ما با دقت بالا و متریال مرغوب.</p>
            </div>
        </div>
        <div class="timeline-row">
            <div class="step-marker">4</div>
            <div class="timeline-content">
                <h3>نصب و تحویل</h3>
                <p>مونتاژ نهایی در سالن نمایشگاه و تحویل به موقع قبل از افتتاحیه.</p>
            </div>
        </div>
    </div>
</section>

<!-- 7. TESTIMONIALS -->
<section class="section-testimonials">
    <div class="section-head">
        <h2>نظر مشتریان ما</h2>
        <p>افتخار ما، اعتماد برندهای بزرگ است</p>
    </div>
    <div class="testi-grid">
        <div class="testi-card">
            <p class="testi-text">"سرعت عمل تیم طراحان باستان باورنکردنی بود. غرفه ما دقیقا طبق طرح سه بعدی و سر وقت تحویل داده شد."</p>
            <div class="testi-author">مهندس رضایی</div>
            <div class="testi-role">مدیر مارکتینگ گروه مپنا</div>
        </div>
        <div class="testi-card">
            <p class="testi-text">"کیفیت ساخت و جزئیات اجرایی بسیار بالا بود. قطعا در نمایشگاه‌های بعدی هم با شما همکاری خواهیم کرد."</p>
            <div class="testi-author">خانم کریمی</div>
            <div class="testi-role">مدیر روابط عمومی کاله</div>
        </div>
        <div class="testi-card">
            <p class="testi-text">"خلاقیت در طراحی باعث شد غرفه ما متمایزترین غرفه سالن باشد. ممنون از انرژی خوب تیم شما."</p>
            <div class="testi-author">آقای محمدی</div>
            <div class="testi-role">مدیر عامل استارتاپ فین‌تک</div>
        </div>
    </div>
</section>

<!-- 8. FAQ -->
<section class="section-faq">
    <div class="section-head">
        <h2>سوالات متداول</h2>
        <p>پاسخ به دغدغه‌های شما</p>
    </div>
    <div class="faq-wrap">
        <div class="accordion-item">
            <div class="accordion-header">حداقل زمان مورد نیاز برای سفارش غرفه چقدر است؟</div>
            <div class="accordion-body">بهترین زمان ۲۰ روز قبل از نمایشگاه است، اما برای پروژه‌های فورس‌ماژور تا ۱۰ روز هم امکان‌پذیر است.</div>
        </div>
        <div class="accordion-item">
            <div class="accordion-header">آیا تجهیزات داخل غرفه هم تامین می‌کنید؟</div>
            <div class="accordion-body">بله، تمام تجهیزات شامل مبلمان، یخچال، آبسردکن، نمایشگر و... توسط ما تامین می‌شود.</div>
        </div>
        <div class="accordion-item">
            <div class="accordion-header">هزینه طراحی چقدر است؟</div>
            <div class="accordion-body">در صورت عقد قرارداد ساخت، هزینه طراحی کاملا رایگان خواهد بود.</div>
        </div>
    </div>
</section>

<!-- 9. CTA -->
<section class="section-cta">
    <div class="cta-container">
        <h2>نمایشگاه بعدی نزدیک است!</h2>
        <p style="margin-bottom: 40px; font-size: 1.2rem;">فرصت را از دست ندهید. همین حالا برای رزرو وقت طراحی اقدام کنید.</p>
        <a href="contact" class="btn-white">دریافت مشاوره و قیمت</a>
    </div>
</section>

<!-- No footer include as requested -->
