<?php require_once 'header.php'; ?>

<!-- Libraries -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" integrity="sha512-c42qTSw/wPZ3/5LBzD+Bw5f7bSF2oxou6wEb+I/lqeaKV5FDIfMvvRp772y4jcJLKuGUOpbJMdg/BTl50fJYAw==" crossorigin="anonymous" referrerpolicy="no-referrer">
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js" integrity="sha512-16ber5sF2mD3iJJp3w0mE0/m9fPQIlxhG1fXVfNv+NjvTd1e/6zBNPLO6elWxhA5xw0PdxZf9MlH7bOqIWJz3Q==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/ScrollTrigger.min.js" integrity="sha512-Ic9xkERjyZ1xgJ5svx3y0u3xrvfT/uPkV99LBwe68xjy/mGtO+4eURHZBW2xW4SZbFrF1Tf090XqB+EVgXnVjw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<style>
/* ══════════════════════════════════════════════════════════════════════════════
   TARAHAN BASTAN - CONTENT PRODUCTION: THE GOLDEN FRAME v6.1 (FIXED)
   ══════════════════════════════════════════════════════════════════════════════ */

:root {
    /* 🎨 PALETTE */
    --brand-brown: #2D1810;
    --brand-brown-light: #4A2C1A;
    --brand-gold: #D4A020;
    --brand-gold-light: #F5C518;
    --brand-orange: #FF4500;
    --brand-cream: #FAF6F1;
    --brand-white: #FFFFFF;
    
    /* 🖌 GRADIENTS */
    --grad-gold: linear-gradient(135deg, #D4A020 0%, #F5C518 100%);
    --grad-hero: linear-gradient(180deg, #FFFBF5 0%, #FAF6F1 100%);
    --grad-card: linear-gradient(145deg, #ffffff, #f5f5f5);
    /* Heroic Button Gradient from Index */
    --grad-btn: linear-gradient(135deg, #D4A020 0%, #E8A820 15%, #F58500 35%, #FF6B00 55%, #FF5500 75%, #FF6B00 100%);

    /* 🌑 SHADOWS */
    --shadow-sm: 0 5px 20px rgba(45, 24, 16, 0.05);
    --shadow-md: 0 10px 40px rgba(45, 24, 16, 0.08);
    --shadow-lg: 0 20px 60px rgba(45, 24, 16, 0.12);
    --shadow-gold: 0 10px 30px rgba(212, 160, 32, 0.35);
    
    /* 📐 SHAPES */
    --radius-md: 20px;
    --radius-lg: 40px;
    --radius-full: 100px;
}

/* 🛠 GLOBAL UTILS */
* { box-sizing: border-box; outline: none; }

body {
    background-color: var(--brand-cream);
    color: var(--brand-brown);
    font-family: 'YekanBakh', sans-serif;
    overflow-x: hidden;
    margin: 0;
    line-height: 1.7;
}

a { text-decoration: none; cursor: pointer; }
button { cursor: pointer; }

/* ══════════════════════════════════════════════════════════════════════════════
   1. HERO SECTION
   ══════════════════════════════════════════════════════════════════════════════ */
.hero-section {
    min-height: 100vh;
    position: relative;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 140px 20px 80px;
    background: var(--grad-hero);
    overflow: hidden;
}

/* Decorative Rings */
.hero-ring {
    position: absolute;
    border-radius: 50%;
    border: 1px solid rgba(212, 160, 32, 0.15);
    pointer-events: none;
    z-index: 0;
}
.ring-1 { width: 600px; height: 600px; animation: spin 60s linear infinite; }
.ring-2 { width: 900px; height: 900px; border-style: dashed; opacity: 0.5; animation: spin 80s linear infinite reverse; }
.ring-3 { width: 1200px; height: 1200px; opacity: 0.3; }

@keyframes spin { 100% { transform: rotate(360deg); } }

.hero-content {
    position: relative;
    z-index: 2;
    text-align: center;
    max-width: 900px;
}

.hero-badge {
    display: inline-flex;
    align-items: center;
    gap: 10px;
    padding: 10px 24px;
    background: white;
    border-radius: var(--radius-full);
    box-shadow: var(--shadow-sm);
    margin-bottom: 30px;
    border: 1px solid rgba(212, 160, 32, 0.3);
}

.hero-badge span {
    font-weight: 700;
    color: var(--brand-brown);
    font-size: 0.95rem;
}

.rec-dot {
    width: 10px;
    height: 10px;
    background: var(--brand-orange);
    border-radius: 50%;
    animation: pulse 1.5s infinite;
}
@keyframes pulse { 0% { opacity: 1; } 50% { opacity: 0.4; } 100% { opacity: 1; } }

.hero-title {
    font-size: clamp(2.8rem, 6vw, 4.5rem);
    font-weight: 900;
    line-height: 1.2;
    margin-bottom: 24px;
    color: var(--brand-brown);
}

.hero-title .highlight {
    color: var(--brand-orange);
    position: relative;
    display: inline-block;
    /* Solid color fix */
    background: none; 
    -webkit-text-fill-color: initial;
}

/* Underline decoration */
.hero-title .highlight::after {
    content: '';
    position: absolute;
    bottom: 5px;
    left: 0;
    width: 100%;
    height: 12px;
    background: rgba(255, 215, 0, 0.3);
    z-index: -1;
    border-radius: 10px;
    transform: rotate(-2deg);
}

.hero-desc {
    font-size: 1.2rem;
    color: #5A3825;
    max-width: 700px;
    margin: 0 auto 48px;
    font-weight: 500;
}

.hero-buttons {
    display: flex;
    gap: 20px;
    justify-content: center;
    flex-wrap: wrap; /* Better mobile wrapping */
}

/* New Button Style (From Index) */
.btn-main {
    display: inline-flex;
    align-items: center;
    gap: 12px;
    padding: 18px 45px;
    background: var(--grad-btn);
    background-size: 200% 100%;
    color: white;
    border-radius: var(--radius-full);
    font-weight: 800;
    font-size: 1.1rem;
    box-shadow: var(--shadow-gold);
    transition: all 0.4s ease;
    animation: btnFlow 4s ease-in-out infinite;
}

@keyframes btnFlow {
    0%, 100% { background-position: 0% 50%; }
    50% { background-position: 100% 50%; }
}

.btn-main:hover {
    transform: translateY(-5px);
    box-shadow: 0 20px 50px rgba(255, 107, 0, 0.4);
}

.btn-outline {
    display: inline-flex;
    align-items: center;
    gap: 12px;
    padding: 18px 45px;
    background: white;
    color: var(--brand-brown);
    border: 2px solid rgba(45, 24, 16, 0.1);
    border-radius: var(--radius-full);
    font-weight: 700;
    font-size: 1.1rem;
    transition: all 0.3s ease;
}

.btn-outline:hover {
    border-color: var(--brand-gold);
    color: var(--brand-gold);
    background: #FFFDF5;
    transform: translateY(-5px);
}

/* ══════════════════════════════════════════════════════════════════════════════
   2. STATS BAR (Floating)
   ══════════════════════════════════════════════════════════════════════════════ */
.stats-section {
    position: relative;
    z-index: 5;
    margin-top: -50px;
    padding: 0 20px;
}

.stats-box {
    max-width: 1100px;
    margin: 0 auto;
    background: white;
    border-radius: var(--radius-lg);
    box-shadow: var(--shadow-md);
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    padding: 40px;
    border: 1px solid rgba(0,0,0,0.03);
}

.stat-item {
    text-align: center;
    position: relative;
}

.stat-item:not(:last-child)::after {
    content: '';
    position: absolute;
    left: 0; top: 20%; bottom: 20%; width: 1px;
    background: #eee;
}

.stat-num {
    display: block;
    font-size: 2.5rem;
    font-weight: 900;
    color: var(--brand-orange);
    line-height: 1;
    margin-bottom: 5px;
}

.stat-label {
    font-size: 0.95rem;
    color: #888;
    font-weight: 700;
}

/* ══════════════════════════════════════════════════════════════════════════════
   3. SERVICES GRID (Modern Cards)
   ══════════════════════════════════════════════════════════════════════════════ */
.services-section {
    padding: 120px 20px;
    background: white;
}

.section-head {
    text-align: center;
    margin-bottom: 60px;
}

.section-title {
    font-size: 2.5rem;
    font-weight: 900;
    margin-bottom: 15px;
    color: var(--brand-brown);
}

.section-subtitle {
    color: #666;
    font-size: 1.1rem;
}

.services-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
    gap: 30px;
    max-width: 1200px;
    margin: 0 auto;
}

.service-card {
    background: #FFFFFF;
    border-radius: var(--radius-md);
    padding: 40px 30px;
    border: 1px solid #f0f0f0;
    transition: all 0.4s ease;
    position: relative;
    overflow: hidden;
    box-shadow: var(--shadow-sm);
}

.service-card:hover {
    transform: translateY(-10px);
    box-shadow: var(--shadow-lg);
    border-color: var(--brand-gold);
}

.card-icon {
    width: 70px;
    height: 70px;
    background: #FFF9F0;
    border-radius: 20px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 25px;
    transition: 0.4s;
}

.service-card:hover .card-icon {
    background: var(--brand-gold);
    transform: rotate(-10deg);
}

.card-icon svg {
    width: 32px;
    height: 32px;
    color: var(--brand-gold);
    transition: 0.4s;
}

.service-card:hover .card-icon svg { color: white; }

.service-card h3 {
    font-size: 1.4rem;
    font-weight: 800;
    margin-bottom: 15px;
    color: var(--brand-brown);
}

.service-card p {
    color: #666;
    line-height: 1.8;
    margin-bottom: 25px;
}

.card-tags {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
}

.tag {
    background: #F5F5F5;
    padding: 5px 12px;
    border-radius: 8px;
    font-size: 0.8rem;
    font-weight: 600;
    color: #555;
}

/* ══════════════════════════════════════════════════════════════════════════════
   4. FEATURED PROJECT (The Player)
   ══════════════════════════════════════════════════════════════════════════════ */
.project-section {
    padding: 100px 20px;
    background: var(--brand-brown);
    color: white;
    position: relative;
}

.project-container {
    max-width: 1100px;
    margin: 0 auto;
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 60px;
    align-items: center;
}

.video-mockup {
    position: relative;
    border-radius: var(--radius-md);
    overflow: hidden;
    box-shadow: var(--shadow-lg);
    border: 4px solid rgba(255,255,255,0.1);
}

.video-thumb {
    width: 100%;
    height: auto;
    display: block;
    transition: 0.5s;
}

.video-mockup:hover .video-thumb { transform: scale(1.05); }

.play-overlay {
    position: absolute;
    inset: 0;
    background: rgba(0,0,0,0.3);
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
}

.play-btn {
    width: 80px;
    height: 80px;
    background: rgba(255,255,255,0.2);
    backdrop-filter: blur(10px);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    border: 2px solid rgba(255,255,255,0.5);
    transition: 0.3s;
}

.play-btn svg { width: 30px; height: 30px; fill: white; margin-left: 5px; }
.play-btn:hover { transform: scale(1.1); background: var(--brand-gold); border-color: var(--brand-gold); }

.project-content h2 {
    font-size: 2.5rem;
    font-weight: 900;
    margin-bottom: 20px;
    color: var(--brand-gold-light);
}

.project-content p {
    font-size: 1.1rem;
    color: rgba(255,255,255,0.8);
    margin-bottom: 30px;
    line-height: 1.8;
}

.project-stats {
    display: flex;
    gap: 40px;
    border-top: 1px solid rgba(255,255,255,0.1);
    padding-top: 20px;
}

.p-stat strong { display: block; font-size: 1.8rem; color: white; }
.p-stat span { font-size: 0.9rem; color: rgba(255,255,255,0.5); }

/* ══════════════════════════════════════════════════════════════════════════════
   5. PROCESS (Vertical Steps)
   ══════════════════════════════════════════════════════════════════════════════ */
.process-section {
    padding: 120px 20px;
    background: var(--brand-cream);
}

.process-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 30px;
    max-width: 1200px;
    margin: 0 auto;
}

.process-step {
    background: white;
    padding: 30px 24px;
    border-radius: var(--radius-md);
    text-align: center;
    position: relative;
    transition: 0.3s;
    box-shadow: var(--shadow-sm);
}

.process-step:hover { transform: translateY(-10px); box-shadow: var(--shadow-md); }

.step-num {
    width: 40px;
    height: 40px;
    background: var(--brand-brown);
    color: white;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 800;
    margin: 0 auto 20px;
    position: relative;
    z-index: 2;
}

.step-icon-box {
    font-size: 2.5rem;
    margin-bottom: 15px;
    color: var(--brand-gold);
}

.process-step h4 { font-size: 1.2rem; font-weight: 800; margin-bottom: 10px; color: var(--brand-brown); }
.process-step p { font-size: 0.9rem; color: #666; }

/* ══════════════════════════════════════════════════════════════════════════════
   6. EQUIPMENT & WHY US
   ══════════════════════════════════════════════════════════════════════════════ */
.equipment-section {
    padding: 100px 20px;
    background: white;
}

.equip-container {
    max-width: 1000px;
    margin: 0 auto;
    text-align: center;
}

.equip-tags {
    display: flex;
    justify-content: center;
    flex-wrap: wrap;
    gap: 15px;
    margin-top: 40px;
}

.equip-tag {
    padding: 15px 30px;
    background: #F9F9F9;
    border-radius: var(--radius-full);
    font-weight: 700;
    color: #555;
    border: 1px solid #eee;
    transition: 0.3s;
}

.equip-tag:hover {
    background: var(--brand-brown);
    color: white;
    transform: scale(1.05);
}

/* ══════════════════════════════════════════════════════════════════════════════
   7. TESTIMONIALS
   ══════════════════════════════════════════════════════════════════════════════ */
.testi-section {
    padding: 100px 20px;
    background: var(--brand-cream);
}

.testi-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 30px;
    max-width: 1200px;
    margin: 0 auto;
}

.testi-card {
    background: white;
    padding: 30px;
    border-radius: var(--radius-md);
    box-shadow: var(--shadow-sm);
    border: 1px solid rgba(0,0,0,0.02);
}

.testi-header {
    display: flex;
    align-items: center;
    gap: 15px;
    margin-bottom: 20px;
}

.testi-avatar {
    width: 50px;
    height: 50px;
    background: #ddd;
    border-radius: 50%;
}

.testi-info h5 { margin: 0; font-size: 1rem; color: var(--brand-brown); }
.testi-info span { font-size: 0.8rem; color: #888; }

.testi-body p {
    font-size: 0.95rem;
    color: #555;
    font-style: italic;
}

/* ══════════════════════════════════════════════════════════════════════════════
   8. FAQ
   ══════════════════════════════════════════════════════════════════════════════ */
.faq-section {
    padding: 100px 20px;
    background: linear-gradient(180deg, #FDFBF9 0%, #F5EBE0 100%);
}

.faq-section h2 {
    text-align: center;
    font-size: clamp(1.8rem, 4vw, 2.5rem);
    color: var(--brand-brown);
    margin-bottom: 50px;
}

.faq-wrapper {
    max-width: 850px;
    margin: 0 auto;
}

.faq-item {
    background: white;
    border-radius: 16px;
    margin-bottom: 16px;
    box-shadow: 0 4px 15px rgba(0,0,0,0.05);
    overflow: hidden;
    border: 1px solid rgba(212, 160, 32, 0.1);
    transition: all 0.3s ease;
}

.faq-item:hover {
    box-shadow: 0 8px 25px rgba(0,0,0,0.08);
    border-color: rgba(212, 160, 32, 0.2);
}

.faq-item.active {
    border-color: var(--brand-gold);
    box-shadow: 0 8px 25px rgba(212, 160, 32, 0.15);
}

.faq-header {
    padding: 22px 26px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    cursor: pointer;
    font-size: 1.05rem;
    font-weight: 700;
    color: var(--brand-brown);
    transition: 0.3s;
    gap: 15px;
}

.faq-header:hover { color: var(--brand-gold); }

.faq-icon {
    min-width: 30px;
    width: 30px;
    height: 30px;
    border-radius: 50%;
    background: linear-gradient(135deg, var(--brand-gold), #E8B830);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.2rem;
    color: var(--brand-brown);
    font-weight: 700;
    transition: 0.3s;
}

.faq-item.active .faq-icon {
    transform: rotate(45deg);
    background: var(--brand-gold);
    color: white;
}

.faq-body {
    max-height: 0;
    overflow: hidden;
    transition: all 0.4s ease;
    color: #5A3825;
    line-height: 2;
    font-size: 0.98rem;
}

.faq-item.active .faq-body {
    max-height: 500px;
    padding: 0 26px 26px 26px;
}

/* ══════════════════════════════════════════════════════════════════════════════
   9. CTA
   ══════════════════════════════════════════════════════════════════════════════ */
.cta-section {
    padding: 80px 20px;
    background: var(--brand-cream);
}

.cta-box {
    max-width: 1000px;
    margin: 0 auto;
    background: var(--brand-brown);
    border-radius: var(--radius-lg);
    padding: 60px 40px;
    text-align: center;
    color: white;
    position: relative;
    overflow: hidden;
    box-shadow: var(--shadow-lg);
}

.cta-box::after {
    content: '';
    position: absolute;
    top: 0; right: 0; width: 300px; height: 300px;
    background: radial-gradient(circle, rgba(212, 160, 32, 0.2) 0%, transparent 70%);
    border-radius: 50%;
    transform: translate(30%, -30%);
}

.cta-title {
    font-size: 2.2rem;
    font-weight: 900;
    margin-bottom: 20px;
}

.cta-btn {
    display: inline-block;
    /* Updated button style */
    background: var(--grad-btn);
    background-size: 200% 100%;
    color: white;
    padding: 15px 45px;
    border-radius: var(--radius-full);
    font-weight: 800;
    margin-top: 30px;
    transition: 0.3s;
    box-shadow: var(--shadow-gold);
    animation: btnFlow 4s ease-in-out infinite;
}

.cta-btn:hover {
    transform: scale(1.05);
    box-shadow: 0 15px 40px rgba(255, 107, 0, 0.4);
}

/* ══════════════════════════════════════════════════════════════════════════════
   📱 RESPONSIVE
   ══════════════════════════════════════════════════════════════════════════════ */
@media (max-width: 1024px) {
    .stats-box { grid-template-columns: repeat(2, 1fr); gap: 30px; }
    .stat-item:not(:last-child)::after { display: none; }
    .project-container { grid-template-columns: 1fr; text-align: center; }
    .project-stats { justify-content: center; }
    .process-grid { grid-template-columns: repeat(2, 1fr); }
}

@media (max-width: 768px) {
    .hero-section { padding-top: 120px; padding-bottom: 60px; }
    .hero-title { font-size: 2.5rem; }
    .hero-buttons { flex-direction: column; }
    .btn-main, .btn-outline { width: 100%; justify-content: center; }
    
    .stats-box { grid-template-columns: 1fr; }
    
    .services-grid { grid-template-columns: 1fr; }
    
    .project-section { padding: 60px 20px; }
    .project-content h2 { font-size: 2rem; }
    
    .process-grid { grid-template-columns: 1fr; }
    
    .testi-grid { grid-template-columns: 1fr; }
    
    .cta-box { padding: 40px 20px; }
    .cta-title { font-size: 1.8rem; }
}
</style>

<div class="content-page">

    <!-- 1. HERO -->
    <section class="hero-section">
        <div class="hero-ring ring-1"></div>
        <div class="hero-ring ring-2"></div>
        <div class="hero-ring ring-3"></div>
        
        <div class="hero-content">
            <div class="hero-badge wow fadeInDown">
                <div class="rec-dot"></div>
                <span>استودیو تولید محتوا طراحان باستان</span>
            </div>
            
            <h1 class="hero-title wow fadeInUp">
                داستان برند شما، <br>
                <span class="highlight">روایت طلایی</span>
            </h1>
            
            <p class="hero-desc wow fadeInUp" data-wow-delay="0.2s">
                ما صدای شما را به تصویر می‌کشیم. ساخت تیزرهای تبلیغاتی، موشن گرافیک و عکاسی صنعتی با استانداردهای جهانی و نگاهی خلاقانه.
            </p>
            
            <div class="hero-buttons wow fadeInUp" data-wow-delay="0.4s">
                <a href="<?php echo URL; ?>/contact" class="btn-main">
                    شروع پروژه جدید
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>
                </a>
                <a href="#portfolio" class="btn-outline">نمونه کارها</a>
            </div>
        </div>
    </section>

    <!-- 2. STATS -->
    <div class="stats-section">
        <div class="stats-box wow fadeInUp">
            <div class="stat-item">
                <span class="stat-num">+۵۰۰</span>
                <span class="stat-label">دقیقه تیزر تولید شده</span>
            </div>
            <div class="stat-item">
                <span class="stat-num">4K</span>
                <span class="stat-label">کیفیت ضبط تصاویر</span>
            </div>
            <div class="stat-item">
                <span class="stat-num">۱۰۰٪</span>
                <span class="stat-label">تجهیزات اختصاصی</span>
            </div>
            <div class="stat-item">
                <span class="stat-num">+۵۰</span>
                <span class="stat-label">برند همکار</span>
            </div>
        </div>
    </div>

    <!-- 3. SERVICES -->
    <section class="services-section">
        <div class="container">
            <div class="section-head">
                <h2 class="section-title">خدمات استودیو</h2>
                <p class="section-subtitle">پکیج کامل تولید محتوا برای رشد کسب‌وکار شما</p>
            </div>
            
            <div class="services-grid">
                <!-- Service 1 -->
                <div class="service-card wow fadeInUp" data-wow-delay="0.1s">
                    <div class="card-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" /></svg>
                    </div>
                    <h3>تیزر تبلیغاتی</h3>
                    <p>سناریو‌نویسی خلاقانه و ساخت ویدیوهای تبلیغاتی با اثرگذاری بالا برای شبکه‌های اجتماعی و تلویزیون.</p>
                    <div class="card-tags">
                        <span class="tag">رئال</span>
                        <span class="tag">معرفی محصول</span>
                    </div>
                </div>

                <!-- Service 2 -->
                <div class="service-card wow fadeInUp" data-wow-delay="0.2s">
                    <div class="card-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M19.428 15.428a2 2 0 00-1.022-.547l-2.384-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" /></svg>
                    </div>
                    <h3>موشن گرافیک</h3>
                    <p>انیمیشن‌های گرافیکی جذاب برای توضیح فرآیندها یا معرفی خدمات پیچیده به زبانی ساده.</p>
                    <div class="card-tags">
                        <span class="tag">دو بعدی</span>
                        <span class="tag">لوگو موشن</span>
                    </div>
                </div>

                <!-- Service 3 -->
                <div class="service-card wow fadeInUp" data-wow-delay="0.3s">
                    <div class="card-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" /><path stroke-linecap="round" stroke-linejoin="round" d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
                    </div>
                    <h3>عکاسی صنعتی</h3>
                    <p>عکاسی حرفه‌ای از محصولات، خط تولید و فضای کسب‌وکار شما با نورپردازی استودیویی.</p>
                    <div class="card-tags">
                        <span class="tag">360 درجه</span>
                        <span class="tag">کاتالوگ</span>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- 4. FEATURED PROJECT -->
    <section class="project-section" id="portfolio">
        <div class="project-container">
            <div class="video-mockup wow fadeInLeft">
                <img src="public/images/hamedan2018.jpg" alt="مستند میراث کهن" class="video-thumb">
                <div class="play-overlay">
                    <div class="play-btn">
                        <svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"></path></svg>
                    </div>
                </div>
            </div>
            
            <div class="project-content wow fadeInRight">
                <h2>مستند "میراث کهن"</h2>
                <p>
                    این پروژه با هدف معرفی جاذبه‌های گردشگری استان همدان به سفارش سازمان میراث فرهنگی تولید شد. 
                    استفاده از تصاویر هوایی (هلی‌شات)، تایم‌لپس‌های طولانی و موسیقی اختصاصی، این اثر را به یکی از پربازدیدترین مستندهای سال تبدیل کرد.
                </p>
                <div class="project-stats">
                    <div class="p-stat">
                        <strong>۱۵</strong>
                        <span>روز تصویربرداری</span>
                    </div>
                    <div class="p-stat">
                        <strong>۴K</strong>
                        <span>کیفیت نهایی</span>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- 5. PROCESS -->
    <section class="process-section">
        <div class="container">
            <div class="section-head">
                <h2 class="section-title">روند تولید محتوا</h2>
                <p class="section-subtitle">از ایده خام تا خروجی نهایی</p>
            </div>
            
            <div class="process-grid">
                <div class="process-step wow fadeInUp">
                    <div class="step-num">۱</div>
                    <div class="step-icon-box">💡</div>
                    <h4>سناریو و ایده</h4>
                    <p>نگارش متن و استوری‌بورد دقیق بر اساس هدف تبلیغات.</p>
                </div>
                <div class="process-step wow fadeInUp" data-wow-delay="0.1s">
                    <div class="step-num">۲</div>
                    <div class="step-icon-box">🎥</div>
                    <h4>تصویربرداری</h4>
                    <p>ضبط تصاویر با دوربین‌های سینمایی و تجهیزات نورپردازی.</p>
                </div>
                <div class="process-step wow fadeInUp" data-wow-delay="0.2s">
                    <div class="step-num">۳</div>
                    <div class="step-icon-box">💻</div>
                    <h4>تدوین و صدا</h4>
                    <p>مونتاژ، اصلاح رنگ، صداگذاری و افزودن جلوه‌های ویژه.</p>
                </div>
                <div class="process-step wow fadeInUp" data-wow-delay="0.3s">
                    <div class="step-num">۴</div>
                    <div class="step-icon-box">🚀</div>
                    <h4>خروجی نهایی</h4>
                    <p>تحویل فایل با فرمت‌های استاندارد وب و تلویزیون.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- 6. EQUIPMENT -->
    <section class="equipment-section">
        <div class="equip-container">
            <h2 class="section-title" style="font-size: 2rem;">تجهیزات حرفه‌ای ما</h2>
            <p style="color: #666;">ما از ابزارهای روز دنیا برای خلق بهترین کیفیت استفاده می‌کنیم</p>
            
            <div class="equip-tags wow fadeInUp">
                <div class="equip-tag">Sony Alpha 7S III</div>
                <div class="equip-tag">DJI Mavic 2 Pro</div>
                <div class="equip-tag">Ronin RS2 Gimbal</div>
                <div class="equip-tag">Godox Lighting</div>
                <div class="equip-tag">Sennheiser Audio</div>
                <div class="equip-tag">DaVinci Resolve</div>
            </div>
        </div>
    </section>

    <!-- 7. TESTIMONIALS -->
    <section class="testi-section">
        <div class="container">
            <div class="section-head">
                <h2 class="section-title">نظر مشتریان</h2>
            </div>
            
            <div class="testi-grid">
                <div class="testi-card wow fadeInUp">
                    <div class="testi-header">
                        <div class="testi-avatar" style="background-color: #D4A020;"></div>
                        <div class="testi-info">
                            <h5>آقای حسینی</h5>
                            <span>مدیر عامل شرکت تکنو</span>
                        </div>
                    </div>
                    <div class="testi-body">
                        <p>"تیزری که برای ما ساختید بازخورد فوق‌العاده‌ای در اینستاگرام داشت. ممنون از خلاقیت تیم خوبتون."</p>
                    </div>
                </div>
                
                <div class="testi-card wow fadeInUp" data-wow-delay="0.1s">
                    <div class="testi-header">
                        <div class="testi-avatar" style="background-color: #2D1810;"></div>
                        <div class="testi-info">
                            <h5>خانم راد</h5>
                            <span>مدیر مارکتینگ</span>
                        </div>
                    </div>
                    <div class="testi-body">
                        <p>"کیفیت عکاسی صنعتی از محصولات ما دقیقاً همون چیزی بود که برای کاتالوگ جدید نیاز داشتیم."</p>
                    </div>
                </div>
                
                <div class="testi-card wow fadeInUp" data-wow-delay="0.2s">
                    <div class="testi-header">
                        <div class="testi-avatar" style="background-color: #FF4500;"></div>
                        <div class="testi-info">
                            <h5>مهندس نوری</h5>
                            <span>سازمان میراث فرهنگی</span>
                        </div>
                    </div>
                    <div class="testi-body">
                        <p>"صبر و حوصله شما در پروسه تدوین و اعمال اصلاحات واقعاً جای تقدیر داره. نتیجه عالی شد."</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- 8. FAQ -->
    <section class="faq-section">
        <div class="container">
            <div class="section-head">
                <h2 class="section-title">سوالات متداول</h2>
            </div>
            
            <div class="faq-wrapper">
                <div class="faq-item wow fadeInUp">
                    <div class="faq-header">
                        هزینه ساخت تیزر تبلیغاتی چقدر است؟
                        <div class="faq-icon">+</div>
                    </div>
                    <div class="faq-body">
                        هزینه بسته به سناریو، تعداد روزهای تصویربرداری، تجهیزات مورد نیاز و وجود بازیگر متغیر است. پس از مشاوره اولیه، پیش‌فاکتور دقیق صادر می‌شود.
                    </div>
                </div>
                
                <div class="faq-item wow fadeInUp" data-wow-delay="0.1s">
                    <div class="faq-header">
                        زمان تحویل پروژه چقدر طول می‌کشد؟
                        <div class="faq-icon">+</div>
                    </div>
                    <div class="faq-body">
                        پروژه‌های ساده مثل عکاسی یا موشن‌گرافیک کوتاه معمولاً ۳ تا ۷ روز کاری، و پروژه‌های تصویربرداری سنگین بین ۱۰ تا ۲۰ روز زمان نیاز دارند.
                    </div>
                </div>
                
                <div class="faq-item wow fadeInUp" data-wow-delay="0.2s">
                    <div class="faq-header">
                        آیا سناریو را هم شما می‌نویسید؟
                        <div class="faq-icon">+</div>
                    </div>
                    <div class="faq-body">
                        بله، تیم ایده‌پردازی ما بر اساس نیاز شما و تحلیل رقبا، چندین سناریوی پیشنهادی را ارائه می‌دهد تا بهترین گزینه را انتخاب کنید.
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- 9. CTA -->
    <section class="cta-section">
        <div class="cta-box wow zoomIn">
            <h2 class="cta-title">وقت دیده شدن است!</h2>
            <p class="cta-desc">همین حالا تماس بگیرید تا ایده‌های شما را به تصویر بکشیم. مشاوره کاملاً رایگان است.</p>
            <a href="<?php echo URL; ?>/contact" class="cta-btn">شروع همکاری</a>
        </div>
    </section>

</div>

<script>
    // Init Animations
    new WOW().init();

    // FAQ Logic
    document.querySelectorAll('.faq-header').forEach(header => {
        header.addEventListener('click', () => {
            const item = header.parentElement;
            const body = item.querySelector('.faq-body');
            
            // Close others
            document.querySelectorAll('.faq-item').forEach(i => {
                if(i !== item) {
                    i.classList.remove('active');
                    i.querySelector('.faq-body').style.maxHeight = null;
                }
            });

            item.classList.toggle('active');
            if(item.classList.contains('active')) {
                body.style.maxHeight = body.scrollHeight + "px";
            } else {
                body.style.maxHeight = null;
            }
        });
    });
</script>
