<?php require_once 'header.php'; ?>

<style>
    /* ══════════════════════════════════════════════════════════════════════════════
       TARAHAN BASTAN - ADS SERVICE PAGE - HEROIC 3D v3.0
       طراحی اختصاصی با عمق میدان و انرژی بالا
       ══════════════════════════════════════════════════════════════════════════════ */

    :root {
        /* ═══ BRAND COLORS ═══ */
        --brand-brown: #2D1810;
        --brand-brown-dark: #1A0D08;
        --brand-gold: #D4A020;
        --brand-gold-bright: #FFD700;
        --brand-orange: #F58500;
        --brand-orange-hot: #FF4500;
        
        /* ═══ GRADIENTS ═══ */
        --gradient-hero: linear-gradient(135deg, #2D1810 0%, #4A2C1A 100%);
        --gradient-gold: linear-gradient(45deg, #D4A020, #F5C518, #FFD700, #D4A020);
        --gradient-fire: linear-gradient(45deg, #FF4500, #FF6B00, #FF9500);
        --gradient-glass: linear-gradient(145deg, rgba(255,255,255,0.9), rgba(255,255,255,0.6));
        
        /* ═══ DEPTH & SHADOWS ═══ */
        --shadow-card: 0 15px 35px rgba(45, 24, 16, 0.1);
        --shadow-float: 0 30px 60px rgba(45, 24, 16, 0.2);
        --shadow-text: 0 10px 20px rgba(0,0,0,0.15);
        --shadow-glow: 0 0 50px rgba(212, 160, 32, 0.3);
    }

    /* ═══ GLOBAL RESET & CURSOR FIX ═══ */
    * {
        box-sizing: border-box;
        cursor: auto !important; /* Fix cursor hiding issue */
    }
    
    a, button, .btn, .card-hover {
        cursor: pointer !important;
    }

    body {
        background: #FAF6F1;
        color: var(--brand-brown);
        font-family: 'YekanBakh', sans-serif;
        overflow-x: hidden;
        margin: 0;
        perspective: 1000px; /* Global perspective for 3D effects */
    }

    /* ══════════════════════════════════════════════════════════════════════════════
       1. HERO SECTION - 3D & ENERGETIC
       ══════════════════════════════════════════════════════════════════════════════ */
    .hero-section {
        min-height: 100vh;
        position: relative;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 140px 20px 100px;
        background: radial-gradient(circle at 50% 30%, #FFFEFB 0%, #F4EBE0 100%);
        overflow: hidden;
        transform-style: preserve-3d;
    }

    /* 3D Background Elements */
    .hero-3d-bg {
        position: absolute;
        inset: 0;
        transform-style: preserve-3d;
        pointer-events: none;
    }
    
    .floating-shape {
        position: absolute;
        border-radius: 30px;
        background: linear-gradient(135deg, rgba(255,255,255,0.8), rgba(255,255,255,0.2));
        border: 1px solid rgba(212, 160, 32, 0.2);
        backdrop-filter: blur(10px);
        box-shadow: var(--shadow-float);
        animation: float3D 10s ease-in-out infinite;
    }

    .shape-1 { width: 300px; height: 300px; top: 10%; left: -5%; transform: rotateY(20deg) rotateX(10deg); animation-delay: 0s; }
    .shape-2 { width: 200px; height: 200px; bottom: 15%; right: -2%; transform: rotateY(-20deg) rotateX(10deg); animation-delay: 2s; background: linear-gradient(135deg, rgba(212, 160, 32, 0.1), rgba(255, 255, 255, 0.4)); }
    .shape-3 { width: 100px; height: 100px; top: 20%; right: 15%; border-radius: 50%; animation-delay: 4s; background: var(--gradient-gold); opacity: 0.2; filter: blur(20px); }

    @keyframes float3D {
        0%, 100% { transform: translateY(0) rotateY(20deg) rotateX(10deg); }
        50% { transform: translateY(-30px) rotateY(25deg) rotateX(5deg); }
    }

    .hero-content {
        position: relative;
        z-index: 10;
        text-align: center;
        max-width: 1100px;
        transform: translateZ(50px); /* Pull content forward */
    }

    .hero-badge {
        display: inline-flex;
        align-items: center;
        gap: 10px;
        padding: 12px 30px;
        background: white;
        border-radius: 50px;
        box-shadow: 0 10px 30px rgba(212, 160, 32, 0.2);
        margin-bottom: 30px;
        border: 2px solid var(--brand-gold);
        animation: popIn 0.8s cubic-bezier(0.175, 0.885, 0.32, 1.275);
    }
    .hero-badge span {
        font-weight: 900;
        background: var(--gradient-fire);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
        font-size: 1.1rem;
    }

    .hero-title {
        font-size: clamp(3.5rem, 8vw, 6rem);
        font-weight: 900;
        line-height: 1;
        margin-bottom: 30px;
        color: var(--brand-brown);
        text-shadow: 2px 2px 0px rgba(255,255,255,0.5), var(--shadow-text);
    }
    
    .hero-title .highlight {
        background: var(--gradient-gold);
        background-size: 200% auto;
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
        animation: shine 3s linear infinite;
        display: inline-block;
    }

    @keyframes shine {
        to { background-position: 200% center; }
    }

    .hero-desc {
        font-size: clamp(1.2rem, 2.5vw, 1.6rem);
        color: var(--text-secondary);
        max-width: 800px;
        margin: 0 auto 50px;
        font-weight: 500;
        line-height: 1.6;
        text-shadow: 0 2px 10px rgba(255,255,255,0.8);
    }

    .hero-actions {
        display: flex;
        justify-content: center;
        gap: 24px;
        perspective: 1000px;
    }

    .btn-hero {
        position: relative;
        padding: 22px 56px;
        border-radius: 60px;
        font-weight: 900;
        font-size: 1.3rem;
        text-decoration: none;
        transition: all 0.4s cubic-bezier(0.34, 1.56, 0.64, 1);
        overflow: hidden;
        display: inline-flex;
        align-items: center;
        gap: 15px;
    }

    .btn-primary {
        background: var(--gradient-fire);
        color: white;
        box-shadow: 0 20px 40px rgba(255, 69, 0, 0.3);
        border: 2px solid transparent;
    }
    .btn-primary::before {
        content: '';
        position: absolute;
        top: 0; left: -100%; width: 100%; height: 100%;
        background: linear-gradient(90deg, transparent, rgba(255,255,255,0.4), transparent);
        transition: 0.5s;
    }
    .btn-primary:hover::before { left: 100%; }
    .btn-primary:hover {
        transform: translateY(-8px) scale(1.05);
        box-shadow: 0 30px 60px rgba(255, 69, 0, 0.5);
    }

    .btn-secondary {
        background: white;
        color: var(--brand-brown);
        border: 2px solid var(--brand-gold);
        box-shadow: 0 10px 30px rgba(0,0,0,0.05);
    }
    .btn-secondary:hover {
        background: var(--brand-gold);
        color: white;
        transform: translateY(-8px) scale(1.05);
        box-shadow: 0 20px 50px rgba(212, 160, 32, 0.4);
    }

    /* ══════════════════════════════════════════════════════════════════════════════
       2. 3D SECTION SEPARATOR
       ══════════════════════════════════════════════════════════════════════════════ */
    .separator-3d {
        height: 150px;
        margin-top: -100px;
        position: relative;
        z-index: 20;
        overflow: hidden;
    }
    .separator-3d svg {
        width: 100%;
        height: 100%;
        fill: #FBF7F1; /* Match next section bg */
        filter: drop-shadow(0 -10px 20px rgba(0,0,0,0.05));
    }

    /* ══════════════════════════════════════════════════════════════════════════════
       3. CARDS SECTION - DEPTH & GLASS
       ══════════════════════════════════════════════════════════════════════════════ */
    .section-cards {
        background: #FBF7F1;
        padding: 100px 20px 160px;
        position: relative;
    }

    .section-head {
        text-align: center;
        margin-bottom: 100px;
    }
    .section-head h2 {
        font-size: 3.5rem;
        font-weight: 900;
        color: var(--brand-brown);
        margin-bottom: 20px;
    }
    .section-head p {
        font-size: 1.4rem;
        color: var(--text-body);
        max-width: 700px;
        margin: 0 auto;
    }

    .cards-container {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
        gap: 50px;
        max-width: 1400px;
        margin: 0 auto;
        perspective: 1500px;
    }

    .premium-card {
        background: var(--gradient-glass);
        border-radius: 40px;
        padding: 50px 40px;
        position: relative;
        transition: all 0.6s cubic-bezier(0.23, 1, 0.32, 1);
        border: 1px solid rgba(255,255,255,0.8);
        box-shadow: var(--shadow-card);
        transform-style: preserve-3d;
    }

    /* 3D Hover Effect */
    .premium-card:hover {
        transform: translateY(-20px) rotateX(5deg) rotateY(-2deg);
        box-shadow: var(--shadow-float), var(--shadow-glow);
        border-color: var(--brand-gold);
        background: white;
    }

    .card-icon-3d {
        width: 100px;
        height: 100px;
        background: var(--gradient-gold);
        border-radius: 30px;
        display: flex;
        align-items: center;
        justify-content: center;
        margin-bottom: 40px;
        transform: translateZ(30px); /* Pop out */
        box-shadow: 0 15px 30px rgba(212, 160, 32, 0.4);
        font-size: 3rem;
        color: white;
    }

    .premium-card h3 {
        font-size: 2rem;
        font-weight: 900;
        margin-bottom: 20px;
        color: var(--brand-brown);
        transform: translateZ(20px);
    }

    .premium-card p {
        font-size: 1.1rem;
        color: var(--text-body);
        margin-bottom: 30px;
        transform: translateZ(10px);
    }

    .card-link {
        display: inline-flex;
        align-items: center;
        gap: 10px;
        font-weight: 800;
        color: var(--brand-orange);
        text-decoration: none;
        font-size: 1.2rem;
        transform: translateZ(20px);
        transition: 0.3s;
    }
    .card-link:hover {
        color: var(--brand-orange-hot);
        transform: translateZ(25px) translateX(-5px);
    }

    /* ══════════════════════════════════════════════════════════════════════════════
       4. SLANTED TRANSITION
       ══════════════════════════════════════════════════════════════════════════════ */
    .slant-wrapper {
        position: relative;
        z-index: 5;
    }
    .slant-top {
        height: 150px;
        background: #FBF7F1;
        clip-path: polygon(0 0, 100% 0, 100% 0, 0 100%);
        margin-bottom: -1px;
    }
    
    /* ══════════════════════════════════════════════════════════════════════════════
       5. LOCATIONS - DARK MODE IMPACT
       ══════════════════════════════════════════════════════════════════════════════ */
    .section-locations {
        background: var(--brand-brown-dark);
        padding: 120px 20px;
        color: white;
        position: relative;
        overflow: hidden;
    }

    .section-locations::before {
        content: '';
        position: absolute;
        inset: 0;
        background: url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23D4A020' fill-opacity='0.05'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E");
    }

    .loc-grid {
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        gap: 20px;
        max-width: 1000px;
        margin: 60px auto 0;
    }

    .loc-pill {
        background: rgba(255,255,255,0.05);
        border: 1px solid rgba(255,255,255,0.1);
        padding: 15px 35px;
        border-radius: 100px;
        font-size: 1.2rem;
        font-weight: 700;
        transition: 0.4s;
        cursor: pointer;
        backdrop-filter: blur(5px);
    }
    .loc-pill:hover {
        background: var(--brand-gold);
        color: var(--brand-brown-dark);
        transform: scale(1.1);
        box-shadow: 0 0 30px rgba(212, 160, 32, 0.5);
        border-color: var(--brand-gold);
    }

    /* ══════════════════════════════════════════════════════════════════════════════
       6. CTA - FLOATING
       ══════════════════════════════════════════════════════════════════════════════ */
    .section-cta {
        padding: 100px 20px;
        background: white;
        margin-top: -50px; /* Overlap */
        padding-top: 100px;
        position: relative;
        z-index: 10;
        clip-path: polygon(0 100px, 100% 0, 100% 100%, 0 100%);
    }
    
    .cta-container {
        max-width: 1000px;
        margin: 0 auto;
        background: var(--gradient-fire);
        border-radius: 50px;
        padding: 80px 40px;
        text-align: center;
        color: white;
        box-shadow: 0 40px 80px rgba(255, 69, 0, 0.4);
        position: relative;
        overflow: hidden;
        transform: translateY(0);
        transition: 0.5s;
    }
    
    .cta-container:hover {
        transform: translateY(-10px) scale(1.02);
    }

    .cta-container h2 {
        font-size: clamp(2.5rem, 5vw, 4rem);
        font-weight: 900;
        margin-bottom: 30px;
        text-shadow: 0 5px 15px rgba(0,0,0,0.2);
    }

    .btn-white {
        background: white;
        color: var(--brand-orange-hot);
        padding: 20px 60px;
        border-radius: 50px;
        font-weight: 900;
        font-size: 1.4rem;
        text-decoration: none;
        display: inline-block;
        box-shadow: 0 15px 30px rgba(0,0,0,0.2);
        transition: 0.3s;
    }
    .btn-white:hover {
        transform: scale(1.1);
        box-shadow: 0 20px 40px rgba(0,0,0,0.3);
        color: var(--brand-brown);
    }

    /* ══════════════════════════════════════════════════════════════════════════════
       RESPONSIVE
       ══════════════════════════════════════════════════════════════════════════════ */
    @media (max-width: 768px) {
        .hero-section { padding-top: 120px; }
        .hero-actions { flex-direction: column; }
        .btn-hero { width: 100%; justify-content: center; }
        .premium-card { padding: 30px 20px; }
        .section-head h2 { font-size: 2.5rem; }
        .section-cta { clip-path: none; margin-top: 0; background: var(--brand-brown-dark); }
        .cta-container { border-radius: 30px; padding: 50px 20px; }
    }

</style>

<!-- 1. HERO SECTION -->
<section class="hero-section">
    <div class="hero-3d-bg">
        <div class="floating-shape shape-1"></div>
        <div class="floating-shape shape-2"></div>
        <div class="floating-shape shape-3"></div>
    </div>
    
    <div class="hero-content">
        <div class="hero-badge">
            <span>🔥 قدرتمندترین رسانه محیطی شهر</span>
        </div>
        <h1 class="hero-title">
            دیده شدن، <br>
            <span class="highlight">حق برند شماست!</span>
        </h1>
        <p class="hero-desc">
            با بیلبوردها و سازه‌های تبلیغاتی طراحان باستان، در بهترین نقاط شهر بدرخشید.
            ما صدای برند شما را به گوش میلیون‌ها نفر می‌رسانیم.
        </p>
        <div class="hero-actions">
            <a href="contact" class="btn-hero btn-primary">
                <span>رزرو تابلو تبلیغاتی</span>
                <svg width="24" height="24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M13 7l5 5m0 0l-5 5m5-5H6" stroke-linecap="round" stroke-linejoin="round"/></svg>
            </a>
            <a href="#services" class="btn-hero btn-secondary">
                <span>مشاهده پلن‌ها</span>
            </a>
        </div>
    </div>
</section>

<!-- 2. SEPARATOR -->
<div class="separator-3d">
    <svg viewBox="0 0 1440 320" preserveAspectRatio="none">
        <path d="M0,224L80,213.3C160,203,320,181,480,181.3C640,181,800,203,960,213.3C1120,224,1280,224,1360,224L1440,224L1440,320L1360,320C1280,320,1120,320,960,320C800,320,640,320,480,320C320,320,160,320,80,320L0,320Z"></path>
    </svg>
</div>

<!-- 3. CARDS -->
<section class="section-cards" id="services">
    <div class="section-head">
        <h2>رسانه‌های قدرتمند ما</h2>
        <p>ابزارهایی که برند شما را به یک قهرمان تبدیل می‌کنند</p>
    </div>

    <div class="cards-container">
        <!-- Card 1 -->
        <div class="premium-card">
            <div class="card-icon-3d">💎</div>
            <h3>بیلبوردهای غول‌پیکر</h3>
            <p>تسلط بر بزرگراه‌ها و میادین اصلی شهر. سازه‌های عظیم با نورپردازی خیره‌کننده که اعتبار برند شما را تضمین می‌کنند.</p>
            <a href="contact" class="card-link">استعلام قیمت ></a>
        </div>
        
        <!-- Card 2 -->
        <div class="premium-card">
            <div class="card-icon-3d">🚀</div>
            <h3>استرابورد مدرن</h3>
            <p>تبلیغات سریع و چابک در قلب محلات و خیابان‌های پرتردد. بهترین گزینه برای کمپین‌های فروش و معرفی محصول جدید.</p>
            <a href="contact" class="card-link">مشاهده موقعیت‌ها ></a>
        </div>
        
        <!-- Card 3 -->
        <div class="premium-card">
            <div class="card-icon-3d">🎨</div>
            <h3>چاپ لارج فرمت</h3>
            <p>کیفیت چاپ بی‌نظیر با دستگاه‌های صنعتی. رنگ‌های زنده و ماندگار که حتی زیر نور مستقیم خورشید هم نمی‌میرند.</p>
            <a href="contact" class="card-link">سفارش چاپ ></a>
        </div>
    </div>
</section>

<!-- 4. SLANT -->
<div class="slant-wrapper">
    <div class="slant-top"></div>
</div>

<!-- 5. LOCATIONS -->
<section class="section-locations">
    <div class="section-head">
        <h2 style="color: white;">پوشش ۳۶۰ درجه شهر</h2>
        <p style="color: rgba(255,255,255,0.7);">ما در هر نقطه استراتژیک، یک تریبون برای شما داریم</p>
    </div>
    
    <div class="loc-grid">
        <div class="loc-pill">میدان آرامگاه بوعلی</div>
        <div class="loc-pill">چهارراه پژوهش</div>
        <div class="loc-pill">بلوار ارم</div>
        <div class="loc-pill">میدان بعثت</div>
        <div class="loc-pill">خیابان سعیدیه</div>
        <div class="loc-pill">ورودی تهران</div>
        <div class="loc-pill">میدان امام</div>
        <div class="loc-pill">شهرک مدنی</div>
        <div class="loc-pill">بلوار چمران</div>
    </div>
</section>

<!-- 6. CTA -->
<section class="section-cta">
    <div class="cta-container">
        <h2>آماده‌اید شهر را <br>تسخیر کنید؟</h2>
        <a href="contact" class="btn-white">همین حالا شروع کنید</a>
    </div>
</section>

<!-- No footer include as requested -->
