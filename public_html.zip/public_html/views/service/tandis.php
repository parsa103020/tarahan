<!-- WOW.js Animation Library -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" integrity="sha512-c42qTSw/wPZ3/5LBzD+Bw5f7bSF2oxou6wEb+I/lqeaKV5FDIfMvvRp772y4jcJLKuGUOpbJMdg/BTl50fJYAw==" crossorigin="anonymous" referrerpolicy="no-referrer">
<script src="https://cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.min.js" integrity="sha512-Eak/29OTpb36LLo2r47IpVzPBLXnAMPAVypbSZiZ4Qkf8p/7S/XRG5xp7OKWPPYfJT6metI+IORkR5G8F900+g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<style>
/* ══════════════════════════════════════════════════════════════════════════════
   TARAHAN BASTAN - PREMIUM TANDIS SERVICE v3.0 (FULL CONTENT)
   طراحی هنرمندانه تندیس و المان - برگرفته از آرکی‌تایپ قهرمان
   ══════════════════════════════════════════════════════════════════════════════ */

/* ═══ RESET & FONTS ═══ */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    cursor: default; 
    font-family: 'YekanBakh', 'Vazirmatn', 'IRANSans', Tahoma, sans-serif !important;
}

a, button, .btn, .hero-cta, .service-card, .cta-button, [role="button"], .clickable, .accordion-header {
    cursor: pointer !important;
}

:root {
    /* ═══ HERO ARCHETYPE COLORS ═══ */
    --brand-brown: #2D1810;
    --brand-brown-light: #4A2C1A;
    --brand-brown-dark: #1A0D08;

    /* ═══ CHAMPION GOLD ═══ */
    --brand-gold: #D4A020;
    --brand-gold-light: #E8B830;
    --brand-gold-dark: #B8890F;
    --brand-gold-vibrant: #F5C518;

    /* ═══ HERO ORANGE ═══ */
    --brand-orange: #F58500;
    --brand-orange-light: #FF9500;
    --brand-orange-vibrant: #FF6B00;
    --brand-orange-fire: #FF4500;

    /* ═══ Text Colors ═══ */
    --text-primary: #2D1810;
    --text-secondary: #5A3825;
    --text-body: #6B4D3A;
    --text-muted: #8B7355;
    --text-light: #F3E4CE;

    /* ═══ Backgrounds ═══ */
    --bg-hero: linear-gradient(180deg, #FFFEFB 0%, #FEF9F2 15%, #FCF4E9 35%, #F8EDDC 55%, #F3E4CE 75%, #ECDBC0 100%);
    --bg-section-warm: linear-gradient(180deg, #FBF7F1 0%, #F4EBE0 50%, #EDE1D4 100%);
    --bg-section-cream: linear-gradient(180deg, #FEFBF7 0%, #F9F3EB 50%, #F3EAE0 100%);
    --bg-card-premium: linear-gradient(145deg, #FFFFFF 0%, #FFF9F0 30%, #FFF3E3 100%);
    
    /* ═══ GRADIENTS ═══ */
    --gold-gradient: linear-gradient(135deg, #D4A020 0%, #E8B830 50%, #F5C518 100%);
    --hero-gradient: linear-gradient(135deg, #D4A020 0%, #F58500 45%, #FF6B00 90%, #FFFCF5 100%);
    --fire-gradient: linear-gradient(135deg, #FF4500 0%, #FF6B00 40%, #FF8C00 80%, #FFD700 100%);

    /* ═══ SHADOWS ═══ */
    --shadow-soft: 0 6px 30px rgba(45, 24, 16, 0.05);
    --shadow-card: 0 10px 30px rgba(45, 24, 16, 0.08);
    --shadow-premium: 0 15px 35px rgba(45, 24, 16, 0.1), 0 5px 15px rgba(212, 160, 32, 0.05);
    --shadow-float: 0 20px 50px rgba(45, 24, 16, 0.15);

    /* ═══ BORDERS ═══ */
    --border-light: rgba(212, 160, 32, 0.25);
    --border-gold: rgba(212, 160, 32, 0.70);
}

body {
    background: #FAF6F1;
    overflow-x: hidden;
    color: var(--text-primary);
    line-height: 1.7;
}

/* ══════════════════════════════════════════════════════════════════════════════
   1. HERO SECTION
   ══════════════════════════════════════════════════════════════════════════════ */
.hero {
    min-height: 100vh;
    background: var(--bg-hero);
    position: relative;
    display: flex;
    align-items: center;
    justify-content: center;
    overflow: hidden;
    padding: 140px 20px 100px;
    perspective: 1200px;
}

.hero-bg-layer {
    position: absolute;
    inset: 0;
    pointer-events: none;
    z-index: 0;
}

.hero-blueprint {
    position: absolute;
    inset: -50%;
    background-image: 
        linear-gradient(rgba(212, 160, 32, 0.05) 1px, transparent 1px),
        linear-gradient(90deg, rgba(212, 160, 32, 0.05) 1px, transparent 1px);
    background-size: 50px 50px;
    transform: perspective(1000px) rotateX(60deg) translateY(-100px) translateZ(-200px);
    opacity: 0.6;
    mask-image: linear-gradient(to bottom, rgba(0,0,0,1) 0%, rgba(0,0,0,0) 80%);
}

.hero-orb {
    position: absolute;
    border-radius: 50%;
    filter: blur(80px);
    opacity: 0.6;
    animation: pulseGlow 8s infinite alternate;
}
.orb-1 { top: 10%; right: -10%; width: 400px; height: 400px; background: radial-gradient(circle, rgba(255, 165, 0, 0.3) 0%, rgba(255, 255, 255, 0) 70%); }
.orb-2 { bottom: -10%; left: -5%; width: 500px; height: 500px; background: radial-gradient(circle, rgba(212, 160, 32, 0.25) 0%, rgba(255, 255, 255, 0) 70%); animation-delay: 2s; }

@keyframes pulseGlow { 0% { opacity: 0.4; transform: scale(1); } 100% { opacity: 0.7; transform: scale(1.1); } }

.hero-content {
    position: relative;
    z-index: 2;
    text-align: center;
    max-width: 1000px;
}

.hero-badge {
    display: inline-flex;
    align-items: center;
    gap: 10px;
    background: linear-gradient(135deg, rgba(255,255,255,0.95) 0%, rgba(253,251,248,0.9) 100%);
    border: 1px solid var(--border-gold);
    padding: 10px 24px;
    border-radius: 50px;
    margin-bottom: 32px;
    box-shadow: 0 4px 15px rgba(212, 160, 32, 0.15);
    animation: fadeInDown 0.8s ease;
}

.hero-badge span {
    font-size: 14px;
    font-weight: 800;
    color: var(--brand-brown);
    letter-spacing: 0.5px;
}

/* Title Fix: Increased visibility */
.hero-title {
    font-size: clamp(2.5rem, 6vw, 5rem);
    font-weight: 900;
    line-height: 1.1;
    margin-bottom: 24px;
    position: relative;
}

.hero-title .line1 {
    display: block;
    color: #2D1810; /* Solid dark color */
    text-shadow: 2px 2px 0px rgba(255,255,255,0.5), 0 10px 20px rgba(0,0,0,0.1); /* Shadow for contrast */
    animation: fadeInUp 0.8s ease 0.2s both;
}

.hero-title .line2 {
    display: block;
    background: linear-gradient(135deg, #D4A020 10%, #FF6B00 50%, #FF4500 90%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    filter: drop-shadow(0 4px 10px rgba(255, 107, 0, 0.25));
    animation: fadeInUp 0.8s ease 0.4s both;
}

.hero-subtitle {
    font-size: clamp(1.1rem, 2vw, 1.35rem);
    color: var(--text-body);
    max-width: 750px;
    margin: 0 auto 48px;
    line-height: 1.8;
    animation: fadeInUp 0.8s ease 0.6s both;
    font-weight: 600; /* Increased weight */
}

.hero-buttons {
    display: flex;
    gap: 20px;
    justify-content: center;
    flex-wrap: wrap;
    animation: fadeInUp 0.8s ease 0.8s both;
}

.btn-primary {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 12px;
    background: linear-gradient(135deg, #D4A020 0%, #F58500 50%, #FF6B00 100%);
    color: white;
    padding: 18px 42px;
    border-radius: 50px;
    font-size: 16px;
    font-weight: 900;
    text-decoration: none;
    box-shadow: 0 10px 25px rgba(245, 133, 0, 0.35);
    transition: all 0.4s ease;
    border: none;
}

.btn-primary:hover {
    transform: translateY(-5px);
    box-shadow: 0 20px 40px rgba(245, 133, 0, 0.5);
}

.btn-secondary {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 12px;
    background: rgba(255, 255, 255, 0.8);
    color: var(--brand-brown);
    padding: 18px 42px;
    border-radius: 50px;
    font-size: 16px;
    font-weight: 800;
    text-decoration: none;
    border: 2px solid var(--border-light);
    transition: all 0.4s ease;
}

.btn-secondary:hover {
    background: white;
    border-color: var(--brand-gold);
    transform: translateY(-5px);
    box-shadow: 0 10px 25px rgba(212, 160, 32, 0.15);
}

/* ══════════════════════════════════════════════════════════════════════════════
   2. STATS STRIP (New)
   ══════════════════════════════════════════════════════════════════════════════ */
.stats-container {
    max-width: 1100px;
    margin: -60px auto 100px;
    position: relative;
    z-index: 10;
    padding: 0 20px;
}

.stats-bar {
    background: white;
    border-radius: 30px;
    box-shadow: var(--shadow-float);
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    padding: 40px;
    border: 1px solid rgba(212, 160, 32, 0.15);
    transform: rotateX(0deg);
    transition: transform 0.5s ease;
}

.stats-bar:hover {
    transform: translateY(-5px);
}

.stat-item {
    text-align: center;
    position: relative;
}

.stat-item:not(:last-child)::after {
    content: '';
    position: absolute;
    left: 0; top: 20%; bottom: 20%; width: 1px;
    background: linear-gradient(180deg, transparent, #eee, transparent);
}

.stat-num {
    font-size: 2.5rem;
    font-weight: 900;
    background: var(--gold-gradient);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    display: block;
    margin-bottom: 5px;
}

.stat-label {
    font-size: 0.95rem;
    font-weight: 700;
    color: var(--brand-brown-light);
}

/* ══════════════════════════════════════════════════════════════════════════════
   3. WHY US (New)
   ══════════════════════════════════════════════════════════════════════════════ */
.section-why {
    padding: 80px 20px 120px;
    background: var(--bg-section-cream);
}

.section-head {
    text-align: center;
    margin-bottom: 60px;
}

.section-head h2 {
    font-size: 2.5rem;
    font-weight: 900;
    color: var(--brand-brown);
    margin-bottom: 15px;
}

.section-head p {
    font-size: 1.1rem;
    color: var(--text-body);
    max-width: 600px;
    margin: 0 auto;
}

.features-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 30px;
    max-width: 1200px;
    margin: 0 auto;
}

.feature-box {
    background: white;
    padding: 40px;
    border-radius: 30px;
    box-shadow: var(--shadow-card);
    transition: 0.4s;
    border: 1px solid transparent;
}

.feature-box:hover {
    transform: translateY(-10px);
    border-color: var(--brand-gold);
    box-shadow: var(--shadow-premium);
}

.feature-icon {
    width: 60px;
    height: 60px;
    background: var(--gold-gradient);
    border-radius: 18px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.8rem;
    color: white;
    margin-bottom: 20px;
    box-shadow: 0 10px 20px rgba(212, 160, 32, 0.2);
}

.feature-box h3 { font-size: 1.3rem; font-weight: 800; margin-bottom: 15px; color: var(--brand-brown); }
.feature-box p { color: var(--text-secondary); line-height: 1.7; font-size: 0.95rem; }

/* ══════════════════════════════════════════════════════════════════════════════
   4. SERVICES GRID
   ══════════════════════════════════════════════════════════════════════════════ */
.services-section {
    background: white;
    padding: 120px 20px;
    position: relative;
}

.services-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
    gap: 30px;
    max-width: 1250px;
    margin: 0 auto;
}

.service-card {
    background: var(--bg-card-premium);
    border-radius: 32px;
    padding: 48px 32px;
    text-align: center;
    position: relative;
    transition: all 0.5s ease;
    border: 1px solid var(--border-light);
    box-shadow: var(--shadow-card);
}

.service-card:hover {
    transform: translateY(-10px);
    box-shadow: var(--shadow-premium);
    border-color: var(--brand-gold);
}

.card-icon {
    width: 80px;
    height: 80px;
    margin: 0 auto 24px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: linear-gradient(135deg, #FFF9F0 0%, #FFF 100%);
    border-radius: 24px;
    box-shadow: inset 0 0 15px rgba(212, 160, 32, 0.1);
    transition: transform 0.5s;
}

.service-card:hover .card-icon {
    transform: scale(1.1) rotate(-5deg);
    background: var(--gold-gradient);
}

.card-icon svg {
    width: 40px;
    height: 40px;
    color: var(--brand-orange);
    transition: color 0.3s;
}

.service-card:hover .card-icon svg { color: white; }
.service-card h3 { font-size: 1.5rem; font-weight: 800; color: var(--text-primary); margin-bottom: 12px; }
.service-card p { font-size: 1rem; color: var(--text-body); line-height: 1.7; }

/* ══════════════════════════════════════════════════════════════════════════════
   5. FEATURED PROJECT
   ══════════════════════════════════════════════════════════════════════════════ */
.featured-section {
    padding: 140px 20px;
    background: linear-gradient(180deg, #FBF7F1 0%, #FFFFFF 100%);
    position: relative;
    overflow: hidden;
}

.featured-bg-text {
    position: absolute;
    top: 5%;
    right: -10%;
    font-size: 15rem;
    font-weight: 900;
    color: rgba(212, 160, 32, 0.03);
    z-index: 0;
    pointer-events: none;
}

.featured-layout {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 80px;
    align-items: center;
    position: relative;
    z-index: 1;
    max-width: 1300px;
    margin: 0 auto;
}

.featured-image-wrapper {
    position: relative;
    border-radius: 40px;
    overflow: hidden;
    box-shadow: 0 20px 60px rgba(0,0,0,0.15);
    transform: perspective(1000px) rotateY(5deg);
    transition: transform 0.6s ease;
}

.featured-image-wrapper:hover { transform: perspective(1000px) rotateY(0deg); }
.featured-image-wrapper img { width: 100%; height: auto; display: block; transition: 0.8s ease; }
.featured-image-wrapper:hover img { transform: scale(1.05); }

.featured-info h2 { font-size: clamp(2rem, 4vw, 3rem); font-weight: 900; line-height: 1.3; margin-bottom: 24px; }
.featured-info h2 span { color: var(--brand-orange); }
.featured-desc { font-size: 1.1rem; color: var(--text-body); line-height: 1.9; margin-bottom: 40px; text-align: justify; }

.specs-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 20px;
    margin-bottom: 40px;
}

.spec-item { border-right: 1px solid var(--border-light); padding-right: 15px; }
.spec-item h4 { font-size: 2rem; font-weight: 900; color: var(--brand-brown); margin-bottom: 5px; }
.spec-item span { font-size: 0.9rem; color: var(--text-muted); font-weight: 600; }

/* ══════════════════════════════════════════════════════════════════════════════
   6. PROCESS TIMELINE
   ══════════════════════════════════════════════════════════════════════════════ */
.process-section {
    padding: 120px 20px;
    background: var(--bg-section-warm);
}

.timeline-wrap {
    max-width: 1000px;
    margin: 60px auto 0;
    position: relative;
}

.timeline-wrap::before {
    content: '';
    position: absolute;
    left: 50%; top: 0; bottom: 0; width: 2px;
    background: linear-gradient(to bottom, transparent, var(--brand-gold), transparent);
    transform: translateX(-50%);
    opacity: 0.3;
}

.timeline-row {
    display: flex;
    justify-content: space-between;
    margin-bottom: 60px;
    position: relative;
}

.timeline-content {
    width: 45%;
    background: white;
    padding: 30px;
    border-radius: 25px;
    position: relative;
    transition: 0.3s;
    box-shadow: var(--shadow-card);
    border: 1px solid transparent;
}

.timeline-content:hover {
    border-color: var(--brand-gold);
    transform: scale(1.02);
    box-shadow: var(--shadow-float);
}

.timeline-row:nth-child(odd) { flex-direction: row-reverse; }
.timeline-row:nth-child(odd) .timeline-content { text-align: right; }

.step-marker {
    position: absolute;
    left: 50%; top: 50%;
    transform: translate(-50%, -50%);
    width: 50px; height: 50px;
    background: var(--gold-gradient);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-weight: 900;
    font-size: 1.2rem;
    box-shadow: 0 0 0 5px #FAF6F1, 0 0 0 8px rgba(212, 160, 32, 0.2);
    z-index: 2;
}

.timeline-content h3 { font-size: 1.25rem; font-weight: 800; margin-bottom: 10px; color: var(--brand-brown); }
.timeline-content p { font-size: 0.95rem; color: var(--text-body); line-height: 1.6; }

/* ══════════════════════════════════════════════════════════════════════════════
   7. TESTIMONIALS (New)
   ══════════════════════════════════════════════════════════════════════════════ */
.section-testimonials {
    padding: 100px 20px;
    background: var(--brand-brown-dark);
    color: white;
    text-align: center;
}

.section-testimonials .section-head h2 { color: white; }
.section-testimonials .section-head p { color: rgba(255,255,255,0.6); }

.testi-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 40px;
    max-width: 1200px;
    margin: 0 auto;
}

.testi-card {
    background: rgba(255,255,255,0.05);
    padding: 40px 30px;
    border-radius: 30px;
    border: 1px solid rgba(255,255,255,0.1);
    backdrop-filter: blur(5px);
    transition: 0.4s;
}
.testi-card:hover {
    background: rgba(255,255,255,0.1);
    transform: translateY(-10px);
    border-color: var(--brand-gold);
}

.testi-text { font-size: 1.1rem; font-style: italic; margin-bottom: 20px; color: #eee; line-height: 1.8; }
.testi-author { font-weight: 800; color: var(--brand-gold); font-size: 1.1rem; }
.testi-role { font-size: 0.9rem; color: rgba(255,255,255,0.5); margin-top: 5px; }

/* ══════════════════════════════════════════════════════════════════════════════
   8. FAQ (New)
   ══════════════════════════════════════════════════════════════════════════════ */
.section-faq {
    padding: 100px 20px;
    background: white;
}

.faq-wrap {
    max-width: 900px;
    margin: 0 auto;
}

.accordion-item {
    margin-bottom: 15px;
    border: 1px solid #eee;
    border-radius: 20px;
    overflow: hidden;
    transition: 0.3s;
    background: #FAF6F1;
}
.accordion-item:hover { box-shadow: var(--shadow-card); border-color: var(--brand-gold); background: white; }

.accordion-header {
    padding: 25px 30px;
    font-weight: 800;
    font-size: 1.1rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
    color: var(--brand-brown);
}
.accordion-header::after { content: '+'; font-size: 1.5rem; color: var(--brand-orange); transition: 0.3s; }
.accordion-item:hover .accordion-header::after { transform: rotate(45deg); }

.accordion-body {
    padding: 0 30px 30px;
    color: var(--text-body);
    display: none;
    line-height: 1.8;
}
.accordion-item:hover .accordion-body { display: block; animation: fadeIn 0.5s; }

@keyframes fadeIn { from{opacity:0;transform:translateY(-10px);} to{opacity:1;transform:translateY(0);} }

/* ══════════════════════════════════════════════════════════════════════════════
   9. CTA
   ══════════════════════════════════════════════════════════════════════════════ */
.cta-wrapper { margin: 100px 20px 60px; }
.cta-banner {
    background: linear-gradient(135deg, #2D1810 0%, #5A3825 100%);
    border-radius: 40px;
    padding: 80px 40px;
    text-align: center;
    position: relative;
    overflow: hidden;
    box-shadow: 0 20px 50px rgba(45, 24, 16, 0.25);
}
.cta-banner::before {
    content: ''; position: absolute; inset: 0;
    background-image: radial-gradient(circle at 20% 80%, rgba(255, 107, 0, 0.15) 0%, transparent 50%);
    pointer-events: none;
}
.cta-content { position: relative; z-index: 2; color: white; }
.cta-title-large { font-size: clamp(2rem, 5vw, 3.5rem); font-weight: 900; margin-bottom: 24px; }
.cta-subtitle { font-size: 1.2rem; color: rgba(255,255,255,0.8); max-width: 700px; margin: 0 auto 48px; }

/* ══════════════════════════════════════════════════════════════════════════════
   RESPONSIVE
   ══════════════════════════════════════════════════════════════════════════════ */
@media (max-width: 1024px) {
    .featured-layout { grid-template-columns: 1fr; gap: 50px; }
    .stats-bar { grid-template-columns: 1fr 1fr; gap: 20px; }
    .stat-item::after { display: none; }
}

@media (max-width: 768px) {
    .timeline-wrap::before { left: 20px; }
    .timeline-row, .timeline-row:nth-child(odd) { flex-direction: column; padding-left: 50px; }
    .timeline-content { width: 100%; text-align: right !important; }
    .step-marker { left: 20px; transform: translate(-50%, -50%); }
    .hero-title { font-size: 3rem; }
}
</style>

<!-- PAGE CONTENT -->
<div class="tandis-page">
    
    <!-- 1. HERO SECTION -->
    <section class="hero">
        <div class="hero-bg-layer">
            <div class="hero-blueprint"></div>
            <div class="hero-orb orb-1"></div>
            <div class="hero-orb orb-2"></div>
        </div>

        <div class="hero-content">
            <div class="hero-badge wow fadeInDown">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="color: var(--brand-orange);"><path d="M6 9H4.5a2.5 2.5 0 0 1 0-5H6"></path><path d="M18 9h1.5a2.5 2.5 0 0 0 0-5H18"></path><path d="M4 22h16"></path><path d="M10 14.66V17"></path><path d="M14 14.66V17"></path><path d="M12 2v20"></path><path d="M12 2a7 7 0 0 1 7 7c0 2.33-1.02 4.42-2.6 5.77"></path><path d="M12 2a7 7 0 0 0-7 7c0 2.33 1.02 4.42 2.6 5.77"></path></svg>
                <span>نماد جاودانگی و افتخار</span>
            </div>

            <h1 class="hero-title">
                <span class="line1">روایتگر داستان اقتدار</span>
                <span class="line2">با زبان هنر و فلز</span>
            </h1>

            <p class="hero-subtitle">
                طراحی و ساخت تخصصی تندیس‌های یادبود، نشان‌های افتخار و المان‌های شهری فاخر.
                جایی که هنر دست و دقت مهندسی برای خلق اثری ماندگار به هم می‌رسند.
            </p>

            <div class="hero-buttons">
                <a href="<?php echo URL; ?>/contact" class="btn-primary">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
                    سفارش طراحی اختصاصی
                </a>
                <a href="#featured" class="btn-secondary">
                    مشاهده نمونه آثار
                </a>
            </div>
        </div>
    </section>

    <!-- 2. STATS STRIP -->
    <div class="stats-container wow fadeInUp" data-wow-delay="0.2s">
        <div class="stats-bar">
            <div class="stat-item">
                <span class="stat-num">+۱۵۰۰</span>
                <span class="stat-label">تندیس ساخته شده</span>
            </div>
            <div class="stat-item">
                <span class="stat-num">۱۵</span>
                <span class="stat-label">سال تجربه هنری</span>
            </div>
            <div class="stat-item">
                <span class="stat-num">۱۰۰٪</span>
                <span class="stat-label">دست‌ساز و یونیک</span>
            </div>
            <div class="stat-item">
                <span class="stat-num">۵۰+</span>
                <span class="stat-label">جشنواره ملی</span>
            </div>
        </div>
    </div>

    <!-- 3. WHY US -->
    <section class="section-why">
        <div class="section-head">
            <h2>چرا تندیس‌های ما متفاوت است؟</h2>
            <p>تفاوت در ظرافت، اصالت متریال و ماندگاری ابدی آثار ماست</p>
        </div>
        <div class="features-grid">
            <div class="feature-box wow fadeInUp" data-wow-delay="0.1s">
                <div class="feature-icon">💎</div>
                <h3>متریال خالص و ارزشمند</h3>
                <p>استفاده از برنج، برنز و آلیاژهای خاص که با گذشت زمان، ارزش و زیبایی خود را حفظ می‌کنند و اکسیده نمی‌شوند.</p>
            </div>
            <div class="feature-box wow fadeInUp" data-wow-delay="0.2s">
                <div class="feature-icon">🎨</div>
                <h3>طراحی انحصاری</h3>
                <p>هر تندیس یک اثر هنری منحصر به فرد است که توسط اساتید مجسمه‌سازی و بر اساس هویت برند شما طراحی می‌شود.</p>
            </div>
            <div class="feature-box wow fadeInUp" data-wow-delay="0.3s">
                <div class="feature-icon">⚙️</div>
                <h3>دقت میکرونی</h3>
                <p>تلفیق هنر دست با تکنولوژی‌های نوین مثل برش لیزر و پرینت سه بعدی برای دستیابی به جزئیات خیره‌کننده.</p>
            </div>
        </div>
    </section>

    <!-- 4. SERVICES GRID -->
    <section class="services-section" id="services">
        <div class="container">
            <div class="section-head">
                <h2>خدمات تخصصی تندیس و المان</h2>
                <p>پاسخ به تمام نیازهای هنری و تبلیغاتی شما</p>
            </div>

            <div class="services-grid">
                <div class="service-card wow fadeInUp">
                    <div class="card-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5"><path stroke-linecap="round" stroke-linejoin="round" d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" /></svg>
                    </div>
                    <h3>تندیس‌های جشنواره‌ای</h3>
                    <p>طراحی و ساخت تندیس‌های زرین و کریستال برای رویدادهای ملی و همایش‌های بین‌المللی.</p>
                </div>
                <div class="service-card wow fadeInUp" data-wow-delay="0.1s">
                    <div class="card-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5"><path stroke-linecap="round" stroke-linejoin="round" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" /></svg>
                    </div>
                    <h3>المان‌های شهری</h3>
                    <p>ساخت سازه‌های حجمی و المان‌های میدانی عظیم که هویت بصری شهر را دگرگون می‌کنند.</p>
                </div>
                <div class="service-card wow fadeInUp" data-wow-delay="0.2s">
                    <div class="card-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5"><path stroke-linecap="round" stroke-linejoin="round" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>
                    </div>
                    <h3>سردیس و مجسمه</h3>
                    <p>شبیه‌سازی دقیق چهره مشاهیر به روش رئال و انتزاعی با ماندگاری چند صد ساله.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- 5. FEATURED PROJECT -->
    <section class="featured-section" id="featured">
        <div class="featured-bg-text">SIMORGH</div>
        <div class="container">
            <div class="featured-layout">
                <div class="featured-visual wow fadeInLeft">
                    <div class="featured-image-wrapper">
                        <img src="public/images/hamedan2018.jpg" alt="تندیس فاخر سیمرغ">
                    </div>
                </div>

                <div class="featured-info wow fadeInRight">
                    <h2>تندیس ملی <br><span>سیمرغ زرین همدان</span></h2>
                    <p class="featured-desc">
                        این شاهکار هنری تلفیقی از اسطوره‌های باستانی و تکنیک‌های مدرن ریخته‌گری است. 
                        در طراحی این اثر، تمام جزئیات آناتومی سیمرغ با الهام از نگاره‌های تخت جمشید بازآفرینی شده است.
                    </p>
                    
                    <div class="specs-grid">
                        <div class="spec-item">
                            <h4>۴۵</h4>
                            <span>روز زمان ساخت</span>
                        </div>
                        <div class="spec-item">
                            <h4>۱۰۰٪</h4>
                            <span>برنز خالص</span>
                        </div>
                        <div class="spec-item">
                            <h4>۱۵</h4>
                            <span>کیلوگرم وزن</span>
                        </div>
                    </div>

                    <div class="featured-cta">
                        <a href="<?php echo URL; ?>/contact" class="btn-primary">سفارش مشابه</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- 6. PROCESS TIMELINE -->
    <section class="process-section">
        <div class="container">
            <div class="section-head">
                <h2>مراحل خلق اثر</h2>
                <p>از ایده خام تا شاهکار هنری</p>
            </div>
            
            <div class="timeline-wrap">
                <div class="timeline-row">
                    <div class="step-marker">1</div>
                    <div class="timeline-content">
                        <h3>ایده‌پردازی و اسکچ</h3>
                        <p>تبدیل مفاهیم ذهنی شما به طرح‌های دستی و هنری برای رسیدن به فرم ایده‌آل.</p>
                    </div>
                </div>
                <div class="timeline-row">
                    <div class="step-marker">2</div>
                    <div class="timeline-content">
                        <h3>مدل‌سازی سه بعدی</h3>
                        <p>ساخت مدل کامپیوتری دقیق برای بررسی زوایا و جزئیات قبل از شروع ساخت فیزیکی.</p>
                    </div>
                </div>
                <div class="timeline-row">
                    <div class="step-marker">3</div>
                    <div class="timeline-content">
                        <h3>قالب‌گیری و ریخته‌گری</h3>
                        <p>تولید قطعه با متریال‌های اصلی (برنز، برنج، رزین) با بالاترین کیفیت پرداخت.</p>
                    </div>
                </div>
                <div class="timeline-row">
                    <div class="step-marker">4</div>
                    <div class="timeline-content">
                        <h3>پتینه و بسته‌بندی</h3>
                        <p>اعمال پوشش‌های محافظ و پتینه‌های هنری و تحویل در بسته‌بندی‌های نفیس چوبی.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- 7. TESTIMONIALS -->
    <section class="section-testimonials">
        <div class="section-head">
            <h2>نظر مشتریان هنردوست</h2>
            <p>افتخار ما رضایت بزرگان صنعت و هنر است</p>
        </div>
        <div class="testi-grid">
            <div class="testi-card">
                <p class="testi-text">"ظرافت تندیس‌های جشنواره سینما حقیقت فراتر از انتظار ما بود. جزئیات صورتک‌ها حیرت‌انگیز است."</p>
                <div class="testi-author">استاد انتظامی</div>
                <div class="testi-role">دبیر جشنواره</div>
            </div>
            <div class="testi-card">
                <p class="testi-text">"المان میدان اصلی شهر که توسط تیم شما ساخته شد، به نماد جدید شهر ما تبدیل شده است."</p>
                <div class="testi-author">دکتر شهبازی</div>
                <div class="testi-role">شهردار منطقه ۱</div>
            </div>
            <div class="testi-card">
                <p class="testi-text">"کیفیت متریال و سنگینی تندیس، حس بسیار ارزشمندی به برندگان جشنواره ما منتقل کرد."</p>
                <div class="testi-author">مهندس صادقی</div>
                <div class="testi-role">مدیر روابط عمومی</div>
            </div>
        </div>
    </section>

    <!-- 8. FAQ -->
    <section class="section-faq">
        <div class="section-head">
            <h2>سوالات متداول</h2>
            <p>پاسخ به پرسش‌های شما درباره سفارش تندیس</p>
        </div>
        <div class="faq-wrap">
            <div class="accordion-item">
                <div class="accordion-header">حداقل تیراژ سفارش تندیس چقدر است؟</div>
                <div class="accordion-body">برای تندیس‌های اختصاصی ریخته‌گری، حداقل سفارش ۱۰ عدد است. اما برای کارهای تک نسخه (مثل سردیس) سفارش تکی هم پذیرفته می‌شود.</div>
            </div>
            <div class="accordion-item">
                <div class="accordion-header">زمان تحویل پروژه چقدر است؟</div>
                <div class="accordion-body">بسته به پیچیدگی طرح و تیراژ، بین ۱۰ تا ۴۵ روز کاری زمان می‌برد. پروژه‌های المان شهری زمان بیشتری نیاز دارند.</div>
            </div>
            <div class="accordion-item">
                <div class="accordion-header">آیا امکان ساخت نمونه اولیه وجود دارد؟</div>
                <div class="accordion-body">بله، قبل از تولید انبوه، یک نمونه اولیه (پروتوتایپ) ساخته می‌شود و پس از تایید شما، تولید نهایی آغاز می‌گردد.</div>
            </div>
            <div class="accordion-item">
                <div class="accordion-header">از چه متریال‌هایی استفاده می‌کنید؟</div>
                <div class="accordion-body">ما در ساخت تندیس از برنز، برنج، زاماک، پلکسی‌گلس، چوب‌های نفیس، سنگ و رزین اپوکسی استفاده می‌کنیم.</div>
            </div>
        </div>
    </section>

    <!-- 9. FINAL CTA -->
    <div class="container">
        <div class="cta-wrapper">
            <div class="cta-banner wow zoomIn">
                <div class="cta-content">
                    <h2 class="cta-title-large">ایده‌ای در ذهن دارید؟</h2>
                    <p class="cta-subtitle">
                        همین حالا با مشاوران هنری ما تماس بگیرید تا ایده شما را به یک اثر ماندگار تبدیل کنیم.
                    </p>
                    <a href="<?php echo URL; ?>/contact" class="btn-primary" style="background: white; color: var(--brand-orange);">
                        شروع مشاوره رایگان
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="color: var(--brand-orange);"><line x1="22" y1="2" x2="11" y2="13"></line><polygon points="22 2 15 22 11 13 2 9 22 2"></polygon></svg>
                    </a>
                </div>
            </div>
        </div>
    </div>

</div>

<script>
    new WOW().init();
</script>