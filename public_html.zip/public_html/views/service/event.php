<!-- WOW.js & Animate.css -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" integrity="sha512-c42qTSw/wPZ3/5LBzD+Bw5f7bSF2oxou6wEb+I/lqeaKV5FDIfMvvRp772y4jcJLKuGUOpbJMdg/BTl50fJYAw==" crossorigin="anonymous" referrerpolicy="no-referrer">
<script src="https://cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.min.js" integrity="sha512-Eak/29OTpb36LLo2r47IpVzPBLXnAMPAVypbSZiZ4Qkf8p/7S/XRG5xp7OKWPPYfJT6metI+IORkR5G8F900+g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<style>
/* ══════════════════════════════════════════════════════════════════════════════
   TARAHAN BASTAN - EVENT SERVICE: CINEMATIC HERO EDITION v5.0
   طراحی: جسورانه، متالیک، داینامیک
   ══════════════════════════════════════════════════════════════════════════════ */

:root {
    /* 🎨 CORE PALETTE */
    --hero-dark: #120805;
    --hero-brown: #2D1810;
    --hero-gold: #D4A020;
    --hero-gold-shine: #FFD700;
    --hero-orange: #FF4500;
    --hero-cream: #F5EBE0;
    --hero-white: #FFFFFF;

    /* 🖌 GRADIENTS */
    --grad-metal: linear-gradient(135deg, #bf953f, #fcf6ba, #b38728, #fbf5b7, #aa771c);
    --grad-fire: linear-gradient(135deg, #FF4500 0%, #FF8C00 100%);
    --grad-dark: linear-gradient(180deg, #2D1810 0%, #120805 100%);
    --grad-glass: linear-gradient(145deg, rgba(255,255,255,0.05), rgba(255,255,255,0.01));

    /* 🌑 SHADOWS */
    --shadow-xs: 0 4px 12px rgba(0, 0, 0, 0.05);
    --shadow-xl: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
    --shadow-glow: 0 0 40px rgba(212, 160, 32, 0.3);
    --shadow-inner: inset 0 2px 4px rgba(255, 255, 255, 0.1);

    /* 📐 SPACING */
    --container-padding: clamp(20px, 5vw, 40px);

    /* 📝 TEXT */
    --text-body: #5A3825;
    --text-muted: #8B7355;
}

/* 🛠 GLOBAL RESET & UTILS */
* {
    box-sizing: border-box;
    outline: none;
    -webkit-tap-highlight-color: transparent;
}

body {
    background-color: #FAF7F2;
    color: var(--hero-brown);
    font-family: 'YekanBakh', sans-serif;
    overflow-x: hidden;
    margin: 0;
}

/* Grain Texture Overlay for Cinematic Feel */
body::before {
    content: "";
    position: fixed;
    top: 0; left: 0; width: 100%; height: 100%;
    background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.65' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)' opacity='0.03'/%3E%3C/svg%3E");
    pointer-events: none;
    z-index: 9999;
    opacity: 0.4;
}

a { text-decoration: none; color: inherit; }
ul { list-style: none; padding: 0; margin: 0; }

/* 🧊 PREMIUM GLASS CARD UTILITY */
.glass-card {
    background: rgba(255, 255, 255, 0.8);
    backdrop-filter: blur(12px);
    -webkit-backdrop-filter: blur(12px);
    border: 1px solid rgba(255, 255, 255, 0.6);
    box-shadow: var(--shadow-xl), var(--shadow-inner);
}

/* ✨ TEXT EFFECTS */
.text-gradient {
    background: var(--grad-metal);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    background-size: 200% auto;
    animation: shine 4s linear infinite;
}

@keyframes shine { to { background-position: 200% center; } }

/* ══════════════════════════════════════════════════════════════════════════════
   1. HERO SECTION: THE STAGE
   ══════════════════════════════════════════════════════════════════════════════ */
.hero-section {
    min-height: 100vh;
    position: relative;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 160px 20px 100px;
    background: var(--hero-dark);
    color: white;
    overflow: hidden;
}

/* Abstract Background Elements */
.hero-bg-mesh {
    position: absolute;
    inset: 0;
    background: 
        radial-gradient(circle at 10% 20%, rgba(212, 160, 32, 0.15) 0%, transparent 40%),
        radial-gradient(circle at 90% 80%, rgba(255, 69, 0, 0.1) 0%, transparent 40%);
    z-index: 1;
}

.hero-grid-lines {
    position: absolute;
    inset: 0;
    background-image: 
        linear-gradient(rgba(255,255,255,0.03) 1px, transparent 1px),
        linear-gradient(90deg, rgba(255,255,255,0.03) 1px, transparent 1px);
    background-size: 60px 60px;
    transform: perspective(500px) rotateX(60deg) scale(2);
    transform-origin: top center;
    opacity: 0.5;
    z-index: 1;
}

.hero-content {
    position: relative;
    z-index: 10;
    text-align: center;
    max-width: 1100px;
}

.hero-label {
    display: inline-flex;
    align-items: center;
    gap: 10px;
    padding: 8px 20px;
    border-radius: 100px;
    background: rgba(212, 160, 32, 0.1);
    border: 1px solid rgba(212, 160, 32, 0.3);
    color: var(--hero-gold-shine);
    font-size: 0.9rem;
    font-weight: 700;
    letter-spacing: 1px;
    margin-bottom: 30px;
    backdrop-filter: blur(5px);
}

.hero-title {
    font-size: clamp(2.8rem, 8vw, 6rem);
    font-weight: 900;
    line-height: 1.1;
    margin-bottom: 30px;
    letter-spacing: -2px;
}

.hero-title span {
    display: block;
}

.hero-desc {
    font-size: clamp(1.1rem, 2.5vw, 1.4rem);
    color: rgba(255, 255, 255, 0.7);
    max-width: 750px;
    margin: 0 auto 50px;
    line-height: 1.8;
}

.hero-actions {
    display: flex;
    gap: 20px;
    justify-content: center;
    flex-wrap: wrap;
}

/* Premium Button */
.btn-premium {
    position: relative;
    padding: 20px 45px;
    border-radius: 16px;
    font-weight: 800;
    font-size: 1.1rem;
    color: var(--hero-dark);
    background: var(--grad-metal);
    border: none;
    overflow: hidden;
    transition: all 0.4s cubic-bezier(0.23, 1, 0.32, 1);
    box-shadow: 0 10px 30px rgba(212, 160, 32, 0.3);
    display: inline-flex;
    align-items: center;
    gap: 10px;
}

.btn-premium::after {
    content: '';
    position: absolute;
    top: 0; left: -100%; width: 100%; height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.6), transparent);
    transition: 0.5s;
}

.btn-premium:hover {
    transform: translateY(-5px);
    box-shadow: 0 20px 50px rgba(212, 160, 32, 0.5);
}

.btn-premium:hover::after { left: 100%; }

.btn-outline {
    padding: 20px 45px;
    border-radius: 16px;
    font-weight: 800;
    font-size: 1.1rem;
    color: white;
    background: transparent;
    border: 1px solid rgba(255,255,255,0.2);
    backdrop-filter: blur(5px);
    transition: all 0.3s ease;
}

.btn-outline:hover {
    background: rgba(255,255,255,0.1);
    border-color: white;
}

/* ══════════════════════════════════════════════════════════════════════════════
   2. STATS TICKER - INFINITE LOOP
   ══════════════════════════════════════════════════════════════════════════════ */
.stats-ticker-wrapper {
    background: var(--hero-gold);
    transform: rotate(-2deg) scale(1.05);
    padding: 20px 0;
    margin-top: -40px;
    position: relative;
    z-index: 20;
    box-shadow: 0 10px 30px rgba(0,0,0,0.2);
    border-top: 2px solid var(--hero-white);
    border-bottom: 2px solid var(--hero-white);
    overflow: hidden;
}

.stats-ticker {
    display: flex;
    white-space: nowrap;
    animation: ticker 20s linear infinite;
}

.ticker-item {
    font-size: 1.5rem;
    font-weight: 900;
    color: var(--hero-dark);
    padding: 0 40px;
    display: flex;
    align-items: center;
    gap: 10px;
}

.ticker-item::after {
    content: "✦";
    margin-right: 40px;
    opacity: 0.5;
}

@keyframes ticker {
    0% { transform: translateX(0); }
    100% { transform: translateX(-50%); }
}

/* ══════════════════════════════════════════════════════════════════════════════
   3. WHY US - BENTO GRID LAYOUT
   ══════════════════════════════════════════════════════════════════════════════ */
.why-section {
    padding: 120px 20px;
    position: relative;
}

.section-header {
    text-align: center;
    margin-bottom: 80px;
    max-width: 800px;
    margin-left: auto;
    margin-right: auto;
}

.section-subtitle {
    color: var(--hero-orange);
    font-weight: 800;
    letter-spacing: 2px;
    text-transform: uppercase;
    display: block;
    margin-bottom: 15px;
    font-size: 0.9rem;
}

.section-title {
    font-size: clamp(2rem, 5vw, 3.5rem);
    font-weight: 900;
    color: var(--hero-brown);
    line-height: 1.2;
}

.bento-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    grid-template-rows: repeat(2, 300px);
    gap: 24px;
    max-width: 1300px;
    margin: 0 auto;
}

.bento-card {
    background: white;
    border-radius: 32px;
    padding: 40px;
    position: relative;
    overflow: hidden;
    transition: all 0.5s cubic-bezier(0.23, 1, 0.32, 1);
    border: 1px solid rgba(0,0,0,0.05);
    display: flex;
    flex-direction: column;
    justify-content: flex-end;
    box-shadow: var(--shadow-xs);
}

.bento-card:hover {
    transform: translateY(-10px);
    box-shadow: var(--shadow-xl);
}

/* Card Specifics */
.bento-large {
    grid-column: span 2;
    background: var(--hero-dark);
    color: white;
}

.bento-card h3 {
    font-size: 1.8rem;
    font-weight: 800;
    margin-bottom: 15px;
    z-index: 2;
}

.bento-card p {
    font-size: 1.1rem;
    opacity: 0.8;
    z-index: 2;
    line-height: 1.6;
}

.bento-icon {
    position: absolute;
    top: 30px;
    right: 30px;
    width: 60px;
    height: 60px;
    background: rgba(212, 160, 32, 0.1);
    border-radius: 16px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.5rem;
    color: var(--hero-gold);
    transition: 0.4s;
}

.bento-card:hover .bento-icon {
    background: var(--hero-gold);
    color: white;
    transform: rotate(-10deg) scale(1.1);
}

/* Background decorations for cards */
.bento-deco {
    position: absolute;
    inset: 0;
    opacity: 0.1;
    transition: 0.5s;
}
.bento-card:hover .bento-deco { opacity: 0.2; transform: scale(1.1); }

/* ══════════════════════════════════════════════════════════════════════════════
   4. SERVICES - 3D CAROUSEL
   ══════════════════════════════════════════════════════════════════════════════ */
.services-section {
    background: var(--hero-brown);
    padding: 120px 20px;
    color: white;
    position: relative;
}

.services-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
    gap: 40px;
    max-width: 1300px;
    margin: 0 auto;
    perspective: 1000px;
}

.service-card-3d {
    background: rgba(255,255,255,0.03);
    border: 1px solid rgba(255,255,255,0.1);
    border-radius: 30px;
    padding: 50px 30px;
    text-align: center;
    transition: 0.6s cubic-bezier(0.23, 1, 0.32, 1);
    position: relative;
    overflow: hidden;
}

.service-card-3d::before {
    content: '';
    position: absolute;
    inset: 0;
    background: linear-gradient(180deg, transparent 0%, rgba(212, 160, 32, 0.1) 100%);
    opacity: 0;
    transition: 0.5s;
}

.service-card-3d:hover {
    background: rgba(255,255,255,0.08);
    transform: translateY(-15px) rotateX(5deg);
    border-color: var(--hero-gold);
    box-shadow: 0 30px 60px rgba(0,0,0,0.5);
}

.service-card-3d:hover::before { opacity: 1; }

.service-icon-glow {
    width: 90px;
    height: 90px;
    margin: 0 auto 30px;
    background: radial-gradient(circle, rgba(212,160,32,0.4) 0%, transparent 70%);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 3rem;
    position: relative;
}

.service-card-3d h3 {
    font-size: 1.8rem;
    font-weight: 800;
    margin-bottom: 15px;
    color: var(--hero-gold-shine);
}

.service-card-3d p {
    color: rgba(255,255,255,0.7);
    line-height: 1.7;
    margin-bottom: 30px;
}

.service-link {
    display: inline-block;
    color: white;
    font-weight: 700;
    border-bottom: 2px solid var(--hero-orange);
    padding-bottom: 5px;
    transition: 0.3s;
}
.service-link:hover { color: var(--hero-orange); }

/* ══════════════════════════════════════════════════════════════════════════════
   5. FEATURED - MAGAZINE STYLE
   ══════════════════════════════════════════════════════════════════════════════ */
.featured-section {
    padding: 140px 20px;
    position: relative;
}

.featured-layout {
    display: grid;
    grid-template-columns: 1.2fr 0.8fr;
    gap: 80px;
    max-width: 1300px;
    margin: 0 auto;
    align-items: center;
}

.featured-visual {
    position: relative;
}

.img-frame {
    border-radius: 40px;
    overflow: hidden;
    position: relative;
    transform: rotate(-3deg);
    box-shadow: var(--shadow-xl);
    transition: 0.8s;
    border: 8px solid white;
}

.img-frame:hover { transform: rotate(0deg) scale(1.02); }

.img-frame img {
    width: 100%;
    height: auto;
    display: block;
}

.floating-stat {
    position: absolute;
    bottom: 40px;
    right: -30px;
    background: var(--hero-gold);
    color: var(--hero-dark);
    padding: 20px 40px;
    border-radius: 20px;
    font-weight: 900;
    box-shadow: var(--shadow-lg);
    animation: float 6s infinite ease-in-out;
    z-index: 5;
}

.floating-stat span { font-size: 2.5rem; display: block; line-height: 1; }
.floating-stat small { font-size: 0.9rem; text-transform: uppercase; letter-spacing: 1px; }

.featured-content h2 {
    font-size: 3.5rem;
    font-weight: 900;
    line-height: 1.1;
    margin-bottom: 30px;
    color: var(--hero-brown);
}

.featured-content .highlight {
    position: relative;
    z-index: 1;
    display: inline-block;
}

.featured-content .highlight::after {
    content: '';
    position: absolute;
    bottom: 5px;
    left: 0;
    width: 100%;
    height: 15px;
    background: var(--hero-gold);
    opacity: 0.4;
    z-index: -1;
    transform: skewX(-20deg);
}

.featured-desc {
    font-size: 1.2rem;
    line-height: 1.8;
    color: var(--text-body);
    margin-bottom: 40px;
}

.stats-row {
    display: flex;
    gap: 40px;
    padding-top: 30px;
    border-top: 1px solid rgba(0,0,0,0.1);
}

.stat-box h4 { font-size: 2.5rem; font-weight: 900; color: var(--hero-orange); margin: 0; line-height: 1; }
.stat-box p { font-size: 0.9rem; font-weight: 700; color: var(--text-muted); margin-top: 5px; }

/* ══════════════════════════════════════════════════════════════════════════════
   6. TIMELINE - PATH TO VICTORY
   ══════════════════════════════════════════════════════════════════════════════ */
.process-section {
    background: #F2F2F2;
    padding: 120px 20px;
    position: relative;
}

.process-path {
    position: absolute;
    left: 50%;
    top: 0;
    bottom: 0;
    width: 4px;
    background: rgba(0,0,0,0.05);
    transform: translateX(-50%);
}

.process-active-line {
    position: absolute;
    left: 50%;
    top: 0;
    width: 4px;
    height: 200px; /* Animated via JS usually, fixed for now */
    background: var(--grad-fire);
    transform: translateX(-50%);
    box-shadow: 0 0 20px var(--hero-orange);
}

.process-item {
    display: flex;
    justify-content: center;
    align-items: center;
    margin-bottom: 100px;
    position: relative;
}

.process-content {
    width: 40%;
    background: white;
    padding: 40px;
    border-radius: 24px;
    box-shadow: var(--shadow-xl);
    position: relative;
    transition: 0.4s;
}

.process-content:hover { transform: scale(1.03); }

.process-item:nth-child(odd) { flex-direction: row-reverse; }
.process-item:nth-child(odd) .process-content { margin-left: 50px; }
.process-item:nth-child(even) .process-content { margin-right: 50px; text-align: right; }

.process-marker {
    position: absolute;
    left: 50%;
    width: 60px;
    height: 60px;
    background: var(--hero-brown);
    color: var(--hero-gold);
    border-radius: 50%;
    transform: translateX(-50%);
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 900;
    font-size: 1.5rem;
    border: 4px solid white;
    box-shadow: 0 0 0 4px rgba(45, 24, 16, 0.1);
    z-index: 5;
}

/* ══════════════════════════════════════════════════════════════════════════════
   7. FAQ - ACCORDION
   ══════════════════════════════════════════════════════════════════════════════ */
.faq-section {
    padding: 120px 20px;
    background: linear-gradient(180deg, #FAF7F2 0%, #F5EBE0 100%);
}

.faq-section h2 {
    text-align: center;
    font-size: clamp(1.8rem, 4vw, 2.5rem);
    color: var(--hero-brown);
    margin-bottom: 60px;
}

.faq-wrapper {
    max-width: 900px;
    margin: 0 auto;
}

.faq-item {
    background: white;
    border-radius: 16px;
    margin-bottom: 16px;
    box-shadow: 0 4px 15px rgba(0,0,0,0.05);
    overflow: hidden;
    border: 1px solid rgba(212, 160, 32, 0.1);
    transition: all 0.3s ease;
}

.faq-item:hover {
    box-shadow: 0 8px 25px rgba(0,0,0,0.08);
    border-color: rgba(212, 160, 32, 0.2);
}

.faq-item.active {
    border-color: var(--hero-gold);
    box-shadow: 0 8px 25px rgba(212, 160, 32, 0.15);
}

.faq-header {
    padding: 24px 28px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    cursor: pointer;
    font-size: 1.1rem;
    font-weight: 700;
    color: var(--hero-brown);
    transition: 0.3s;
    gap: 15px;
}

.faq-header:hover { color: var(--hero-gold); }

.faq-icon {
    min-width: 32px;
    width: 32px;
    height: 32px;
    background: linear-gradient(135deg, var(--hero-gold), #E8B830);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: 0.3s;
    color: var(--hero-brown);
    font-weight: 700;
    font-size: 1.3rem;
}

.faq-item.active .faq-icon {
    transform: rotate(45deg);
    background: var(--hero-orange);
    color: white;
}

.faq-body {
    max-height: 0;
    overflow: hidden;
    transition: all 0.4s ease;
    color: var(--text-body);
    line-height: 2;
    font-size: 1rem;
}

.faq-item.active .faq-body {
    max-height: 500px;
    padding: 0 28px 28px 28px;
}

/* ══════════════════════════════════════════════════════════════════════════════
   8. CTA - FINAL PUSH
   ══════════════════════════════════════════════════════════════════════════════ */
.cta-section {
    margin: 0 20px 60px;
}

.cta-box {
    background: var(--grad-dark);
    border-radius: 40px;
    padding: 100px 40px;
    text-align: center;
    color: white;
    position: relative;
    overflow: hidden;
    box-shadow: 0 30px 80px rgba(0,0,0,0.4);
}

.cta-box::before {
    content: '';
    position: absolute;
    top: 0; left: 0; width: 100%; height: 100%;
    background: radial-gradient(circle at center, rgba(212, 160, 32, 0.2) 0%, transparent 70%);
    pointer-events: none;
}

.cta-title {
    font-size: clamp(2.5rem, 6vw, 4rem);
    font-weight: 900;
    margin-bottom: 30px;
    text-transform: uppercase;
}

.cta-desc {
    font-size: 1.3rem;
    color: rgba(255,255,255,0.7);
    max-width: 700px;
    margin: 0 auto 50px;
}

/* ══════════════════════════════════════════════════════════════════════════════
   📱 MOBILE OPTIMIZATIONS (Crucial)
   ══════════════════════════════════════════════════════════════════════════════ */
@media (max-width: 1024px) {
    .bento-grid { grid-template-columns: 1fr 1fr; grid-template-rows: auto; }
    .bento-large { grid-column: span 2; }
    .featured-layout { grid-template-columns: 1fr; }
    .img-frame { transform: rotate(0); margin-bottom: 40px; }
    .floating-stat { right: 0; bottom: -20px; }
}

@media (max-width: 768px) {
    .hero-section { padding-top: 120px; }
    .bento-grid { grid-template-columns: 1fr; }
    .bento-large { grid-column: span 1; }
    
    .process-item, .process-item:nth-child(odd) { flex-direction: column; }
    .process-content, .process-item:nth-child(odd) .process-content, .process-item:nth-child(even) .process-content {
        width: 100%; margin: 0 0 50px 0; text-align: center; padding: 30px 20px;
    }
    .process-content h3 { padding-top: 10px; }
    .process-marker {
        position: absolute;
        top: -25px;
        bottom: auto;
        left: 50%;
        transform: translateX(-50%);
        width: 50px;
        height: 50px;
        font-size: 1.2rem;
    }
    .process-path { display: none; }
    .process-item { margin-bottom: 60px; }
    
    .stats-row { flex-wrap: wrap; gap: 20px; }
    .stat-box { width: 45%; }
    
    .cta-box { padding: 60px 20px; }
}
</style>

<!-- CONTENT STRUCTURE -->
<div class="event-page">

    <!-- 1. HERO -->
    <section class="hero-section">
        <div class="hero-bg-mesh"></div>
        <div class="hero-grid-lines"></div>
        
        <div class="hero-content">
            <div class="hero-label wow fadeInDown">✨ Premium Events Production</div>
            <h1 class="hero-title wow fadeInUp" data-wow-delay="0.2s">
                <span class="text-gradient">خلق حماسه‌ای ماندگار</span>
                <span>در رویدادهای شما</span>
            </h1>
            <p class="hero-desc wow fadeInUp" data-wow-delay="0.4s">
                ما فقط همایش برگزار نمی‌کنیم؛ ما تجربه می‌سازیم. تیمی متخصص برای تبدیل ایده‌های جسورانه شما به واقعیتی خیره‌کننده، با دقتی وسواس‌گونه.
            </p>
            <div class="hero-actions wow fadeInUp" data-wow-delay="0.6s">
                <a href="<?php echo URL; ?>/contact" class="btn-premium">
                    شروع همکاری
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>
                </a>
                <a href="#portfolio" class="btn-outline">نمونه کارها</a>
            </div>
        </div>
    </section>

    <!-- 2. STATS TICKER -->
    <div class="stats-ticker-wrapper">
        <div class="stats-ticker">
            <div class="ticker-item">برگزاری بیش از ۵۰ همایش ملی</div>
            <div class="ticker-item">طراحی اختصاصی غرفه‌های نمایشگاهی</div>
            <div class="ticker-item">تیم اجرایی مقیم در سراسر کشور</div>
            <div class="ticker-item">رعایت استانداردهای بین‌المللی تشریفات</div>
            <div class="ticker-item">برگزاری بیش از ۵۰ همایش ملی</div>
            <div class="ticker-item">طراحی اختصاصی غرفه‌های نمایشگاهی</div>
        </div>
    </div>

    <!-- 3. WHY US (BENTO GRID) -->
    <section class="why-section">
        <div class="section-header">
            <span class="section-subtitle">چرا طراحان باستان؟</span>
            <h2 class="section-title">تفاوت در جزئیات است</h2>
        </div>

        <div class="bento-grid">
            <div class="bento-card bento-large wow fadeInUp">
                <div class="bento-deco" style="background: url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI0MCIgaGVpZ2h0PSI0MCIgdmlld0JveD0iMCAwIDQwIDQwIj48ZyBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNGRkZGRkYiIGZpbGwtb3BhY2l0eT0iMC4xIj48cGF0aCBkPSJNMCAwaDQwdjQwSDBWMHptMjAgMjBoMjB2MjBIMjAyMHpNMjAgMGgyMHYyMEgyMFYweiIvPjwvZz48L2c+PC9zdmc+')"></div>
                <div class="bento-icon">🚀</div>
                <h3>مدیریت یکپارچه و چابک</h3>
                <p>حذف تمام واسطه‌ها. ما تیم طراحی، تیم ساخت، تیم فنی و تیم تشریفات را زیر یک سقف داریم. این یعنی سرعت اجرای بالاتر و هزینه کمتر برای شما.</p>
            </div>
            <div class="bento-card wow fadeInUp" data-wow-delay="0.2s">
                <div class="bento-icon">💎</div>
                <h3>متریال لوکس</h3>
                <p>استفاده از سازه‌های اسپیس‌فریم مهندسی شده و متریال‌های دکوراتیو وارداتی.</p>
            </div>
            <div class="bento-card wow fadeInUp" data-wow-delay="0.3s">
                <div class="bento-icon">💡</div>
                <h3>خلاقیت بی‌پایان</h3>
                <p>طراحی‌هایی که کپی نیستند. هر رویداد هویت بصری منحصر به فرد خود را دارد.</p>
            </div>
            <div class="bento-card bento-large wow fadeInUp" data-wow-delay="0.4s" style="background: #fff; color: var(--hero-brown);">
                <div class="bento-icon" style="background: var(--hero-orange); color: white;">🎯</div>
                <h3>تضمین زمان تحویل</h3>
                <p>در صنعت برگزاری رویداد، یک دقیقه تاخیر یعنی فاجعه. ما با قرارداد رسمی، تحویل دقیق و به موقع پروژه را (حتی یک ساعت زودتر) تضمین می‌کنیم.</p>
            </div>
        </div>
    </section>

    <!-- 4. SERVICES 3D -->
    <section class="services-section" id="services">
        <div class="section-header">
            <h2 class="section-title" style="color: white">خدمات ۳۶۰ درجه</h2>
            <p style="color: rgba(255,255,255,0.7)">تمام نیازهای شما در یک پکیج کامل</p>
        </div>

        <div class="services-grid">
            <div class="service-card-3d wow flipInY">
                <div class="service-icon-glow">🏛️</div>
                <h3>برگزاری همایش</h3>
                <p>از رزرو سالن و دعوت سخنرانان تا پذیرایی و صدور گواهی‌نامه. مدیریت صفر تا صد.</p>
                <a href="#" class="service-link">جزئیات بیشتر</a>
            </div>
            <div class="service-card-3d wow flipInY" data-wow-delay="0.2s">
                <div class="service-icon-glow">🏗️</div>
                <h3>غرفه‌سازی</h3>
                <p>طراحی و ساخت غرفه‌های نمایشگاهی خاص با متریال چوب، فلز و شیشه.</p>
                <a href="#" class="service-link">مشاهده نمونه‌ها</a>
            </div>
            <div class="service-card-3d wow flipInY" data-wow-delay="0.4s">
                <div class="service-icon-glow">🎬</div>
                <h3>تولید مدیا</h3>
                <p>تیم فیلمبرداری حرفه‌ای، ساخت تیزر، پخش زنده و پوشش خبری رویداد.</p>
                <a href="#" class="service-link">تجهیزات ما</a>
            </div>
        </div>
    </section>

    <!-- 5. FEATURED STORY -->
    <section class="featured-section">
        <div class="featured-layout">
            <div class="featured-visual wow fadeInLeft">
                <div class="img-frame">
                    <img src="public/images/hamedan2018.jpg" alt="همایش همدان ۲۰۱۸">
                </div>
                <div class="floating-stat">
                    <span>۱۵</span>
                    <small>کشور شرکت‌کننده</small>
                </div>
            </div>
            <div class="featured-content wow fadeInRight">
                <h2>وقتی غیرممکن، <br><span class="highlight">ممکن شد</span></h2>
                <p class="featured-desc">
                    روایت همایش بین‌المللی همدان ۲۰۱۸. پروژه‌ای که تنها ۴۵ روز زمان داشت و هیچ پیمانکاری ریسک آن را نمی‌پذیرفت. طراحان باستان با بسیج ۱۰۰ نفر نیروی متخصص، میزبان شایسته‌ای برای نمایندگان ۱۵ کشور جهان بود.
                </p>
                <div class="stats-row">
                    <div class="stat-box">
                        <h4>۴۵</h4>
                        <p>روز تلاش شبانه‌روزی</p>
                    </div>
                    <div class="stat-box">
                        <h4>۱۰۰٪</h4>
                        <p>رضایت استانداری</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- 6. PROCESS PATH -->
    <section class="process-section">
        <div class="section-header">
            <h2 class="section-title">مسیر موفقیت</h2>
        </div>
        
        <div class="process-path"></div>
        <!-- An active line could be animated with JS based on scroll position -->
        
        <div class="process-item wow fadeInUp">
            <div class="process-content">
                <h3>۱. استراتژی و سناریو</h3>
                <p>تعریف دقیق اهداف همایش و نوشتن سناریوی اجرایی لحظه به لحظه.</p>
            </div>
            <div class="process-marker">۱</div>
        </div>

        <div class="process-item wow fadeInUp">
            <div class="process-content">
                <h3>۲. طراحی هویت بصری</h3>
                <p>طراحی لوگو، پوستر، دعوت‌نامه و دکوراسیون محیطی هماهنگ با برند.</p>
            </div>
            <div class="process-marker">۲</div>
        </div>

        <div class="process-item wow fadeInUp">
            <div class="process-content">
                <h3>۳. اجرا و لجستیک</h3>
                <p>ساخت دکور، نصب تجهیزات صوتی تصویری و چیدمان سالن.</p>
            </div>
            <div class="process-marker">۳</div>
        </div>

        <div class="process-item wow fadeInUp">
            <div class="process-content">
                <h3>۴. مدیریت روز رویداد</h3>
                <p>کارگردانی صحنه، مدیریت کنداکتور و پذیرایی از مهمانان.</p>
            </div>
            <div class="process-marker">۴</div>
        </div>
    </section>

    <!-- 7. FAQ -->
    <section class="faq-section">
        <div class="section-header">
            <h2 class="section-title">سوالات متداول</h2>
        </div>
        <div class="container" style="max-width: 800px;">
            <div class="faq-item wow fadeInUp">
                <div class="faq-header">
                    هزینه برگزاری همایش چقدر است؟
                    <div class="faq-icon">+</div>
                </div>
                <div class="faq-body">
                    هزینه بسته به تعداد مهمانان، محل برگزاری، نوع پذیرایی و تجهیزات مورد نیاز متغیر است. ما در جلسه مشاوره اولیه، بودجه شما را بررسی و بهترین پلن را پیشنهاد می‌دهیم.
                </div>
            </div>
            <div class="faq-item wow fadeInUp" data-wow-delay="0.1s">
                <div class="faq-header">
                    آیا خدمات شما شامل شهرستان‌ها هم می‌شود؟
                    <div class="faq-icon">+</div>
                </div>
                <div class="faq-body">
                    بله، تیم اجرایی ما آمادگی سفر و اجرای پروژه در تمام نقاط کشور را دارد. هزینه‌های لجستیک به صورت جداگانه محاسبه می‌شود.
                </div>
            </div>
            <div class="faq-item wow fadeInUp" data-wow-delay="0.2s">
                <div class="faq-header">
                    حداقل زمان مورد نیاز برای هماهنگی چقدر است؟
                    <div class="faq-icon">+</div>
                </div>
                <div class="faq-body">
                    برای همایش‌های کوچک حداقل ۲ هفته و برای همایش‌های بزرگ حداقل ۲ ماه زمان پیشنهاد می‌شود تا کیفیت اجرا تضمین گردد.
                </div>
            </div>
        </div>
    </section>

    <!-- 8. CTA -->
    <section class="cta-section">
        <div class="cta-box wow pulse">
            <h2 class="cta-title">آماده درخشش هستید؟</h2>
            <p class="cta-desc">زمان آن رسیده که برند خود را با شکوهی که شایسته آن است به نمایش بگذارید. مشاوره رایگان ما اولین قدم است.</p>
            <a href="<?php echo URL; ?>/contact" class="btn-premium" style="background: white; color: var(--hero-brown);">
                رزرو وقت مشاوره
            </a>
        </div>
    </section>

</div>

<script>
    // Initialize Animations
    new WOW().init();

    // FAQ Interaction
    document.querySelectorAll('.faq-header').forEach(header => {
        header.addEventListener('click', () => {
            const item = header.parentElement;
            const body = item.querySelector('.faq-body');
            
            // Close others
            document.querySelectorAll('.faq-item').forEach(i => {
                if(i !== item) {
                    i.classList.remove('active');
                    i.querySelector('.faq-body').style.maxHeight = null;
                }
            });

            // Toggle current
            item.classList.toggle('active');
            if (item.classList.contains('active')) {
                body.style.maxHeight = body.scrollHeight + "px";
            } else {
                body.style.maxHeight = null;
            }
        });
    });
</script>