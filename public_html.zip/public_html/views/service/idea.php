
<?php
/**
 * TARAHAN BASTAN - IDEA & CONSULTING SERVICE PAGE
 * Masterpiece Edition v6.0
 * Concept: The Golden Neural Network (Structure of Genius)
 * Focus: Extreme Depth, Double-Layered Elements, Premium Physics
 */
?>

<!-- WOW.js & Animate.css -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" integrity="sha512-c42qTSw/wPZ3/5LBzD+Bw5f7bSF2oxou6wEb+I/lqeaKV5FDIfMvvRp772y4jcJLKuGUOpbJMdg/BTl50fJYAw==" crossorigin="anonymous" referrerpolicy="no-referrer">
<script src="https://cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.min.js" integrity="sha512-Eak/29OTpb36LLo2r47IpVzPBLXnAMPAVypbSZiZ4Qkf8p/7S/XRG5xp7OKWPPYfJT6metI+IORkR5G8F900+g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<style>
    /* ═══════════════════════════════════════════════════════════════════════════
       💎 MASTERPIECE VARIABLES
       ═══════════════════════════════════════════════════════════════════════════ */
    :root {
        --font-primary: 'YekanBakh', sans-serif;
        
        /* 🎨 Palette: The Royal Studio */
        --color-brown-deep: #2D1810;
        --color-brown-rich: #4A2C1A;
        
        --color-gold-pure: #D4A020;
        --color-gold-metallic: #B8890F;
        --color-gold-glow: #FFD700;
        
        --color-orange-vital: #F58500;
        --color-orange-burn: #FF4500;
        
        --bg-paper: #F9F7F2;
        --bg-cream: #F5EFE6;
        
        /* 🌌 Gradients with DEPTH */
        --grad-gold-luxury: linear-gradient(135deg, #CCA045 0%, #FFE082 50%, #B88A30 100%);
        --grad-gold-text: linear-gradient(to bottom, #D4A020, #8F6B15);
        --grad-card-glass: linear-gradient(145deg, rgba(255,255,255,0.95) 0%, rgba(255,248,235,0.85) 100%);
        --grad-card-back: linear-gradient(135deg, #2D1810 0%, #4A2C1A 100%);
        
        /* 🌑 Ultra Shadows */
        --shadow-layer-1: 0 10px 30px -5px rgba(45, 24, 16, 0.1);
        --shadow-layer-2: 0 25px 60px -10px rgba(45, 24, 16, 0.15);
        --shadow-neon: 0 0 20px rgba(212, 160, 32, 0.4);
        --shadow-inset-gold: inset 0 0 0 1px rgba(212, 160, 32, 0.2), inset 0 2px 10px rgba(255,255,255,0.5);
    }

    /* ═══════════════════════════════════════════════════════════════════════════
       🛠 GLOBAL RESET & TYPOGRAPHY
       ═══════════════════════════════════════════════════════════════════════════ */
    body {
        background-color: var(--bg-paper);
        color: var(--color-brown-deep);
        font-family: var(--font-primary) !important;
        line-height: 1.9;
        overflow-x: hidden;
    }

    h1, h2, h3, h4, h5, h6, p, span, div, a, button, input {
        font-family: var(--font-primary) !important;
    }

    /* Ensure cursor visibility on all interactive elements */
    a, button, [role="button"], input, select, textarea, label, summary,
    .btn-primary, .btn-secondary, .faq-header, .portfolio-item {
        cursor: pointer !important;
    }

    /* Noise Texture Overlay for Premium Paper Feel */
    .global-texture {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.65' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3e%3crect width='100%25' height='100%25' filter='url(%23noiseFilter)' opacity='0.03'/%3E%3C/svg%3E");
        pointer-events: none;
        z-index: 9999;
        mix-blend-mode: multiply;
    }

    .container-master {
        max-width: 1360px;
        margin: 0 auto;
        padding: 0 30px;
        position: relative;
        z-index: 2;
    }

    /* ═══════════════════════════════════════════════════════════════════════════
       1. HERO SECTION: THE GEOMETRY OF THOUGHT
       ═══════════════════════════════════════════════════════════════════════════ */
    .hero-master {
        position: relative;
        min-height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
        background: radial-gradient(circle at center, #FFFDF5 0%, #F2E6D8 100%);
        overflow: hidden;
        padding: 150px 0 100px;
    }

    /* 3D Floating Elements (CSS Only) */
    .hero-geometry {
        position: absolute;
        inset: 0;
        perspective: 1000px;
        pointer-events: none;
    }

    .geo-shape {
        position: absolute;
        transform-style: preserve-3d;
        animation: floatRotate 20s infinite linear;
        opacity: 0.6;
    }

    .geo-cube {
        width: 100px;
        height: 100px;
        border: 1px solid rgba(212, 160, 32, 0.3);
        position: absolute;
    }

    /* Shape Positions */
    .shape-1 { top: 15%; left: 10%; animation-duration: 25s; }
    .shape-2 { bottom: 20%; right: 10%; animation-duration: 30s; animation-direction: reverse; }
    .shape-3 { top: 40%; right: 25%; width: 60px; height: 60px; border-color: rgba(245, 133, 0, 0.2); animation-duration: 18s; }

    @keyframes floatRotate {
        0% { transform: translateY(0) rotateX(0) rotateY(0); }
        50% { transform: translateY(-40px) rotateX(180deg) rotateY(90deg); }
        100% { transform: translateY(0) rotateX(360deg) rotateY(180deg); }
    }

    .hero-content-wrapper {
        position: relative;
        z-index: 10;
        text-align: center;
        max-width: 1000px;
    }

    /* Premium Badge */
    .hero-badge-royal {
        display: inline-flex;
        align-items: center;
        gap: 12px;
        background: rgba(255,255,255,0.9);
        backdrop-filter: blur(10px);
        padding: 12px 30px;
        border-radius: 60px;
        border: 1px solid var(--color-gold-pure);
        box-shadow: 0 10px 20px rgba(212, 160, 32, 0.15);
        margin-bottom: 40px;
    }

    .hero-badge-royal span {
        font-weight: 900;
        color: var(--color-brown-deep);
        letter-spacing: 1px;
        text-transform: uppercase;
        font-size: 0.9rem;
    }

    .hero-badge-royal i {
        color: var(--color-orange-vital);
        font-size: 1.2rem;
    }

    /* Massive Title with Depth */
    .hero-title-master {
        font-size: clamp(3rem, 7vw, 5.5rem);
        line-height: 1.1;
        font-weight: 900;
        color: var(--color-brown-deep);
        margin-bottom: 30px;
        position: relative;
    }

    .hero-title-highlight {
        background: var(--grad-gold-luxury);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        position: relative;
        display: inline-block;
    }
    
    /* Glow behind text */
    .hero-title-highlight::after {
        content: attr(data-text);
        position: absolute;
        left: 0;
        top: 0;
        z-index: -1;
        background: none;
        -webkit-text-stroke: 8px rgba(212, 160, 32, 0.1);
        opacity: 0.5;
    }

    .hero-desc-master {
        font-size: 1.25rem;
        color: var(--color-brown-rich);
        max-width: 750px;
        margin: 0 auto 50px;
        line-height: 1.8;
    }

    /* ═══════════════════════════════════════════════════════════════════════════
       2. TIMELINE: THE DOUBLE-LAYERED ASCENSION (FIXED)
       ═══════════════════════════════════════════════════════════════════════════ */
    .timeline-section {
        padding: 150px 0;
        background: linear-gradient(to bottom, #fff 0%, #F9F7F2 100%);
        position: relative;
    }

    .section-title-wrapper {
        text-align: center;
        margin-bottom: 100px;
    }

    .section-title-master {
        font-size: 3.5rem;
        font-weight: 900;
        color: var(--color-brown-deep);
        position: relative;
        display: inline-block;
    }

    .section-title-master::after {
        content: '';
        display: block;
        width: 80%;
        height: 6px;
        background: var(--color-orange-vital);
        margin: 10px auto 0;
        border-radius: 10px;
    }

    /* Timeline Physics */
    .ascension-path {
        position: relative;
        max-width: 1100px;
        margin: 0 auto;
    }

    /* The Golden Spine */
    .ascension-spine {
        position: absolute;
        left: 50%;
        top: 0;
        bottom: 0;
        width: 6px;
        background: linear-gradient(to bottom, 
            var(--color-gold-pure) 0%, 
            var(--color-orange-vital) 50%, 
            var(--color-brown-deep) 100%);
        transform: translateX(-50%);
        border-radius: 10px;
        z-index: 1;
        box-shadow: 0 0 20px rgba(212, 160, 32, 0.3);
    }

    .ascension-step {
        position: relative;
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 120px;
        z-index: 5;
    }

    /* Alternating Directions */
    .ascension-step:nth-child(odd) { flex-direction: row-reverse; }
    
    /* THE DOUBLE-LAYERED BOX SYSTEM */
    .step-card-wrapper {
        width: 45%;
        position: relative;
        perspective: 1000px; /* Enable 3D */
    }

    /* Layer 1: The Shadow/Base (Deep Gold) */
    .step-layer-back {
        position: absolute;
        top: 20px;
        left: 20px;
        width: 100%;
        height: 100%;
        background: var(--grad-card-back);
        border-radius: 30px;
        z-index: 1;
        opacity: 0.8;
        transform: rotateZ(-2deg); /* Slight tilt for depth */
        transition: transform 0.5s ease;
    }
    
    /* Layer 2: The Content (Glass/Paper) */
    .step-layer-front {
        position: relative;
        background: var(--grad-card-glass);
        backdrop-filter: blur(20px);
        border: 1px solid rgba(255,255,255,0.8);
        border-radius: 30px;
        padding: 40px;
        z-index: 2;
        box-shadow: var(--shadow-layer-2);
        transform-style: preserve-3d;
        transition: transform 0.5s ease;
    }

    /* Hover Effect: Layers separate further */
    .step-card-wrapper:hover .step-layer-back {
        transform: rotateZ(-4deg) translate(-10px, 10px);
    }
    .step-card-wrapper:hover .step-layer-front {
        transform: translateY(-10px);
    }

    /* The Giant Number (Background Depth) */
    .step-number-giant {
        position: absolute;
        top: -40px;
        font-size: 8rem;
        font-weight: 900;
        color: rgba(212, 160, 32, 0.15);
        z-index: 0;
        line-height: 1;
        font-family: var(--font-primary);
        pointer-events: none;
    }
    
    .ascension-step:nth-child(odd) .step-number-giant { right: -20px; }
    .ascension-step:nth-child(even) .step-number-giant { left: -20px; }

    /* Connector Dot */
    .step-connector {
        position: absolute;
        left: 50%;
        top: 50%;
        transform: translate(-50%, -50%);
        width: 24px;
        height: 24px;
        background: var(--color-gold-pure);
        border: 4px solid #fff;
        border-radius: 50%;
        box-shadow: 0 0 0 4px var(--color-gold-pure);
        z-index: 10;
    }

    /* Content Styling */
    .step-title {
        font-size: 1.8rem;
        font-weight: 900;
        color: var(--color-brown-deep);
        margin-bottom: 15px;
    }

    .step-desc {
        font-size: 1rem;
        color: #666;
        line-height: 1.8;
    }

    /* ═══════════════════════════════════════════════════════════════════════════
       3. CARDS: SERVICES & FEATURES (Stacked Cards)
       ═══════════════════════════════════════════════════════════════════════════ */
    .services-grid-master {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
        gap: 40px;
        padding: 100px 0;
    }

    .service-stack {
        position: relative;
        height: 100%;
        transition: transform 0.4s ease;
    }

    /* Stack Effect */
    .service-stack::before {
        content: '';
        position: absolute;
        top: 15px;
        left: 15px;
        right: -15px;
        bottom: -15px;
        background: rgba(212, 160, 32, 0.1);
        border-radius: 30px;
        z-index: 0;
        transition: all 0.4s ease;
    }

    .service-card-front {
        position: relative;
        background: #fff;
        border-radius: 30px;
        padding: 50px 40px;
        z-index: 1;
        height: 100%;
        border: 1px solid rgba(0,0,0,0.05);
        box-shadow: var(--shadow-layer-1);
        overflow: hidden;
    }

    /* Top Gold Bar */
    .service-card-front::after {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 6px;
        background: var(--grad-gold-luxury);
    }

    .service-stack:hover {
        transform: translateY(-10px);
    }
    .service-stack:hover::before {
        top: 25px;
        left: 25px;
        background: rgba(245, 133, 0, 0.15);
    }

    .service-icon-box {
        width: 80px;
        height: 80px;
        background: var(--bg-cream);
        border-radius: 20px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 2.5rem;
        margin-bottom: 30px;
        box-shadow: var(--shadow-inset-gold);
    }

    /* ═══════════════════════════════════════════════════════════════════════════
       4. FAQ: SECRET GOLDEN FILES (FIXED)
       ═══════════════════════════════════════════════════════════════════════════ */
    .faq-section-master {
        padding: 100px 0;
        background: var(--bg-cream);
    }

    .faq-wrapper {
        max-width: 900px;
        margin: 0 auto;
    }

    .faq-file {
        background: #fff;
        margin-bottom: 20px;
        border-radius: 16px;
        overflow: hidden;
        box-shadow: var(--shadow-sm);
        border-left: 6px solid var(--color-gold-metallic);
        transition: all 0.3s ease;
    }

    .faq-file.active {
        border-left-color: var(--color-orange-vital);
        box-shadow: var(--shadow-md);
        transform: scale(1.02);
    }

    .faq-trigger {
        width: 100%;
        padding: 25px 30px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        background: none;
        border: none;
        cursor: pointer;
        text-align: right;
    }

    .faq-question-text {
        font-size: 1.2rem;
        font-weight: 800;
        color: var(--color-brown-deep);
        font-family: var(--font-primary) !important; /* Forced Font */
    }

    .faq-icon-rotator {
        width: 30px;
        height: 30px;
        background: var(--bg-cream);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        color: var(--color-gold-pure);
        font-weight: bold;
        transition: transform 0.4s ease;
    }

    .faq-file.active .faq-icon-rotator {
        transform: rotate(90deg);
        background: var(--color-orange-vital);
        color: #fff;
    }

    .faq-body {
        max-height: 0;
        overflow: hidden;
        transition: max-height 0.5s cubic-bezier(0.77, 0, 0.175, 1);
    }

    .faq-body-inner {
        padding: 0 30px 30px;
        color: var(--color-brown-rich);
        line-height: 1.8;
        font-family: var(--font-primary);
        border-top: 1px solid rgba(0,0,0,0.05);
        padding-top: 20px;
    }

    /* ═══════════════════════════════════════════════════════════════════════════
       MOBILE OPTIMIZATIONS
       ═══════════════════════════════════════════════════════════════════════════ */
    @media (max-width: 992px) {
        .ascension-spine { left: 30px; }
        .ascension-step, .ascension-step:nth-child(odd) { 
            flex-direction: column; 
            align-items: flex-start; 
            padding-left: 70px; 
        }
        .step-card-wrapper { width: 100%; }
        .step-connector { left: 30px; }
        
        .step-number-giant {
            font-size: 5rem;
            top: -20px;
            right: 10px !important;
            left: auto !important;
        }
        
        .hero-title-master { font-size: 3rem; }
    }
</style>

<!-- GLOBAL NOISE TEXTURE -->
<div class="global-texture"></div>

<div class="idea-page-master">

    <!-- 1. HERO: GEOMETRY OF THOUGHT -->
    <section class="hero-master">
        <div class="hero-geometry">
            <!-- Abstract 3D Shapes -->
            <div class="geo-shape shape-1"><div class="geo-cube"></div></div>
            <div class="geo-shape shape-2"><div class="geo-cube"></div></div>
            <div class="geo-shape shape-3"><div class="geo-cube"></div></div>
        </div>

        <div class="hero-content-wrapper container-master">
            <div class="hero-badge-royal wow animate__fadeInDown">
                <i class="wow animate__pulse infinite">⚡</i>
                <span>مشاوره تخصصی و ایده‌پردازی</span>
            </div>

            <h1 class="hero-title-master wow animate__fadeInUp" data-wow-delay="0.2s">
                هر ایده، آغاز یک<br>
                <span class="hero-title-highlight" data-text="امپراطوری">امپراطوری</span> است
            </h1>

            <p class="hero-desc-master wow animate__fadeInUp" data-wow-delay="0.4s">
                ما اینجا نیستیم تا فقط به شما ایده بدهیم. ما اینجا هستیم تا ساختار ذهنی کسب‌وکار شما را بازطراحی کنیم. 
                از جرقه اولیه تا فتح کامل بازار، با نقشه‌ای که با طلا ترسیم شده است.
            </p>

            <div class="wow animate__fadeInUp" data-wow-delay="0.6s">
                <a href="#contact" style="
                    background: var(--grad-gold-luxury);
                    color: #fff;
                    padding: 18px 45px;
                    border-radius: 50px;
                    font-weight: 900;
                    font-size: 1.1rem;
                    box-shadow: 0 15px 40px rgba(212, 160, 32, 0.4);
                    display: inline-block;
                    text-decoration: none;
                    transition: transform 0.3s;
                " onmouseover="this.style.transform='translateY(-5px)'" onmouseout="this.style.transform='translateY(0)'">
                    دریافت نقشه گنج
                </a>
            </div>
        </div>
    </section>

    <!-- 2. WHY US: STACKED CARDS -->
    <section class="section-padding" style="background: #fff; padding: 100px 0;">
        <div class="container-master">
            <div class="section-title-wrapper wow animate__fadeInUp">
                <h2 class="section-title-master">چرا طراحان باستان؟</h2>
                <p style="margin-top: 20px; font-size: 1.2rem;">تفاوت بین یک "ایده" و یک "پیروزی"</p>
            </div>

            <div class="services-grid-master">
                <!-- Card 1 -->
                <div class="service-stack wow animate__fadeInUp" data-wow-delay="0.1s">
                    <div class="service-card-front">
                        <div class="service-icon-box">🧠</div>
                        <h3 class="step-title">مهندسی خلاقیت</h3>
                        <p class="step-desc">ما خلاقیت را به شانس واگذار نمی‌کنیم. ما از متدولوژی‌های مهندسی برای خلق ایده‌های پولساز استفاده می‌کنیم.</p>
                    </div>
                </div>

                <!-- Card 2 -->
                <div class="service-stack wow animate__fadeInUp" data-wow-delay="0.2s">
                    <div class="service-card-front">
                        <div class="service-icon-box">🎯</div>
                        <h3 class="step-title">تمرکز بر اجرا</h3>
                        <p class="step-desc">زیباترین ایده اگر اجرا نشود، زباله است. ما ایده‌هایی می‌دهیم که با بودجه و امکانات شما همخوانی دارد.</p>
                    </div>
                </div>

                <!-- Card 3 -->
                <div class="service-stack wow animate__fadeInUp" data-wow-delay="0.3s">
                    <div class="service-card-front">
                        <div class="service-icon-box">💰</div>
                        <h3 class="step-title">سودآوری قطعی</h3>
                        <p class="step-desc">هدف نهایی، افزایش اعداد در حساب بانکی شماست. استراتژی ما مستقیماً روی ROI (بازگشت سرمایه) تمرکز دارد.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- 3. TIMELINE: PATH TO ASCENSION (DOUBLE LAYERED) -->
    <section class="timeline-section">
        <div class="container-master">
            <div class="section-title-wrapper wow animate__fadeInUp">
                <h2 class="section-title-master">مسیر صعود به قله</h2>
                <p style="margin-top: 20px; font-size: 1.2rem;">پنج گام طلایی تا تحول کسب‌وکار</p>
            </div>

            <div class="ascension-path">
                <div class="ascension-spine"></div>

                <!-- Step 1 -->
                <div class="ascension-step wow animate__fadeInUp">
                    <div class="step-connector"></div>
                    <div class="step-card-wrapper">
                        <div class="step-layer-back"></div> <!-- Metallic Base -->
                        <div class="step-layer-front"> <!-- Glass Front -->
                            <div class="step-number-giant">01</div>
                            <h3 class="step-title">کشف و استخراج</h3>
                            <p class="step-desc">ما مثل باستان‌شناس، لایه‌های پنهان کسب‌وکار شما را کنار می‌زنیم تا گنجینه واقعی (مزیت رقابتی) را پیدا کنیم.</p>
                        </div>
                    </div>
                </div>

                <!-- Step 2 -->
                <div class="ascension-step wow animate__fadeInUp">
                    <div class="step-connector"></div>
                    <div class="step-card-wrapper">
                        <div class="step-layer-back"></div>
                        <div class="step-layer-front">
                            <div class="step-number-giant">02</div>
                            <h3 class="step-title">رصد میدان نبرد</h3>
                            <p class="step-desc">رقبا چه می‌کنند؟ مشتریان چه می‌خواهند؟ ما با داده‌های دقیق بازار برمی‌گردیم، نه با حدس و گمان.</p>
                        </div>
                    </div>
                </div>

                <!-- Step 3 -->
                <div class="ascension-step wow animate__fadeInUp">
                    <div class="step-connector"></div>
                    <div class="step-card-wrapper">
                        <div class="step-layer-back"></div>
                        <div class="step-layer-front">
                            <div class="step-number-giant">03</div>
                            <h3 class="step-title">کیمیاگری (اتاق فکر)</h3>
                            <p class="step-desc">ترکیب هنر و بیزنس. اینجا ایده‌های خام صیقل می‌خورند، چکش‌کاری می‌شوند و به شمش طلا تبدیل می‌شوند.</p>
                        </div>
                    </div>
                </div>

                <!-- Step 4 -->
                <div class="ascension-step wow animate__fadeInUp">
                    <div class="step-connector"></div>
                    <div class="step-card-wrapper">
                        <div class="step-layer-back"></div>
                        <div class="step-layer-front">
                            <div class="step-number-giant">04</div>
                            <h3 class="step-title">طراحی نقشه گنج</h3>
                            <p class="step-desc">یک برنامه عملیاتی (Action Plan) دقیق دریافت می‌کنید. کی، کجا، چطور و با چه بودجه‌ای باید حمله کنید.</p>
                        </div>
                    </div>
                </div>

                <!-- Step 5 -->
                <div class="ascension-step wow animate__fadeInUp">
                    <div class="step-connector"></div>
                    <div class="step-card-wrapper">
                        <div class="step-layer-back"></div>
                        <div class="step-layer-front">
                            <div class="step-number-giant">05</div>
                            <h3 class="step-title">فتح پرچم</h3>
                            <p class="step-desc">ما در زمان اجرا کنارتان هستیم. نظارت می‌کنیم تا استراتژی دقیقاً مثل نقشه پیاده شود و جشن پیروزی را بگیریم.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- 4. PACKAGES: TREASURE CHESTS -->
    <section style="padding: 100px 0; background: var(--bg-cream);">
        <div class="container-master">
            <div class="section-title-wrapper wow animate__fadeInUp">
                <h2 class="section-title-master">سرمایه‌گذاری هوشمند</h2>
            </div>
            <div class="services-grid-master">
                <!-- Basic -->
                <div class="service-stack wow animate__fadeInUp">
                    <div class="service-card-front" style="text-align: center;">
                        <h3 class="step-title">مشاوره ساعتی</h3>
                        <div style="font-size: 2rem; color: var(--color-orange-vital); font-weight: 900; margin: 20px 0;">VIP Session</div>
                        <p class="step-desc">برای حل یک چالش خاص و فوری</p>
                        <hr style="border-color: rgba(0,0,0,0.05); margin: 30px 0;">
                        <a href="#contact" style="color: var(--color-brown-deep); font-weight: bold; text-decoration: none;">رزرو جلسه &larr;</a>
                    </div>
                </div>

                <!-- Premium -->
                <div class="service-stack wow animate__fadeInUp" data-wow-delay="0.2s">
                    <div class="service-card-front" style="background: linear-gradient(180deg, #FFFDF5 0%, #fff 100%); border: 2px solid var(--color-gold-pure); text-align: center;">
                        <div style="position: absolute; top: 0; right: 0; background: var(--color-gold-pure); color: #fff; padding: 5px 15px; border-radius: 0 0 0 15px; font-weight: bold;">Popular</div>
                        <h3 class="step-title">پکیج استراتژی</h3>
                        <div style="font-size: 2rem; color: var(--color-gold-metallic); font-weight: 900; margin: 20px 0;">Full Blueprint</div>
                        <p class="step-desc">نقشه راه کامل + ۳ ایده خلاقانه + بودجه‌بندی</p>
                        <hr style="border-color: rgba(0,0,0,0.05); margin: 30px 0;">
                        <a href="#contact" style="background: var(--color-gold-pure); color: #fff; padding: 10px 30px; border-radius: 30px; text-decoration: none; font-weight: bold;">شروع همکاری</a>
                    </div>
                </div>

                <!-- Enterprise -->
                <div class="service-stack wow animate__fadeInUp" data-wow-delay="0.4s">
                    <div class="service-card-front" style="text-align: center;">
                        <h3 class="step-title">رهبری بازار</h3>
                        <div style="font-size: 2rem; color: var(--color-brown-deep); font-weight: 900; margin: 20px 0;">Partner</div>
                        <p class="step-desc">ما دپارتمان مارکتینگ شما می‌شویم (صفر تا صد)</p>
                        <hr style="border-color: rgba(0,0,0,0.05); margin: 30px 0;">
                        <a href="#contact" style="color: var(--color-brown-deep); font-weight: bold; text-decoration: none;">درخواست پروپوزال &larr;</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- 5. FAQ: SECRET FILES (FIXED FONTS) -->
    <section class="faq-section-master">
        <div class="container-master">
            <div class="section-title-wrapper">
                <h2 class="section-title-master">اسناد محرمانه</h2>
                <p>پاسخ به سوالات شما</p>
            </div>

            <div class="faq-wrapper">
                <!-- Q1 -->
                <div class="faq-file wow animate__fadeInUp">
                    <button class="faq-trigger">
                        <span class="faq-question-text">هزینه این سرمایه‌گذاری چقدر است؟</span>
                        <div class="faq-icon-rotator">+</div>
                    </button>
                    <div class="faq-body">
                        <div class="faq-body-inner">
                            هزینه بر اساس مقیاس پروژه و اهداف شما متغیر است. اما نگران نباشید، جلسه اول نیازسنجی کاملاً رایگان است تا ما ابعاد کار را بررسی کنیم و بهترین پیشنهاد را بدهیم.
                        </div>
                    </div>
                </div>

                <!-- Q2 -->
                <div class="faq-file wow animate__fadeInUp" data-wow-delay="0.1s">
                    <button class="faq-trigger">
                        <span class="faq-question-text">آیا تضمینی برای موفقیت وجود دارد؟</span>
                        <div class="faq-icon-rotator">+</div>
                    </button>
                    <div class="faq-body">
                        <div class="faq-body-inner">
                            در دنیای بیزنس هیچ تضمین ۱۰۰ درصدی وجود ندارد، اما ما تضمین می‌کنیم که تمام استراتژی‌ها بر اساس داده‌های واقعی و تجربه ۱۰ ساله ما طراحی شوند که ریسک را به حداقل و شانس پیروزی را به حداکثر می‌رساند.
                        </div>
                    </div>
                </div>

                <!-- Q3 -->
                <div class="faq-file wow animate__fadeInUp" data-wow-delay="0.2s">
                    <button class="faq-trigger">
                        <span class="faq-question-text">زمان‌بندی اجرا چگونه است؟</span>
                        <div class="faq-icon-rotator">+</div>
                    </button>
                    <div class="faq-body">
                        <div class="faq-body-inner">
                            ما طرفدار "پیروزی‌های سریع" (Quick Wins) هستیم. معمولاً در ماه اول نتایج اولیه را می‌بینید، اما پروژه‌های برندینگ و تغییر پوزیشنینگ بین ۳ تا ۶ ماه زمان نیاز دارند.
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- 6. CTA -->
    <section style="padding: 100px 0; background: #fff;" id="contact">
        <div class="container-master">
            <div style="
                background: var(--grad-gold-luxury);
                border-radius: 50px;
                padding: 80px 50px;
                text-align: center;
                position: relative;
                overflow: hidden;
                box-shadow: 0 30px 80px -10px rgba(212, 160, 32, 0.5);
            " class="wow animate__zoomIn">
                
                <h2 style="font-size: 3rem; color: #fff; margin-bottom: 30px; text-shadow: 0 2px 10px rgba(0,0,0,0.1);">
                    آماده فتح قله هستید؟
                </h2>
                <p style="font-size: 1.3rem; color: rgba(255,255,255,0.9); max-width: 700px; margin: 0 auto 50px;">
                    زمان منتظر تصمیم‌گیری نمی‌ماند. رقبا در حال حرکت هستند.
                    همین امروز استراتژی پیروزی خود را دریافت کنید.
                </p>
                
                <a href="tel:+989183333368" style="
                    background: #fff;
                    color: var(--color-orange-vital);
                    font-size: 1.5rem;
                    font-weight: 900;
                    padding: 20px 60px;
                    border-radius: 20px;
                    text-decoration: none;
                    box-shadow: 0 10px 30px rgba(0,0,0,0.1);
                    display: inline-block;
                ">
                    0918-333-3368
                </a>
            </div>
        </div>
    </section>

</div>

<script>
    new WOW().init();

    document.querySelectorAll('.faq-trigger').forEach(btn => {
        btn.addEventListener('click', () => {
            const file = btn.parentElement;
            const body = btn.nextElementSibling;
            
            // Close others
            document.querySelectorAll('.faq-file').forEach(other => {
                if(other !== file) {
                    other.classList.remove('active');
                    other.querySelector('.faq-body').style.maxHeight = null;
                }
            });

            // Toggle current
            file.classList.toggle('active');
            if(file.classList.contains('active')){
                body.style.maxHeight = body.scrollHeight + 'px';
            } else {
                body.style.maxHeight = null;
            }
        });
    });
</script>
