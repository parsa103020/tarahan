
<!-- Libraries -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" integrity="sha512-c42qTSw/wPZ3/5LBzD+Bw5f7bSF2oxou6wEb+I/lqeaKV5FDIfMvvRp772y4jcJLKuGUOpbJMdg/BTl50fJYAw==" crossorigin="anonymous" referrerpolicy="no-referrer">
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js" integrity="sha512-16ber5sF2mD3iJJp3w0mE0/m9fPQIlxhG1fXVfNv+NjvTd1e/6zBNPLO6elWxhA5xw0PdxZf9MlH7bOqIWJz3Q==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/ScrollTrigger.min.js" integrity="sha512-Ic9xkERjyZ1xgJ5svx3y0u3xrvfT/uPkV99LBwe68xjy/mGtO+4eURHZBW2xW4SZbFrF1Tf090XqB+EVgXnVjw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<style>
/* ══════════════════════════════════════════════════════════════════════════════
   TARAHAN BASTAN - PRINT SERVICE: PREMIUM LIGHT MODE v2.0 (FIXED)
   ══════════════════════════════════════════════════════════════════════════════ */

:root {
    /* 🎨 PALETTE */
    --brand-brown: #2D1810;
    --brand-brown-light: #4A2C1A;
    --brand-gold: #D4A020;
    --brand-gold-light: #F5C518;
    --brand-orange: #FF4500;
    --brand-cream: #FAF6F1;
    --brand-white: #FFFFFF;

    /* 🖌 GRADIENTS */
    --grad-gold: linear-gradient(135deg, #D4A020 0%, #F5C518 100%);
    --grad-hero: linear-gradient(180deg, #FFFBF5 0%, #FAF6F1 100%);

    /* 🌑 SHADOWS */
    --shadow-sm: 0 5px 20px rgba(45, 24, 16, 0.05);
    --shadow-md: 0 10px 40px rgba(45, 24, 16, 0.08);
    --shadow-lg: 0 20px 60px rgba(45, 24, 16, 0.12);
    --shadow-gold: 0 10px 30px rgba(212, 160, 32, 0.35);

    /* 📐 SHAPES */
    --radius-md: 20px;
    --radius-lg: 40px;
    --radius-full: 100px;
}

/* 🛠 GLOBAL UTILS */
* { box-sizing: border-box; outline: none; }

body {
    background-color: var(--brand-cream);
    color: var(--brand-brown);
    font-family: 'YekanBakh', sans-serif;
    overflow-x: hidden;
    margin: 0;
    line-height: 1.7;
}

a { text-decoration: none; cursor: pointer; }
button { cursor: pointer; }

/* ══════════════════════════════════════════════════════════════════════════════
   1. HERO SECTION
   ══════════════════════════════════════════════════════════════════════════════ */
.hero-section {
    min-height: 100vh;
    position: relative;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 140px 20px 80px;
    background: var(--grad-hero);
    overflow: hidden;
}

/* Decorative Elements - Properly Positioned */
.hero-bg-decoration {
    position: absolute;
    inset: 0;
    pointer-events: none;
    z-index: 0;
}

.paper-stack {
    position: absolute;
    bottom: 10%;
    left: 5%;
    transform: rotate(-15deg);
    opacity: 0.8;
}

.paper-sheet {
    width: 120px;
    height: 160px;
    background: white;
    border: 1px solid rgba(45, 24, 16, 0.1);
    border-radius: 4px;
    position: absolute;
    box-shadow: var(--shadow-md);
}
.paper-sheet:nth-child(1) { transform: rotate(-5deg); }
.paper-sheet:nth-child(2) { transform: rotate(5deg) translate(10px, -10px); }
.paper-sheet:nth-child(3) { transform: rotate(-2deg) translate(20px, -20px); }

.cmyk-dots {
    position: absolute;
    top: 15%;
    right: 5%;
    display: flex;
    gap: 15px;
    opacity: 0.6;
}

.cmyk-dot {
    width: 20px;
    height: 20px;
    border-radius: 50%;
}
.cmyk-c { background: #00AEEF; }
.cmyk-m { background: #EC008C; }
.cmyk-y { background: #FFF200; }
.cmyk-k { background: #2D1810; }

.hero-content {
    position: relative;
    z-index: 2;
    text-align: center;
    max-width: 900px;
}

.hero-badge {
    display: inline-flex;
    align-items: center;
    gap: 10px;
    padding: 10px 24px;
    background: white;
    border-radius: var(--radius-full);
    box-shadow: var(--shadow-sm);
    margin-bottom: 30px;
    border: 1px solid rgba(212, 160, 32, 0.3);
    font-weight: 700;
    color: var(--brand-brown);
    font-size: 0.95rem;
}

.hero-title {
    font-size: clamp(2.5rem, 6vw, 4.5rem);
    font-weight: 900;
    line-height: 1.2;
    margin-bottom: 24px;
    color: var(--brand-brown);
}

.hero-title .highlight {
    background: linear-gradient(135deg, #D4A020 0%, #F5C518 50%, #FF6B00 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    background-size: 200% auto;
    animation: goldShine 4s linear infinite;
}

@keyframes goldShine {
    to { background-position: 200% center; }
}

.hero-subtitle {
    font-size: 1.2rem;
    color: #5A3825;
    max-width: 700px;
    margin: 0 auto 48px;
    font-weight: 500;
}

.btn-primary {
    display: inline-flex;
    align-items: center;
    gap: 12px;
    padding: 18px 45px;
    background: linear-gradient(135deg, var(--brand-gold) 0%, var(--brand-orange) 100%);
    color: white;
    border-radius: var(--radius-full);
    font-weight: 800;
    font-size: 1.1rem;
    box-shadow: var(--shadow-gold);
    transition: all 0.4s ease;
}

.btn-primary:hover {
    transform: translateY(-5px);
    box-shadow: 0 20px 50px rgba(255, 107, 0, 0.4);
}

/* ==========================================
   2. FEATURES
   ========================================== */
.section-features {
    padding: 100px 20px;
    background: white;
}

.container {
    max-width: 1200px;
    margin: 0 auto;
}

.features-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 30px;
}

.feature-card {
    background: var(--brand-cream);
    padding: 40px 30px;
    border-radius: var(--radius-md);
    text-align: center;
    transition: 0.4s;
    border: 1px solid transparent;
}

.feature-card:hover {
    background: white;
    box-shadow: var(--shadow-lg);
    transform: translateY(-10px);
    border-color: var(--brand-gold);
}

.feature-icon {
    width: 70px;
    height: 70px;
    background: white;
    border-radius: 20px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 25px;
    box-shadow: var(--shadow-sm);
    color: var(--brand-gold);
    font-size: 2rem;
}

.feature-card h3 {
    font-size: 1.2rem;
    font-weight: 800;
    margin-bottom: 15px;
    color: var(--brand-brown);
}

.feature-card p {
    font-size: 0.95rem;
    color: #666;
    line-height: 1.7;
}

/* ==========================================
   3. SERVICES GRID
   ========================================== */
.section-services {
    padding: 100px 20px;
    background: var(--brand-cream);
}

.section-header {
    text-align: center;
    margin-bottom: 60px;
}

.section-title {
    font-size: 2.5rem;
    font-weight: 900;
    margin-bottom: 15px;
    color: var(--brand-brown);
}

.services-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 30px;
}

.service-card {
    background: white;
    border-radius: var(--radius-md);
    padding: 40px;
    box-shadow: var(--shadow-sm);
    transition: 0.4s;
    position: relative;
    overflow: hidden;
}

.service-card:hover {
    transform: translateY(-8px);
    box-shadow: var(--shadow-lg);
}

.service-card::before {
    content: '';
    position: absolute;
    top: 0; left: 0; width: 100%; height: 4px;
    background: var(--grad-gold);
    transform: scaleX(0);
    transform-origin: left;
    transition: 0.4s;
}

.service-card:hover::before { transform: scaleX(1); }

.service-icon {
    width: 60px;
    height: 60px;
    background: var(--brand-cream);
    border-radius: 15px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 25px;
    color: var(--brand-orange);
}

.service-card h3 {
    font-size: 1.5rem;
    font-weight: 800;
    margin-bottom: 15px;
    color: var(--brand-brown);
}

.service-list {
    list-style: none;
    padding: 0;
    margin: 0;
}

.service-list li {
    padding: 8px 0;
    border-bottom: 1px solid #eee;
    color: #555;
    font-size: 0.95rem;
}

.service-list li:last-child { border-bottom: none; }

/* ==========================================
   4. COMPARISON
   ========================================== */
.section-compare {
    padding: 100px 20px;
    background: white;
}

.compare-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 40px;
    max-width: 1000px;
    margin: 0 auto;
}

.compare-card {
    border: 2px solid #eee;
    border-radius: var(--radius-md);
    padding: 40px;
    text-align: center;
    transition: 0.4s;
}

.compare-card:hover {
    border-color: var(--brand-gold);
    box-shadow: var(--shadow-md);
}

.compare-title {
    font-size: 1.8rem;
    font-weight: 900;
    margin-bottom: 10px;
    color: var(--brand-brown);
}

.compare-badge {
    display: inline-block;
    padding: 5px 15px;
    background: var(--brand-cream);
    color: var(--brand-orange);
    border-radius: 20px;
    font-size: 0.85rem;
    font-weight: 700;
    margin-bottom: 30px;
}

.compare-row {
    display: flex;
    justify-content: space-between;
    padding: 15px 0;
    border-bottom: 1px solid #eee;
}

.label { color: #888; font-weight: 600; }
.value { color: var(--brand-brown); font-weight: 700; }

/* ==========================================
   5. PROCESS
   ========================================== */
.section-process {
    padding: 100px 20px;
    background: var(--brand-cream);
}

.process-steps {
    display: grid;
    grid-template-columns: repeat(5, 1fr);
    gap: 20px;
    position: relative;
    margin-top: 50px;
}

.process-line {
    position: absolute;
    top: 30px;
    left: 10%;
    right: 10%;
    height: 2px;
    background: #ddd;
    z-index: 0;
}

.process-step {
    position: relative;
    z-index: 1;
    text-align: center;
}

.step-num {
    width: 60px;
    height: 60px;
    background: white;
    border: 2px solid var(--brand-gold);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.2rem;
    font-weight: 900;
    color: var(--brand-brown);
    margin: 0 auto 20px;
    box-shadow: var(--shadow-sm);
}

.process-step:hover .step-num {
    background: var(--brand-gold);
    color: white;
}

.process-step h4 { font-weight: 800; margin-bottom: 10px; }
.process-step p { font-size: 0.9rem; color: #666; }

/* ==========================================
   6. PAPER TYPES
   ========================================== */
.section-papers {
    padding: 100px 20px;
    background: white;
}

.paper-grid {
    display: grid;
    grid-template-columns: repeat(5, 1fr);
    gap: 20px;
}

.paper-card {
    background: var(--brand-cream);
    padding: 30px 20px;
    border-radius: var(--radius-md);
    text-align: center;
    transition: 0.3s;
}

.paper-card:hover {
    background: var(--brand-brown);
    color: white;
    transform: scale(1.05);
}

.paper-card h4 { font-size: 1.1rem; font-weight: 800; margin-bottom: 10px; }
.paper-card:hover h4 { color: var(--brand-gold); }
.paper-card p { font-size: 0.9rem; opacity: 0.8; }

/* ==========================================
   7. GALLERY
   ========================================== */
.section-gallery {
    padding: 100px 20px;
    background: var(--brand-brown);
    color: white;
}

.section-gallery .section-title { color: white; }
.section-gallery .section-subtitle { color: rgba(255,255,255,0.7); }

.gallery-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 20px;
}

.gallery-item {
    background: rgba(255,255,255,0.1);
    border-radius: 20px;
    aspect-ratio: 1;
    position: relative;
    overflow: hidden;
    cursor: pointer;
}

.gallery-item:hover img { transform: scale(1.1); }

.gallery-overlay {
    position: absolute;
    inset: 0;
    background: linear-gradient(to top, rgba(0,0,0,0.8), transparent);
    display: flex;
    flex-direction: column;
    justify-content: flex-end;
    padding: 20px;
    opacity: 0;
    transition: 0.3s;
}

.gallery-item:hover .gallery-overlay { opacity: 1; }

/* ==========================================
   8. FAQ
   ========================================== */
.section-faq {
    padding: 100px 20px;
    background: linear-gradient(180deg, #FDFBF9 0%, #F5EBE0 100%);
}

.section-faq h2 {
    text-align: center;
    font-size: clamp(1.8rem, 4vw, 2.5rem);
    color: var(--brand-brown);
    margin-bottom: 50px;
}

.faq-wrap {
    max-width: 850px;
    margin: 0 auto;
}

.faq-item {
    background: white;
    border-radius: 16px;
    margin-bottom: 16px;
    box-shadow: 0 4px 15px rgba(0,0,0,0.05);
    overflow: hidden;
    border: 1px solid rgba(212, 160, 32, 0.1);
    transition: all 0.3s ease;
}

.faq-item:hover {
    box-shadow: 0 8px 25px rgba(0,0,0,0.08);
    border-color: rgba(212, 160, 32, 0.2);
}

.faq-item.active {
    border-color: var(--brand-gold);
    box-shadow: 0 8px 25px rgba(212, 160, 32, 0.15);
}

.faq-header {
    padding: 22px 26px;
    background: #fff;
    cursor: pointer;
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-weight: 700;
    font-size: 1.05rem;
    color: var(--brand-brown);
    gap: 15px;
    transition: color 0.3s ease;
}

.faq-header:hover { color: var(--brand-gold); }

.faq-icon {
    min-width: 30px;
    width: 30px;
    height: 30px;
    border-radius: 50%;
    background: linear-gradient(135deg, var(--brand-gold), #E8B830);
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--brand-brown);
    font-weight: 700;
    font-size: 1.2rem;
    transition: 0.3s;
}

.faq-item.active .faq-icon {
    transform: rotate(45deg);
    background: var(--brand-orange);
    color: white;
}

.faq-body {
    max-height: 0;
    overflow: hidden;
    transition: all 0.4s ease;
    color: #5A3825;
    line-height: 2;
    font-size: 0.98rem;
}

.faq-item.active .faq-body {
    max-height: 500px;
    padding: 0 26px 26px 26px;
}

/* ==========================================
   9. CTA
   ========================================== */
.section-cta {
    padding: 80px 20px;
    background: var(--brand-cream);
}

.cta-box {
    max-width: 1000px;
    margin: 0 auto;
    background: var(--brand-brown);
    border-radius: var(--radius-lg);
    padding: 80px 40px;
    text-align: center;
    color: white;
    position: relative;
    overflow: hidden;
    box-shadow: var(--shadow-lg);
}

.cta-title { font-size: 2.5rem; font-weight: 900; margin-bottom: 20px; }
.cta-btn {
    display: inline-block;
    background: white;
    color: var(--brand-brown);
    padding: 15px 40px;
    border-radius: var(--radius-full);
    font-weight: 800;
    margin-top: 30px;
    transition: 0.3s;
}
.cta-btn:hover { background: var(--brand-gold); color: white; }

/* ==========================================
   📱 RESPONSIVE
   ========================================== */
@media (max-width: 1024px) {
    .features-grid, .process-grid, .paper-grid { grid-template-columns: repeat(2, 1fr); }
    .services-grid, .gallery-grid { grid-template-columns: repeat(2, 1fr); }
    .process-line { display: none; }
}

@media (max-width: 768px) {
    .hero-title { font-size: 2.5rem; }
    .features-grid, .services-grid, .compare-grid, .process-grid, .paper-grid, .gallery-grid { grid-template-columns: 1fr; }
    
    .hero-bg-decoration, .paper-stack, .cmyk-dots { display: none; } /* Clean up mobile view */
    
    .section-features, .section-services, .section-compare, .section-process, .section-papers, .section-gallery, .section-faq, .section-cta {
        padding: 60px 20px;
    }
}
</style>

<!-- PAGE CONTENT -->
<div class="print-page">

    <!-- 1. HERO -->
    <section class="hero-section">
        <div class="hero-bg-decoration">
            <div class="paper-stack">
                <div class="paper-sheet"></div>
                <div class="paper-sheet"></div>
                <div class="paper-sheet"></div>
            </div>
            <div class="cmyk-dots">
                <div class="cmyk-dot cmyk-c"></div>
                <div class="cmyk-dot cmyk-m"></div>
                <div class="cmyk-dot cmyk-y"></div>
                <div class="cmyk-dot cmyk-k"></div>
            </div>
        </div>

        <div class="hero-content">
            <div class="hero-badge wow fadeInDown">
                چاپ آفست و دیجیتال حرفه‌ای
            </div>
            <h1 class="hero-title wow fadeInUp">
                کیفیتی که <span class="highlight">لمس می‌شود</span>
            </h1>
            <p class="hero-subtitle wow fadeInUp" data-wow-delay="0.2s">
                ارائه خدمات جامع چاپ با بالاترین استاندارد رنگ و کاغذ. از کارت ویزیت شخصی تا تیراژهای میلیونی صنعتی.
            </p>
            <div class="wow fadeInUp" data-wow-delay="0.4s">
                <a href="<?php echo URL; ?>/contact" class="btn-primary">ثبت سفارش آنلاین</a>
            </div>
        </div>
    </section>

    <!-- 2. FEATURES -->
    <section class="section-features">
        <div class="container">
            <div class="features-grid">
                <div class="feature-card wow fadeInUp">
                    <div class="feature-icon">💎</div>
                    <h3>کیفیت تضمینی</h3>
                    <p>استفاده از ماشین‌های چاپ هایدلبرگ آلمان برای دقت رنگ بی‌نظیر.</p>
                </div>
                <div class="feature-card wow fadeInUp" data-wow-delay="0.1s">
                    <div class="feature-icon">⚡</div>
                    <h3>تحویل فوری</h3>
                    <p>سرویس چاپ دیجیتال ۲۴ ساعته برای پروژه‌های اضطراری شما.</p>
                </div>
                <div class="feature-card wow fadeInUp" data-wow-delay="0.2s">
                    <div class="feature-icon">📄</div>
                    <h3>تنوع کاغذ</h3>
                    <p>بیش از ۵۰ نوع کاغذ گلاسه، تحریر، کرافت و فانتزی.</p>
                </div>
                <div class="feature-card wow fadeInUp" data-wow-delay="0.3s">
                    <div class="feature-icon">💰</div>
                    <h3>قیمت رقابتی</h3>
                    <p>حذف واسطه‌ها و چاپ مستقیم در چاپخانه اختصاصی ما.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- 3. SERVICES -->
    <section class="section-services">
        <div class="container">
            <div class="section-header">
                <h2 class="section-title">خدمات چاپ ما</h2>
                <p>پوشش کامل نیازهای چاپی کسب‌وکار شما</p>
            </div>
            <div class="services-grid">
                <!-- Offset -->
                <div class="service-card wow fadeInUp">
                    <div class="service-icon">🖨️</div>
                    <h3>چاپ آفست</h3>
                    <p>بهترین گزینه برای تیراژ بالا و کیفیت عالی.</p>
                    <ul class="service-list">
                        <li>کاتالوگ و بروشور</li>
                        <li>ست اداری و پاکت</li>
                        <li>پوستر و تراکت</li>
                    </ul>
                </div>
                <!-- Digital -->
                <div class="service-card wow fadeInUp" data-wow-delay="0.1s">
                    <div class="service-icon">💻</div>
                    <h3>چاپ دیجیتال</h3>
                    <p>مناسب برای تیراژ کم و سرعت بالا.</p>
                    <ul class="service-list">
                        <li>کارت ویزیت فوری</li>
                        <li>منو رستوران</li>
                        <li>لیبل و استیکر</li>
                    </ul>
                </div>
                <!-- Packaging -->
                <div class="service-card wow fadeInUp" data-wow-delay="0.2s">
                    <div class="service-icon">📦</div>
                    <h3>بسته‌بندی</h3>
                    <p>طراحی و تولید جعبه‌های محصول اختصاصی.</p>
                    <ul class="service-list">
                        <li>جعبه مقوایی</li>
                        <li>هارد باکس</li>
                        <li>ساک دستی</li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <!-- 4. COMPARISON -->
    <section class="section-compare">
        <div class="container">
            <div class="section-header">
                <h2 class="section-title">افست یا دیجیتال؟</h2>
                <p>راهنمای انتخاب روش چاپ مناسب برای پروژه شما</p>
            </div>
            <div class="compare-grid">
                <div class="compare-card wow fadeInLeft">
                    <h3 class="compare-title">چاپ آفست</h3>
                    <span class="compare-badge">مناسب تیراژ بالا</span>
                    <div class="compare-row">
                        <span class="label">تعداد</span>
                        <span class="value">+۱۰۰۰ عدد</span>
                    </div>
                    <div class="compare-row">
                        <span class="label">زمان</span>
                        <span class="value">۷-۱۰ روز کاری</span>
                    </div>
                    <div class="compare-row">
                        <span class="label">هزینه واحد</span>
                        <span class="value">بسیار اقتصادی</span>
                    </div>
                </div>
                <div class="compare-card wow fadeInRight">
                    <h3 class="compare-title">چاپ دیجیتال</h3>
                    <span class="compare-badge">مناسب سرعت بالا</span>
                    <div class="compare-row">
                        <span class="label">تعداد</span>
                        <span class="value">۱-۵۰۰ عدد</span>
                    </div>
                    <div class="compare-row">
                        <span class="label">زمان</span>
                        <span class="value">۱-۲ روز کاری</span>
                    </div>
                    <div class="compare-row">
                        <span class="label">هزینه واحد</span>
                        <span class="value">بالاتر</span>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- 5. PROCESS -->
    <section class="section-process">
        <div class="container">
            <div class="section-header">
                <h2 class="section-title">مراحل کار</h2>
            </div>
            <div class="process-steps">
                <div class="process-line"></div>
                
                <div class="process-step wow fadeInUp">
                    <div class="step-num">1</div>
                    <h4>سفارش</h4>
                    <p>ثبت جزئیات و ارسال فایل</p>
                </div>
                <div class="process-step wow fadeInUp" data-wow-delay="0.1s">
                    <div class="step-num">2</div>
                    <h4>کنترل فایل</h4>
                    <p>بررسی فنی و اصلاح رنگ</p>
                </div>
                <div class="process-step wow fadeInUp" data-wow-delay="0.2s">
                    <div class="step-num">3</div>
                    <h4>لیتوگرافی</h4>
                    <p>تهیه زینک (برای آفست)</p>
                </div>
                <div class="process-step wow fadeInUp" data-wow-delay="0.3s">
                    <div class="step-num">4</div>
                    <h4>چاپ</h4>
                    <p>اجرا با نظارت ناظر چاپ</p>
                </div>
                <div class="process-step wow fadeInUp" data-wow-delay="0.4s">
                    <div class="step-num">5</div>
                    <h4>تکمیل</h4>
                    <p>برش، صحافی و تحویل</p>
                </div>
            </div>
        </div>
    </section>

    <!-- 6. PAPERS -->
    <section class="section-papers">
        <div class="container">
            <div class="section-header">
                <h2 class="section-title">انواع کاغذ</h2>
            </div>
            <div class="paper-grid">
                <div class="paper-card">
                    <h4>گلاسه</h4>
                    <p>براق و صیقلی، عالی برای عکس</p>
                </div>
                <div class="paper-card">
                    <h4>تحریر</h4>
                    <p>مات و معمولی، مناسب نوشتن</p>
                </div>
                <div class="paper-card">
                    <h4>کتان</h4>
                    <p>بافت‌دار و کلاسیک</p>
                </div>
                <div class="paper-card">
                    <h4>کرافت</h4>
                    <p>قهوه‌ای و نوستالژیک</p>
                </div>
                <div class="paper-card">
                    <h4>ایندربرد</h4>
                    <p>ضخیم، مناسب جعبه‌سازی</p>
                </div>
            </div>
        </div>
    </section>

    <!-- 7. GALLERY -->
    <section class="section-gallery" id="portfolio">
        <div class="container">
            <div class="section-header">
                <h2 class="section-title">نمونه کارهای چاپ</h2>
                <p class="section-subtitle">ظرافت در اجرا را ببینید</p>
            </div>
            <div class="gallery-grid">
                <div class="gallery-item wow zoomIn">
                    <div class="gallery-overlay">
                        <h4>کاتالوگ صنعتی</h4>
                    </div>
                </div>
                <div class="gallery-item wow zoomIn" data-wow-delay="0.1s">
                    <div class="gallery-overlay">
                        <h4>کارت ویزیت طلاکوب</h4>
                    </div>
                </div>
                <div class="gallery-item wow zoomIn" data-wow-delay="0.2s">
                    <div class="gallery-overlay">
                        <h4>بسته‌بندی زعفران</h4>
                    </div>
                </div>
                <div class="gallery-item wow zoomIn" data-wow-delay="0.3s">
                    <div class="gallery-overlay">
                        <h4>ست اداری کامل</h4>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- 8. FAQ -->
    <section class="section-faq">
        <div class="faq-wrap">
            <div class="section-header">
                <h2 class="section-title">سوالات متداول</h2>
            </div>
            
            <div class="faq-item">
                <div class="faq-header">
                    فایل چاپی باید چه فرمتی داشته باشد؟
                    <span class="faq-icon">+</span>
                </div>
                <div class="faq-body">
                    <p>بهترین فرمت PDF با استاندارد رنگی CMYK و رزولوشن 300dpi است. حاشیه امن برش (Bleed) را فراموش نکنید.</p>
                </div>
            </div>
            
            <div class="faq-item">
                <div class="faq-header">
                    تفاوت لمینت و سلفون چیست؟
                    <span class="faq-icon">+</span>
                </div>
                <div class="faq-body">
                    <p>لمینت ضخامت بیشتری دارد و استحکام کار را بالا می‌برد، اما سلفون نازک‌تر و ظریف‌تر است و برای کارهایی که باید تا شوند مناسب‌تر است.</p>
                </div>
            </div>
            
            <div class="faq-item">
                <div class="faq-header">
                    حداقل تیراژ سفارش چقدر است؟
                    <span class="faq-icon">+</span>
                </div>
                <div class="faq-body">
                    <p>در چاپ دیجیتال حتی ۱ عدد هم امکان‌پذیر است. در چاپ افست معمولاً حداقل تیراژ ۱۰۰۰ عدد می‌باشد تا مقرون به صرفه باشد.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- 9. CTA -->
    <section class="section-cta">
        <div class="cta-box wow pulse">
            <h2 class="cta-title">پروژه چاپی دارید؟</h2>
            <p style="margin-bottom: 30px;">همین حالا استعلام قیمت بگیرید و کیفیت را تجربه کنید.</p>
            <a href="<?php echo URL; ?>/contact" class="cta-btn">دریافت قیمت</a>
        </div>
    </section>

</div>

<script>
    // Init WOW.js
    new WOW().init();

    // FAQ Logic
    document.querySelectorAll('.faq-header').forEach(header => {
        header.addEventListener('click', () => {
            const item = header.parentElement;
            const body = item.querySelector('.faq-body');
            const icon = item.querySelector('.faq-icon');
            
            item.classList.toggle('active');
            
            if (item.classList.contains('active')) {
                body.style.maxHeight = body.scrollHeight + "px";
                icon.style.transform = "rotate(45deg)";
            } else {
                body.style.maxHeight = null;
                icon.style.transform = "rotate(0deg)";
            }
        });
    });
</script>