<?php
/**
 * TARAHAN BASTAN - BLOG PAGE
 * Article Listing Page
 */

// Jalali date conversion function
if (!function_exists('toJalali')) {
    function toJalali($gregorianDate) {
        if (empty($gregorianDate)) return '';
        $timestamp = strtotime($gregorianDate);
        $gy = date('Y', $timestamp);
        $gm = date('m', $timestamp);
        $gd = date('d', $timestamp);

        $g_d_m = array(0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334);
        $gy2 = ($gm > 2) ? ($gy + 1) : $gy;
        $days = 355666 + (365 * $gy) + ((int)(($gy2 + 3) / 4)) - ((int)(($gy2 + 99) / 100)) + ((int)(($gy2 + 399) / 400)) + $gd + $g_d_m[$gm - 1];
        $jy = -1595 + (33 * ((int)($days / 12053)));
        $days %= 12053;
        $jy += 4 * ((int)($days / 1461));
        $days %= 1461;
        if ($days > 365) {
            $jy += (int)(($days - 1) / 365);
            $days = ($days - 1) % 365;
        }
        if ($days < 186) {
            $jm = 1 + (int)($days / 31);
            $jd = 1 + ($days % 31);
        } else {
            $jm = 7 + (int)(($days - 186) / 30);
            $jd = 1 + (($days - 186) % 30);
        }

        $months = ['', 'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'];
        return $jd . ' ' . $months[$jm] . ' ' . $jy;
    }
}
?>

<!-- Hero Section -->
<section class="blog-hero">
    <div class="container-master">
        <h1 class="blog-hero-title">
            دانش و <span>تجربه ما</span>
        </h1>
        <p class="blog-hero-text">
            مقالات تخصصی در زمینه تبلیغات، غرفه‌سازی و برگزاری رویداد
        </p>
    </div>
</section>

<!-- Articles Section -->
<section class="blog-section">
    <div class="container-master">
        <?php if (!empty($data['articles'])): ?>
            <div class="articles-grid">
                <?php foreach ($data['articles'] as $index => $article): ?>
                    <a href="<?= URL ?>article/show/<?= $article['slug'] ?>" class="article-card">
                        <div class="article-card-image">
                            <?php if (!empty($article['featured_image'])): ?>
                                <img src="<?= URL . $article['featured_image'] ?>" alt="<?= htmlspecialchars($article['title']) ?>">
                            <?php else: ?>
                                <div class="article-card-placeholder">
                                    <svg viewBox="0 0 24 24">
                                        <path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V5h14v14zm-5-7l-3 3.72L9 13l-3 4h12l-4-5z"/>
                                    </svg>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="article-card-content">
                            <h3 class="article-card-title"><?= htmlspecialchars($article['title']) ?></h3>
                            <p class="article-card-excerpt">
                                <?= htmlspecialchars(mb_substr($article['excerpt'], 0, 120, 'UTF-8')) ?>...
                            </p>
                            <div class="article-card-footer">
                                <div class="article-card-meta">
                                    <span>
                                        <svg viewBox="0 0 24 24"><path d="M19 3h-1V1h-2v2H8V1H6v2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V8h14v11z"/></svg>
                                        <?= toJalali($article['published_at']) ?>
                                    </span>
                                    <span>
                                        <svg viewBox="0 0 24 24"><path d="M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67z"/></svg>
                                        <?= $article['reading_time'] ?> دقیقه
                                    </span>
                                </div>
                                <span class="read-more-btn">
                                    ادامه مطلب
                                    <svg viewBox="0 0 24 24"><path d="M15.41 16.59L10.83 12l4.58-4.59L14 6l-6 6 6 6 1.41-1.41z"/></svg>
                                </span>
                            </div>
                        </div>
                    </a>
                <?php endforeach; ?>
            </div>

            <!-- Pagination -->
            <?php if ($data['totalPages'] > 1): ?>
            <div class="pagination">
                <?php if ($data['currentPage'] > 1): ?>
                    <a href="?page=<?= $data['currentPage'] - 1 ?>" class="pagination-btn">
                        <svg viewBox="0 0 24 24"><path d="M8.59 16.59L13.17 12 8.59 7.41 10 6l6 6-6 6-1.41-1.41z"/></svg>
                        قبلی
                    </a>
                <?php endif; ?>

                <?php for ($i = 1; $i <= $data['totalPages']; $i++): ?>
                    <a href="?page=<?= $i ?>" class="pagination-btn <?= $i === $data['currentPage'] ? 'active' : '' ?>">
                        <?= $i ?>
                    </a>
                <?php endfor; ?>

                <?php if ($data['currentPage'] < $data['totalPages']): ?>
                    <a href="?page=<?= $data['currentPage'] + 1 ?>" class="pagination-btn">
                        بعدی
                        <svg viewBox="0 0 24 24"><path d="M15.41 16.59L10.83 12l4.58-4.59L14 6l-6 6 6 6 1.41-1.41z"/></svg>
                    </a>
                <?php endif; ?>
            </div>
            <?php endif; ?>

        <?php else: ?>
            <div class="no-articles">
                <svg class="no-articles-icon" viewBox="0 0 24 24">
                    <path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-5 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z"/>
                </svg>
                <h3>هنوز مقاله‌ای منتشر نشده است</h3>
                <p>به زودی مقالات جدید اضافه خواهد شد</p>
            </div>
        <?php endif; ?>
    </div>
</section>

<!-- Blog Schema.org Structured Data -->
<script type="application/ld+json">
{
    "@context": "https://schema.org",
    "@type": "Blog",
    "name": "وبلاگ طراحان باستان",
    "description": "مقالات تخصصی در زمینه تبلیغات، غرفه‌سازی و برگزاری رویداد",
    "url": "<?= URL ?>article",
    "publisher": {
        "@type": "Organization",
        "name": "طراحان باستان",
        "logo": {
            "@type": "ImageObject",
            "url": "<?= URL ?>public/assets/images/logo.png"
        }
    }
}
</script>
