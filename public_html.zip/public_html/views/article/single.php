<?php
/**
 * TARAHAN BASTAN - SINGLE ARTICLE PAGE
 * Article Detail View
 */

// Jalali date conversion function
function toJalali($gregorianDate) {
    if (empty($gregorianDate)) return '';
    $timestamp = strtotime($gregorianDate);
    $gy = date('Y', $timestamp);
    $gm = date('m', $timestamp);
    $gd = date('d', $timestamp);

    $g_d_m = array(0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334);
    $gy2 = ($gm > 2) ? ($gy + 1) : $gy;
    $days = 355666 + (365 * $gy) + ((int)(($gy2 + 3) / 4)) - ((int)(($gy2 + 99) / 100)) + ((int)(($gy2 + 399) / 400)) + $gd + $g_d_m[$gm - 1];
    $jy = -1595 + (33 * ((int)($days / 12053)));
    $days %= 12053;
    $jy += 4 * ((int)($days / 1461));
    $days %= 1461;
    if ($days > 365) {
        $jy += (int)(($days - 1) / 365);
        $days = ($days - 1) % 365;
    }
    if ($days < 186) {
        $jm = 1 + (int)($days / 31);
        $jd = 1 + ($days % 31);
    } else {
        $jm = 7 + (int)(($days - 186) / 30);
        $jd = 1 + (($days - 186) % 30);
    }

    $months = ['', 'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'];
    return $jd . ' ' . $months[$jm] . ' ' . $jy;
}

$article = $data['article'];
?>

<!-- Breadcrumb -->
<section class="breadcrumb-section">
    <div class="container-master">
        <nav class="breadcrumb">
            <a href="<?= URL ?>">خانه</a>
            <span class="separator">/</span>
            <a href="<?= URL ?>article">وبلاگ</a>
            <span class="separator">/</span>
            <span class="current"><?= htmlspecialchars($article['title']) ?></span>
        </nav>
    </div>
</section>

<!-- Article Header -->
<header class="article-header">
    <div class="container-master">
        <h1 class="article-title">
            <?= htmlspecialchars($article['title']) ?>
        </h1>
        <div class="article-meta">
            <span>
                <svg viewBox="0 0 24 24"><path d="M19 3h-1V1h-2v2H8V1H6v2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V8h14v11z"/></svg>
                <?= toJalali($article['published_at']) ?>
            </span>
            <span>
                <svg viewBox="0 0 24 24"><path d="M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5zm0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3z"/></svg>
                <?= number_format($article['views']) ?> بازدید
            </span>
            <span>
                <svg viewBox="0 0 24 24"><path d="M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67z"/></svg>
                <?= $article['reading_time'] ?> دقیقه مطالعه
            </span>
        </div>
    </div>
</header>

<!-- Featured Image -->
<?php if (!empty($article['featured_image'])): ?>
<div class="container-narrow">
    <div class="featured-image-wrapper">
        <div class="featured-image">
            <img src="<?= URL . $article['featured_image'] ?>" alt="<?= htmlspecialchars($article['title']) ?>">
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Article Body -->
<section class="article-body">
    <div class="container-narrow">
        <a href="<?= URL ?>article" class="back-link">
            <svg viewBox="0 0 24 24"><path d="M8.59 16.59L13.17 12 8.59 7.41 10 6l6 6-6 6-1.41-1.41z"/></svg>
            بازگشت به وبلاگ
        </a>

        <div class="article-content">
            <?= $article['content'] ?>
        </div>
    </div>
</section>

<!-- Related Articles -->
<?php if (!empty($data['relatedArticles'])): ?>
<section class="related-section">
    <div class="container-master">
        <h2 class="section-title">
            مقالات <span>مرتبط</span>
        </h2>
        <div class="related-grid">
            <?php foreach ($data['relatedArticles'] as $index => $related): ?>
                <a href="<?= URL ?>article/show/<?= $related['slug'] ?>" class="related-card">
                    <div class="related-card-image">
                        <?php if (!empty($related['featured_image'])): ?>
                            <img src="<?= URL . $related['featured_image'] ?>" alt="<?= htmlspecialchars($related['title']) ?>">
                        <?php else: ?>
                            <div class="related-card-placeholder">
                                <svg viewBox="0 0 24 24">
                                    <path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V5h14v14zm-5-7l-3 3.72L9 13l-3 4h12l-4-5z"/>
                                </svg>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="related-card-content">
                        <h3 class="related-card-title"><?= htmlspecialchars($related['title']) ?></h3>
                        <div class="related-card-meta">
                            <svg viewBox="0 0 24 24"><path d="M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67z"/></svg>
                            <?= $related['reading_time'] ?> دقیقه مطالعه
                        </div>
                    </div>
                </a>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php endif; ?>

<!-- CTA Section -->
<section class="article-cta-section">
    <div class="container-master">
        <h2 class="cta-title">سوالی دارید؟</h2>
        <p class="cta-text">
            تیم طراحان باستان آماده پاسخگویی به سوالات شماست
        </p>
        <a href="<?= URL ?>contact" class="cta-btn">
            <svg viewBox="0 0 24 24"><path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/></svg>
            تماس با ما
        </a>
    </div>
</section>

<!-- Article Schema.org Structured Data -->
<script type="application/ld+json">
{
    "@context": "https://schema.org",
    "@type": "Article",
    "headline": "<?= htmlspecialchars($article['title']) ?>",
    "description": "<?= htmlspecialchars($article['excerpt'] ?? '') ?>",
    "image": "<?= !empty($article['featured_image']) ? URL . $article['featured_image'] : '' ?>",
    "datePublished": "<?= $article['published_at'] ?? $article['created_at'] ?>",
    "dateModified": "<?= $article['updated_at'] ?? $article['published_at'] ?? $article['created_at'] ?>",
    "author": {
        "@type": "Organization",
        "name": "طراحان باستان"
    },
    "publisher": {
        "@type": "Organization",
        "name": "طراحان باستان",
        "logo": {
            "@type": "ImageObject",
            "url": "<?= URL ?>public/assets/images/logo.png"
        }
    },
    "mainEntityOfPage": {
        "@type": "WebPage",
        "@id": "<?= URL ?>article/show/<?= $article['slug'] ?>"
    }
}
</script>
