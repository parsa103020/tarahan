<?php
/**
 * TARAHAN BASTAN - CONTACT PAGE
 * High-Energy Edition v7.0
 * Concept: The Royal Command Center (Heroic Energy)
 * Note: Title, meta, fonts loaded in header.php
 */
?>

<!-- Page-specific libraries (WOW.js & Animate.css) -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" integrity="sha512-c42qTSw/wPZ3/5LBzD+Bw5f7bSF2oxou6wEb+I/lqeaKV5FDIfMvvRp772y4jcJLKuGUOpbJMdg/BTl50fJYAw==" crossorigin="anonymous" referrerpolicy="no-referrer" media="print" onload="this.media='all'">
<script src="https://cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.min.js" integrity="sha512-Eak/29OTpb36LLo2r47IpVzPBLXnAMPAVypbSZiZ4Qkf8p/7S/XRG5xp7OKWPPYfJT6metI+IORkR5G8F900+g==" crossorigin="anonymous" referrerpolicy="no-referrer" defer></script>

<style>
    /* ═══════════════════════════════════════════════════════════════════════════
       ⚡ HIGH-ENERGY VARIABLES (HERO VIBE)
       ═══════════════════════════════════════════════════════════════════════════ */
    :root {
        --font-primary: 'YekanBakh', sans-serif !important;
        
        /* 🎨 Palette: Magma & Gold */
        --color-brown-deep: #2D1810;
        --color-brown-rich: #4A2C1A;
        
        --color-gold-pure: #D4A020;
        --color-gold-light: #FFD700;
        
        /* 🔥 ENERGY INJECTION */
        --color-energy-1: #FF4500; /* Orange Red */
        --color-energy-2: #FF8C00; /* Dark Orange */
        --color-energy-3: #FFA500; /* Orange */
        
        --bg-paper: #FFFBF2;
        --bg-white: #FFFFFF;
        
        /* 🌌 Gradients */
        --grad-magma: linear-gradient(135deg, #FF4500 0%, #FF8C00 100%);
        --grad-royal: linear-gradient(135deg, #D4A020 0%, #FFD700 50%, #F58500 100%);
        --grad-glass: linear-gradient(145deg, rgba(255,255,255,0.9) 0%, rgba(255,250,240,0.8) 100%);
        
        /* 🌑 Premium Shadows */
        --shadow-card: 0 15px 35px rgba(212, 160, 32, 0.1);
        --shadow-card-hover: 0 25px 50px rgba(255, 69, 0, 0.15);
        --shadow-glow: 0 0 20px rgba(255, 140, 0, 0.3);
    }

    /* ═══════════════════════════════════════════════════════════════════════════
       🛠 GLOBAL RESET & TYPOGRAPHY FIX
       ═══════════════════════════════════════════════════════════════════════════ */
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: var(--font-primary);
    }

    body {
        background-color: var(--bg-paper);
        color: var(--color-brown-deep);
        line-height: 1.8;
        overflow-x: hidden;
    }

    /* FORCE FONT ON ALL ELEMENTS */
    h1, h2, h3, h4, h5, h6, p, span, div, a, button, input, textarea, label, li, ul {
        font-family: var(--font-primary);
    }

    .ltr-number {
        direction: ltr;
        display: inline-block;
        unicode-bidi: embed;
        font-family: sans-serif !important;
        font-weight: 700;
    }

    .container-master {
        max-width: 1300px;
        margin: 0 auto;
        padding: 0 25px;
        position: relative;
        z-index: 2;
    }

    /* Screen reader only - accessibility */
    .sr-only {
        position: absolute;
        width: 1px;
        height: 1px;
        padding: 0;
        margin: -1px;
        overflow: hidden;
        clip: rect(0, 0, 0, 0);
        white-space: nowrap;
        border: 0;
    }

    /* ═══════════════════════════════════════════════════════════════════════════
       1. HERO SECTION: HIGH ENERGY
       ═══════════════════════════════════════════════════════════════════════════ */
    .hero-energy {
        position: relative;
        min-height: 85vh;
        display: flex;
        align-items: center;
        justify-content: center;
        background: radial-gradient(circle at 50% 30%, #FFF8E7 0%, #FFFBF2 100%);
        overflow: hidden;
        padding-top: 100px;
    }

    /* Dynamic Background Particles */
    .hero-particles {
        position: absolute;
        inset: 0;
        pointer-events: none;
    }
    .particle {
        position: absolute;
        border-radius: 50%;
        background: var(--grad-magma);
        opacity: 0.1;
        animation: floatUp 10s infinite linear;
    }
    .p1 { width: 100px; height: 100px; left: 10%; bottom: -50px; animation-duration: 15s; }
    .p2 { width: 60px; height: 60px; right: 20%; bottom: -30px; animation-duration: 12s; animation-delay: 2s; }
    .p3 { width: 150px; height: 150px; left: 80%; top: 20%; animation-duration: 20s; opacity: 0.05; }

    @keyframes floatUp {
        0% { transform: translateY(0) scale(1); opacity: 0.1; }
        100% { transform: translateY(-100vh) scale(1.2); opacity: 0; }
    }

    .hero-content {
        text-align: center;
        z-index: 5;
        max-width: 900px;
    }

    .hero-badge {
        display: inline-flex;
        align-items: center;
        gap: 10px;
        background: #fff;
        padding: 10px 25px;
        border-radius: 50px;
        box-shadow: 0 10px 20px rgba(255, 69, 0, 0.1);
        margin-bottom: 30px;
        border: 1px solid rgba(255, 69, 0, 0.2);
    }

    .hero-badge span {
        font-weight: 800;
        background: var(--grad-magma);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        text-transform: uppercase;
        letter-spacing: 1px;
    }

    .hero-title {
        font-size: clamp(2.5rem, 6vw, 4.5rem);
        font-weight: 900;
        line-height: 1.1;
        color: var(--color-brown-deep);
        margin-bottom: 25px;
    }

    .hero-title .highlight {
        position: relative;
        color: var(--color-energy-1);
        display: inline-block;
    }
    
    .hero-title .highlight::after {
        content: '';
        position: absolute;
        bottom: 5px;
        left: 0;
        width: 100%;
        height: 10px;
        background: rgba(255, 215, 0, 0.3);
        z-index: -1;
        transform: rotate(-2deg);
    }

    .hero-subtitle {
        font-size: 1.2rem;
        color: #666;
        max-width: 600px;
        margin: 0 auto 50px;
    }

    /* ═══════════════════════════════════════════════════════════════════════════
       2. CONTACT CARDS: 3D & VIBRANT
       ═══════════════════════════════════════════════════════════════════════════ */
    .cards-section {
        padding: 50px 0 100px;
        margin-top: -50px; /* Overlap Hero */
        position: relative;
        z-index: 10;
    }

    .info-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
        gap: 30px;
    }

    .contact-card {
        background: #fff;
        border-radius: 24px;
        padding: 40px 30px;
        text-align: center;
        box-shadow: var(--shadow-card);
        transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        border: 1px solid rgba(0,0,0,0.03);
        position: relative;
        overflow: hidden;
    }

    .contact-card::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 4px;
        background: var(--grad-magma);
        transform: scaleX(0);
        transition: transform 0.4s ease;
        transform-origin: left;
    }

    .contact-card:hover {
        transform: translateY(-10px);
        box-shadow: var(--shadow-card-hover);
    }

    .contact-card:hover::before {
        transform: scaleX(1);
    }

    .icon-circle {
        width: 70px;
        height: 70px;
        background: #FFF5E6;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 25px;
        color: var(--color-energy-1);
        font-size: 1.8rem;
        transition: all 0.4s ease;
    }

    .contact-card:hover .icon-circle {
        background: var(--grad-magma);
        color: #fff;
        transform: rotate(10deg);
    }

    .card-label {
        font-size: 0.9rem;
        color: #999;
        font-weight: 700;
        letter-spacing: 1px;
        margin-bottom: 10px;
    }

    .card-value {
        font-size: 1.3rem;
        font-weight: 800;
        color: var(--color-brown-deep);
        line-height: 1.5;
    }

    /* ═══════════════════════════════════════════════════════════════════════════
       3. THE FORM: PREMIUM & CLEAN
       ═══════════════════════════════════════════════════════════════════════════ */
    .form-section {
        padding: 100px 0;
        background: #fff;
        position: relative;
    }

    .form-wrapper {
        max-width: 900px;
        margin: 0 auto;
        background: var(--bg-paper);
        border-radius: 40px;
        padding: 60px;
        box-shadow: 0 20px 60px rgba(0,0,0,0.05);
        border: 1px solid rgba(212, 160, 32, 0.1);
    }

    .form-header {
        text-align: center;
        margin-bottom: 50px;
    }

    .form-header h2 {
        font-size: 2.2rem;
        color: var(--color-brown-deep);
        font-weight: 900;
        margin-bottom: 15px;
    }

    .form-row {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 25px;
        margin-bottom: 25px;
    }

    .input-group {
        position: relative;
    }

    .modern-input {
        width: 100%;
        padding: 18px 20px;
        border: 2px solid #eee;
        border-radius: 15px;
        background: #fff;
        font-size: 1rem;
        transition: all 0.3s ease;
        outline: none;
    }

    .modern-input:focus {
        border-color: var(--color-energy-2);
        box-shadow: 0 0 0 4px rgba(255, 69, 0, 0.1);
    }

    .modern-input::placeholder {
        color: #ccc;
        font-weight: 300;
    }

    .submit-btn {
        width: 100%;
        padding: 20px;
        background: var(--grad-magma);
        color: #fff;
        font-size: 1.2rem;
        font-weight: 900;
        border: none;
        border-radius: 15px;
        cursor: pointer;
        transition: all 0.3s ease;
        box-shadow: 0 10px 20px rgba(255, 69, 0, 0.3);
    }

    .submit-btn:hover {
        transform: translateY(-3px);
        box-shadow: 0 15px 30px rgba(255, 69, 0, 0.4);
    }

    /* ═══════════════════════════════════════════════════════════════════════════
       4. FAQ: THE ACCORDION (FIXED STYLE)
       ═══════════════════════════════════════════════════════════════════════════ */
    .faq-section {
        padding: 100px 0;
        background: var(--bg-paper);
    }

    .faq-container {
        max-width: 800px;
        margin: 0 auto;
    }

    .faq-card {
        background: #fff;
        border-radius: 16px;
        margin-bottom: 15px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.03);
        overflow: hidden;
        transition: all 0.3s ease;
        border: 1px solid transparent;
    }

    .faq-card.active {
        box-shadow: 0 10px 30px rgba(212, 160, 32, 0.15);
        border-color: var(--color-gold-pure);
    }

    .faq-header {
        padding: 25px 30px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        cursor: pointer;
        background: #fff;
    }

    .faq-question {
        font-size: 1.1rem;
        font-weight: 700;
        color: var(--color-brown-deep);
    }

    .faq-icon {
        width: 30px;
        height: 30px;
        background: #FFF5E6;
        color: var(--color-energy-1);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: bold;
        transition: transform 0.3s ease;
    }

    .faq-card.active .faq-icon {
        transform: rotate(45deg);
        background: var(--color-energy-1);
        color: #fff;
    }

    .faq-body {
        max-height: 0;
        overflow: hidden;
        transition: max-height 0.4s cubic-bezier(0.65, 0, 0.35, 1);
        background: #FAFAFA;
    }

    .faq-content {
        padding: 0 30px 30px;
        color: #555;
        line-height: 1.8;
        font-size: 0.95rem;
    }

    /* ═══════════════════════════════════════════════════════════════════════════
       RESPONSIVE
       ═══════════════════════════════════════════════════════════════════════════ */
    @media (max-width: 768px) {
        .hero-title { font-size: 2.8rem; }
        .form-row { grid-template-columns: 1fr; }
        .form-wrapper { padding: 30px 20px; }
        .contact-card { padding: 30px 20px; }
        .faq-header { padding: 20px; }
    }
</style>

<!-- BACKGROUND TEXTURE -->
<div style="position:fixed; top:0; left:0; width:100%; height:100%; opacity:0.4; pointer-events:none; background-image: radial-gradient(#D4A020 0.5px, transparent 0.5px); background-size: 20px 20px; z-index:-1;"></div>

<!-- 1. HERO -->
<section class="hero-energy" aria-label="ارتباط با طراحان باستان">
    <div class="hero-particles" aria-hidden="true">
        <div class="particle p1"></div>
        <div class="particle p2"></div>
        <div class="particle p3"></div>
    </div>

    <div class="hero-content container-master">
        <div class="hero-badge wow animate__bounceIn" aria-hidden="true">
            <span>⚡ Ready for Action</span>
        </div>

        <h1 class="hero-title wow animate__fadeInUp">
            ارتباط با <span class="highlight">قهرمانان</span><br>
            آغاز یک تحول بزرگ
        </h1>

        <p class="hero-subtitle wow animate__fadeInUp" data-wow-delay="0.2s">
            ما آماده‌ایم تا به سوالات شما پاسخ دهیم و ایده‌هایتان را به واقعیت تبدیل کنیم.
            همین حالا خطوط ارتباطی باز است.
        </p>
    </div>
</section>

<!-- 2. CARDS -->
<section class="cards-section">
    <div class="container-master">
        <div class="info-grid">
            <!-- Phone -->
            <a href="tel:<?= $data['info']['phone'] ?? '08138284242' ?>" style="text-decoration:none;">
                <div class="contact-card wow animate__fadeInUp" data-wow-delay="0.1s">
                    <div class="icon-circle">📞</div>
                    <div class="card-label">تماس فوری</div>
                    <div class="card-value ltr-number"><?= $data['info']['phone_display'] ?? '081-38284242' ?></div>
                    <div style="font-size:0.9rem; color:#FF8C00; margin-top:5px;"><?= $data['info']['work_hours'] ?? 'پاسخگویی ۹ تا ۱۸' ?></div>
                </div>
            </a>

            <!-- Address -->
            <div class="contact-card wow animate__fadeInUp" data-wow-delay="0.2s">
                <div class="icon-circle">📍</div>
                <div class="card-label">ملاقات حضوری</div>
                <div class="card-value" style="font-size:1.1rem;"><?= $data['info']['address'] ?? 'همدان، بلوار شهید مدنی، ساختمان پارسیان، طبقه ۳' ?></div>
            </div>

            <!-- Email -->
            <a href="mailto:<?= $data['info']['email'] ?? 'info@tarahanbastan.ir' ?>" style="text-decoration:none;">
                <div class="contact-card wow animate__fadeInUp" data-wow-delay="0.3s">
                    <div class="icon-circle">✉️</div>
                    <div class="card-label">ارسال پیام</div>
                    <div class="card-value"><?= $data['info']['email'] ?? 'info@tarahanbastan.ir' ?></div>
                </div>
            </a>
        </div>
    </div>
</section>

<!-- 3. FORM -->
<section class="form-section" id="contact-form">
    <div class="container-master">
        <div class="form-wrapper wow animate__zoomIn">
            <div class="form-header">
                <h2>شروع یک پروژه جدید</h2>
                <p>فرم زیر را پر کنید، ما عاشق خواندن پیام‌های شما هستیم.</p>
            </div>

            <form action="<?= URL ?>contact/send" method="post">
                <div class="form-row">
                    <div class="input-group">
                        <label for="contact-name" class="sr-only">نام و نام خانوادگی</label>
                        <input type="text" name="name" id="contact-name" class="modern-input" placeholder="نام و نام خانوادگی" required autocomplete="name">
                    </div>
                    <div class="input-group">
                        <label for="contact-phone" class="sr-only">شماره تماس</label>
                        <input type="tel" name="phone" id="contact-phone" class="modern-input" placeholder="شماره تماس (الزامی)" required autocomplete="tel">
                    </div>
                </div>

                <div class="form-row">
                    <div class="input-group">
                        <label for="contact-email" class="sr-only">ایمیل</label>
                        <input type="email" name="email" id="contact-email" class="modern-input" placeholder="ایمیل (اختیاری)" autocomplete="email">
                    </div>
                    <div class="input-group">
                        <label for="contact-subject" class="sr-only">موضوع پیام</label>
                        <input type="text" name="subject" id="contact-subject" class="modern-input" placeholder="موضوع پیام">
                    </div>
                </div>

                <div class="input-group" style="margin-bottom:25px;">
                    <label for="contact-message" class="sr-only">متن پیام</label>
                    <textarea name="message" id="contact-message" class="modern-input" rows="5" placeholder="بنویسید... ما می‌خوانیم" required></textarea>
                </div>

                <button type="submit" class="submit-btn">ارسال پیام با سرعت نور 🚀</button>
            </form>
        </div>
    </div>
</section>

<!-- 4. MAP -->
<section style="height: 450px; filter: grayscale(100%); transition: filter 0.5s;" onmouseover="this.style.filter='grayscale(0%)'" onmouseout="this.style.filter='grayscale(100%)'" aria-label="نقشه محل شرکت طراحان باستان">
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3280.169627766784!2d48.512345!3d34.798765!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMzTCsDQ3JzU1LjUiTiA0OMKwMzAnNDQuNCJF!5e0!3m2!1sen!2sir!4v1600000000000!5m2!1sen!2sir" width="100%" height="100%" style="border:0;" allowfullscreen="" loading="lazy" title="نقشه گوگل - محل شرکت طراحان باستان در همدان"></iframe>
</section>

<!-- 5. FAQ: FIXED ACCORDION -->
<section class="faq-section" aria-labelledby="faq-heading">
    <div class="container-master">
        <div style="text-align: center; margin-bottom: 50px;">
            <h2 id="faq-heading" style="font-size: 2rem; font-weight: 900; color: var(--color-brown-deep);">سوالات متداول</h2>
        </div>

        <div class="faq-container">
            <?php if (!empty($data['faq'])): $delay = 0; foreach ($data['faq'] as $faq): ?>
            <div class="faq-card wow animate__fadeInUp" <?= $delay > 0 ? "data-wow-delay=\"{$delay}s\"" : '' ?>>
                <button type="button" class="faq-header" aria-expanded="false">
                    <span class="faq-question"><?= htmlspecialchars($faq['question'] ?? '', ENT_QUOTES, 'UTF-8') ?></span>
                    <span class="faq-icon" aria-hidden="true">+</span>
                </button>
                <div class="faq-body" hidden>
                    <div class="faq-content">
                        <?= htmlspecialchars($faq['answer'] ?? '', ENT_QUOTES, 'UTF-8') ?>
                    </div>
                </div>
            </div>
            <?php $delay += 0.1; endforeach; endif; ?>
        </div>
    </div>
</section>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Initialize WOW.js
    if (typeof WOW !== 'undefined') {
        new WOW().init();
    }

    // FAQ Accordion Logic with accessibility
    document.querySelectorAll('.faq-header').forEach(header => {
        header.addEventListener('click', () => {
            const card = header.parentElement;
            const body = card.querySelector('.faq-body');
            const isActive = card.classList.contains('active');

            // Close others
            document.querySelectorAll('.faq-card').forEach(item => {
                item.classList.remove('active');
                item.querySelector('.faq-header').setAttribute('aria-expanded', 'false');
                item.querySelector('.faq-body').hidden = true;
                item.querySelector('.faq-body').style.maxHeight = null;
            });

            // Toggle current
            if (!isActive) {
                card.classList.add('active');
                header.setAttribute('aria-expanded', 'true');
                body.hidden = false;
                body.style.maxHeight = body.scrollHeight + "px";
            }
        });
    });
});
</script>
