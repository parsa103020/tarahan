<?php
/**
 * Icon Helper Function - Converts icon names to SVG code
 * Supports common icon names used in the database
 */
function getIconSvg($iconName, $class = '') {
    $icons = [
        // Stats icons
        'users' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>',
        'check-circle' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>',
        'award' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8" r="7"/><polyline points="8.21 13.89 7 23 12 20 17 23 15.79 13.88"/></svg>',
        'calendar' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>',
        'star' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>',
        'briefcase' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="7" width="20" height="14" rx="2" ry="2"/><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/></svg>',
        'trending-up' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg>',
        'target' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/></svg>',
        'clock' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>',
        'heart' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>',
        'thumbs-up' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3zM7 22H4a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h3"/></svg>',
        'zap' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>',
        'shield' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>',
        'layers' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 2 7 12 12 22 7 12 2"/><polyline points="2 17 12 22 22 17"/><polyline points="2 12 12 17 22 12"/></svg>',
        'package' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="16.5" y1="9.4" x2="7.5" y2="4.21"/><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/></svg>',
        // Service icons
        'booth' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/></svg>',
        'image' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>',
        'sparkles' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z"/></svg>',
        'video' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2" ry="2"/></svg>',
        'printer' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>',
        'lightbulb' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"/></svg>',
        // Process icons
        'message-circle' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/></svg>',
        'edit' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>',
        'tool' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/></svg>',
        'check' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>',
        'truck' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="1" y="3" width="15" height="13"/><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/></svg>',
        'settings' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>',
        'eye' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>',
        'phone' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>',
        'mail' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>',
        'map-pin' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>',
        'globe' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>',
        'home' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>',
        'building' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="2" width="16" height="20" rx="2" ry="2"/><path d="M9 22v-4h6v4"/><path d="M8 6h.01"/><path d="M16 6h.01"/><path d="M12 6h.01"/><path d="M12 10h.01"/><path d="M12 14h.01"/><path d="M16 10h.01"/><path d="M16 14h.01"/><path d="M8 10h.01"/><path d="M8 14h.01"/></svg>',
    ];

    $iconName = strtolower(trim($iconName));

    // If it looks like an SVG already, return it
    if (strpos($iconName, '<svg') !== false || strpos($iconName, '<path') !== false) {
        return $iconName;
    }

    // If it's an emoji (no mapping needed), return it
    if (mb_strlen($iconName) <= 4 && !preg_match('/^[a-z\-]+$/', $iconName)) {
        return $iconName;
    }

    // Return the mapped SVG or a default icon
    return $icons[$iconName] ?? $icons['star'];
}
?>

<!-- WOW.js Animation Library -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" integrity="sha512-c42qTSw/wPZ3/5LBzD+Bw5f7bSF2oxou6wEb+I/lqeaKV5FDIfMvvRp772y4jcJLKuGUOpbJMdg/BTl50fJYAw==" crossorigin="anonymous" referrerpolicy="no-referrer">
<script src="https://cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.min.js" integrity="sha512-Eak/29OTpb36LLo2r47IpVzPBLXnAMPAVypbSZiZ4Qkf8p/7S/XRG5xp7OKWPPYfJT6metI+IORkR5G8F900+g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<style>
/* ══════════════════════════════════════════════════════════════════════════════
   TARAHAN BASTAN - PREMIUM LIGHT MODE v4.1
   طراحی هنرمندانه پروداکشن - رنگ‌های درخشان و هیجانی
   ══════════════════════════════════════════════════════════════════════════════ */

/* ═══ YEKANBAKH FONT - BOLD & POWERFUL ═══ */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'YekanBakh', 'Vazirmatn', 'IRANSans', Tahoma, sans-serif !important;
}

/* Proper cursor for interactive elements */
a, button, [role="button"], input, select, textarea, label, summary {
    cursor: pointer;
}

:root {
    /* ═══════════════════════════════════════════════════════════════════════════
       🔥 HERO ARCHETYPE COLORS - POWERFUL LIKE NIKE 🔥
       قهرمان = قدرت، انرژی، جسارت، پیروزی
       ═══════════════════════════════════════════════════════════════════════════ */

    /* ═══ Brown Spectrum - DEEP & POWERFUL ═══ */
    --brand-brown: #2D1810;
    --brand-brown-light: #4A2C1A;
    --brand-brown-dark: #1A0D08;
    --brand-brown-intense: #3D2015;     /* قهوه‌ای غنی */

    /* ═══ 🏆 CHAMPION GOLD - طلایی قهرمانانه ═══ */
    --brand-gold: #D4A020;              /* طلایی خالص - نه کمرنگ! */
    --brand-gold-light: #E8B830;        /* طلایی روشن درخشان */
    --brand-gold-dark: #B8890F;         /* طلایی عمیق */
    --brand-gold-vibrant: #F5C518;      /* طلایی IMDB - خیلی درخشان */
    --brand-gold-pure: #FFD700;         /* طلایی Pure Gold */

    /* ═══ 🔥 HERO ORANGE - نارنجی قدرتمند ═══ */
    --brand-orange: #F58500;            /* نارنجی Hermes */
    --brand-orange-light: #FF9500;      /* نارنجی iOS */
    --brand-orange-vibrant: #FF6B00;    /* نارنجی آتشین */
    --brand-orange-fire: #FF4500;       /* OrangeRed - آتش خالص */
    --brand-orange-energy: #FF8C00;     /* DarkOrange - انرژی */

    /* ═══ 🌟 ACCENT COLORS - تاکید قدرتمند ═══ */
    --accent-red: #DC2626;              /* قرمز قدرت */
    --accent-amber: #F59E0B;            /* کهربایی درخشان */
    --accent-yellow: #FBBF24;           /* زرد انرژی */

    --brand-cream: #FFF8E7;             /* کرم گرم */
    --brand-cream-light: #FFFCF5;

    /* ═══ Rich Background Palette - Production Grade ═══ */
    --bg-hero: linear-gradient(180deg,
        #FFFEFB 0%,
        #FEF9F2 15%,
        #FCF4E9 35%,
        #F8EDDC 55%,
        #F3E4CE 75%,
        #ECDBC0 100%);
    --bg-section-warm: linear-gradient(180deg, #FBF7F1 0%, #F4EBE0 50%, #EDE1D4 100%);
    --bg-section-cream: linear-gradient(180deg, #FEFBF7 0%, #F9F3EB 50%, #F3EAE0 100%);
    --bg-section-rich: linear-gradient(180deg, #F5EBE0 0%, #EBDFD0 50%, #E2D4C2 100%);
    --bg-section-deep: linear-gradient(180deg, #EDE3D5 0%, #E3D6C4 50%, #D9CBB5 100%);
    --bg-section-accent: linear-gradient(180deg, #E8DCD0 0%, #DED0C0 50%, #D4C6B2 100%);
    --bg-section-dark: linear-gradient(135deg, #3D2419 0%, #2D1810 50%, #1F100A 100%);
    --bg-card: linear-gradient(145deg, #FFFFFF 0%, #FDFBF9 50%, #FAF5EF 100%);
    --bg-card-hover: linear-gradient(145deg, #FFFEFB 0%, #FDF9F3 50%, #F8F0E5 100%);
    --bg-card-premium: linear-gradient(145deg, #FFFFFF 0%, #FFF9F0 30%, #FFF3E3 100%);

    /* ═══ Text Colors ═══ */
    --text-primary: #2D1810;
    --text-secondary: #5A3825;
    --text-body: #6B4D3A;
    --text-muted: #8B7355;
    --text-light: #A89076;

    /* ═══ 🔥 POWER Gold-Orange Spectrum - قدرت رنگ ═══ */
    --gold-50: rgba(212, 160, 32, 0.12);
    --gold-100: rgba(212, 160, 32, 0.20);
    --gold-150: rgba(212, 160, 32, 0.28);
    --gold-200: rgba(212, 160, 32, 0.38);
    --gold-250: rgba(212, 160, 32, 0.48);
    --gold-300: rgba(212, 160, 32, 0.58);
    --gold-400: rgba(245, 133, 0, 0.65);
    --gold-500: rgba(245, 133, 0, 0.75);
    --gold-600: rgba(255, 107, 0, 0.85);

    /* ═══ 🏆 CHAMPION GRADIENTS - گرادیان‌های قهرمانانه ═══ */
    --gold-gradient: linear-gradient(135deg, #D4A020 0%, #E8B830 50%, #F5C518 100%);
    --gold-gradient-rich: linear-gradient(135deg, #B8890F 0%, #D4A020 30%, #E8B830 60%, #FFD700 100%);
    --gold-gradient-vibrant: linear-gradient(135deg, #F58500 0%, #FF9500 40%, #FFAA00 70%, #FFD700 100%);
    --gold-gradient-orange: linear-gradient(135deg, #FF4500 0%, #FF6B00 30%, #FF9500 60%, #FFB800 100%);
    --gold-gradient-dark: linear-gradient(135deg, #9A7000 0%, #B8890F 50%, #D4A020 100%);
    --gold-shimmer: linear-gradient(110deg, #D4A020 0%, #FFD700 20%, #FF9500 40%, #FFD700 60%, #D4A020 80%, #FFD700 100%);
    --orange-gradient: linear-gradient(135deg, #FF4500 0%, #FF6B00 50%, #FF9500 100%);

    /* ═══ 🔥 FIRE GRADIENTS - آتشین ═══ */
    --fire-gradient: linear-gradient(135deg, #FF4500 0%, #FF6B00 40%, #FF8C00 80%, #FFD700 100%); /* Smoother transition */
    --hero-gradient: linear-gradient(135deg, #D4A020 0%, #F58500 45%, #FF6B00 90%, #FFFCF5 100%); /* Added cream for delicacy */
    --power-gradient: linear-gradient(135deg, #B8890F 0%, #D4A020 20%, #F58500 50%, #FF6B00 80%, #FF4500 100%); /* Smoother transition */

    /* ═══ 🔥 POWERFUL Shadows - سایه‌های قدرتمند ═══ */
    --shadow-soft: 0 6px 30px rgba(45, 24, 16, 0.05); /* Softer, wider blur */
    --shadow-medium: 0 10px 48px rgba(45, 24, 16, 0.08); /* Softer, wider blur */
    --shadow-strong: 0 20px 70px rgba(45, 24, 16, 0.1); /* Softer, wider blur */
    --shadow-xl: 0 30px 90px rgba(45, 24, 16, 0.12); /* Softer, wider blur */

    /* 🏆 Gold Power Shadows - Enhanced glow */
    --shadow-gold: 0 10px 40px rgba(212, 160, 32, 0.25); /* Softer glow */
    --shadow-gold-strong: 0 16px 60px rgba(212, 160, 32, 0.35); /* Softer glow */
    --shadow-gold-glow: 0 0 70px rgba(212, 160, 32, 0.3), 0 0 110px rgba(245, 133, 0, 0.15); /* Softer, wider glow */
    --shadow-gold-intense: 0 6px 25px rgba(212, 160, 32, 0.4), 0 10px 50px rgba(245, 133, 0, 0.2); /* Softer, wider glow */

    /* 🔥 Fire Shadows - More subtle glow */
    --shadow-fire: 0 10px 40px rgba(255, 69, 0, 0.25), 0 20px 50px rgba(255, 107, 0, 0.15); /* Softer, wider glow */
    --shadow-orange: 0 10px 35px rgba(245, 133, 0, 0.3); /* Softer glow */
    --shadow-orange-glow: 0 0 50px rgba(255, 107, 0, 0.3), 0 0 90px rgba(255, 149, 0, 0.15); /* Softer, wider glow */

    --shadow-inner: inset 0 3px 10px rgba(45, 24, 16, 0.04); /* Softer inner shadow */
    --shadow-inner-gold: inset 0 0 30px rgba(212, 160, 32, 0.1); /* Softer inner shadow */

    --shadow-card:
        0 4px 16px rgba(45, 24, 16, 0.04),
        0 10px 40px rgba(45, 24, 16, 0.06),
        0 20px 50px rgba(212, 160, 32, 0.08); /* Softer card shadows */
    --shadow-card-hover:
        0 6px 20px rgba(45, 24, 16, 0.06),
        0 20px 50px rgba(45, 24, 16, 0.09),
        0 30px 70px rgba(212, 160, 32, 0.15); /* Softer card hover shadows */
    --shadow-premium:
        0 6px 20px rgba(212, 160, 32, 0.1),
        0 10px 40px rgba(45, 24, 16, 0.06),
        0 25px 70px rgba(212, 160, 32, 0.15),
        inset 0 1px 0 rgba(255, 255, 255, 0.9); /* Softer premium shadows */

    /* 🎯 Hero Shadow - برای عناصر مهم - More refined glow */
    --shadow-hero:
        0 10px 35px rgba(245, 133, 0, 0.25),
        0 20px 55px rgba(212, 160, 32, 0.15),
        0 0 70px rgba(255, 107, 0, 0.1); /* Softer, wider hero shadow */

    /* ═══ 🏆 POWERFUL Borders - مرزهای قدرتمند ═══ */
    --border-subtle: rgba(212, 160, 32, 0.20);
    --border-light: rgba(212, 160, 32, 0.35);
    --border-medium: rgba(212, 160, 32, 0.50);
    --border-gold: rgba(212, 160, 32, 0.70);
    --border-orange: rgba(245, 133, 0, 0.60);
    --border-fire: rgba(255, 107, 0, 0.70);
    --border-hero: 2px solid rgba(212, 160, 32, 0.6);
}

html {
    scroll-behavior: smooth;
}

body {
    font-family: 'YekanBakh', sans-serif;
    color: var(--text-primary);
    line-height: 1.75; /* Slightly reduced for a tighter, more deliberate look, but still airy */
    overflow-x: hidden;
    background: #FAF6F1;
}

/* ══════════════════════════════════════════════════════════════════════════════
   SECTION DIVIDERS - جداکننده‌های هنری بین سکشن‌ها
   ══════════════════════════════════════════════════════════════════════════════ */

/* Base Divider */
.section-divider {
    height: 80px;
    position: relative;
    display: flex;
    align-items: center;
    justify-content: center;
    overflow: visible;
}

/* Style 1: Diamond with Lines */
.section-divider.diamond {
    background: transparent;
}

.section-divider.diamond::before {
    content: '';
    position: absolute;
    top: 50%;
    left: 10%;
    right: 10%;
    height: 1px;
    background: linear-gradient(90deg,
        transparent 0%,
        var(--gold-200) 20%,
        var(--gold-300) 45%,
        transparent 50%,
        var(--gold-300) 55%,
        var(--gold-200) 80%,
        transparent 100%);
}

.section-divider.diamond .divider-icon {
    width: 50px;
    height: 50px;
    background: linear-gradient(135deg, #FFFDFB 0%, #FDF8F3 100%);
    border: 2px solid var(--border-light);
    transform: rotate(45deg);
    position: relative;
    z-index: 2;
    box-shadow: var(--shadow-soft);
}

.section-divider.diamond .divider-icon::before {
    content: '';
    position: absolute;
    inset: 6px;
    background: var(--gold-gradient);
    border-radius: 2px;
}

/* Style 2: Wave Pattern */
.section-divider.wave {
    height: 100px;
    background: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1440 100' preserveAspectRatio='none'%3E%3Cpath fill='%23C9A066' fill-opacity='0.1' d='M0,30 C240,80 480,0 720,50 C960,100 1200,20 1440,60 L1440,100 L0,100 Z'/%3E%3Cpath fill='%23C9A066' fill-opacity='0.05' d='M0,50 C360,10 720,90 1080,40 C1260,15 1350,55 1440,40 L1440,100 L0,100 Z'/%3E%3C/svg%3E") no-repeat bottom;
    background-size: 100% 100%;
}

/* Style 3: Ornament Pattern - Refined SVG */
.section-divider.ornament {
    height: 80px; /* Increased height for better visibility */
    background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='100' height='20' viewBox='0 0 100 20'%3E%3Cpath d='M0 10 C20 0, 30 20, 50 10 C70 0, 80 20, 100 10' stroke='%23D4A020' fill='none' stroke-width='1.5' stroke-opacity='0.6'/%3E%3Ccircle cx='25' cy='10' r='2' fill='%23D4A020' fill-opacity='0.8'/%3E%3Ccircle cx='75' cy='10' r='2' fill='%23D4A020' fill-opacity='0.8'/%3E%3C/svg%3E");
    background-repeat: no-repeat;
    background-position: center;
    background-size: 200px 20px; /* Adjust size as needed */
    opacity: 0.7;
    transition: opacity 0.5s ease;
}

.section-divider.ornament:hover {
    opacity: 1;
}

.section-divider.ornament::before {
    content: none; /* Remove old content */
}

/* Style 4: Dots Pattern */
.section-divider.dots {
    gap: 12px;
}

.section-divider.dots::before,
.section-divider.dots::after {
    content: '';
    width: 80px;
    height: 1px;
    background: linear-gradient(90deg, transparent, var(--gold-300));
}

.section-divider.dots::after {
    background: linear-gradient(90deg, var(--gold-300), transparent);
}

.section-divider.dots .dot-group {
    display: flex;
    gap: 8px;
}

.section-divider.dots .dot-group span {
    width: 8px;
    height: 8px;
    background: var(--gold-gradient);
    border-radius: 50%;
    box-shadow: 0 0 10px rgba(201,160,102,0.4);
}

.section-divider.dots .dot-group span:nth-child(2) {
    width: 12px;
    height: 12px;
}

/* Style 5: Gradient Bar */
.section-divider.gradient-bar {
    height: 8px;
    background: linear-gradient(90deg,
        transparent 0%,
        var(--gold-100) 15%,
        var(--gold-200) 35%,
        var(--gold-gradient) 50%,
        var(--gold-200) 65%,
        var(--gold-100) 85%,
        transparent 100%);
    margin: 20px auto;
    max-width: 60%;
    border-radius: 4px;
}



/* ══════════════════════════════════════════════════════════════════════════════
   1. HERO SECTION - v4.3 "Architect's Desk" 3D Redesign
   ══════════════════════════════════════════════════════════════════════════════ */
.hero {
    min-height: 100vh;
    background: var(--bg-hero);
    position: relative;
    display: flex;
    align-items: center;
    justify-content: center;
    overflow: hidden;
    padding: 160px 20px 120px;
    perspective: 1200px; /* Creates the 3D space */
}

.hero-decoration-wrapper {
    position: absolute;
    inset: 0;
    transform-style: preserve-3d;
}

.hero-blueprint-layer {
    position: absolute;
    inset: -20%;
    background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1600 900'%3e%3cdefs%3e%3cfilter id='sketch'%3e%3cfeTurbulence type='fractalNoise' baseFrequency='0.5' numOctaves='1' result='turbulence' /%3e%3cfeDisplacementMap in='SourceGraphic' in2='turbulence' scale='0.5' /%3e%3c/filter%3e%3cradialGradient id='glow'%3e%3cstop offset='0%25' stop-color='%23D4A020' stop-opacity='0.3'/%3e%3cstop offset='100%25' stop-color='%23D4A020' stop-opacity='0'/%3e%3c/radialGradient%3e%3c/defs%3e%3cg fill='none' stroke='%23D4A020' stroke-opacity='0.4' filter='url(%23sketch)'%3e%3ccircle cx='800' cy='450' r='400' /%3e%3ccircle cx='800' cy='450' r='350' stroke-dasharray='5 15'/%3e%3ccircle cx='800' cy='450' r='300' /%3e%3ccircle cx='800' cy='450' r='200' stroke-dasharray='1 10'/%3e%3ccircle cx='800' cy='450' r='100' /%3e%3cg transform='translate(800 450)'%3e%3cpath d='M0-400 V-380' /%3e%3cpath d='M0 400 V 380' /%3e%3cpath d='M-400 0 H-380' /%3e%3cpath d='M400 0 H 380' /%3e%3cpath transform='rotate(30)' d='M0-400 V-380' /%3e%3cpath transform='rotate(60)' d='M0-400 V-380' /%3e%3cpath transform='rotate(120)' d='M0-400 V-380' /%3e%3cpath transform='rotate(150)' d='M0-400 V-380' /%3e%3cpath transform='rotate(210)' d='M0-400 V-380' /%3e%3cpath transform='rotate(240)' d='M0-400 V-380' /%3e%3cpath transform='rotate(300)' d='M0-400 V-380' /%3e%3cpath transform='rotate(330)' d='M0-400 V-380' /%3e%3c/g%3e%3cpath d='M450 450 A 350 350 0 0 1 1150 450' stroke-width='1.5' stroke-opacity='0.4'/%3e%3cpath d='M800 100 A 350 350 0 0 1 1150 450' stroke-dasharray='3 3'/%3e%3cpath d='M800 100 A 350 350 0 0 0 450 450' stroke-dasharray='3 3'/%3e%3cpath d='M600 250 A 200 200 0 0 1 1000 250' stroke-opacity='0.1'/%3e%3cpath d='M600 650 A 200 200 0 0 0 1000 650' stroke-opacity='0.1'/%3e%3c/g%3e%3ccircle cx='800' cy='450' r='100' fill='url(%23glow)'/%3e%3c/svg%3e");
    background-position: center;
    background-size: contain;
    background-repeat: no-repeat;
    transform: translateZ(-300px) scale(1.6);
    opacity: 0.7;
}

.hero-wireframe-layer {
    position: absolute;
    inset: 0;
    transform-style: preserve-3d;
    transform: translateZ(-100px);
}

.wireframe-sphere {
    width: 100px;
    height: 100px;
    position: absolute;
    transform-style: preserve-3d;
    animation: spin-sphere 60s linear infinite;
}

.wireframe-sphere .ring {
    position: absolute;
    width: 100%;
    height: 100%;
    border: 1px solid var(--gold-200);
    border-radius: 50%;
}

.ring-1 { transform: rotateY(30deg) rotateX(10deg); }
.ring-2 { transform: rotateY(60deg) rotateX(20deg); }
.ring-3 { transform: rotateY(90deg) rotateX(30deg); }
.ring-4 { transform: rotateY(120deg) rotateX(40deg); }
.ring-5 { transform: rotateY(150deg) rotateX(50deg); }

.wireframe-sphere-1 { top: 20%; left: 15%; transform: scale(0.8); }
.wireframe-sphere-2 { bottom: 25%; right: 20%; animation-duration: 80s; animation-direction: reverse; transform: scale(1.2); }

@keyframes spin-sphere {
    from { transform: rotateY(0) rotateX(0); }
    to { transform: rotateY(360deg) rotateX(360deg); }
}

.hero-content {
    position: relative;
    z-index: 1; /* Ensure content is above pseudo-elements */
    text-align: center;
    max-width: 950px;
    transform: translateZ(0); /* Bring content to the front */
}


/* Badge */
.hero-badge {
    display: inline-flex;
    align-items: center;
    gap: 12px;
    background: linear-gradient(135deg, rgba(255,255,255,0.9) 0%, rgba(253,251,248,0.95) 100%);
    border: 2px solid var(--border-light);
    padding: 14px 28px;
    border-radius: 60px;
    margin-bottom: 32px;
    box-shadow: var(--shadow-soft), inset 0 1px 0 rgba(255,255,255,0.8);
    animation: fadeInDown 0.8s ease;
}

.hero-badge svg {
    width: 24px;
    height: 24px;
    color: var(--brand-orange-vibrant);
    filter: drop-shadow(0 2px 8px rgba(255, 107, 0, 0.5));
}

.hero-badge span {
    font-size: 15px;
    font-weight: 800;
    color: var(--brand-brown);
    letter-spacing: 0.5px;
}

/* Hero Title - POWER Typography */
.hero-title {
    font-size: clamp(2.8rem, 7vw, 5.5rem);
    font-weight: 900;
    line-height: 1.1;
    margin-bottom: 20px;
    animation: fadeInUp 0.8s ease 0.2s both;
    letter-spacing: -2px;
    text-transform: none;
}

.hero-title .line1 {
    display: block;
    background: linear-gradient(135deg,
        var(--text-primary) 0%,
        #4A2C1A 40%,
        var(--brand-brown-light) 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    font-weight: 900;
    position: relative;
}

/* Subtle shadow effect for depth */
.hero-title .line1::before {
    content: attr(data-text);
    position: absolute;
    inset: 0;
    z-index: -1;
    -webkit-text-stroke: 3px rgba(45, 24, 16, 0.08); /* Slightly increased stroke */
    -webkit-text-fill-color: transparent;
}

.hero-title .line2 {
    display: block;
    background: linear-gradient(135deg,
        #D4A020 10%, /* Softer start */
        #F58500 40%,
        #FF6B00 60%,
        #FF4500 90%); /* Softer end */
    background-size: 200% 100%;
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    filter: drop-shadow(0 4px 10px rgba(255, 69, 0, 0.3)); /* Reduced drop-shadow intensity */
    animation: heroTextShimmer 4s ease-in-out infinite;
    font-weight: 900;
    position: relative;
}

@keyframes heroTextShimmer {
    0%, 100% { background-position: 0% 50%; }
    50% { background-position: 100% 50%; }
}

/* Bold underline accent */
.hero-title .line2::after {
    content: '';
    display: block;
    width: 120px;
    height: 6px;
    margin: 16px auto 0;
    background: linear-gradient(90deg, #D4A020, #FF6B00, #D4A020);
    border-radius: 3px;
    box-shadow: 0 4px 15px rgba(255, 107, 0, 0.4);
}

/* Subtitle with highlight */
.hero-subtitle-wrapper {
    margin-bottom: 24px;
    animation: fadeInUp 0.8s ease 0.4s both;
}

.hero-subtitle {
    font-size: clamp(1.3rem, 3vw, 2rem);
    font-weight: 900;
    color: var(--brand-orange-vibrant);
    position: relative;
    display: inline-block;
    text-shadow: 0 2px 12px rgba(255, 107, 0, 0.4);
}

.hero-subtitle::before,
.hero-subtitle::after {
    content: '—';
    color: var(--brand-orange-energy);
    margin: 0 16px;
}

/* Description */
.hero-description {
    font-size: clamp(1rem, 1.8vw, 1.2rem);
    color: var(--text-body);
    line-height: 1.8; /* Adjusted for consistency with global body line-height */
    max-width: 700px;
    margin: 0 auto 40px;
    animation: fadeInUp 0.8s ease 0.6s both;
}

/* CTA Buttons */
.hero-buttons {
    display: flex;
    gap: 20px;
    justify-content: center;
    flex-wrap: wrap;
    animation: fadeInUp 0.8s ease 0.8s both;
}

/* Premium CTA Button - Hero Power Style */
.btn-primary {
    display: inline-flex;
    align-items: center;
    gap: 14px;
    background: linear-gradient(135deg,
        #D4A020 0%,
        #E8A820 15%,
        #F58500 35%,
        #FF6B00 55%,
        #FF5500 75%,
        #FF6B00 100%);
    background-size: 200% 100%;
    color: white;
    padding: 20px 48px;
    border-radius: 60px;
    font-size: 17px;
    font-weight: 900;
    text-decoration: none;
    box-shadow:
        0 10px 35px rgba(245, 133, 0, 0.45),
        0 5px 20px rgba(255, 107, 0, 0.35),
        inset 0 1px 0 rgba(255, 255, 255, 0.2);
    transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
    position: relative;
    overflow: hidden;
    text-shadow: 0 2px 4px rgba(0,0,0,0.2);
    border: none;
    cursor: pointer;
    animation: btnGradientFlow 4s ease-in-out infinite;
}

@keyframes btnGradientFlow {
    0%, 100% { background-position: 0% 50%; }
    50% { background-position: 100% 50%; }
}

/* Shimmer effect overlay */
.btn-primary::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(
        90deg,
        transparent,
        rgba(255, 255, 255, 0.25),
        rgba(255, 255, 255, 0.4),
        rgba(255, 255, 255, 0.25),
        transparent
    );
    transition: left 0.7s ease;
}

.btn-primary:hover::before {
    left: 100%;
}

/* Glow ring effect */
.btn-primary::after {
    content: '';
    position: absolute;
    inset: -3px;
    border-radius: 63px;
    background: linear-gradient(135deg, #D4A020, #FF6B00, #FF4500, #FF6B00, #D4A020);
    background-size: 300% 100%;
    z-index: -1;
    opacity: 0;
    transition: opacity 0.4s ease;
    animation: glowRing 3s linear infinite;
}

@keyframes glowRing {
    0% { background-position: 0% 50%; }
    100% { background-position: 300% 50%; }
}

.btn-primary:hover::after {
    opacity: 0.6;
}

.btn-primary:hover {
    transform: translateY(-5px) scale(1.03);
    box-shadow:
        0 20px 50px rgba(255, 107, 0, 0.5),
        0 10px 30px rgba(245, 133, 0, 0.4),
        0 0 60px rgba(255, 107, 0, 0.25),
        inset 0 1px 0 rgba(255, 255, 255, 0.3);
}

.btn-primary:active {
    transform: translateY(-2px) scale(1.01);
}

.btn-primary svg {
    width: 22px;
    height: 22px;
    filter: drop-shadow(0 2px 4px rgba(0,0,0,0.15));
}

.btn-secondary {
    display: inline-flex;
    align-items: center;
    gap: 12px;
    background: linear-gradient(135deg, rgba(255,255,255,0.95) 0%, rgba(253,251,248,0.9) 100%);
    color: var(--brand-gold-dark);
    padding: 18px 40px;
    border-radius: 60px;
    font-size: 16px;
    font-weight: 800;
    text-decoration: none;
    border: 2px solid var(--border-medium);
    box-shadow: var(--shadow-soft);
    transition: all 0.4s ease;
}

.btn-secondary:hover {
    background: var(--gold-gradient);
    color: white;
    border-color: transparent;
    transform: translateY(-4px);
    box-shadow: var(--shadow-gold);
}

.btn-secondary svg {
    width: 20px;
    height: 20px;
}

/* Scroll Indicator */
.scroll-indicator {
    position: absolute;
    bottom: 40px;
    left: 50%;
    transform: translateX(-50%);
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 12px;
    animation: fadeInUp 1s ease 1s both;
}

.scroll-indicator span {
    font-size: 13px;
    color: var(--text-muted);
    font-weight: 600;
    letter-spacing: 1px;
}

.scroll-arrow {
    width: 24px;
    height: 40px;
    border: 2px solid var(--border-medium);
    border-radius: 12px;
    position: relative;
    display: flex;
    justify-content: center;
    padding-top: 8px;
}

.scroll-arrow::before {
    content: '';
    width: 4px;
    height: 10px;
    background: var(--brand-gold);
    border-radius: 4px;
    animation: scrollBounce 2s ease-in-out infinite;
}

@keyframes scrollBounce {
    0%, 100% { transform: translateY(0); opacity: 1; }
    50% { transform: translateY(8px); opacity: 0.5; }
}

/* ══════════════════════════════════════════════════════════════════════════════
   2. STATS SECTION - ☀️ LIGHT MODE PREMIUM WITH FLOATING CARDS
   ══════════════════════════════════════════════════════════════════════════════
   طراحی Premium Light Mode با کارت‌های شناور و Counter Animation
   ══════════════════════════════════════════════════════════════════════════════ */

.stats-section {
    background: linear-gradient(180deg,
        #FAF6F0 0%,
        #F5EDE3 50%,
        #EFE5D8 100%);
    padding: 140px 20px; /* Increased padding */
    position: relative;
    overflow: hidden;
}

/* Decorative Background Pattern */
.stats-section::before {
    content: '';
    position: absolute;
    inset: 0;
    background:
        radial-gradient(ellipse 60% 40% at 20% 30%, rgba(212, 160, 32, 0.08) 0%, transparent 50%),
        radial-gradient(ellipse 60% 40% at 80% 70%, rgba(245, 133, 0, 0.06) 0%, transparent 50%);
    pointer-events: none;
}

/* Geometric Decorations */
.stats-section::after {
    content: '';
    position: absolute;
    inset: 0;
    background-image:
        radial-gradient(circle at 10% 20%, rgba(212, 160, 32, 0.15) 0%, transparent 2%),
        radial-gradient(circle at 90% 80%, rgba(245, 133, 0, 0.12) 0%, transparent 2%),
        radial-gradient(circle at 50% 10%, rgba(212, 160, 32, 0.1) 0%, transparent 1.5%),
        radial-gradient(circle at 30% 90%, rgba(245, 133, 0, 0.08) 0%, transparent 1%);
    pointer-events: none;
}

.stats-container {
    max-width: 1200px;
    margin: 0 auto;
    position: relative;
    z-index: 2;
}

/* Section Header */
.stats-header {
    text-align: center;
    margin-bottom: 70px;
}

.stats-header .section-eyebrow {
    display: inline-flex;
    align-items: center;
    gap: 16px;
    margin-bottom: 20px;
}

.stats-header .eyebrow-line {
    width: 50px;
    height: 2px;
    background: linear-gradient(90deg, transparent, #D4A020, transparent);
    border-radius: 2px;
}

.stats-header .eyebrow-text {
    font-size: 14px;
    font-weight: 800;
    letter-spacing: 3px;
    text-transform: uppercase;
    color: #D4A020;
}

.stats-header .section-title {
    font-size: clamp(2.2rem, 5vw, 3.5rem);
    font-weight: 900;
    color: #2D1810;
    line-height: 1.2;
    margin-bottom: 16px;
}

.stats-header .title-highlight {
    background: linear-gradient(135deg, #F58500 0%, #FF6B00 50%, #FF4500 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

.stats-header .section-subtitle {
    font-size: 18px;
    color: #6B4D3A;
    max-width: 450px;
    margin: 0 auto;
    line-height: 1.7;
}

/* Stats Grid */
.stats-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 28px;
}

/* 🎯 STAT CARD - Floating Premium Style */
.stat-card {
    background: white;
    border-radius: 28px;
    padding: 48px 28px 40px;
    text-align: center;
    position: relative;
    transition: all 0.5s cubic-bezier(0.23, 1, 0.32, 1);
    box-shadow:
        var(--shadow-card),
        var(--shadow-inner); /* Added subtle inner shadow */
    border: 1px solid var(--border-light);
}

/* Top Accent Bar */
.stat-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 50%;
    transform: translateX(-50%);
    width: 60px;
    height: 4px;
    background: linear-gradient(90deg, #D4A020, #F58500, #FF6B00);
    border-radius: 0 0 4px 4px;
    transition: width 0.4s ease;
}

.stat-card:hover::before {
    width: 100px;
}

.stat-card:hover {
    transform: translateY(-8px); /* Slightly less aggressive lift */
    box-shadow:
        var(--shadow-card-hover),
        var(--shadow-gold-glow); /* Enhanced glow on hover */
    border-color: var(--brand-gold); /* Refined border color on hover */
}

/* Stat Icon - Circle with Gradient Border */
.stat-icon {
    width: 90px;
    height: 90px;
    margin: 0 auto 24px;
    position: relative;
    display: flex;
    align-items: center;
    justify-content: center;
}

.stat-icon::before {
    content: '';
    position: absolute;
    inset: 0;
    border-radius: 50%;
    padding: 3px;
    background: linear-gradient(135deg, #D4A020, #F58500, #FF6B00, #D4A020);
    -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
    -webkit-mask-composite: xor;
    mask-composite: exclude;
}

.stat-icon .icon-inner {
    width: 100%;
    height: 100%;
    border-radius: 50%;
    background: linear-gradient(145deg, #FFF9F0, #FFF5E8);
    display: flex;
    align-items: center;
    justify-content: center;
    box-shadow: inset 0 2px 8px rgba(212, 160, 32, 0.1);
}

.stat-icon svg {
    width: 36px;
    height: 36px;
    color: #F58500;
    filter: drop-shadow(0 2px 4px rgba(245, 133, 0, 0.3));
}

/* Stat Number - Counter Animation Ready */
.stat-number {
    font-size: 3.5rem;
    font-weight: 900;
    line-height: 1;
    margin-bottom: 12px;
    color: #2D1810;
    font-family: 'YekanBakh', sans-serif;
    letter-spacing: -2px;
}

.stat-number .counter {
    display: inline-block;
    background: linear-gradient(135deg, #2D1810 0%, #5A3825 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

.stat-number .suffix {
    font-size: 2rem;
    background: linear-gradient(135deg, #F58500 0%, #FF6B00 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    margin-right: 4px;
    font-weight: 800;
}

/* Stat Label */
.stat-label {
    font-size: 16px;
    font-weight: 700;
    color: #6B4D3A;
    letter-spacing: 0.3px;
}

/* 📱 Responsive */
@media (max-width: 1100px) {
    .stats-grid {
        grid-template-columns: repeat(2, 1fr);
        gap: 24px;
    }
}

@media (max-width: 600px) {
    .stats-section {
        padding: 80px 16px;
    }

    .stats-grid {
        grid-template-columns: 1fr;
        gap: 20px;
    }

    .stat-card {
        padding: 36px 20px 32px;
    }

    .stat-icon {
        width: 76px;
        height: 76px;
    }

    .stat-number {
        font-size: 2.8rem;
    }

    .stats-header .section-title {
        font-size: 1.8rem;
    }
}

/* ══════════════════════════════════════════════════════════════════════════════
   3. SERVICES SECTION - Production Grade با رنگ و لعاب
   ══════════════════════════════════════════════════════════════════════════════ */
.services-section {
    background: var(--bg-section-warm);
    padding: 140px 20px; /* Increased padding */
    position: relative;
    overflow: hidden;
}

/* Multiple decorative layers */
.services-section::before {
    content: '';
    position: absolute;
    inset: 0;
    background:
        radial-gradient(ellipse 70% 50% at 5% 30%, var(--gold-150) 0%, transparent 40%),
        radial-gradient(ellipse 70% 50% at 95% 70%, var(--gold-150) 0%, transparent 40%),
        radial-gradient(circle at 50% 50%, var(--gold-50) 0%, transparent 60%);
    pointer-events: none;
}

/* Subtle dot pattern */
.services-section::after {
    content: '';
    position: absolute;
    inset: 0;
    background-image: radial-gradient(circle, var(--gold-100) 1px, transparent 1px);
    background-size: 40px 40px;
    opacity: 0.4;
    pointer-events: none;
}

.services-container {
    max-width: 1300px;
    margin: 0 auto;
    position: relative;
    z-index: 1;
}

.section-header {
    text-align: center;
    margin-bottom: 70px;
}

.section-tag {
    display: inline-flex;
    align-items: center;
    gap: 10px;
    background: linear-gradient(135deg, rgba(255,255,255,0.9) 0%, rgba(253,251,248,0.95) 100%);
    border: 2px solid var(--border-light);
    padding: 10px 24px;
    border-radius: 50px;
    margin-bottom: 24px;
    box-shadow: var(--shadow-soft);
}

.section-tag::before {
    content: '';
    width: 10px;
    height: 10px;
    background: var(--fire-gradient);
    border-radius: 50%;
    box-shadow: 0 0 15px rgba(255, 107, 0, 0.7);
}

.section-tag span {
    font-size: 14px;
    font-weight: 700;
    color: var(--brand-brown);
}

.section-title {
    font-size: clamp(2rem, 4vw, 3rem);
    font-weight: 900;
    color: var(--text-primary);
    margin-bottom: 16px;
    line-height: 1.3;
}

.section-title .highlight {
    background: var(--fire-gradient);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    filter: drop-shadow(0 3px 8px rgba(255, 69, 0, 0.35));
}

.section-description {
    font-size: 1.1rem;
    color: var(--text-body);
    line-height: 1.75; /* Adjusted for consistency with global body line-height */
    max-width: 600px;
    margin: 0 auto;
}

.services-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 30px;
}

.service-card {
    background: var(--bg-card-premium);
    border: 2px solid var(--border-light);
    border-radius: 32px;
    padding: 48px 32px 44px;
    text-align: center;
    position: relative;
    overflow: hidden;
    box-shadow:
        var(--shadow-premium),
        var(--shadow-inner-gold); /* Added subtle inner shadow */
    transition: all 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275);
    text-decoration: none;
    display: block;
}

/* Top gradient bar with shimmer */
.service-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 6px;
    background: var(--gold-gradient-rich);
    box-shadow: 0 2px 12px rgba(201,160,102,0.3);
}

/* Pattern overlay */
.service-card::after {
    content: '';
    position: absolute;
    inset: 0;
    background:
        radial-gradient(circle at 80% 20%, var(--gold-50) 0%, transparent 35%),
        radial-gradient(circle at 20% 80%, var(--gold-50) 0%, transparent 25%);
    pointer-events: none;
    opacity: 0.8;
}

/* Inner frame */
.service-card .card-frame {
    position: absolute;
    inset: 10px;
    border: 1px solid var(--gold-100);
    border-radius: 24px;
    pointer-events: none;
}

/* Floating corner badge */
.service-card .card-badge {
    position: absolute;
    top: 20px;
    left: 20px;
    width: 32px;
    height: 32px;
    background: var(--gold-gradient);
    border-radius: 8px;
    transform: rotate(45deg);
    opacity: 0.15;
}

.service-card:hover {
    transform: translateY(-10px) scale(1.01); /* Slightly less aggressive lift */
    box-shadow:
        var(--shadow-card-hover),
        var(--shadow-gold-glow);
    border-color: var(--brand-gold);
    background: var(--bg-card-hover);
}

.service-icon {
    width: 80px;
    height: 80px;
    background: linear-gradient(135deg, var(--gold-100) 0%, var(--gold-50) 100%);
    border: 2px solid var(--border-subtle);
    border-radius: 24px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 24px;
    transition: all 0.4s ease;
}

.service-card:hover .service-icon {
    background: var(--hero-gradient);
    border-color: transparent;
    transform: scale(1.1) rotate(-5deg);
    box-shadow: var(--shadow-orange-glow);
}

.service-icon svg {
    width: 36px;
    height: 36px;
    color: var(--brand-orange-vibrant);
    transition: color 0.4s ease;
    filter: drop-shadow(0 3px 8px rgba(255, 107, 0, 0.5));
}

.service-card:hover .service-icon svg {
    color: white;
}

.service-card h3 {
    font-size: 1.25rem;
    font-weight: 800;
    color: var(--text-primary);
    margin-bottom: 12px;
}

.service-card p {
    font-size: 0.95rem;
    color: var(--text-body);
    line-height: 1.7;
}

/* ══════════════════════════════════════════════════════════════════════════════
   4. FEATURED PROJECT - Premium Showcase Section
   ══════════════════════════════════════════════════════════════════════════════ */
.featured-section {
    background: linear-gradient(180deg,
        #FAF6F0 0%,
        #F8F2EA 30%,
        #F5EDE3 60%,
        #EFE5D8 100%);
    padding: 180px 20px; /* Increased padding */
    position: relative;
    overflow: hidden;
}

/* Premium geometric pattern overlay */
.featured-section::before {
    content: '';
    position: absolute;
    inset: 0;
    background-image:
        radial-gradient(circle at 20% 20%, rgba(212, 160, 32, 0.08) 0%, transparent 40%),
        radial-gradient(circle at 80% 80%, rgba(255, 107, 0, 0.06) 0%, transparent 35%),
        repeating-linear-gradient(
            45deg,
            transparent,
            transparent 60px,
            rgba(201, 160, 102, 0.03) 60px,
            rgba(201, 160, 102, 0.03) 61px
        );
    pointer-events: none;
}

/* Floating golden orb */
.featured-section::after {
    content: '';
    position: absolute;
    top: 15%;
    right: 5%;
    width: 400px;
    height: 400px;
    background: radial-gradient(
        circle,
        rgba(212, 160, 32, 0.15) 0%,
        rgba(245, 133, 0, 0.08) 40%,
        transparent 70%
    );
    filter: blur(40px);
    pointer-events: none;
    animation: floatOrb 20s ease-in-out infinite;
}

@keyframes floatOrb {
    0%, 100% { transform: translate(0, 0) scale(1); opacity: 0.8; }
    25% { transform: translate(-30px, 40px) scale(1.1); opacity: 1; }
    50% { transform: translate(20px, 60px) scale(0.95); opacity: 0.7; }
    75% { transform: translate(40px, 20px) scale(1.05); opacity: 0.9; }
}

.featured-container {
    max-width: 1400px;
    margin: 0 auto;
    position: relative;
    z-index: 1;
}

/* Section Header - Premium */
.featured-section .section-header {
    text-align: center;
    margin-bottom: 80px;
}

.featured-section .section-tag {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 12px;
    padding: 14px 32px;
    background: linear-gradient(135deg,
        rgba(255, 255, 255, 0.95) 0%,
        rgba(253, 251, 248, 0.9) 100%);
    border-radius: 50px;
    border: 2px solid transparent;
    background-clip: padding-box;
    position: relative;
    box-shadow:
        0 4px 20px rgba(212, 160, 32, 0.15),
        0 2px 10px rgba(45, 24, 16, 0.05);
}

.featured-section .section-tag::before {
    content: '';
    position: absolute;
    inset: -2px;
    border-radius: 52px;
    background: linear-gradient(135deg, #D4A020, #F58500, #FF6B00, #D4A020);
    z-index: -1;
}

.featured-section .section-tag span {
    font-size: 15px;
    font-weight: 800;
    background: linear-gradient(135deg, #D4A020, #FF6B00);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    letter-spacing: 0.5px;
}

/* Award Badge Icon */
.featured-section .section-tag::after {
    content: '🏆';
    font-size: 18px;
    filter: drop-shadow(0 2px 4px rgba(212, 160, 32, 0.4));
    animation: trophyBounce 2s ease-in-out infinite;
}

@keyframes trophyBounce {
    0%, 100% { transform: translateY(0) rotate(0deg); }
    25% { transform: translateY(-3px) rotate(-5deg); }
    75% { transform: translateY(-3px) rotate(5deg); }
}

/* Main Showcase Card */
.featured-wrapper {
    display: grid;
    grid-template-columns: 1fr 1.1fr;
    gap: 60px;
    align-items: stretch;
}

/* Content Side - Premium Glass Card */
.featured-content {
    background: linear-gradient(145deg,
        rgba(255, 255, 255, 0.98) 0%,
        rgba(253, 251, 248, 0.95) 50%,
        rgba(250, 246, 240, 0.92) 100%);
    border-radius: 36px;
    padding: 48px;
    position: relative;
    box-shadow:
        0 25px 80px rgba(45, 24, 16, 0.08),
        0 10px 40px rgba(45, 24, 16, 0.04),
        inset 0 1px 0 rgba(255, 255, 255, 1);
    border: 1px solid rgba(212, 160, 32, 0.15);
    overflow: hidden;
    transition: all 0.5s cubic-bezier(0.23, 1, 0.32, 1);
}

.featured-content:hover {
    transform: translateY(-8px);
    box-shadow:
        0 35px 100px rgba(45, 24, 16, 0.12),
        0 15px 50px rgba(212, 160, 32, 0.08),
        inset 0 1px 0 rgba(255, 255, 255, 1);
}

/* Premium corner accent */
.featured-content::before {
    content: '';
    position: absolute;
    top: 0;
    right: 0;
    width: 200px;
    height: 200px;
    background: linear-gradient(135deg,
        rgba(212, 160, 32, 0.1) 0%,
        rgba(245, 133, 0, 0.05) 50%,
        transparent 70%);
    border-radius: 0 36px 0 200px;
    pointer-events: none;
}

/* Gold ribbon accent */
.featured-content::after {
    content: '';
    position: absolute;
    bottom: 0;
    left: 0;
    width: 100%;
    height: 6px;
    background: linear-gradient(90deg,
        #D4A020 0%,
        #F58500 30%,
        #FF6B00 50%,
        #F58500 70%,
        #D4A020 100%);
    background-size: 200% 100%;
    animation: shimmerRibbon 3s linear infinite;
}

@keyframes shimmerRibbon {
    0% { background-position: 200% 0; }
    100% { background-position: -200% 0; }
}

/* Project Type Tag */
.featured-tag {
    display: inline-flex;
    align-items: center;
    gap: 10px;
    background: linear-gradient(135deg, #D4A020 0%, #F58500 50%, #FF6B00 100%);
    color: white;
    padding: 10px 24px;
    border-radius: 30px;
    font-size: 13px;
    font-weight: 800;
    margin-bottom: 28px;
    box-shadow:
        0 8px 25px rgba(245, 133, 0, 0.4),
        0 4px 12px rgba(255, 107, 0, 0.3);
    text-shadow: 0 1px 2px rgba(0,0,0,0.15);
    position: relative;
    overflow: hidden;
}

.featured-tag::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
    animation: tagShimmer 2.5s infinite;
}

@keyframes tagShimmer {
    0% { left: -100%; }
    100% { left: 100%; }
}

.featured-title {
    font-size: clamp(1.8rem, 3.2vw, 2.4rem);
    font-weight: 900;
    color: var(--text-primary);
    margin-bottom: 24px;
    line-height: 1.4;
    position: relative;
}

/* Decorative line after title */
.featured-title::after {
    content: '';
    display: block;
    width: 80px;
    height: 4px;
    margin-top: 20px;
    background: linear-gradient(90deg, #D4A020, #FF6B00);
    border-radius: 2px;
}

.featured-description {
    font-size: 1.05rem;
    color: var(--text-body);
    line-height: 1.75; /* Adjusted for consistency with global body line-height */
    margin-bottom: 36px;
    position: relative;
    padding-right: 24px;
}

/* Quote mark decoration */
.featured-description::before {
    content: '"';
    position: absolute;
    right: 0;
    top: -10px;
    font-size: 48px;
    font-weight: 900;
    color: rgba(212, 160, 32, 0.15);
    line-height: 1;
}

/* Achievement Stats Grid */
.featured-stats {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 16px;
    margin-bottom: 0;
}

.featured-stat {
    display: flex;
    flex-direction: column;
    align-items: center;
    text-align: center;
    gap: 12px;
    padding: 24px 16px;
    background: linear-gradient(145deg,
        rgba(250, 246, 240, 0.9) 0%,
        rgba(245, 237, 227, 0.8) 100%);
    border: 1px solid rgba(212, 160, 32, 0.12);
    border-radius: 20px;
    transition: all 0.4s cubic-bezier(0.23, 1, 0.32, 1);
    position: relative;
    overflow: hidden;
}

.featured-stat:hover {
    transform: translateY(-5px);
    border-color: rgba(212, 160, 32, 0.3);
    box-shadow: 0 15px 40px rgba(212, 160, 32, 0.15);
}

.featured-stat svg {
    width: 32px;
    height: 32px;
    color: #FF6B00;
    filter: drop-shadow(0 3px 8px rgba(255, 107, 0, 0.35));
}

.featured-stat span {
    font-size: 13px;
    font-weight: 700;
    color: var(--text-secondary);
    line-height: 1.4;
}

/* Image Side - Premium Showcase */
.featured-image {
    position: relative;
    border-radius: 36px;
}

/* Main image container with premium frame */
.featured-image-wrapper {
    position: relative;
    border-radius: 32px;
    overflow: hidden;
    box-shadow:
        0 30px 80px rgba(45, 24, 16, 0.15),
        0 15px 40px rgba(45, 24, 16, 0.08);
}

.featured-image img {
    width: 100%;
    height: auto;
    min-height: 450px;
    object-fit: cover;
    border-radius: 32px;
    transition: all 0.6s cubic-bezier(0.23, 1, 0.32, 1);
}

.featured-image:hover img {
    transform: scale(1.03);
}

/* Overlay gradient */
.featured-image::before {
    content: '';
    position: absolute;
    inset: 0;
    background: linear-gradient(
        180deg,
        transparent 40%,
        rgba(45, 24, 16, 0.3) 80%,
        rgba(45, 24, 16, 0.6) 100%
    );
    border-radius: 32px;
    z-index: 1;
    pointer-events: none;
}

/* National Project Badge - Premium */
.featured-image-badge {
    position: absolute;
    top: 24px;
    right: 24px;
    z-index: 3;
    display: flex;
    align-items: center;
    gap: 8px;
    background: linear-gradient(135deg,
        rgba(255, 255, 255, 0.98) 0%,
        rgba(253, 251, 248, 0.95) 100%);
    color: #2D1810;
    padding: 14px 24px;
    border-radius: 50px;
    font-size: 14px;
    font-weight: 800;
    box-shadow:
        0 10px 30px rgba(45, 24, 16, 0.15),
        0 5px 15px rgba(0, 0, 0, 0.1);
    border: 2px solid rgba(212, 160, 32, 0.2);
}

.featured-image-badge::before {
    content: '🇮🇷';
    font-size: 18px;
}

/* Quote Box - Now positioned relative to the image wrapper */
.featured-quote {
    position: absolute;
    bottom: -40px;
    left: 5%;
    right: 5%;
    width: 90%;
    z-index: 4;
    margin: 0 auto; /* Center it */
    background: linear-gradient(145deg,
        rgba(45, 24, 16, 0.97) 0%,
        rgba(60, 35, 22, 0.95) 100%);
    padding: 36px 40px;
    border-radius: 28px;
    box-shadow:
        0 25px 60px rgba(45, 24, 16, 0.25),
        0 10px 30px rgba(0, 0, 0, 0.15);
    backdrop-filter: blur(20px);
    border: 1px solid rgba(201, 160, 102, 0.2);
}

/* Decorative quote marks */
.featured-quote::before {
    content: '"';
    position: absolute;
    top: 16px;
    right: 28px;
    font-size: 72px;
    font-weight: 900;
    color: rgba(201, 160, 102, 0.15);
    line-height: 1;
    font-family: Georgia, serif;
}

.featured-quote p {
    font-size: 1.1rem;
    color: #F5E6D3;
    font-style: italic;
    line-height: 1.9;
    margin-bottom: 20px;
    position: relative;
    z-index: 1;
}

.featured-quote cite {
    display: flex;
    align-items: center;
    gap: 12px;
    font-size: 14px;
    color: #C9A066;
    font-weight: 700;
    font-style: normal;
}

.featured-quote cite::before {
    content: '';
    width: 30px;
    height: 2px;
    background: linear-gradient(90deg, #D4A020, #FF6B00);
    border-radius: 1px;
}

/* Decorative floating elements */
.featured-decor {
    position: absolute;
    pointer-events: none;
    z-index: 0;
}

.featured-decor-1 {
    top: -30px;
    left: -30px;
    width: 120px;
    height: 120px;
    border: 3px solid rgba(212, 160, 32, 0.15);
    border-radius: 50%;
    animation: decorSpin 20s linear infinite;
}

.featured-decor-2 {
    bottom: 60px;
    right: -20px;
    width: 80px;
    height: 80px;
    background: linear-gradient(135deg,
        rgba(212, 160, 32, 0.1) 0%,
        rgba(255, 107, 0, 0.05) 100%);
    border-radius: 20px;
    transform: rotate(45deg);
    animation: decorFloat 8s ease-in-out infinite;
}

@keyframes decorSpin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}

@keyframes decorFloat {
    0%, 100% { transform: rotate(45deg) translateY(0); }
    50% { transform: rotate(45deg) translateY(-15px); }
}

/* ══════════════════════════════════════════════════════════════════════════════
   5. WHY US SECTION - Production Grade Premium
   ══════════════════════════════════════════════════════════════════════════════ */
.why-section {
    background: var(--bg-section-cream);
    padding: 160px 20px; /* Increased padding */
    position: relative;
    overflow: hidden;
}

/* Ambient lighting effects */
.why-section::before {
    content: '';
    position: absolute;
    inset: 0;
    background:
        radial-gradient(ellipse 60% 40% at 0% 50%, var(--gold-150) 0%, transparent 50%),
        radial-gradient(ellipse 60% 40% at 100% 50%, var(--gold-150) 0%, transparent 50%);
    pointer-events: none;
}

/* Geometric pattern */
.why-section::after {
    content: '';
    position: absolute;
    inset: 0;
    background-image:
        linear-gradient(45deg, var(--gold-50) 25%, transparent 25%),
        linear-gradient(-45deg, var(--gold-50) 25%, transparent 25%);
    background-size: 60px 60px;
    opacity: 0.3;
    pointer-events: none;
}

.why-container {
    max-width: 1300px;
    margin: 0 auto;
    position: relative;
    z-index: 1;
}

.why-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 24px;
}

.why-card {
    background: var(--bg-card-premium);
    border: 2px solid var(--border-light);
    border-radius: 28px;
    padding: 44px 28px;
    text-align: center;
    position: relative;
    overflow: hidden;
    box-shadow:
        var(--shadow-premium),
        var(--shadow-inner); /* Added subtle inner shadow */
    transition: all 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275);
}

.why-card:hover {
    transform: translateY(-8px) scale(1.01); /* Slightly less aggressive lift */
    box-shadow:
        var(--shadow-card-hover),
        var(--shadow-gold-glow);
    border-color: var(--brand-gold);
}

/* Pattern overlay */
.why-card::before {
    content: '';
    position: absolute;
    inset: 0;
    background:
        radial-gradient(circle at 100% 0%, var(--gold-100) 0%, transparent 35%),
        radial-gradient(circle at 0% 100%, var(--gold-50) 0%, transparent 30%);
    pointer-events: none;
}

/* Bottom accent line */
.why-card::after {
    content: '';
    position: absolute;
    bottom: 0;
    left: 20%;
    right: 20%;
    height: 3px;
    background: var(--gold-gradient);
    border-radius: 3px 3px 0 0;
}

/* Number badge */
.why-card .card-number {
    position: absolute;
    top: 16px;
    left: 16px;
    width: 32px;
    height: 32px;
    background: var(--hero-gradient);
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 14px;
    font-weight: 900;
    color: white;
    box-shadow: var(--shadow-orange);
    text-shadow: 0 1px 2px rgba(0,0,0,0.2);
}

.why-icon {
    width: 76px;
    height: 76px;
    background: linear-gradient(135deg, var(--gold-100) 0%, var(--gold-50) 100%);
    border: 3px solid var(--border-subtle);
    border-radius: 22px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 24px;
    position: relative;
    box-shadow: inset 0 -3px 10px rgba(201,160,102,0.1);
}

/* Icon ring */
.why-icon::before {
    content: '';
    position: absolute;
    inset: -6px;
    border: 1px dashed var(--gold-200);
    border-radius: 26px;
}

.why-icon svg {
    width: 34px;
    height: 34px;
    color: var(--brand-orange-vibrant);
    filter: drop-shadow(0 3px 8px rgba(255, 107, 0, 0.55));
}

.why-card h3 {
    font-size: 1.15rem;
    font-weight: 800;
    color: var(--text-primary);
    margin-bottom: 12px;
    position: relative;
}

.why-card p {
    font-size: 0.92rem;
    color: var(--text-body);
    line-height: 1.8;
    position: relative;
}

/* ══════════════════════════════════════════════════════════════════════════════
   6. TESTIMONIALS - Production Grade Premium Feedback
   ══════════════════════════════════════════════════════════════════════════════ */
.testimonials-section {
    background: var(--bg-section-warm);
    padding: 160px 20px; /* Increased padding */
    position: relative;
    overflow: hidden;
}

/* Elegant background effects */
.testimonials-section::before {
    content: '';
    position: absolute;
    inset: 0;
    background:
        radial-gradient(ellipse 80% 50% at 30% 0%, var(--gold-150) 0%, transparent 50%),
        radial-gradient(ellipse 80% 50% at 70% 100%, var(--gold-150) 0%, transparent 50%);
    pointer-events: none;
}

/* Quote marks background decoration */
.testimonials-section::after {
    content: '"';
    position: absolute;
    top: 10%;
    left: 5%;
    font-size: 300px;
    font-family: Georgia, serif;
    color: var(--gold-100);
    pointer-events: none;
    line-height: 1;
}

.testimonials-container {
    max-width: 1200px;
    margin: 0 auto;
    position: relative;
    z-index: 1;
}

.testimonials-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 30px;
}

.testimonial-card {
    background: var(--bg-card-premium);
    border: 2px solid var(--border-light);
    border-radius: 28px;
    padding: 44px 36px;
    position: relative;
    box-shadow:
        var(--shadow-premium),
        var(--shadow-inner); /* Added subtle inner shadow */
    overflow: hidden;
    transition: all 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275);
}

.testimonial-card:hover {
    transform: translateY(-6px) scale(1.005); /* Slightly less aggressive lift */
    box-shadow: var(--shadow-card-hover);
    border-color: var(--brand-gold-light);
}

/* Pattern background */
.testimonial-card::before {
    content: '';
    position: absolute;
    inset: 0;
    background:
        radial-gradient(circle at 90% 10%, var(--gold-100) 0%, transparent 30%),
        radial-gradient(circle at 10% 90%, var(--gold-50) 0%, transparent 25%);
    pointer-events: none;
}

/* Quote mark decoration */
.testimonial-card::after {
    content: '"';
    position: absolute;
    top: 16px;
    right: 24px;
    font-size: 90px;
    font-family: Georgia, serif;
    background: var(--gold-gradient);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    opacity: 0.25;
    line-height: 1;
}

/* Top accent bar */
.testimonial-card .card-accent {
    position: absolute;
    top: 0;
    left: 30px;
    right: 30px;
    height: 4px;
    background: var(--gold-gradient);
    border-radius: 0 0 4px 4px;
}

.testimonial-content {
    margin-bottom: 28px;
    position: relative;
    z-index: 1;
}

.testimonial-content p {
    font-size: 1rem;
    color: var(--text-body);
    line-height: 1.75; /* Adjusted for consistency with global body line-height */
    font-style: italic;
}

.testimonial-author {
    display: flex;
    align-items: center;
    gap: 16px;
    padding-top: 20px;
    border-top: 1px solid var(--border-subtle);
}

.author-avatar {
    width: 56px;
    height: 56px;
    background: var(--hero-gradient);
    border-radius: 50%;
    display: flex;
    align-items: center;
    box-shadow: var(--shadow-orange);
    justify-content: center;
    font-size: 20px;
    font-weight: 800;
    color: white;
}

.author-info h4 {
    font-size: 1rem;
    font-weight: 800;
    color: var(--text-primary);
    margin-bottom: 4px;
}

.author-info span {
    font-size: 13px;
    color: var(--text-muted);
}

.testimonial-rating {
    margin-top: 16px;
    display: flex;
    gap: 4px;
}

.testimonial-rating svg {
    width: 20px;
    height: 20px;
    color: var(--brand-orange-energy);
    fill: var(--brand-orange-energy);
    filter: drop-shadow(0 1px 3px rgba(255, 140, 0, 0.4));
}

/* ══════════════════════════════════════════════════════════════════════════════
   7. PROCESS SECTION - Production Grade Timeline
   ══════════════════════════════════════════════════════════════════════════════ */
.process-section {
    background: var(--bg-section-deep);
    padding: 160px 20px; /* Increased padding */
    position: relative;
    overflow: hidden;
}

/* Rich layered background */
.process-section::before {
    content: '';
    position: absolute;
    inset: 0;
    background:
        radial-gradient(ellipse 50% 80% at 50% 0%, var(--gold-200) 0%, transparent 50%),
        radial-gradient(ellipse 50% 80% at 50% 100%, var(--gold-150) 0%, transparent 50%);
    pointer-events: none;
}

/* Connection line glow effect */
.process-section::after {
    content: '';
    position: absolute;
    top: 50%;
    left: 15%;
    right: 15%;
    height: 4px;
    background: var(--gold-gradient-vibrant);
    border-radius: 4px;
    box-shadow: var(--shadow-gold-glow);
    transform: translateY(-50%);
    z-index: 0;
}

.process-container {
    max-width: 1200px;
    margin: 0 auto;
    position: relative;
    z-index: 1;
}

.process-timeline {
    display: flex;
    justify-content: space-between;
    position: relative;
    margin-top: 60px;
    padding: 0 20px;
}

/* Connection line with gradient */
.process-timeline::before {
    content: '';
    position: absolute;
    top: 55px;
    left: 100px;
    right: 100px;
    height: 4px;
    background: linear-gradient(90deg,
        var(--gold-100) 0%,
        var(--brand-gold) 20%,
        var(--brand-gold) 80%,
        var(--gold-100) 100%);
    border-radius: 4px;
    box-shadow: 0 2px 15px rgba(201,160,102,0.3);
}

/* Glowing dots on the line */
.process-timeline::after {
    content: '';
    position: absolute;
    top: 52px;
    left: 50%;
    transform: translateX(-50%);
    width: 10px;
    height: 10px;
    background: var(--brand-gold);
    border-radius: 50%;
    box-shadow: 0 0 20px rgba(201,160,102,0.6);
    animation: pulse 2s ease-in-out infinite;
}

.process-step {
    text-align: center;
    position: relative;
    flex: 1;
    max-width: 180px;
}

.step-number {
    width: 90px;
    height: 90px;
    background: linear-gradient(145deg, #FFFFFF 0%, #FDFBF8 100%);
    border: 4px solid var(--border-medium);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 24px;
    position: relative;
    z-index: 2;
    box-shadow:
        var(--shadow-medium),
        inset 0 -4px 12px rgba(201,160,102,0.1);
}

/* Outer ring decoration */
.step-number::before {
    content: '';
    position: absolute;
    inset: -12px;
    border: 2px dashed var(--gold-200);
    border-radius: 50%;
    animation: spin 25s linear infinite;
}

/* Inner glow */
.step-number::after {
    content: '';
    position: absolute;
    inset: 4px;
    border: 2px solid var(--gold-100);
    border-radius: 50%;
}

.step-number span {
    font-size: 32px;
    font-weight: 900;
    background: var(--fire-gradient);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    position: relative;
    z-index: 1;
}

.step-icon {
    position: absolute;
    top: -10px;
    right: -10px;
    width: 40px;
    height: 40px;
    background: var(--hero-gradient);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    box-shadow: var(--shadow-fire);
    border: 3px solid white;
    z-index: 3;
}

.step-icon svg {
    width: 18px;
    height: 18px;
    color: white;
}

.step-content h3 {
    font-size: 1.1rem;
    font-weight: 800;
    color: var(--text-primary);
    margin-bottom: 10px;
}

.step-content p {
    font-size: 0.9rem;
    color: var(--text-body);
    line-height: 1.7;
}

@keyframes pulse {
    0%, 100% { transform: translateX(-50%) scale(1); opacity: 0.6; }
    50% { transform: translateX(-50%) scale(1.5); opacity: 1; }
}

/* ══════════════════════════════════════════════════════════════════════════════
   8. LOCATION SECTION - Production Grade Location Display
   ══════════════════════════════════════════════════════════════════════════════ */
.location-section {
    background: var(--bg-section-accent);
    padding: 160px 20px; /* Increased padding */
    position: relative;
    overflow: hidden;
}

/* Map-like pattern background */
.location-section::before {
    content: '';
    position: absolute;
    inset: 0;
    background:
        radial-gradient(ellipse 70% 50% at 80% 30%, var(--gold-200) 0%, transparent 50%),
        radial-gradient(ellipse 60% 60% at 20% 70%, var(--gold-150) 0%, transparent 50%);
    pointer-events: none;
}

/* Subtle grid pattern */
.location-section::after {
    content: '';
    position: absolute;
    inset: 0;
    background-image:
        linear-gradient(var(--gold-50) 1px, transparent 1px),
        linear-gradient(90deg, var(--gold-50) 1px, transparent 1px);
    background-size: 50px 50px;
    opacity: 0.3;
    pointer-events: none;
}

.location-container {
    max-width: 1300px;
    margin: 0 auto;
    position: relative;
    z-index: 1;
}

.location-wrapper {
    display: grid;
    grid-template-columns: 1.2fr 1fr;
    gap: 40px;
    align-items: start;
}

.location-map {
    border-radius: 32px;
    overflow: hidden;
    box-shadow: var(--shadow-strong);
    border: 3px solid var(--border-light);
}

.location-map iframe {
    width: 100%;
    height: 450px;
    display: block;
}

.location-info {
    display: flex;
    flex-direction: column;
    gap: 20px;
}

.info-card {
    background: var(--bg-card-premium);
    border: 2px solid var(--border-light);
    border-radius: 24px;
    padding: 32px 28px 32px 32px;
    display: flex;
    align-items: flex-start;
    gap: 20px;
    box-shadow:
        var(--shadow-premium),
        var(--shadow-inner); /* Added subtle inner shadow */
    position: relative;
    overflow: hidden;
    transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
}

.info-card:hover {
    transform: translateX(-6px); /* Slightly less aggressive movement */
    box-shadow: var(--shadow-card-hover);
    border-color: var(--brand-gold);
}

/* Right border accent */
.info-card::before {
    content: '';
    position: absolute;
    top: 20%;
    right: 0;
    bottom: 20%;
    width: 4px;
    background: var(--gold-gradient);
    border-radius: 4px 0 0 4px;
}

/* Pattern overlay */
.info-card::after {
    content: '';
    position: absolute;
    inset: 0;
    background: radial-gradient(circle at 100% 50%, var(--gold-50) 0%, transparent 40%);
    pointer-events: none;
}

.info-icon {
    width: 60px;
    height: 60px;
    background: linear-gradient(135deg, var(--gold-100) 0%, var(--gold-50) 100%);
    border: 3px solid var(--border-subtle);
    border-radius: 18px;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
    position: relative;
    box-shadow: inset 0 -2px 8px rgba(201,160,102,0.1);
}

.info-icon svg {
    width: 28px;
    height: 28px;
    color: var(--brand-orange-vibrant);
    filter: drop-shadow(0 3px 8px rgba(255, 107, 0, 0.55));
}

.info-content {
    position: relative;
    z-index: 1;
}

.info-content h4 {
    font-size: 1.05rem;
    font-weight: 800;
    color: var(--text-primary);
    margin-bottom: 10px;
}

.info-content p {
    font-size: 0.95rem;
    color: var(--text-body);
    line-height: 1.8;
}

/* ══════════════════════════════════════════════════════════════════════════════
   9. CTA SECTION - Production Grade WOW Call to Action
   ══════════════════════════════════════════════════════════════════════════════ */
.cta-section {
    background: linear-gradient(135deg,
        #4A2C1A 0%,
        #3D2015 20%,
        #2D1810 50%,
        #251410 75%,
        #1A0D08 100%);
    padding: 180px 20px; /* Increased padding */
    position: relative;
    overflow: hidden;
}

/* 🔥 HERO POWER - Rich multi-layer decorative overlay */
.cta-section::before {
    content: '';
    position: absolute;
    inset: 0;
    background:
        /* Large spotlight effects - More vibrant */
        radial-gradient(ellipse 80% 100% at 10% 50%, rgba(255, 107, 0, 0.25) 0%, transparent 50%),
        radial-gradient(ellipse 80% 100% at 90% 50%, rgba(245, 133, 0, 0.20) 0%, transparent 50%),
        /* Top glow - Orange fire */
        radial-gradient(ellipse 100% 50% at 50% 0%, rgba(255, 149, 0, 0.18) 0%, transparent 50%),
        /* Bottom glow */
        radial-gradient(ellipse 100% 50% at 50% 100%, rgba(212, 160, 32, 0.15) 0%, transparent 50%),
        /* Center highlight - Fire */
        radial-gradient(circle at 50% 50%, rgba(255, 107, 0, 0.12) 0%, transparent 40%);
    pointer-events: none;
}

/* Decorative floating elements */
.cta-section::after {
    content: '';
    position: absolute;
    top: 20%;
    left: 10%;
    width: 200px;
    height: 200px;
    border: 1px solid rgba(201, 160, 102, 0.15);
    border-radius: 50%;
    animation: float 15s ease-in-out infinite;
}

/* Floating shapes */
.cta-decoration {
    position: absolute;
    inset: 0;
    pointer-events: none;
    overflow: hidden;
}

.cta-decoration .shape-1 {
    position: absolute;
    top: 15%;
    right: 8%;
    width: 150px;
    height: 150px;
    border: 1px solid rgba(201, 160, 102, 0.1);
    border-radius: 30px;
    transform: rotate(45deg);
    animation: floatRotate 20s ease-in-out infinite;
}

.cta-decoration .shape-2 {
    position: absolute;
    bottom: 20%;
    left: 5%;
    width: 100px;
    height: 100px;
    background: radial-gradient(circle, rgba(201, 160, 102, 0.1) 0%, transparent 60%);
    border-radius: 50%;
    animation: float 18s ease-in-out infinite reverse;
}

.cta-decoration .sparkle {
    position: absolute;
    width: 20px;
    height: 20px;
}

.cta-decoration .sparkle::before,
.cta-decoration .sparkle::after {
    content: '';
    position: absolute;
    background: rgba(201, 160, 102, 0.4);
}

.cta-decoration .sparkle::before {
    width: 100%;
    height: 2px;
    top: 50%;
    left: 0;
    transform: translateY(-50%);
}

.cta-decoration .sparkle::after {
    width: 2px;
    height: 100%;
    top: 0;
    left: 50%;
    transform: translateX(-50%);
}

.cta-decoration .sparkle-1 {
    top: 25%;
    right: 20%;
    animation: sparkle 3s ease-in-out infinite;
}

.cta-decoration .sparkle-2 {
    bottom: 30%;
    left: 15%;
    animation: sparkle 4s ease-in-out infinite 1s;
}

.cta-container {
    max-width: 900px;
    margin: 0 auto;
    text-align: center;
    position: relative;
    z-index: 1;
}

.cta-title {
    font-size: clamp(2rem, 4vw, 3rem);
    font-weight: 900;
    color: var(--brand-cream);
    margin-bottom: 16px;
    line-height: 1.3;
}

.cta-subtitle {
    font-size: 1.1rem;
    color: rgba(245, 230, 211, 0.8);
    margin-bottom: 40px;
}

.cta-buttons {
    display: flex;
    gap: 20px;
    justify-content: center;
    flex-wrap: wrap;
}

.cta-btn-primary {
    display: inline-flex;
    align-items: center;
    gap: 12px;
    background: linear-gradient(135deg, rgba(255,255,255,0.95) 0%, rgba(255,255,255,0.9) 100%);
    color: var(--brand-brown);
    padding: 20px 44px;
    border-radius: 60px;
    font-size: 17px;
    font-weight: 800;
    text-decoration: none;
    box-shadow: 0 8px 32px rgba(0,0,0,0.2);
    transition: all 0.4s ease;
}

.cta-btn-primary:hover {
    transform: translateY(-4px) scale(1.02);
    box-shadow: 0 16px 48px rgba(0,0,0,0.3);
}

.cta-btn-primary svg {
    width: 22px;
    height: 22px;
}

.cta-btn-secondary {
    display: inline-flex;
    align-items: center;
    gap: 12px;
    background: transparent;
    color: var(--brand-cream);
    padding: 20px 44px;
    border-radius: 60px;
    font-size: 17px;
    font-weight: 800;
    text-decoration: none;
    border: 2px solid rgba(201, 160, 102, 0.5);
    transition: all 0.4s ease;
}

.cta-btn-secondary:hover {
    background: var(--fire-gradient);
    border-color: transparent;
    color: white;
    transform: translateY(-4px);
    box-shadow: var(--shadow-fire);
}

/* ══════════════════════════════════════════════════════════════════════════════
   ANIMATIONS
   ══════════════════════════════════════════════════════════════════════════════ */
@keyframes fadeInUp {
    from { opacity: 0; transform: translateY(40px); }
    to { opacity: 1; transform: translateY(0); }
}

@keyframes fadeInDown {
    from { opacity: 0; transform: translateY(-30px); }
    to { opacity: 1; transform: translateY(0); }
}

@keyframes float {
    0%, 100% { transform: translateY(0) rotate(0); }
    50% { transform: translateY(-20px) rotate(3deg); }
}

@keyframes spin {
    to { transform: rotate(360deg); }
}

@keyframes dotFloat {
    0%, 100% { transform: translateY(0); opacity: 0.4; }
    50% { transform: translateY(-25px); opacity: 0.8; }
}

@keyframes floatRotate {
    0%, 100% { transform: rotate(45deg) translateY(0); }
    50% { transform: rotate(55deg) translateY(-15px); }
}

@keyframes floatSlow {
    0%, 100% { transform: translateY(0) scale(1); }
    50% { transform: translateY(-10px) scale(1.05); }
}

@keyframes sparkle {
    0%, 100% { opacity: 0.2; transform: scale(0.8); }
    50% { opacity: 0.6; transform: scale(1.2); }
}

/* 🔥 HERO POWER ANIMATIONS */
@keyframes heroPulse {
    0%, 100% {
        box-shadow: 0 8px 30px rgba(245, 133, 0, 0.35),
                    0 16px 50px rgba(212, 160, 32, 0.25),
                    0 0 60px rgba(255, 107, 0, 0.15);
    }
    50% {
        box-shadow: 0 12px 40px rgba(255, 69, 0, 0.5),
                    0 20px 60px rgba(255, 107, 0, 0.35),
                    0 0 80px rgba(255, 149, 0, 0.25);
    }
}

@keyframes fireGlow {
    0%, 100% {
        filter: drop-shadow(0 3px 8px rgba(255, 107, 0, 0.5));
    }
    50% {
        filter: drop-shadow(0 5px 15px rgba(255, 69, 0, 0.7));
    }
}

@keyframes energyPulse {
    0%, 100% { transform: scale(1); }
    50% { transform: scale(1.05); }
}

.fade-in {
    opacity: 0;
    transform: translateY(40px);
    transition: all 0.8s cubic-bezier(0.4, 0, 0.2, 1);
}

.fade-in.visible {
    opacity: 1;
    transform: translateY(0);
}

/* ══════════════════════════════════════════════════════════════════════════════
   RESPONSIVE
   ══════════════════════════════════════════════════════════════════════════════ */
@media (max-width: 1200px) {
    .stats-grid { grid-template-columns: repeat(2, 1fr); }
    .services-grid { grid-template-columns: repeat(2, 1fr); }
    .why-grid { grid-template-columns: repeat(2, 1fr); }
}

@media (max-width: 1024px) {
    .featured-wrapper { grid-template-columns: 1fr; gap: 50px; }
    .featured-content { text-align: center; padding: 40px 32px; }
    .featured-content::before { border-radius: 36px 36px 0 0; }
    .featured-title::after { margin: 20px auto 0; }
    .featured-description { padding-right: 0; }
    .featured-description::before { display: none; }
    .featured-stats { grid-template-columns: repeat(3, 1fr); }
    .featured-quote {
        position: relative;
        width: 100%;
        transform: none;
        margin-top: -70px; /* Pulls it up over the bottom of the image */
        z-index: 2; /* Make sure it's above the image but below the next section */
    }
    .featured-decor { display: none; }
    .location-wrapper { grid-template-columns: 1fr; }
    
    /* New Vertical Process Timeline for Mobile */
    .process-timeline { 
        flex-direction: column;
        align-items: center;
        gap: 50px;
    }
    .process-timeline::before { 
        display: block;
        content: '';
        position: absolute;
        top: 50px;
        bottom: 50px;
        left: 50%;
        width: 4px;
        background: linear-gradient(180deg, var(--gold-100) 0%, var(--brand-gold) 20%, var(--brand-gold) 80%, var(--gold-100) 100%);
        transform: translateX(-50%);
        border-radius: 4px;
    }
    .process-step {
        max-width: 300px;
        width: 100%;
    }
}

@media (max-width: 768px) {
    .hero { padding: 120px 20px 80px; min-height: auto; }
    .hero-buttons { flex-direction: column; align-items: center; }
    .stats-grid { grid-template-columns: 1fr; }
    .services-grid { grid-template-columns: 1fr; }
    .why-grid { grid-template-columns: 1fr; }
    .testimonials-grid { grid-template-columns: 1fr; }
    .cta-buttons { flex-direction: column; align-items: center; }

    /* Featured Section Responsive */
    .featured-section { padding: 80px 15px 100px; }
    .featured-section .section-header { margin-bottom: 50px; }
    .featured-content { padding: 32px 24px; border-radius: 28px; }
    .featured-title { font-size: 1.5rem; }
    .featured-stats { grid-template-columns: 1fr; gap: 12px; }
    .featured-stat { flex-direction: column; gap: 8px; padding: 16px; text-align: center; }
    .featured-stat span { text-align: center; }
    .featured-image img { min-height: 300px; }
    .featured-quote {
        padding: 20px;
        left: 5%;
        right: 5%;
        width: 90%;
        margin: 0 auto; /* Center horizontally */
        bottom: -20px; /* Adjust as needed to overlay the image */
        transform: none; /* Remove problematic transform */
    }
    .featured-quote::before { font-size: 48px; top: 10px; right: 16px; }
    .featured-quote p { font-size: 0.95rem; }
    .featured-image-badge { padding: 10px 18px; font-size: 12px; top: 16px; right: 16px; }

    /* Process Section Responsive */
    .process-timeline {
        gap: 30px; /* Reduced gap for smaller screens */
    }
    .process-step {
        padding: 0 20px; /* Add some horizontal padding */
        text-align: left; /* Align text to left for better readability */
    }
    .process-step:nth-child(even) { /* Alternate alignment for visual balance */
        text-align: right;
    }
    .process-step .step-number {
        margin-left: 0; /* Adjust positioning */
        margin-right: auto;
    }
    .process-step:nth-child(even) .step-number {
        margin-left: auto;
        margin-right: 0;
    }
    .process-timeline::before { /* Adjust vertical line for new layout */
        left: 50%;
        transform: translateX(-50%);
    }

    /* Hide decorative elements on mobile */
    .deco-circle,
    .deco-line,
    .deco-square,
    .deco-triangle,
    .deco-sparkle { display: none; }

    /* Smaller section dividers */
    .section-divider { height: 50px; }
    .section-divider.diamond .divider-icon { width: 35px; height: 35px; }
    .section-divider.wave { height: 60px; }

    /* Smaller process steps */
    .step-number { width: 70px; height: 70px; }
    .step-number span { font-size: 26px; }
    .step-number::before { inset: -8px; }
    .step-icon { width: 32px; height: 32px; top: -8px; right: -8px; }
    .step-icon svg { width: 14px; height: 14px; }

    /* CTA decorations */
    .cta-decoration { display: none; }
}

@media (max-width: 480px) {
    .hero-badge { padding: 10px 20px; }
    .btn-primary, .btn-secondary { padding: 16px 32px; font-size: 15px; }
    .stat-card { padding: 32px 24px; }
    .service-card { padding: 32px 24px; }
}
</style>

<!-- ══════════════════════════════════════════════════════════════════════════════
     HERO SECTION
     ══════════════════════════════════════════════════════════════════════════════ -->
<section class="hero" aria-label="بخش اصلی معرفی طراحان باستان">
    <div class="hero-decoration-wrapper" aria-hidden="true">
        <div class="hero-blueprint-layer"></div>
        <div class="hero-wireframe-layer">
            <div class="wireframe-sphere wireframe-sphere-1">
                <div class="ring ring-1"></div>
                <div class="ring ring-2"></div>
                <div class="ring ring-3"></div>
                <div class="ring ring-4"></div>
                <div class="ring ring-5"></div>
            </div>
            <div class="wireframe-sphere wireframe-sphere-2">
                <div class="ring ring-1"></div>
                <div class="ring ring-2"></div>
                <div class="ring ring-3"></div>
                <div class="ring ring-4"></div>
                <div class="ring ring-5"></div>
            </div>
        </div>
    </div>
    <div class="hero-content">
        <div class="hero-badge">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
                <path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z"/>
            </svg>
            <span><?= $data['hero']['badge'] ?? 'بیش از ۱۰ سال تجربه در همدان' ?></span>
        </div>

        <h1 class="hero-title">
            <span class="line1" data-text="<?= $data['hero']['title_line1'] ?? 'وقتی پروژه شما' ?>"><?= $data['hero']['title_line1'] ?? 'وقتی پروژه شما' ?></span>
            <span class="line2"><?= $data['hero']['title_line2'] ?? 'چالش‌برانگیز است' ?></span>
        </h1>

        <div class="hero-subtitle-wrapper">
            <span class="hero-subtitle"><?= $data['hero']['subtitle'] ?? 'ما کنار شما می‌ایستیم' ?></span>
        </div>

        <p class="hero-description">
            <?= $data['hero']['description'] ?? 'از ایده تا اجرا، طراحان باستان همه چیز را برای موفقیت پروژه‌های تبلیغاتی و رویدادی شما انجام می‌دهد. چون برای ما، غیرممکن وجود نداره.' ?>
        </p>

        <div class="hero-buttons">
            <a href="<?= URL ?>contact" class="btn-primary">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
                    <path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07 19.5 19.5 0 01-6-6 19.79 19.79 0 01-3.07-8.67A2 2 0 014.11 2h3a2 2 0 012 1.72 12.84 12.84 0 00.7 2.81 2 2 0 01-.45 2.11L8.09 9.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45 12.84 12.84 0 002.81.7A2 2 0 0122 16.92z"/>
                </svg>
                <span>با ما تماس بگیرید</span>
            </a>
            <a href="#services" class="btn-secondary">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
                    <path d="M6 9l6 6 6-6"/>
                </svg>
                <span>خدمات ما را ببینید</span>
            </a>
        </div>
    </div>

    <div class="scroll-indicator" aria-hidden="true">
        <span>اسکرول کنید</span>
        <div class="scroll-arrow"></div>
    </div>
</section>

<!-- ══════════════════════════════════════════════════════════════════════════════
     STATS SECTION
     ══════════════════════════════════════════════════════════════════════════════ -->
<!-- Divider: Hero to Stats -->
<div class="section-divider dots" style="background: var(--bg-section-cream);">
    <div class="dot-group">
        <span></span>
        <span></span>
        <span></span>
    </div>
</div>

<section class="stats-section" aria-labelledby="stats-heading">
    <div class="stats-container">
        <!-- Section Header -->
        <div class="stats-header fade-in">
            <div class="section-eyebrow">
                <span class="eyebrow-line"></span>
                <span class="eyebrow-text">دستاوردها</span>
                <span class="eyebrow-line"></span>
            </div>
            <h2 class="section-title" id="stats-heading">
                اعداد که <span class="title-highlight">حرف می‌زنند</span>
            </h2>
            <p class="section-subtitle">
                بیش از یک دهه تلاش بی‌وقفه برای خلق بهترین‌ها
            </p>
        </div>

        <!-- Stats Grid -->
        <div class="stats-grid">
            <?php if (!empty($data['stats'])): foreach ($data['stats'] as $stat): ?>
            <div class="stat-card fade-in">
                <div class="stat-icon">
                    <div class="icon-inner">
                        <?= getIconSvg($stat['icon'] ?? 'star') ?>
                    </div>
                </div>
                <div class="stat-number">
                    <?php if (!empty($stat['prefix'])): ?><span class="suffix"><?= $stat['prefix'] ?></span><?php endif; ?>
                    <span class="counter" data-target="<?= is_numeric($stat['stat_value']) ? $stat['stat_value'] : '0' ?>">0</span>
                    <?php if (!empty($stat['suffix'])): ?><span class="suffix"><?= $stat['suffix'] ?></span><?php endif; ?>
                </div>
                <div class="stat-label"><?= $stat['stat_label'] ?? '' ?></div>
            </div>
            <?php endforeach; endif; ?>
        </div>
    </div>
</section>

<!-- Divider: Stats to Services -->
<div class="section-divider diamond" style="background: var(--bg-section-warm);">
    <div class="divider-icon"></div>
</div>

<!-- ══════════════════════════════════════════════════════════════════════════════
     SERVICES SECTION
     ══════════════════════════════════════════════════════════════════════════════ -->
<section class="services-section" id="services" aria-labelledby="services-heading">
    <div class="services-container">
        <div class="section-header fade-in">
            <div class="section-tag">
                <span>خدمات ما</span>
            </div>
            <h2 class="section-title" id="services-heading">
                خدماتی که شما را<br>
                <span class="highlight">به موفقیت می‌رساند</span>
            </h2>
            <p class="section-description">
                از ایده تا اجرا، همه چیز زیر یک سقف
            </p>
        </div>

        <div class="services-grid">
            <?php if (!empty($data['services'])): foreach ($data['services'] as $service): ?>
            <a href="<?= URL ?>service/<?= htmlspecialchars($service['slug'] ?? '', ENT_QUOTES, 'UTF-8') ?>" class="service-card fade-in">
                <div class="card-frame" aria-hidden="true"></div>
                <div class="card-badge" aria-hidden="true"></div>
                <div class="service-icon" aria-hidden="true">
                    <?= getIconSvg($service['icon'] ?? 'star') ?>
                </div>
                <h3><?= htmlspecialchars($service['title'] ?? '', ENT_QUOTES, 'UTF-8') ?></h3>
                <p><?= htmlspecialchars($service['short_description'] ?? '', ENT_QUOTES, 'UTF-8') ?></p>
            </a>
            <?php endforeach; endif; ?>
        </div>
    </div>
</section>

<!-- Divider: Services to Featured -->
<div class="section-divider ornament" style="background: var(--bg-section-rich);"></div>

<!-- ══════════════════════════════════════════════════════════════════════════════
     FEATURED PROJECT SECTION - Premium Showcase
     ══════════════════════════════════════════════════════════════════════════════ -->
<section class="featured-section" aria-labelledby="featured-heading">
    <div class="featured-container">
        <!-- Premium Section Header -->
        <div class="section-header fade-in">
            <div class="section-tag">
                <span>دستاورد ویژه</span>
            </div>
        </div>

        <div class="featured-wrapper">
            <!-- Content Card -->
            <div class="featured-content fade-in">
                <span class="featured-tag">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16" aria-hidden="true">
                        <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>
                    </svg>
                    پروژه ملی
                </span>
                <h2 class="featured-title" id="featured-heading">همایش بین‌المللی همدان 2018<br>پایتخت تاریخی خاورمیانه</h2>
                <p class="featured-description">
                    زمانی که تنها 45 روز فرصت بود و سه پیمانکار قبلی گفته بودند "غیرممکن است"،
                    طراحان باستان پذیرفت. نتیجه؟ برگزاری موفق همایش بین‌المللی با حضور نمایندگان 15 کشور خاورمیانه.
                </p>

                <!-- Achievement Stats Grid -->
                <div class="featured-stats">
                    <div class="featured-stat">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <circle cx="12" cy="8" r="5"/>
                            <path d="M20 21a8 8 0 10-16 0"/>
                            <path d="M12 13v8"/>
                            <path d="M9 18h6"/>
                        </svg>
                        <span>15 کشور<br>شرکت‌کننده</span>
                    </div>
                    <div class="featured-stat">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <circle cx="12" cy="12" r="10"/>
                            <polyline points="12 6 12 12 16 14"/>
                        </svg>
                        <span>فقط 45 روز<br>برای اجرا</span>
                    </div>
                    <div class="featured-stat">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M22 11.08V12a10 10 0 11-5.93-9.14"/>
                            <polyline points="22 4 12 14.01 9 11.01"/>
                        </svg>
                        <span>تحویل<br>بی‌نقص</span>
                    </div>
                </div>
            </div>

            <!-- Image Showcase -->
            <div class="featured-image fade-in">
                <img src="<?= URL ?>public/file/hamayesh.jpg" alt="همایش بین‌المللی همدان 2018 - پروژه ملی طراحان باستان" loading="lazy" onerror="this.style.display='none'">
                <span class="featured-image-badge" aria-hidden="true">پروژه ملی</span>
            </div>

            <!-- Floating Quote Card - MOVED HERE FOR RESPONSIVE FIX -->
            <div class="featured-quote">
                <p>"انگار یک سال آماده‌سازی کردیم. این همراهی تیمی بود که گفت غیرممکن وجود نداره."</p>
                <cite>— مدیر اجرایی همایش</cite>
            </div>
        </div>
    </div>
</section>

<!-- Divider: Featured to Why Us -->
<div class="section-divider dots" style="background: var(--bg-section-cream);">
    <div class="dot-group">
        <span></span>
        <span></span>
        <span></span>
    </div>
</div>

<!-- ══════════════════════════════════════════════════════════════════════════════
     WHY US SECTION
     ══════════════════════════════════════════════════════════════════════════════ -->
<section class="why-section">
    <div class="why-container">
        <div class="section-header fade-in">
            <div class="section-tag">
                <span>مزیت‌های ما</span>
            </div>
            <h2 class="section-title">
                چرا کسب‌وکارهای بزرگ<br>
                <span class="highlight">به ما اعتماد می‌کنند؟</span>
            </h2>
        </div>

        <div class="why-grid">
            <div class="why-card fade-in">
                <span class="card-number">۱</span>
                <div class="why-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
                        <path d="M9 12l2 2 4-4"/>
                    </svg>
                </div>
                <h3>همه چیز زیر یک سقف</h3>
                <p>از ایده اولیه تا اجرای نهایی، دیگر نیازی به هماهنگی با چند پیمانکار ندارید.</p>
            </div>

            <div class="why-card fade-in">
                <span class="card-number">۲</span>
                <div class="why-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>
                    </svg>
                </div>
                <h3>بیش از ۱۰ سال تجربه</h3>
                <p>انجام موفق صدها پروژه چالش‌برانگیز برای سازمان‌ها و برندهای بزرگ.</p>
            </div>

            <div class="why-card fade-in">
                <span class="card-number">۳</span>
                <div class="why-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>
                    </svg>
                </div>
                <h3>پروژه‌های فوری</h3>
                <p>وقتی زمان کم است، ما با شما می‌ایستیم و پروژه را به موقع تحویل می‌دهیم.</p>
            </div>

            <div class="why-card fade-in">
                <span class="card-number">۴</span>
                <div class="why-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M22 11.08V12a10 10 0 11-5.93-9.14"/>
                        <polyline points="22 4 12 14.01 9 11.01"/>
                    </svg>
                </div>
                <h3>کیفیت تضمین‌شده</h3>
                <p>استفاده از بهترین مواد و تکنولوژی روز دنیا با QC مرحله‌ای.</p>
            </div>
        </div>
    </div>
</section>

<!-- Divider: Why Us to Testimonials -->
<div class="section-divider diamond" style="background: var(--bg-section-warm);">
    <div class="divider-icon"></div>
</div>

<!-- ══════════════════════════════════════════════════════════════════════════════
     TESTIMONIALS SECTION
     ══════════════════════════════════════════════════════════════════════════════ -->
<section class="testimonials-section" aria-labelledby="testimonials-heading">
    <div class="testimonials-container">
        <div class="section-header fade-in">
            <div class="section-tag">
                <span>نظرات مشتریان</span>
            </div>
            <h2 class="section-title" id="testimonials-heading">
                مشتریانی که به ما<br>
                <span class="highlight">اعتماد کرده‌اند</span>
            </h2>
        </div>

        <div class="testimonials-grid">
            <?php if (!empty($data['testimonials'])): foreach ($data['testimonials'] as $testimonial): ?>
            <article class="testimonial-card fade-in">
                <div class="card-accent" aria-hidden="true"></div>
                <blockquote class="testimonial-content">
                    <p><?= htmlspecialchars($testimonial['content'] ?? '', ENT_QUOTES, 'UTF-8') ?></p>
                </blockquote>
                <footer class="testimonial-author">
                    <div class="author-avatar" aria-hidden="true"><?= mb_substr($testimonial['author_name'] ?? '?', 0, 1, 'UTF-8') ?></div>
                    <div class="author-info">
                        <cite><?= htmlspecialchars($testimonial['author_name'] ?? '', ENT_QUOTES, 'UTF-8') ?></cite>
                        <span><?= htmlspecialchars($testimonial['author_position'] ?? '', ENT_QUOTES, 'UTF-8') ?></span>
                    </div>
                </footer>
                <div class="testimonial-rating" aria-label="امتیاز: <?= (int)($testimonial['rating'] ?? 5) ?> از 5">
                    <?php for ($i = 0; $i < ($testimonial['rating'] ?? 5); $i++): ?>
                    <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
                    <?php endfor; ?>
                </div>
            </article>
            <?php endforeach; endif; ?>
        </div>
    </div>
</section>

<!-- ══════════════════════════════════════════════════════════════════════════════
     PROCESS SECTION
     ══════════════════════════════════════════════════════════════════════════════ -->
<section class="process-section">
    <div class="process-container">
        <div class="section-header fade-in">
            <div class="section-tag">
                <span>فرآیند کار</span>
            </div>
            <h2 class="section-title">
                از اولین تماس<br>
                <span class="highlight">تا تحویل پروژه</span>
            </h2>
        </div>

        <div class="process-timeline">
            <?php
            $persianNumbers = ['۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹', '۱۰'];
            if (!empty($data['process'])):
                foreach ($data['process'] as $index => $step):
            ?>
            <div class="process-step fade-in">
                <div class="step-number">
                    <span><?= $persianNumbers[$index] ?? ($index + 1) ?></span>
                    <div class="step-icon">
                        <?= getIconSvg($step['icon'] ?? 'check') ?>
                    </div>
                </div>
                <div class="step-content">
                    <h3><?= $step['title'] ?? '' ?></h3>
                    <p><?= $step['description'] ?? '' ?></p>
                </div>
            </div>
            <?php endforeach; endif; ?>
        </div>
    </div>
</section>

<!-- Divider: Process to Location -->
<div class="section-divider ornament" style="background: var(--bg-section-cream);"></div>

<!-- ══════════════════════════════════════════════════════════════════════════════
     LOCATION SECTION
     ══════════════════════════════════════════════════════════════════════════════ -->
<section class="location-section">
    <div class="location-container">
        <div class="section-header fade-in">
            <div class="section-tag">
                <span>موقعیت ما</span>
            </div>
            <h2 class="section-title">
                در همدان<br>
                <span class="highlight">در خدمت شما</span>
            </h2>
        </div>

        <div class="location-wrapper">
            <div class="location-map fade-in">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3281.8988888888888!2d48.5145!3d34.7992!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMzTCsDQ3JzU3LjEiTiA0OMKwMzAnNTIuMiJF!5e0!3m2!1sfa!2sir!4v1234567890" allowfullscreen="" loading="lazy"></iframe>
            </div>

            <div class="location-info">
                <div class="info-card fade-in">
                    <div class="info-icon">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/>
                            <circle cx="12" cy="10" r="3"/>
                        </svg>
                    </div>
                    <div class="info-content">
                        <h4>آدرس</h4>
                        <p>همدان، خیابان اصلی، پلاک ۱۲۳<br>کدپستی: ۱۲۳۴۵۶۷۸۹۰</p>
                    </div>
                </div>

                <div class="info-card fade-in">
                    <div class="info-icon">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07 19.5 19.5 0 01-6-6 19.79 19.79 0 01-3.07-8.67A2 2 0 014.11 2h3a2 2 0 012 1.72c.127.96.361 1.903.7 2.81a2 2 0 01-.45 2.11L8.09 9.91"/>
                        </svg>
                    </div>
                    <div class="info-content">
                        <h4>تلفن</h4>
                        <p style="direction: ltr; text-align: right;">0912 345 6789<br>081 1234 5678</p>
                    </div>
                </div>

                <div class="info-card fade-in">
                    <div class="info-icon">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <circle cx="12" cy="12" r="10"/>
                            <polyline points="12 6 12 12 16 14"/>
                        </svg>
                    </div>
                    <div class="info-content">
                        <h4>ساعات کاری</h4>
                        <p>شنبه تا پنجشنبه<br>۸ صبح تا ۶ عصر</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ══════════════════════════════════════════════════════════════════════════════
     CTA SECTION
     ══════════════════════════════════════════════════════════════════════════════ -->
<section class="cta-section">
    <!-- Decorative elements -->
    <div class="cta-decoration">
        <div class="shape-1"></div>
        <div class="shape-2"></div>
        <div class="sparkle sparkle-1"></div>
        <div class="sparkle sparkle-2"></div>
    </div>

    <div class="cta-container">
        <h2 class="cta-title fade-in"><?= $data['cta']['title'] ?? 'آماده برای شروع<br>پروژه موفق بعدی؟' ?></h2>
        <p class="cta-subtitle fade-in"><?= $data['cta']['subtitle'] ?? 'فقط یک تماس تا موفقیت فاصله دارید' ?></p>

        <div class="cta-buttons fade-in">
            <a href="tel:<?= $data['cta']['phone'] ?? '+989183333368' ?>" class="cta-btn-primary">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07 19.5 19.5 0 01-6-6 19.79 19.79 0 01-3.07-8.67A2 2 0 014.11 2h3a2 2 0 012 1.72c.127.96.361 1.903.7 2.81a2 2 0 01-.45 2.11L8.09 9.91"/>
                </svg>
                <?= $data['cta']['button_text'] ?? 'همین حالا تماس بگیرید' ?>
            </a>
            <a href="<?= URL ?>about" class="cta-btn-secondary">
                <?= $data['cta']['secondary_button_text'] ?? 'مشاهده نمونه کارها' ?>
            </a>
        </div>
    </div>
</section>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Initialize WOW.js for scroll animations
    if (typeof WOW !== 'undefined') {
        new WOW({
            boxClass: 'wow',
            animateClass: 'animate__animated',
            offset: 100,
            mobile: true,
            live: true
        }).init();
    }

    // Enhanced Intersection Observer for fade-in animations
    const observerOptions = {
        threshold: 0.15,
        rootMargin: '0px 0px -80px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach((entry, index) => {
            if (entry.isIntersecting) {
                // Staggered animation delay
                setTimeout(() => {
                    entry.target.classList.add('visible');
                }, index * 100);
            }
        });
    }, observerOptions);

    document.querySelectorAll('.fade-in').forEach(el => {
        observer.observe(el);
    });

    // Parallax effect for decorative elements
    window.addEventListener('scroll', () => {
        const scrolled = window.pageYOffset;
        const parallaxElements = document.querySelectorAll('.deco-circle, .deco-square');

        parallaxElements.forEach((el, index) => {
            const speed = 0.05 + (index * 0.01);
            const yPos = -(scrolled * speed);
            el.style.transform = `translateY(${yPos}px)`;
        });
    }, { passive: true });

    // Smooth scroll for anchor links with offset
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                const headerOffset = 100;
                const elementPosition = target.getBoundingClientRect().top;
                const offsetPosition = elementPosition + window.pageYOffset - headerOffset;

                window.scrollTo({
                    top: offsetPosition,
                    behavior: 'smooth'
                });
            }
        });
    });

    // Counter animation for stats - English Numbers with Animation
    const animateCounters = () => {
        document.querySelectorAll('.counter').forEach(counter => {
            // Skip if already animated
            if (counter.dataset.animated === 'true') return;

            const rect = counter.getBoundingClientRect();
            if (rect.top < window.innerHeight && rect.bottom > 0) {
                counter.dataset.animated = 'true';

                const target = parseInt(counter.dataset.target) || 0;

                // Skip if target is 0 or invalid
                if (target <= 0) {
                    counter.textContent = '0';
                    return;
                }

                const duration = 2000; // 2 seconds
                const steps = 60;
                const stepDuration = duration / steps;
                let current = 0;
                const increment = target / steps;

                const updateCounter = () => {
                    current += increment;
                    if (current < target) {
                        counter.textContent = Math.floor(current);
                        setTimeout(updateCounter, stepDuration);
                    } else {
                        counter.textContent = target;
                    }
                };

                // Add entrance animation
                counter.style.opacity = '0';
                counter.style.transform = 'scale(0.5)';

                setTimeout(() => {
                    counter.style.transition = 'all 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275)';
                    counter.style.opacity = '1';
                    counter.style.transform = 'scale(1)';
                    updateCounter();
                }, 200);
            }
        });
    };

    window.addEventListener('scroll', animateCounters, { passive: true });
    animateCounters(); // Initial check

    // Add subtle hover sound effect (optional - commented out)
    // const cards = document.querySelectorAll('.service-card, .stat-card, .why-card');
    // cards.forEach(card => {
    //     card.addEventListener('mouseenter', () => {
    //         // Subtle haptic feedback simulation
    //         card.style.willChange = 'transform';
    //     });
    // });
});
</script>
