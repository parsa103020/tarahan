<?php
$active = 'messages';
ob_start();
?>

<div class="d-flex justify-between align-center mb-3">
    <a href="<?php echo URL; ?>admin/messages" class="btn btn-outline">
        <svg viewBox="0 0 24 24" width="18" height="18"><path fill="currentColor" d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z"/></svg>
        بازگشت به لیست
    </a>
    <button type="button" class="btn btn-danger" onclick="deleteMessage(<?php echo $message['id']; ?>)">
        <svg viewBox="0 0 24 24" width="18" height="18"><path fill="currentColor" d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg>
        حذف پیام
    </button>
</div>

<div class="card">
    <div class="card-header">
        <h3 class="card-title">
            <svg viewBox="0 0 24 24"><path fill="currentColor" d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2z"/></svg>
            جزئیات پیام
        </h3>
        <span style="padding: 0.25rem 0.75rem; background: rgba(40,167,69,0.1); color: var(--success); border-radius: 20px; font-size: 0.8rem;">
            <?php echo date('Y/m/d H:i', strtotime($message['created_at'])); ?>
        </span>
    </div>

    <div class="row">
        <div class="col-6">
            <div class="form-group">
                <label class="form-label">نام فرستنده</label>
                <div style="padding: 0.875rem 1rem; background: var(--bg-light); border-radius: 8px; font-weight: 600;">
                    <?php echo htmlspecialchars($message['name']); ?>
                </div>
            </div>
        </div>
        <div class="col-6">
            <div class="form-group">
                <label class="form-label">شماره تماس</label>
                <div style="padding: 0.875rem 1rem; background: var(--bg-light); border-radius: 8px; direction: ltr; text-align: right;">
                    <a href="tel:<?php echo $message['phone']; ?>" style="color: var(--secondary); text-decoration: none;">
                        <?php echo htmlspecialchars($message['phone']); ?>
                    </a>
                </div>
            </div>
        </div>
        <?php if (!empty($message['email'])): ?>
            <div class="col-6">
                <div class="form-group">
                    <label class="form-label">ایمیل</label>
                    <div style="padding: 0.875rem 1rem; background: var(--bg-light); border-radius: 8px; direction: ltr; text-align: right;">
                        <a href="mailto:<?php echo $message['email']; ?>" style="color: var(--secondary); text-decoration: none;">
                            <?php echo htmlspecialchars($message['email']); ?>
                        </a>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        <?php if (!empty($message['subject'])): ?>
            <div class="col-6">
                <div class="form-group">
                    <label class="form-label">موضوع</label>
                    <div style="padding: 0.875rem 1rem; background: var(--bg-light); border-radius: 8px;">
                        <?php echo htmlspecialchars($message['subject']); ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        <div class="col-12">
            <div class="form-group mb-0">
                <label class="form-label">متن پیام</label>
                <div style="padding: 1.5rem; background: var(--bg-light); border-radius: 8px; line-height: 2; white-space: pre-wrap;">
<?php echo htmlspecialchars($message['message']); ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Quick Actions -->
<div class="card" style="background: linear-gradient(135deg, var(--secondary) 0%, var(--secondary-light) 100%);">
    <div class="d-flex justify-between align-center">
        <div>
            <h3 style="color: var(--primary); margin-bottom: 0.5rem;">پاسخ‌دهی سریع</h3>
            <p style="color: var(--primary); opacity: 0.7; font-size: 0.9rem;">از طریق تماس یا پیامک پاسخ دهید</p>
        </div>
        <div style="display: flex; gap: 0.75rem;">
            <a href="tel:<?php echo $message['phone']; ?>" class="btn btn-primary">
                <svg viewBox="0 0 24 24" width="18" height="18"><path fill="currentColor" d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"/></svg>
                تماس
            </a>
            <a href="https://wa.me/98<?php echo ltrim($message['phone'], '0'); ?>" target="_blank" class="btn btn-success">
                <svg viewBox="0 0 24 24" width="18" height="18"><path fill="currentColor" d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
                واتساپ
            </a>
        </div>
    </div>
</div>

<script>
    function deleteMessage(id) {
        confirmDelete('<?php echo URL; ?>admin/deleteMessage/' + id, () => {
            window.location.href = '<?php echo URL; ?>admin/messages';
        });
    }
</script>

<?php
$content = ob_get_clean();
include dirname(__DIR__) . '/layout.php';
?>
