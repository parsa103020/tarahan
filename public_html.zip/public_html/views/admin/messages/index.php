<?php
$active = 'messages';
$pageTitle = 'پیام‌های دریافتی';
ob_start();

// Extract data
$messages = $data['messages'] ?? [];
?>

<div class="card">
    <div class="card-header">
        <h3 class="card-title">
            <svg viewBox="0 0 24 24"><path fill="currentColor" d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2z"/></svg>
            پیام‌های دریافتی
        </h3>
    </div>
    <p class="form-hint" style="margin-bottom: 1rem;">پیام‌های ارسالی از فرم تماس سایت. پیام‌های جدید با رنگ متفاوت مشخص شده‌اند.</p>

    <?php if (!empty($messages)): ?>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th style="width: 50px;">#</th>
                        <th>نام</th>
                        <th>تلفن</th>
                        <th>موضوع</th>
                        <th>تاریخ</th>
                        <th>وضعیت</th>
                        <th style="width: 150px;">عملیات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($messages as $index => $message): ?>
                        <tr style="<?php echo !$message['is_read'] ? 'background: rgba(201, 160, 102, 0.05);' : ''; ?>">
                            <td><?php echo $index + 1; ?></td>
                            <td>
                                <div style="font-weight: 600;"><?php echo htmlspecialchars($message['name']); ?></div>
                                <?php if (!empty($message['email'])): ?>
                                    <div style="font-size: 0.8rem; color: var(--text-light);"><?php echo htmlspecialchars($message['email']); ?></div>
                                <?php endif; ?>
                            </td>
                            <td style="direction: ltr; text-align: right;"><?php echo htmlspecialchars($message['phone']); ?></td>
                            <td><?php echo htmlspecialchars($message['subject'] ?? '-'); ?></td>
                            <td><?php echo date('Y/m/d H:i', strtotime($message['created_at'])); ?></td>
                            <td>
                                <?php if ($message['is_read']): ?>
                                    <span style="display: inline-flex; align-items: center; gap: 0.25rem; padding: 0.25rem 0.75rem; background: rgba(40,167,69,0.1); color: var(--success); border-radius: 20px; font-size: 0.8rem;">
                                        <svg viewBox="0 0 24 24" width="14" height="14"><path fill="currentColor" d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>
                                        خوانده شده
                                    </span>
                                <?php else: ?>
                                    <span style="display: inline-flex; align-items: center; gap: 0.25rem; padding: 0.25rem 0.75rem; background: rgba(255,193,7,0.1); color: #856404; border-radius: 20px; font-size: 0.8rem; font-weight: 600;">
                                        <svg viewBox="0 0 24 24" width="14" height="14"><path fill="currentColor" d="M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/></svg>
                                        جدید
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="actions">
                                    <a href="<?php echo URL; ?>admin/viewMessage/<?php echo $message['id']; ?>" class="action-btn edit" title="مشاهده">
                                        <svg viewBox="0 0 24 24"><path fill="currentColor" d="M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5zm0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3z"/></svg>
                                    </a>
                                    <button type="button" class="action-btn delete" onclick="deleteMessage(<?php echo $message['id']; ?>)" title="حذف">
                                        <svg viewBox="0 0 24 24"><path fill="currentColor" d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <div class="empty-state">
            <svg viewBox="0 0 24 24">
                <path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2z"/>
            </svg>
            <h4>هنوز پیامی دریافت نشده است</h4>
            <p>پیام‌های ارسالی از فرم تماس سایت در اینجا نمایش داده می‌شوند</p>
        </div>
    <?php endif; ?>
</div>

<script>
    function deleteMessage(id) {
        confirmDelete('<?php echo URL; ?>admin/deleteMessage/' + id, () => {
            location.reload();
        });
    }
</script>

<?php
$content = ob_get_clean();
include dirname(__DIR__) . '/layout.php';
?>
