<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ورود به پنل مدیریت | طراحان باستان</title>

    <!-- YekanBakh Font - All Weights from CDN -->
    <link href="https://db.onlinewebfonts.com/c/7296ae79f6faca68798b00fbbbee4c22?family=YekanBakh-Regular" rel="stylesheet">
    <link href="https://db.onlinewebfonts.com/c/41e49eab42867016423011dccc96c22a?family=YekanBakh-Bold" rel="stylesheet">
    <link href="https://db.onlinewebfonts.com/c/3231c6a7b3ba5a66dd21bfc6b461165e?family=YekanBakh-Heavy" rel="stylesheet">

    <style>
        /* YekanBakh Font Faces */
        @font-face { font-family: 'YekanBakh'; src: url('https://db.onlinewebfonts.com/t/7296ae79f6faca68798b00fbbbee4c22.woff2') format('woff2'); font-weight: 400; font-style: normal; font-display: swap; }
        @font-face { font-family: 'YekanBakh'; src: url('https://db.onlinewebfonts.com/t/41e49eab42867016423011dccc96c22a.woff2') format('woff2'); font-weight: 700; font-style: normal; font-display: swap; }
        @font-face { font-family: 'YekanBakh'; src: url('https://db.onlinewebfonts.com/t/3231c6a7b3ba5a66dd21bfc6b461165e.woff2') format('woff2'); font-weight: 800; font-style: normal; font-display: swap; }
        :root {
            --primary: #2D1810;
            --primary-light: #3d2218;
            --secondary: #C9A066;
            --secondary-light: #d4b07a;
            --cream: #F5E6D3;
            --text-dark: #333;
            --danger: #dc3545;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        *, *::before, *::after {
            font-family: 'YekanBakh', 'Tahoma', sans-serif !important;
        }

        body {
            font-family: 'YekanBakh', 'Tahoma', sans-serif !important;
            min-height: 100vh;
            background: linear-gradient(135deg, var(--primary) 0%, #1a0f0a 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 1rem;
            position: relative;
            overflow: hidden;
        }

        /* Background Pattern */
        body::before {
            content: '';
            position: absolute;
            inset: 0;
            background-image: url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23C9A066' fill-opacity='0.05'%3E%3Ccircle cx='30' cy='30' r='2'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E");
            pointer-events: none;
        }

        /* Animated Orbs */
        .orb {
            position: absolute;
            border-radius: 50%;
            filter: blur(100px);
            pointer-events: none;
        }

        .orb-1 {
            width: 400px;
            height: 400px;
            background: rgba(201, 160, 102, 0.15);
            top: -100px;
            right: -100px;
            animation: float 20s ease-in-out infinite;
        }

        .orb-2 {
            width: 300px;
            height: 300px;
            background: rgba(201, 160, 102, 0.1);
            bottom: -50px;
            left: -50px;
            animation: float 25s ease-in-out infinite reverse;
        }

        @keyframes float {
            0%, 100% { transform: translate(0, 0) scale(1); }
            50% { transform: translate(50px, 50px) scale(1.1); }
        }

        .login-container {
            position: relative;
            z-index: 1;
            width: 100%;
            max-width: 420px;
        }

        .login-card {
            background: rgba(255, 255, 255, 0.98);
            border-radius: 24px;
            box-shadow: 0 25px 80px rgba(0, 0, 0, 0.3);
            overflow: hidden;
        }

        .login-header {
            background: linear-gradient(135deg, var(--primary) 0%, var(--primary-light) 100%);
            padding: 2.5rem;
            text-align: center;
        }

        .login-logo {
            width: 80px;
            height: 80px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 1.5rem;
            backdrop-filter: blur(10px);
        }

        .login-logo svg {
            width: 45px;
            height: 45px;
            fill: var(--secondary);
        }

        .login-title {
            color: var(--cream);
            font-size: 1.5rem;
            font-weight: 800;
            margin-bottom: 0.5rem;
        }

        .login-subtitle {
            color: rgba(255, 255, 255, 0.6);
            font-size: 0.9rem;
        }

        .login-body {
            padding: 2.5rem;
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        .form-label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 600;
            font-size: 0.9rem;
            color: var(--text-dark);
        }

        .input-wrapper {
            position: relative;
        }

        .input-wrapper svg {
            position: absolute;
            right: 1rem;
            top: 50%;
            transform: translateY(-50%);
            width: 20px;
            height: 20px;
            fill: #aaa;
            transition: fill 0.3s ease;
        }

        .form-control {
            width: 100%;
            padding: 1rem 1rem 1rem 3rem;
            border: 2px solid #e0e0e0;
            border-radius: 12px;
            font-family: inherit;
            font-size: 1rem;
            transition: all 0.3s ease;
            background: white;
        }

        .form-control:focus {
            outline: none;
            border-color: var(--secondary);
            box-shadow: 0 0 0 4px rgba(201, 160, 102, 0.1);
        }

        .form-control:focus + svg {
            fill: var(--secondary);
        }

        .form-control::placeholder {
            color: #aaa;
        }

        .password-toggle {
            position: absolute;
            left: 1rem;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            cursor: pointer;
            padding: 0;
        }

        .password-toggle svg {
            position: static;
            transform: none;
            fill: #aaa;
        }

        .password-toggle:hover svg {
            fill: var(--secondary);
        }

        .remember-row {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 1.5rem;
        }

        .remember-check {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            cursor: pointer;
        }

        .remember-check input {
            width: 18px;
            height: 18px;
            accent-color: var(--secondary);
        }

        .remember-check span {
            font-size: 0.9rem;
            color: var(--text-dark);
        }

        .login-hint {
            font-size: 0.8rem;
            color: #888;
            text-align: center;
            margin-bottom: 1.5rem;
        }

        .btn-login {
            width: 100%;
            padding: 1rem;
            background: linear-gradient(135deg, var(--primary) 0%, var(--primary-light) 100%);
            color: white;
            border: none;
            border-radius: 12px;
            font-family: inherit;
            font-size: 1rem;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .btn-login::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
            transition: left 0.5s ease;
        }

        .btn-login:hover::before {
            left: 100%;
        }

        .btn-login:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 30px rgba(45, 24, 16, 0.3);
        }

        .btn-login:active {
            transform: translateY(0);
        }

        .btn-login:disabled {
            opacity: 0.7;
            cursor: not-allowed;
            transform: none;
        }

        .btn-login .spinner {
            display: none;
            width: 20px;
            height: 20px;
            border: 2px solid rgba(255,255,255,0.3);
            border-top-color: white;
            border-radius: 50%;
            animation: spin 0.8s linear infinite;
            margin-left: 0.5rem;
        }

        .btn-login.loading .spinner {
            display: inline-block;
        }

        .btn-login.loading .btn-text {
            opacity: 0.7;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }

        .login-footer {
            text-align: center;
            padding: 0 2.5rem 2rem;
        }

        .back-link {
            color: var(--secondary);
            text-decoration: none;
            font-size: 0.9rem;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            transition: color 0.3s ease;
        }

        .back-link:hover {
            color: var(--primary);
        }

        .back-link svg {
            width: 18px;
            height: 18px;
            fill: currentColor;
        }

        .error-message {
            background: rgba(220, 53, 69, 0.1);
            color: var(--danger);
            padding: 1rem;
            border-radius: 10px;
            margin-bottom: 1.5rem;
            font-size: 0.9rem;
            display: none;
            align-items: center;
            gap: 0.5rem;
        }

        .error-message.show {
            display: flex;
        }

        .error-message svg {
            width: 20px;
            height: 20px;
            fill: currentColor;
            flex-shrink: 0;
        }

        /* Responsive */
        @media (max-width: 480px) {
            .login-header {
                padding: 2rem 1.5rem;
            }

            .login-body {
                padding: 1.5rem;
            }

            .login-footer {
                padding: 0 1.5rem 1.5rem;
            }
        }
    </style>
</head>
<body>
    <div class="orb orb-1"></div>
    <div class="orb orb-2"></div>

    <div class="login-container">
        <div class="login-card">
            <div class="login-header">
                <div class="login-logo">
                    <svg viewBox="0 0 24 24">
                        <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/>
                    </svg>
                </div>
                <h1 class="login-title">طراحان باستان</h1>
                <p class="login-subtitle">پنل مدیریت</p>
            </div>

            <div class="login-body">
                <div class="error-message" id="errorMessage">
                    <svg viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/></svg>
                    <span id="errorText"></span>
                </div>

                <?php
                    // Generate CSRF token
                    if (!isset($_SESSION['csrf_token'])) {
                        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
                    }
                    ?>
                <form id="loginForm">
                    <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                    <div class="form-group">
                        <label class="form-label" for="username">نام کاربری</label>
                        <div class="input-wrapper">
                            <input type="text" class="form-control" id="username" name="username" placeholder="نام کاربری خود را وارد کنید" required autofocus>
                            <svg viewBox="0 0 24 24"><path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/></svg>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="password">رمز عبور</label>
                        <div class="input-wrapper">
                            <input type="password" class="form-control" id="password" name="password" placeholder="رمز عبور خود را وارد کنید" required>
                            <svg viewBox="0 0 24 24"><path d="M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zm-6 9c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm3.1-9H8.9V6c0-1.71 1.39-3.1 3.1-3.1 1.71 0 3.1 1.39 3.1 3.1v2z"/></svg>
                            <button type="button" class="password-toggle" id="passwordToggle">
                                <svg viewBox="0 0 24 24" id="eyeIcon"><path d="M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5zm0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3z"/></svg>
                            </button>
                        </div>
                    </div>

                    <div class="remember-row">
                        <label class="remember-check">
                            <input type="checkbox" name="remember">
                            <span>مرا به خاطر بسپار</span>
                        </label>
                    </div>
                    <p class="login-hint">رمز عبور را فراموش کرده‌اید؟ با مدیر سیستم تماس بگیرید.</p>

                    <button type="submit" class="btn-login" id="loginBtn">
                        <span class="btn-text">ورود به پنل</span>
                        <span class="spinner"></span>
                    </button>
                </form>
            </div>

            <div class="login-footer">
                <a href="<?php echo URL; ?>" class="back-link">
                    <svg viewBox="0 0 24 24"><path d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z"/></svg>
                    بازگشت به سایت
                </a>
            </div>
        </div>
    </div>

    <script>
        const loginForm = document.getElementById('loginForm');
        const loginBtn = document.getElementById('loginBtn');
        const errorMessage = document.getElementById('errorMessage');
        const errorText = document.getElementById('errorText');
        const passwordInput = document.getElementById('password');
        const passwordToggle = document.getElementById('passwordToggle');
        const eyeIcon = document.getElementById('eyeIcon');

        // Toggle Password Visibility
        passwordToggle.addEventListener('click', () => {
            const isPassword = passwordInput.type === 'password';
            passwordInput.type = isPassword ? 'text' : 'password';
            eyeIcon.innerHTML = isPassword
                ? '<path d="M12 7c2.76 0 5 2.24 5 5 0 .65-.13 1.26-.36 1.83l2.92 2.92c1.51-1.26 2.7-2.89 3.43-4.75-1.73-4.39-6-7.5-11-7.5-1.4 0-2.74.25-3.98.7l2.16 2.16C10.74 7.13 11.35 7 12 7zM2 4.27l2.28 2.28.46.46C3.08 8.3 1.78 10.02 1 12c1.73 4.39 6 7.5 11 7.5 1.55 0 3.03-.3 4.38-.84l.42.42L19.73 22 21 20.73 3.27 3 2 4.27zM7.53 9.8l1.55 1.55c-.05.21-.08.43-.08.65 0 1.66 1.34 3 3 3 .22 0 .44-.03.65-.08l1.55 1.55c-.67.33-1.41.53-2.2.53-2.76 0-5-2.24-5-5 0-.79.2-1.53.53-2.2zm4.31-.78l3.15 3.15.02-.16c0-1.66-1.34-3-3-3l-.17.01z"/>'
                : '<path d="M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5zm0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3z"/>';
        });

        // Form Submit
        loginForm.addEventListener('submit', async (e) => {
            e.preventDefault();

            // Hide error
            errorMessage.classList.remove('show');

            // Show loading
            loginBtn.classList.add('loading');
            loginBtn.disabled = true;

            try {
                const formData = new FormData(loginForm);
                const response = await fetch('<?php echo URL; ?>admin/doLogin', {
                    method: 'POST',
                    body: formData
                });
                const result = await response.json();

                if (result.success) {
                    window.location.href = result.redirect;
                } else {
                    errorText.textContent = result.message || 'نام کاربری یا رمز عبور اشتباه است';
                    errorMessage.classList.add('show');
                    loginBtn.classList.remove('loading');
                    loginBtn.disabled = false;
                }
            } catch (error) {
                errorText.textContent = 'خطا در ارتباط با سرور';
                errorMessage.classList.add('show');
                loginBtn.classList.remove('loading');
                loginBtn.disabled = false;
            }
        });
    </script>
</body>
</html>
