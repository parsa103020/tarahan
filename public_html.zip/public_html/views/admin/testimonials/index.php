<?php
$active = 'testimonials';
$pageTitle = 'مدیریت نظرات مشتریان';
ob_start();

// Extract data
$testimonials = $data['testimonials'] ?? [];
?>

<div class="card">
    <div class="card-header">
        <h3 class="card-title">
            <svg viewBox="0 0 24 24"><path fill="currentColor" d="M6 17c0-2 4-3.1 6-3.1s6 1.1 6 3.1v1H6v-1zM12 12c-1.7 0-3-1.3-3-3s1.3-3 3-3 3 1.3 3 3-1.3 3-3 3z"/></svg>
            نظرات مشتریان
        </h3>
        <button type="button" class="btn btn-sm btn-secondary" onclick="openAddModal()">
            <svg viewBox="0 0 24 24" width="16" height="16"><path fill="currentColor" d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/></svg>
            افزودن نظر
        </button>
    </div>
    <p class="form-hint" style="margin-bottom: 1rem;">نظرات مشتریان راضی که در صفحه اصلی نمایش داده می‌شوند. نظرات واقعی به اعتمادسازی کمک می‌کنند.</p>

    <?php if (!empty($testimonials)): ?>
        <div class="testimonials-grid">
            <?php foreach ($testimonials as $testimonial): ?>
                <div class="item-card testimonial-item">
                    <div class="item-actions">
                        <button type="button" class="action-btn edit" onclick='editTestimonial(<?php echo json_encode($testimonial, JSON_HEX_APOS | JSON_HEX_QUOT); ?>)' title="ویرایش این نظر">
                            <svg viewBox="0 0 24 24"><path fill="currentColor" d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/></svg>
                        </button>
                        <button type="button" class="action-btn delete" onclick="deleteTestimonial(<?php echo $testimonial['id']; ?>)" title="حذف این نظر">
                            <svg viewBox="0 0 24 24"><path fill="currentColor" d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg>
                        </button>
                    </div>

                    <div class="testimonial-quote">"</div>
                    <p class="testimonial-content"><?php echo htmlspecialchars($testimonial['content']); ?></p>
                    <div class="testimonial-author">
                        <div class="author-avatar">
                            <?php echo mb_substr($testimonial['author_name'], 0, 1, 'UTF-8'); ?>
                        </div>
                        <div class="author-info">
                            <div class="author-name"><?php echo htmlspecialchars($testimonial['author_name']); ?></div>
                            <div class="author-position"><?php echo htmlspecialchars($testimonial['author_position'] ?? ''); ?></div>
                        </div>
                        <div class="testimonial-rating">
                            <?php for ($i = 0; $i < ($testimonial['rating'] ?? 5); $i++): ?>
                                <svg viewBox="0 0 24 24" width="16" height="16"><path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/></svg>
                            <?php endfor; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div class="empty-state">
            <svg viewBox="0 0 24 24">
                <path d="M6 17c0-2 4-3.1 6-3.1s6 1.1 6 3.1v1H6v-1zM12 12c-1.7 0-3-1.3-3-3s1.3-3 3-3 3 1.3 3 3-1.3 3-3 3z"/>
            </svg>
            <h4>نظری ثبت نشده است</h4>
            <p>نظرات مشتریان راضی را اضافه کنید تا در صفحه اصلی نمایش داده شوند</p>
            <button type="button" class="btn btn-primary mt-2" onclick="openAddModal()">
                <svg viewBox="0 0 24 24" width="18" height="18"><path fill="currentColor" d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/></svg>
                افزودن اولین نظر
            </button>
        </div>
    <?php endif; ?>
</div>

<style>
.testimonials-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
    gap: 1.5rem;
}

.testimonial-item {
    padding-left: 4rem;
}

.testimonial-quote {
    font-size: 2.5rem;
    color: var(--secondary);
    line-height: 1;
    margin-bottom: 0.5rem;
}

.testimonial-content {
    color: var(--text-primary);
    line-height: 1.8;
    margin-bottom: 1.5rem;
}

.testimonial-author {
    display: flex;
    align-items: center;
    gap: 1rem;
}

.author-avatar {
    width: 50px;
    height: 50px;
    background: linear-gradient(135deg, var(--primary), #60a5fa);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-weight: 700;
    font-size: 1.25rem;
}

.author-info {
    flex: 1;
}

.author-name {
    font-weight: 700;
    color: var(--text-primary);
}

.author-position {
    font-size: 0.85rem;
    color: var(--text-muted);
}

.testimonial-rating {
    display: flex;
    gap: 0.25rem;
}

.testimonial-rating svg {
    fill: var(--secondary);
}
</style>

<!-- Add/Edit Modal -->
<div class="modal-overlay" id="addTestimonialModal">
    <div class="modal">
        <div class="modal-header">
            <h3 class="modal-title" id="testimonialModalTitle">افزودن نظر جدید</h3>
            <button type="button" class="modal-close" onclick="closeModal('addTestimonialModal')">
                <svg viewBox="0 0 24 24"><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg>
            </button>
        </div>
        <form id="testimonialForm">
            <div class="modal-body">
                <input type="hidden" name="id" id="testimonial_id">
                <input type="hidden" name="page" value="home">

                <div class="form-group">
                    <label class="form-label">متن نظر مشتری *</label>
                    <textarea class="form-control" name="content" id="testimonial_content" rows="4" placeholder="تجربه کار با طراحان باستان فوق‌العاده بود..." required></textarea>
                    <span class="form-hint">نظر واقعی مشتری درباره خدمات شرکت</span>
                </div>
                <div class="row">
                    <div class="col-6">
                        <div class="form-group">
                            <label class="form-label">نام مشتری *</label>
                            <input type="text" class="form-control" name="author_name" id="testimonial_author_name" placeholder="علی محمدی" required>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group">
                            <label class="form-label">سمت / شرکت</label>
                            <input type="text" class="form-control" name="author_position" id="testimonial_author_position" placeholder="مدیرعامل شرکت ABC">
                            <span class="form-hint">اختیاری</span>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <label class="form-label">امتیاز</label>
                    <select class="form-control" name="rating" id="testimonial_rating">
                        <option value="5">۵ ستاره - عالی</option>
                        <option value="4">۴ ستاره - خوب</option>
                        <option value="3">۳ ستاره - متوسط</option>
                        <option value="2">۲ ستاره - ضعیف</option>
                        <option value="1">۱ ستاره - بد</option>
                    </select>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline" onclick="closeModal('addTestimonialModal')">انصراف</button>
                <button type="submit" class="btn btn-primary">
                    <svg viewBox="0 0 24 24" width="18" height="18"><path fill="currentColor" d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>
                    ذخیره نظر
                </button>
            </div>
        </form>
    </div>
</div>

<script>
    function openAddModal() {
        document.getElementById('testimonialModalTitle').textContent = 'افزودن نظر جدید';
        document.getElementById('testimonialForm').reset();
        document.getElementById('testimonial_id').value = '';
        openModal('addTestimonialModal');
    }

    function editTestimonial(testimonial) {
        document.getElementById('testimonialModalTitle').textContent = 'ویرایش نظر';
        document.getElementById('testimonial_id').value = testimonial.id;
        document.getElementById('testimonial_content').value = testimonial.content;
        document.getElementById('testimonial_author_name').value = testimonial.author_name;
        document.getElementById('testimonial_author_position').value = testimonial.author_position || '';
        document.getElementById('testimonial_rating').value = testimonial.rating || 5;
        openModal('addTestimonialModal');
    }

    function deleteTestimonial(id) {
        confirmDelete('<?php echo URL; ?>admin/deleteTestimonial/' + id, () => {
            location.reload();
        });
    }

    document.getElementById('testimonialForm').addEventListener('submit', async function(e) {
        e.preventDefault();
        showLoading();

        try {
            const formData = new FormData(this);
            const response = await fetch('<?php echo URL; ?>admin/saveTestimonial', {
                method: 'POST',
                body: formData
            });
            const result = await response.json();

            hideLoading();

            if (result.success) {
                showToast('نظر با موفقیت ذخیره شد', 'success');
                setTimeout(() => location.reload(), 1000);
            } else {
                showToast('خطا در ذخیره', 'error');
            }
        } catch (error) {
            hideLoading();
            showToast('خطا در ارتباط با سرور', 'error');
        }
    });
</script>

<?php
$content = ob_get_clean();
include dirname(__DIR__) . '/layout.php';
?>
