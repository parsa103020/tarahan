<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($pageTitle) ? $pageTitle . ' | ' : ''; ?>پنل مدیریت طراحان باستان</title>

    <!-- YekanBakh Font - All Weights from CDN -->
    <link href="https://db.onlinewebfonts.com/c/7296ae79f6faca68798b00fbbbee4c22?family=YekanBakh-Regular" rel="stylesheet">
    <link href="https://db.onlinewebfonts.com/c/41e49eab42867016423011dccc96c22a?family=YekanBakh-Bold" rel="stylesheet">
    <link href="https://db.onlinewebfonts.com/c/3231c6a7b3ba5a66dd21bfc6b461165e?family=YekanBakh-Heavy" rel="stylesheet">
    <link href="https://db.onlinewebfonts.com/c/e1d06869ee86ac98052a5a1788122235?family=YekanBakh-Fat" rel="stylesheet">

    <style>
        /* YekanBakh Font Faces */
        @font-face { font-family: 'YekanBakh'; src: url('https://db.onlinewebfonts.com/t/7296ae79f6faca68798b00fbbbee4c22.woff2') format('woff2'); font-weight: 400; font-style: normal; font-display: swap; }
        @font-face { font-family: 'YekanBakh'; src: url('https://db.onlinewebfonts.com/t/41e49eab42867016423011dccc96c22a.woff2') format('woff2'); font-weight: 700; font-style: normal; font-display: swap; }
        @font-face { font-family: 'YekanBakh'; src: url('https://db.onlinewebfonts.com/t/3231c6a7b3ba5a66dd21bfc6b461165e.woff2') format('woff2'); font-weight: 800; font-style: normal; font-display: swap; }
        @font-face { font-family: 'YekanBakh'; src: url('https://db.onlinewebfonts.com/t/e1d06869ee86ac98052a5a1788122235.woff2') format('woff2'); font-weight: 900; font-style: normal; font-display: swap; }
        :root {
            /* Elegant Purple-Indigo Theme */
            --sidebar-bg: linear-gradient(180deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%);
            --sidebar-text: #a8b2d1;
            --sidebar-text-hover: #ffffff;
            --sidebar-active-bg: linear-gradient(90deg, rgba(233, 69, 96, 0.2), rgba(233, 69, 96, 0.05));
            --sidebar-active-text: #e94560;
            --sidebar-border: rgba(233, 69, 96, 0.15);

            /* Accent Colors - Vibrant Modern */
            --primary: #6366f1;
            --primary-hover: #4f46e5;
            --primary-light: rgba(99, 102, 241, 0.1);
            --secondary: #e94560;
            --success: #10b981;
            --warning: #f59e0b;
            --danger: #ef4444;
            --info: #06b6d4;

            /* Neutrals */
            --bg-main: #f8fafc;
            --bg-card: #ffffff;
            --text-primary: #1e293b;
            --text-secondary: #64748b;
            --text-muted: #94a3b8;
            --border-color: #e2e8f0;

            /* Layout */
            --sidebar-width: 280px;
            --header-height: 70px;
            --transition: all 0.2s ease;
            --shadow-sm: 0 1px 2px rgba(0,0,0,0.05);
            --shadow: 0 4px 6px -1px rgba(0,0,0,0.1);
            --shadow-lg: 0 10px 15px -3px rgba(0,0,0,0.1);
            --radius: 12px;
            --radius-sm: 8px;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'YekanBakh', 'Tahoma', system-ui, sans-serif !important;
            background: var(--bg-main);
            color: var(--text-primary);
            min-height: 100vh;
            overflow-x: hidden;
            line-height: 1.6;
            cursor: default;
        }

        /* Ensure all elements use YekanBakh font */
        *, *::before, *::after {
            font-family: 'YekanBakh', 'Tahoma', system-ui, sans-serif !important;
        }

        /* Form elements explicitly */
        input, textarea, select, button,
        .btn, .form-control, .form-label,
        .nav-item, .nav-section-title,
        .page-title, .card-title, .modal-title,
        .stat-info h3, .stat-info p,
        h1, h2, h3, h4, h5, h6, p, span, a, label, div {
            font-family: 'YekanBakh', 'Tahoma', system-ui, sans-serif !important;
        }

        /* Ensure cursor is visible everywhere */
        * {
            cursor: inherit;
        }

        a, button, .btn, .action-btn, [onclick], input, textarea, select, label {
            cursor: pointer;
        }

        input[type="text"], input[type="email"], input[type="password"], input[type="number"], textarea {
            cursor: text;
        }

        /* ===== SIDEBAR ===== */
        .sidebar {
            position: fixed;
            top: 0;
            right: 0;
            width: var(--sidebar-width);
            height: 100vh;
            background: var(--sidebar-bg);
            z-index: 1000;
            transition: var(--transition);
            overflow-y: auto;
            overflow-x: hidden;
        }

        .sidebar::-webkit-scrollbar {
            width: 4px;
        }

        .sidebar::-webkit-scrollbar-track {
            background: transparent;
        }

        .sidebar::-webkit-scrollbar-thumb {
            background: rgba(148, 163, 184, 0.3);
            border-radius: 4px;
        }

        .sidebar-header {
            padding: 1.5rem;
            border-bottom: 1px solid var(--sidebar-border);
            position: sticky;
            top: 0;
            background: inherit;
            z-index: 10;
        }

        .sidebar-logo {
            color: #f1f5f9;
            font-size: 1.25rem;
            font-weight: 800;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .sidebar-logo .logo-icon {
            width: 42px;
            height: 42px;
            background: linear-gradient(135deg, #e94560, #6366f1);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 15px rgba(233, 69, 96, 0.3);
        }

        .sidebar-logo .logo-icon svg {
            width: 24px;
            height: 24px;
            fill: white;
        }

        .sidebar-nav {
            padding: 1rem 0;
        }

        .nav-section {
            padding: 0.75rem 1.25rem 0.5rem;
            margin-top: 0.5rem;
        }

        .nav-section-title {
            color: var(--sidebar-text);
            font-size: 0.7rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            opacity: 0.7;
        }

        .nav-item {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            padding: 0.75rem 1.25rem;
            margin: 0.125rem 0.75rem;
            color: var(--sidebar-text);
            text-decoration: none;
            font-size: 0.9rem;
            font-weight: 500;
            transition: var(--transition);
            border-radius: var(--radius-sm);
            position: relative;
        }

        .nav-item:hover {
            background: rgba(255,255,255,0.05);
            color: var(--sidebar-text-hover);
        }

        .nav-item.active {
            background: var(--sidebar-active-bg);
            color: var(--sidebar-active-text);
            border-radius: var(--radius-sm);
        }

        .nav-item.active::before {
            content: '';
            position: absolute;
            right: 0;
            top: 50%;
            transform: translateY(-50%);
            width: 3px;
            height: 60%;
            background: linear-gradient(180deg, #e94560, #6366f1);
            border-radius: 3px 0 0 3px;
            box-shadow: 0 0 10px rgba(233, 69, 96, 0.5);
        }

        .nav-item svg {
            width: 20px;
            height: 20px;
            flex-shrink: 0;
            opacity: 0.8;
        }

        .nav-item.active svg {
            opacity: 1;
        }

        .nav-badge {
            background: var(--danger);
            color: white;
            font-size: 0.65rem;
            font-weight: 700;
            padding: 0.15rem 0.5rem;
            border-radius: 10px;
            margin-right: auto;
        }

        /* ===== HEADER ===== */
        .main-header {
            position: fixed;
            top: 0;
            left: 0;
            right: var(--sidebar-width);
            height: var(--header-height);
            background: var(--bg-card);
            border-bottom: 1px solid var(--border-color);
            z-index: 999;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 1.5rem;
            transition: var(--transition);
        }

        .header-right {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .menu-toggle {
            display: none;
            background: none;
            border: none;
            cursor: pointer;
            padding: 0.5rem;
            border-radius: var(--radius-sm);
            transition: var(--transition);
        }

        .menu-toggle:hover {
            background: var(--bg-main);
        }

        .menu-toggle svg {
            width: 24px;
            height: 24px;
            fill: var(--text-secondary);
        }

        .page-title {
            font-size: 1.25rem;
            font-weight: 700;
            color: var(--text-primary);
        }

        .header-left {
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .header-btn {
            width: 42px;
            height: 42px;
            background: var(--bg-main);
            border: none;
            cursor: pointer;
            position: relative;
            border-radius: var(--radius-sm);
            display: flex;
            align-items: center;
            justify-content: center;
            transition: var(--transition);
        }

        .header-btn:hover {
            background: var(--border-color);
        }

        .header-btn svg {
            width: 20px;
            height: 20px;
            fill: var(--text-secondary);
        }

        .header-btn .badge {
            position: absolute;
            top: 6px;
            left: 6px;
            background: var(--danger);
            color: white;
            font-size: 0.6rem;
            font-weight: 700;
            min-width: 16px;
            height: 16px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .user-menu {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            cursor: pointer;
            padding: 0.5rem 0.75rem;
            border-radius: var(--radius-sm);
            transition: var(--transition);
            border: 1px solid transparent;
        }

        .user-menu:hover {
            background: var(--bg-main);
            border-color: var(--border-color);
        }

        .user-avatar {
            width: 38px;
            height: 38px;
            border-radius: 10px;
            background: linear-gradient(135deg, #e94560, #6366f1);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 700;
            font-size: 0.95rem;
            box-shadow: 0 2px 10px rgba(99, 102, 241, 0.2);
        }

        .user-info {
            text-align: right;
        }

        .user-name {
            font-weight: 600;
            font-size: 0.9rem;
            color: var(--text-primary);
        }

        .user-role {
            font-size: 0.75rem;
            color: var(--text-muted);
        }

        /* ===== MAIN CONTENT ===== */
        .main-content {
            margin-right: var(--sidebar-width);
            margin-top: var(--header-height);
            padding: 1.5rem;
            min-height: calc(100vh - var(--header-height));
            transition: var(--transition);
        }

        /* ===== CARDS ===== */
        .card {
            background: var(--bg-card);
            border-radius: var(--radius);
            box-shadow: var(--shadow-sm);
            border: 1px solid var(--border-color);
            padding: 1.5rem;
            margin-bottom: 1.5rem;
        }

        .card-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 1.5rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid var(--border-color);
        }

        .card-title {
            font-size: 1rem;
            font-weight: 700;
            color: var(--text-primary);
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .card-title svg {
            width: 20px;
            height: 20px;
            fill: var(--primary);
        }

        /* ===== BUTTONS ===== */
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            padding: 0.625rem 1.25rem;
            border-radius: var(--radius-sm);
            font-family: 'YekanBakh', 'Tahoma', system-ui, sans-serif !important;
            font-size: 0.875rem;
            font-weight: 600;
            cursor: pointer;
            transition: var(--transition);
            border: none;
            text-decoration: none;
        }

        .btn svg {
            width: 18px;
            height: 18px;
        }

        .btn-primary {
            background: var(--primary);
            color: white;
        }

        .btn-primary:hover {
            background: var(--primary-hover);
            transform: translateY(-1px);
            box-shadow: var(--shadow);
        }

        .btn-secondary {
            background: var(--secondary);
            color: white;
        }

        .btn-secondary:hover {
            opacity: 0.9;
            transform: translateY(-1px);
        }

        .btn-outline {
            background: transparent;
            border: 1px solid var(--border-color);
            color: var(--text-secondary);
        }

        .btn-outline:hover {
            border-color: var(--primary);
            color: var(--primary);
            background: var(--primary-light);
        }

        .btn-danger {
            background: var(--danger);
            color: white;
        }

        .btn-danger:hover {
            opacity: 0.9;
        }

        .btn-success {
            background: var(--success);
            color: white;
        }

        .btn-sm {
            padding: 0.5rem 1rem;
            font-size: 0.8rem;
        }

        .btn-lg {
            padding: 0.875rem 1.75rem;
            font-size: 1rem;
        }

        /* ===== FORMS ===== */
        .form-group {
            margin-bottom: 1.25rem;
        }

        .form-label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 600;
            font-size: 0.875rem;
            color: var(--text-primary);
        }

        .form-control {
            width: 100%;
            padding: 0.75rem 1rem;
            border: 1px solid var(--border-color);
            border-radius: var(--radius-sm);
            font-family: 'YekanBakh', 'Tahoma', system-ui, sans-serif !important;
            font-size: 0.9rem;
            transition: var(--transition);
            background: var(--bg-card);
            color: var(--text-primary);
        }

        .form-control:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px var(--primary-light);
        }

        .form-control::placeholder {
            color: var(--text-muted);
        }

        textarea.form-control {
            min-height: 100px;
            resize: vertical;
        }

        .form-hint {
            font-size: 0.75rem;
            color: var(--text-muted);
            margin-top: 0.25rem;
        }

        /* ===== TABLES ===== */
        .table-responsive {
            overflow-x: auto;
            border-radius: var(--radius-sm);
            border: 1px solid var(--border-color);
        }

        .table {
            width: 100%;
            border-collapse: collapse;
        }

        .table th,
        .table td {
            padding: 1rem;
            text-align: right;
            border-bottom: 1px solid var(--border-color);
        }

        .table th {
            background: var(--bg-main);
            font-weight: 600;
            color: var(--text-secondary);
            font-size: 0.8rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .table tbody tr {
            transition: var(--transition);
        }

        .table tbody tr:hover {
            background: var(--bg-main);
        }

        .table tbody tr:last-child td {
            border-bottom: none;
        }

        .table .actions {
            display: flex;
            gap: 0.5rem;
        }

        .table .action-btn {
            width: 34px;
            height: 34px;
            border-radius: var(--radius-sm);
            border: none;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: var(--transition);
        }

        .table .action-btn svg {
            width: 16px;
            height: 16px;
        }

        .table .action-btn.edit {
            background: var(--primary-light);
            color: var(--primary);
        }

        .table .action-btn.edit:hover {
            background: var(--primary);
            color: white;
        }

        .table .action-btn.delete {
            background: rgba(239, 68, 68, 0.1);
            color: var(--danger);
        }

        .table .action-btn.delete:hover {
            background: var(--danger);
            color: white;
        }

        /* ===== ITEM CARDS with ACTIONS ===== */
        .item-card {
            background: var(--bg-main);
            border-radius: var(--radius-sm);
            padding: 1.25rem;
            border: 1px solid var(--border-color);
            position: relative;
            transition: var(--transition);
        }

        .item-card:hover {
            border-color: var(--primary);
            box-shadow: var(--shadow);
        }

        .item-card:hover .item-actions {
            opacity: 1;
        }

        .item-actions {
            position: absolute;
            top: 0.75rem;
            left: 0.75rem;
            display: flex;
            gap: 0.5rem;
            opacity: 0.5;
            transition: var(--transition);
        }

        .item-actions .action-btn {
            width: 32px;
            height: 32px;
            border-radius: var(--radius-sm);
            border: none;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: var(--transition);
        }

        .item-actions .action-btn svg {
            width: 16px;
            height: 16px;
            fill: currentColor;
        }

        .item-actions .action-btn.edit {
            background: var(--primary-light);
            color: var(--primary);
        }

        .item-actions .action-btn.edit:hover {
            background: var(--primary);
            color: white;
        }

        .item-actions .action-btn.delete {
            background: rgba(239, 68, 68, 0.1);
            color: var(--danger);
        }

        .item-actions .action-btn.delete:hover {
            background: var(--danger);
            color: white;
        }

        /* Form hints and placeholders */
        .form-hint {
            display: block;
            font-size: 0.8rem;
            color: var(--text-muted);
            margin-top: 0.35rem;
            line-height: 1.5;
        }

        .form-hint code {
            background: var(--bg-main);
            padding: 0.1rem 0.4rem;
            border-radius: 4px;
            font-family: monospace;
            font-size: 0.75rem;
            color: var(--primary);
        }

        /* ===== STATS GRID ===== */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 1.25rem;
            margin-bottom: 1.5rem;
        }

        .stat-card {
            background: var(--bg-card);
            border-radius: var(--radius);
            padding: 1.25rem;
            border: 1px solid var(--border-color);
            display: flex;
            align-items: flex-start;
            gap: 1rem;
            transition: var(--transition);
        }

        .stat-card:hover {
            border-color: var(--primary);
            box-shadow: var(--shadow);
        }

        .stat-icon {
            width: 50px;
            height: 50px;
            border-radius: var(--radius-sm);
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
        }

        .stat-icon svg {
            width: 24px;
            height: 24px;
            fill: white;
        }

        .stat-icon.primary { background: linear-gradient(135deg, var(--primary), #60a5fa); }
        .stat-icon.secondary { background: linear-gradient(135deg, var(--secondary), #a78bfa); }
        .stat-icon.success { background: linear-gradient(135deg, var(--success), #34d399); }
        .stat-icon.warning { background: linear-gradient(135deg, var(--warning), #fbbf24); }
        .stat-icon.danger { background: linear-gradient(135deg, var(--danger), #f87171); }
        .stat-icon.info { background: linear-gradient(135deg, var(--info), #22d3ee); }

        .stat-info h3 {
            font-size: 1.5rem;
            font-weight: 800;
            color: var(--text-primary);
            margin-bottom: 0.125rem;
        }

        .stat-info p {
            font-size: 0.8rem;
            color: var(--text-muted);
        }

        /* ===== ALERTS ===== */
        .alert {
            padding: 1rem 1.25rem;
            border-radius: var(--radius-sm);
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            font-size: 0.9rem;
        }

        .alert svg {
            width: 20px;
            height: 20px;
            flex-shrink: 0;
        }

        .alert-success {
            background: rgba(16, 185, 129, 0.1);
            color: var(--success);
            border: 1px solid rgba(16, 185, 129, 0.2);
        }

        .alert-danger {
            background: rgba(239, 68, 68, 0.1);
            color: var(--danger);
            border: 1px solid rgba(239, 68, 68, 0.2);
        }

        .alert-warning {
            background: rgba(245, 158, 11, 0.1);
            color: #b45309;
            border: 1px solid rgba(245, 158, 11, 0.2);
        }

        .alert-info {
            background: rgba(6, 182, 212, 0.1);
            color: var(--info);
            border: 1px solid rgba(6, 182, 212, 0.2);
        }

        /* ===== MODAL ===== */
        .modal-overlay {
            position: fixed;
            inset: 0;
            background: rgba(15, 23, 42, 0.6);
            backdrop-filter: blur(4px);
            z-index: 2000;
            display: none;
            align-items: center;
            justify-content: center;
            padding: 1rem;
        }

        .modal-overlay.active {
            display: flex;
        }

        .modal {
            background: var(--bg-card);
            border-radius: var(--radius);
            width: 100%;
            max-width: 500px;
            max-height: 90vh;
            overflow-y: auto;
            animation: modalIn 0.2s ease;
            box-shadow: var(--shadow-lg);
        }

        @keyframes modalIn {
            from {
                opacity: 0;
                transform: scale(0.95) translateY(-10px);
            }
            to {
                opacity: 1;
                transform: scale(1) translateY(0);
            }
        }

        .modal-header {
            padding: 1.25rem 1.5rem;
            border-bottom: 1px solid var(--border-color);
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .modal-title {
            font-size: 1.1rem;
            font-weight: 700;
            color: var(--text-primary);
        }

        .modal-close {
            background: var(--bg-main);
            border: none;
            cursor: pointer;
            padding: 0.5rem;
            border-radius: var(--radius-sm);
            transition: var(--transition);
        }

        .modal-close:hover {
            background: var(--border-color);
        }

        .modal-close svg {
            width: 18px;
            height: 18px;
            fill: var(--text-secondary);
        }

        .modal-body {
            padding: 1.5rem;
        }

        .modal-footer {
            padding: 1rem 1.5rem;
            border-top: 1px solid var(--border-color);
            display: flex;
            justify-content: flex-end;
            gap: 0.75rem;
        }

        /* ===== GRID ===== */
        .row {
            display: flex;
            flex-wrap: wrap;
            margin: -0.625rem;
        }

        .col-6 { width: 50%; padding: 0.625rem; }
        .col-4 { width: 33.333%; padding: 0.625rem; }
        .col-3 { width: 25%; padding: 0.625rem; }
        .col-12 { width: 100%; padding: 0.625rem; }

        /* ===== EMPTY STATE ===== */
        .empty-state {
            text-align: center;
            padding: 3rem 2rem;
            color: var(--text-muted);
        }

        .empty-state svg {
            width: 48px;
            height: 48px;
            fill: var(--text-muted);
            opacity: 0.5;
            margin-bottom: 1rem;
        }

        .empty-state h4 {
            font-size: 1rem;
            color: var(--text-secondary);
            margin-bottom: 0.5rem;
        }

        .empty-state p {
            font-size: 0.875rem;
        }

        /* ===== STATUS BADGES ===== */
        .badge {
            display: inline-flex;
            align-items: center;
            padding: 0.25rem 0.625rem;
            font-size: 0.75rem;
            font-weight: 600;
            border-radius: 6px;
        }

        .badge-success {
            background: rgba(16, 185, 129, 0.1);
            color: var(--success);
        }

        .badge-warning {
            background: rgba(245, 158, 11, 0.1);
            color: #b45309;
        }

        .badge-danger {
            background: rgba(239, 68, 68, 0.1);
            color: var(--danger);
        }

        .badge-info {
            background: rgba(59, 130, 246, 0.1);
            color: var(--primary);
        }

        /* ===== RESPONSIVE ===== */
        @media (max-width: 1024px) {
            .sidebar {
                transform: translateX(100%);
            }

            .sidebar.open {
                transform: translateX(0);
            }

            .main-header {
                right: 0;
            }

            .main-content {
                margin-right: 0;
            }

            .menu-toggle {
                display: flex;
            }

            .sidebar-overlay {
                position: fixed;
                inset: 0;
                background: rgba(15, 23, 42, 0.5);
                z-index: 999;
                display: none;
            }

            .sidebar-overlay.active {
                display: block;
            }
        }

        @media (max-width: 768px) {
            .main-content {
                padding: 1rem;
            }

            .col-6, .col-4, .col-3 {
                width: 100%;
            }

            .stats-grid {
                grid-template-columns: 1fr;
            }

            .header-left .user-info {
                display: none;
            }

            .page-title {
                font-size: 1rem;
            }
        }

        /* ===== UTILITIES ===== */
        .text-center { text-align: center; }
        .text-left { text-align: left; }
        .mb-0 { margin-bottom: 0; }
        .mb-1 { margin-bottom: 0.5rem; }
        .mb-2 { margin-bottom: 1rem; }
        .mb-3 { margin-bottom: 1.5rem; }
        .mt-2 { margin-top: 1rem; }
        .d-flex { display: flex; }
        .align-center { align-items: center; }
        .justify-between { justify-content: space-between; }
        .gap-1 { gap: 0.5rem; }
        .gap-2 { gap: 1rem; }

        /* ===== LOADING ===== */
        .loading {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(255,255,255,0.9);
            z-index: 3000;
            align-items: center;
            justify-content: center;
        }

        .loading.active {
            display: flex;
        }

        .spinner {
            width: 44px;
            height: 44px;
            border: 3px solid var(--border-color);
            border-top-color: var(--primary);
            border-radius: 50%;
            animation: spin 0.8s linear infinite;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }

        /* ===== TOAST NOTIFICATIONS ===== */
        .toast-container {
            position: fixed;
            bottom: 1.5rem;
            left: 1.5rem;
            z-index: 3000;
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }

        .toast {
            background: var(--bg-card);
            padding: 1rem 1.25rem;
            border-radius: var(--radius-sm);
            box-shadow: var(--shadow-lg);
            display: flex;
            align-items: center;
            gap: 0.75rem;
            animation: toastIn 0.3s ease;
            min-width: 300px;
            border: 1px solid var(--border-color);
        }

        @keyframes toastIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .toast.success { border-right: 4px solid var(--success); }
        .toast.error { border-right: 4px solid var(--danger); }
        .toast.warning { border-right: 4px solid var(--warning); }

        .toast svg {
            width: 20px;
            height: 20px;
            flex-shrink: 0;
        }

        .toast.success svg { fill: var(--success); }
        .toast.error svg { fill: var(--danger); }
        .toast.warning svg { fill: var(--warning); }

        /* ===== DATA PREVIEW CARDS ===== */
        .preview-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 1rem;
        }

        .preview-card {
            background: var(--bg-main);
            border-radius: var(--radius-sm);
            padding: 1.25rem;
            border: 1px solid var(--border-color);
            transition: var(--transition);
        }

        .preview-card:hover {
            border-color: var(--primary);
        }

        /* ===== SAVE BAR ===== */
        .save-bar {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
            border-radius: var(--radius);
            padding: 1.25rem 1.5rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-top: 1.5rem;
        }

        .save-bar h4 {
            font-size: 1rem;
            font-weight: 700;
            margin-bottom: 0.25rem;
        }

        .save-bar p {
            font-size: 0.85rem;
            opacity: 0.9;
        }

        .save-bar .btn {
            background: white;
            color: var(--primary);
        }

        .save-bar .btn:hover {
            background: var(--bg-main);
        }
    </style>
</head>
<body>
    <!-- Sidebar Overlay (Mobile) -->
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <!-- Sidebar -->
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <a href="<?php echo URL; ?>admin" class="sidebar-logo">
                <div class="logo-icon">
                    <svg viewBox="0 0 24 24"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/></svg>
                </div>
                <span>طراحان باستان</span>
            </a>
        </div>
        <nav class="sidebar-nav">
            <!-- داشبورد -->
            <a href="<?php echo URL; ?>admin" class="nav-item <?php echo (!isset($active) || $active == 'index') ? 'active' : ''; ?>">
                <svg viewBox="0 0 24 24"><path fill="currentColor" d="M4 13h6a1 1 0 0 0 1-1V4a1 1 0 0 0-1-1H4a1 1 0 0 0-1 1v8a1 1 0 0 0 1 1zm-1 7a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1v-4a1 1 0 0 0-1-1H4a1 1 0 0 0-1 1v4zm10 0a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1v-8a1 1 0 0 0-1-1h-6a1 1 0 0 0-1 1v8zm1-10h6a1 1 0 0 0 1-1V4a1 1 0 0 0-1-1h-6a1 1 0 0 0-1 1v5a1 1 0 0 0 1 1z"/></svg>
                داشبورد
            </a>

            <div class="nav-section">
                <div class="nav-section-title">مدیریت محتوا</div>
            </div>

            <a href="<?php echo URL; ?>admin/home" class="nav-item <?php echo (isset($active) && $active == 'home') ? 'active' : ''; ?>">
                <svg viewBox="0 0 24 24"><path fill="currentColor" d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/></svg>
                صفحه اصلی
            </a>
            <a href="<?php echo URL; ?>admin/about" class="nav-item <?php echo (isset($active) && $active == 'about') ? 'active' : ''; ?>">
                <svg viewBox="0 0 24 24"><path fill="currentColor" d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"/></svg>
                درباره ما
            </a>
            <a href="<?php echo URL; ?>admin/contact" class="nav-item <?php echo (isset($active) && $active == 'contact') ? 'active' : ''; ?>">
                <svg viewBox="0 0 24 24"><path fill="currentColor" d="M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/></svg>
                تماس با ما
            </a>

            <div class="nav-section">
                <div class="nav-section-title">خدمات</div>
            </div>

            <a href="<?php echo URL; ?>admin/services" class="nav-item <?php echo (isset($active) && $active == 'services') ? 'active' : ''; ?>">
                <svg viewBox="0 0 24 24"><path fill="currentColor" d="M20 6h-4V4c0-1.11-.89-2-2-2h-4c-1.11 0-2 .89-2 2v2H4c-1.11 0-1.99.89-1.99 2L2 19c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V8c0-1.11-.89-2-2-2zm-6 0h-4V4h4v2z"/></svg>
                مدیریت خدمات
            </a>

            <div class="nav-section">
                <div class="nav-section-title">اجزای سایت</div>
            </div>

            <a href="<?php echo URL; ?>admin/stats" class="nav-item <?php echo (isset($active) && $active == 'stats') ? 'active' : ''; ?>">
                <svg viewBox="0 0 24 24"><path fill="currentColor" d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zM9 17H7v-7h2v7zm4 0h-2V7h2v10zm4 0h-2v-4h2v4z"/></svg>
                آمار و ارقام
            </a>
            <a href="<?php echo URL; ?>admin/testimonials" class="nav-item <?php echo (isset($active) && $active == 'testimonials') ? 'active' : ''; ?>">
                <svg viewBox="0 0 24 24"><path fill="currentColor" d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/></svg>
                نظرات مشتریان
            </a>
            <a href="<?php echo URL; ?>admin/timeline" class="nav-item <?php echo (isset($active) && $active == 'timeline') ? 'active' : ''; ?>">
                <svg viewBox="0 0 24 24"><path fill="currentColor" d="M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67z"/></svg>
                تاریخچه
            </a>
            <a href="<?php echo URL; ?>admin/values" class="nav-item <?php echo (isset($active) && $active == 'values') ? 'active' : ''; ?>">
                <svg viewBox="0 0 24 24"><path fill="currentColor" d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>
                ارزش‌ها
            </a>
            <a href="<?php echo URL; ?>admin/faq" class="nav-item <?php echo (isset($active) && $active == 'faq') ? 'active' : ''; ?>">
                <svg viewBox="0 0 24 24"><path fill="currentColor" d="M11 18h2v-2h-2v2zm1-16C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm0-14c-2.21 0-4 1.79-4 4h2c0-1.1.9-2 2-2s2 .9 2 2c0 2-3 1.75-3 5h2c0-2.25 3-2.5 3-5 0-2.21-1.79-4-4-4z"/></svg>
                سوالات متداول
            </a>
            <a href="<?php echo URL; ?>admin/process" class="nav-item <?php echo (isset($active) && $active == 'process') ? 'active' : ''; ?>">
                <svg viewBox="0 0 24 24"><path fill="currentColor" d="M19.35 10.04C18.67 6.59 15.64 4 12 4 9.11 4 6.6 5.64 5.35 8.04 2.34 8.36 0 10.91 0 14c0 3.31 2.69 6 6 6h13c2.76 0 5-2.24 5-5 0-2.64-2.05-4.78-4.65-4.96zM10 17l-3.5-3.5 1.41-1.41L10 14.17l4.59-4.59L16 11l-6 6z"/></svg>
                فرآیند کار
            </a>

            <div class="nav-section">
                <div class="nav-section-title">وبلاگ</div>
            </div>

            <a href="<?php echo URL; ?>admin/articles" class="nav-item <?php echo (isset($active) && $active == 'articles') ? 'active' : ''; ?>">
                <svg viewBox="0 0 24 24"><path fill="currentColor" d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-5 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z"/></svg>
                مقالات
            </a>

            <div class="nav-section">
                <div class="nav-section-title">ارتباطات</div>
            </div>

            <a href="<?php echo URL; ?>admin/messages" class="nav-item <?php echo (isset($active) && $active == 'messages') ? 'active' : ''; ?>">
                <svg viewBox="0 0 24 24"><path fill="currentColor" d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm0 14H6l-2 2V4h16v12z"/></svg>
                پیام‌ها
                <?php if (isset($unreadMessages) && $unreadMessages > 0): ?>
                    <span class="nav-badge"><?php echo $unreadMessages; ?></span>
                <?php endif; ?>
            </a>

            <div class="nav-section">
                <div class="nav-section-title">سیستم</div>
            </div>

            <a href="<?php echo URL; ?>admin/settings" class="nav-item <?php echo (isset($active) && $active == 'settings') ? 'active' : ''; ?>">
                <svg viewBox="0 0 24 24"><path fill="currentColor" d="M19.14 12.94c.04-.31.06-.63.06-.94 0-.31-.02-.63-.06-.94l2.03-1.58a.49.49 0 0 0 .12-.61l-1.92-3.32a.49.49 0 0 0-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54a.484.484 0 0 0-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96a.49.49 0 0 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.04.31-.06.63-.06.94s.02.63.06.94l-2.03 1.58a.49.49 0 0 0-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z"/></svg>
                تنظیمات
            </a>
            <a href="<?php echo URL; ?>" class="nav-item" target="_blank">
                <svg viewBox="0 0 24 24"><path fill="currentColor" d="M19 19H5V5h7V3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14c1.1 0 2-.9 2-2v-7h-2v7zM14 3v2h3.59l-9.83 9.83 1.41 1.41L19 6.41V10h2V3h-7z"/></svg>
                مشاهده سایت
            </a>
            <a href="<?php echo URL; ?>admin/logout" class="nav-item">
                <svg viewBox="0 0 24 24"><path fill="currentColor" d="M17 7l-1.41 1.41L18.17 11H8v2h10.17l-2.58 2.58L17 17l5-5zM4 5h8V3H4c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h8v-2H4V5z"/></svg>
                خروج
            </a>
        </nav>
    </aside>

    <!-- Header -->
    <header class="main-header">
        <div class="header-right">
            <button class="menu-toggle" id="menuToggle">
                <svg viewBox="0 0 24 24"><path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"/></svg>
            </button>
            <h1 class="page-title"><?php echo $pageTitle ?? 'داشبورد'; ?></h1>
        </div>
        <div class="header-left">
            <a href="<?php echo URL; ?>admin/messages" class="header-btn" title="پیام‌ها">
                <svg viewBox="0 0 24 24"><path fill="currentColor" d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2z"/></svg>
                <?php if (isset($unreadMessages) && $unreadMessages > 0): ?>
                    <span class="badge"><?php echo $unreadMessages; ?></span>
                <?php endif; ?>
            </a>
            <div class="user-menu">
                <div class="user-avatar">
                    <?php echo mb_substr($_SESSION['admin_name'] ?? 'ا', 0, 1, 'UTF-8'); ?>
                </div>
                <div class="user-info">
                    <div class="user-name"><?php echo $_SESSION['admin_name'] ?? 'مدیر'; ?></div>
                    <div class="user-role"><?php echo ($_SESSION['admin_role'] ?? '') == 'superadmin' ? 'مدیر اصلی' : 'مدیر'; ?></div>
                </div>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <main class="main-content">
        <?php echo $content ?? ''; ?>
    </main>

    <!-- Toast Container -->
    <div class="toast-container" id="toastContainer"></div>

    <!-- Loading Overlay -->
    <div class="loading" id="loading">
        <div class="spinner"></div>
    </div>

    <script>
        // Toggle Sidebar (Mobile)
        const menuToggle = document.getElementById('menuToggle');
        const sidebar = document.getElementById('sidebar');
        const sidebarOverlay = document.getElementById('sidebarOverlay');

        menuToggle?.addEventListener('click', () => {
            sidebar.classList.toggle('open');
            sidebarOverlay.classList.toggle('active');
        });

        sidebarOverlay?.addEventListener('click', () => {
            sidebar.classList.remove('open');
            sidebarOverlay.classList.remove('active');
        });

        // Toast Notification
        function showToast(message, type = 'success') {
            const container = document.getElementById('toastContainer');
            const toast = document.createElement('div');
            toast.className = `toast ${type}`;

            const icons = {
                success: '<path fill="currentColor" d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/>',
                error: '<path fill="currentColor" d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/>',
                warning: '<path fill="currentColor" d="M1 21h22L12 2 1 21zm12-3h-2v-2h2v2zm0-4h-2v-4h2v4z"/>'
            };

            toast.innerHTML = `
                <svg viewBox="0 0 24 24" width="20" height="20">${icons[type] || icons.success}</svg>
                <span>${message}</span>
            `;
            container.appendChild(toast);

            setTimeout(() => {
                toast.style.opacity = '0';
                toast.style.transform = 'translateY(20px)';
                setTimeout(() => toast.remove(), 300);
            }, 4000);
        }

        // Loading
        function showLoading() {
            document.getElementById('loading').classList.add('active');
        }

        function hideLoading() {
            document.getElementById('loading').classList.remove('active');
        }

        // Form Submit with AJAX
        async function submitFormAjax(form, url, successCallback) {
            showLoading();
            try {
                const formData = new FormData(form);
                const response = await fetch(url, {
                    method: 'POST',
                    body: formData
                });
                const result = await response.json();
                hideLoading();

                if (result.success) {
                    showToast(result.message || 'عملیات با موفقیت انجام شد', 'success');
                    if (successCallback) successCallback(result);
                } else {
                    showToast(result.message || 'خطایی رخ داد', 'error');
                }
                return result;
            } catch (error) {
                hideLoading();
                showToast('خطا در ارتباط با سرور', 'error');
                return { success: false };
            }
        }

        // Delete Confirmation
        function confirmDelete(url, callback) {
            if (confirm('آیا از حذف این مورد اطمینان دارید؟')) {
                showLoading();
                fetch(url, { method: 'POST' })
                    .then(res => res.json())
                    .then(result => {
                        hideLoading();
                        if (result.success) {
                            showToast('با موفقیت حذف شد', 'success');
                            if (callback) callback();
                        } else {
                            showToast('خطا در حذف', 'error');
                        }
                    })
                    .catch(() => {
                        hideLoading();
                        showToast('خطا در ارتباط با سرور', 'error');
                    });
            }
        }

        // Modal Functions
        function openModal(modalId) {
            document.getElementById(modalId)?.classList.add('active');
        }

        function closeModal(modalId) {
            document.getElementById(modalId)?.classList.remove('active');
        }

        // Close modal on overlay click
        document.querySelectorAll('.modal-overlay').forEach(overlay => {
            overlay.addEventListener('click', (e) => {
                if (e.target === overlay) {
                    overlay.classList.remove('active');
                }
            });
        });
    </script>
</body>
</html>
