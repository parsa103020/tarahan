<?php
$active = 'faq';
$pageTitle = 'مدیریت سوالات متداول';
ob_start();

// Extract data
$faqs = $data['faqs'] ?? [];
?>

<div class="card">
    <div class="card-header">
        <h3 class="card-title">
            <svg viewBox="0 0 24 24"><path fill="currentColor" d="M11 18h2v-2h-2v2zm1-16C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm0-14c-2.21 0-4 1.79-4 4h2c0-1.1.9-2 2-2s2 .9 2 2c0 2-3 1.75-3 5h2c0-2.25 3-2.5 3-5 0-2.21-1.79-4-4-4z"/></svg>
            سوالات متداول
        </h3>
        <button type="button" class="btn btn-sm btn-secondary" onclick="openAddModal()">
            <svg viewBox="0 0 24 24" width="16" height="16"><path fill="currentColor" d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/></svg>
            افزودن سوال
        </button>
    </div>
    <p class="form-hint" style="margin-bottom: 1rem;">سوالات متداولی که در صفحه تماس نمایش داده می‌شوند. این بخش به سئو و کاهش تماس‌های تکراری کمک می‌کند.</p>

    <?php if (!empty($faqs)): ?>
        <div class="faq-container">
            <?php foreach ($faqs as $faq): ?>
                <div class="item-card faq-item">
                    <div class="item-actions">
                        <button type="button" class="action-btn edit" onclick='editFaq(<?php echo json_encode($faq, JSON_HEX_APOS | JSON_HEX_QUOT); ?>)' title="ویرایش این سوال">
                            <svg viewBox="0 0 24 24"><path fill="currentColor" d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/></svg>
                        </button>
                        <button type="button" class="action-btn delete" onclick="deleteFaq(<?php echo $faq['id']; ?>)" title="حذف این سوال">
                            <svg viewBox="0 0 24 24"><path fill="currentColor" d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg>
                        </button>
                    </div>
                    <div class="faq-question">
                        <svg viewBox="0 0 24 24" width="20" height="20" style="fill: var(--secondary); flex-shrink: 0;">
                            <path d="M11 18h2v-2h-2v2zm1-16C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm0-14c-2.21 0-4 1.79-4 4h2c0-1.1.9-2 2-2s2 .9 2 2c0 2-3 1.75-3 5h2c0-2.25 3-2.5 3-5 0-2.21-1.79-4-4-4z"/>
                        </svg>
                        <span><?php echo htmlspecialchars($faq['question']); ?></span>
                    </div>
                    <div class="faq-answer"><?php echo htmlspecialchars($faq['answer']); ?></div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div class="empty-state">
            <svg viewBox="0 0 24 24">
                <path d="M11 18h2v-2h-2v2zm1-16C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm0-14c-2.21 0-4 1.79-4 4h2c0-1.1.9-2 2-2s2 .9 2 2c0 2-3 1.75-3 5h2c0-2.25 3-2.5 3-5 0-2.21-1.79-4-4-4z"/>
            </svg>
            <h4>سوالی ثبت نشده است</h4>
            <p>سوالات متداول مشتریان را اینجا اضافه کنید تا در صفحه تماس نمایش داده شوند</p>
            <button type="button" class="btn btn-primary mt-2" onclick="openAddModal()">
                <svg viewBox="0 0 24 24" width="18" height="18"><path fill="currentColor" d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/></svg>
                افزودن اولین سوال
            </button>
        </div>
    <?php endif; ?>
</div>

<style>
.faq-container {
    display: flex;
    flex-direction: column;
    gap: 1rem;
}

.faq-item {
    padding-left: 4rem;
}

.faq-question {
    display: flex;
    align-items: flex-start;
    gap: 0.75rem;
    font-weight: 700;
    color: var(--primary);
    margin-bottom: 0.75rem;
    font-size: 1rem;
}

.faq-answer {
    color: var(--text-secondary);
    font-size: 0.9rem;
    line-height: 1.8;
    padding-right: 2rem;
    border-right: 3px solid var(--secondary);
}
</style>

<!-- Add/Edit Modal -->
<div class="modal-overlay" id="addFaqModal">
    <div class="modal">
        <div class="modal-header">
            <h3 class="modal-title" id="faqModalTitle">افزودن سوال جدید</h3>
            <button type="button" class="modal-close" onclick="closeModal('addFaqModal')">
                <svg viewBox="0 0 24 24"><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg>
            </button>
        </div>
        <form id="faqForm">
            <div class="modal-body">
                <input type="hidden" name="id" id="faq_id">
                <input type="hidden" name="page" value="contact">

                <div class="form-group">
                    <label class="form-label">سوال *</label>
                    <input type="text" class="form-control" name="question" id="faq_question" placeholder="مثال: ساعات کاری شرکت چگونه است؟" required>
                    <span class="form-hint">سوالی که معمولا مشتریان می‌پرسند را وارد کنید</span>
                </div>
                <div class="form-group">
                    <label class="form-label">پاسخ *</label>
                    <textarea class="form-control" name="answer" id="faq_answer" rows="5" placeholder="پاسخ کامل و روشن به این سوال..." required></textarea>
                    <span class="form-hint">پاسخ را به صورت کامل و قابل فهم بنویسید</span>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline" onclick="closeModal('addFaqModal')">انصراف</button>
                <button type="submit" class="btn btn-primary">
                    <svg viewBox="0 0 24 24" width="18" height="18"><path fill="currentColor" d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>
                    ذخیره سوال
                </button>
            </div>
        </form>
    </div>
</div>

<script>
    function openAddModal() {
        document.getElementById('faqModalTitle').textContent = 'افزودن سوال جدید';
        document.getElementById('faqForm').reset();
        document.getElementById('faq_id').value = '';
        openModal('addFaqModal');
    }

    function editFaq(faq) {
        document.getElementById('faqModalTitle').textContent = 'ویرایش سوال';
        document.getElementById('faq_id').value = faq.id;
        document.getElementById('faq_question').value = faq.question;
        document.getElementById('faq_answer').value = faq.answer;
        openModal('addFaqModal');
    }

    function deleteFaq(id) {
        confirmDelete('<?php echo URL; ?>admin/deleteFAQ/' + id, () => {
            location.reload();
        });
    }

    document.getElementById('faqForm').addEventListener('submit', async function(e) {
        e.preventDefault();
        showLoading();

        try {
            const formData = new FormData(this);
            const response = await fetch('<?php echo URL; ?>admin/saveFAQ', {
                method: 'POST',
                body: formData
            });
            const result = await response.json();

            hideLoading();

            if (result.success) {
                showToast('سوال با موفقیت ذخیره شد', 'success');
                setTimeout(() => location.reload(), 1000);
            } else {
                showToast('خطا در ذخیره', 'error');
            }
        } catch (error) {
            hideLoading();
            showToast('خطا در ارتباط با سرور', 'error');
        }
    });
</script>

<?php
$content = ob_get_clean();
include dirname(__DIR__) . '/layout.php';
?>
