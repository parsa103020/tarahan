<?php
$active = 'articles';
$pageTitle = 'مدیریت مقالات';
ob_start();
?>

<!-- Page Header -->
<div class="page-header" style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 1.5rem;">
    <div>
        <h2 style="font-size: 1.5rem; font-weight: 700; margin-bottom: 0.25rem;">مقالات وبلاگ</h2>
        <p style="color: var(--text-muted); font-size: 0.9rem;">مدیریت و ویرایش مقالات سایت</p>
    </div>
    <a href="<?php echo URL; ?>admin/editArticle" class="btn btn-primary">
        <svg viewBox="0 0 24 24" width="18" height="18"><path fill="currentColor" d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/></svg>
        مقاله جدید
    </a>
</div>

<!-- Stats Cards -->
<div class="stats-grid" style="margin-bottom: 1.5rem;">
    <?php
    $totalArticles = count($data['articles'] ?? []);
    $publishedCount = 0;
    $draftCount = 0;
    $totalViews = 0;

    foreach ($data['articles'] ?? [] as $article) {
        if ($article['status'] === 'published') $publishedCount++;
        else $draftCount++;
        $totalViews += $article['views'] ?? 0;
    }
    ?>
    <div class="stat-card">
        <div class="stat-icon primary">
            <svg viewBox="0 0 24 24"><path fill="currentColor" d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-5 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z"/></svg>
        </div>
        <div class="stat-info">
            <h3><?php echo $totalArticles; ?></h3>
            <p>کل مقالات</p>
        </div>
    </div>

    <div class="stat-card">
        <div class="stat-icon success">
            <svg viewBox="0 0 24 24"><path fill="currentColor" d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>
        </div>
        <div class="stat-info">
            <h3><?php echo $publishedCount; ?></h3>
            <p>منتشر شده</p>
        </div>
    </div>

    <div class="stat-card">
        <div class="stat-icon warning">
            <svg viewBox="0 0 24 24"><path fill="currentColor" d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/></svg>
        </div>
        <div class="stat-info">
            <h3><?php echo $draftCount; ?></h3>
            <p>پیش‌نویس</p>
        </div>
    </div>

    <div class="stat-card">
        <div class="stat-icon info">
            <svg viewBox="0 0 24 24"><path fill="currentColor" d="M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5zm0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3z"/></svg>
        </div>
        <div class="stat-info">
            <h3><?php echo number_format($totalViews); ?></h3>
            <p>کل بازدید</p>
        </div>
    </div>
</div>

<!-- Articles Table -->
<div class="card">
    <div class="card-header">
        <h3 class="card-title">
            <svg viewBox="0 0 24 24"><path fill="currentColor" d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6zm4 18H6V4h7v5h5v11z"/></svg>
            لیست مقالات
        </h3>
        <div class="d-flex gap-1">
            <input type="text" class="form-control" id="searchArticles" placeholder="جستجو..." style="width: 200px; padding: 0.5rem 1rem; font-size: 0.85rem;">
        </div>
    </div>

    <?php if (!empty($data['articles'])): ?>
    <div class="table-responsive">
        <table class="table" id="articlesTable">
            <thead>
                <tr>
                    <th style="width: 60px;">#</th>
                    <th style="width: 80px;">تصویر</th>
                    <th>عنوان مقاله</th>
                    <th style="width: 120px;">وضعیت</th>
                    <th style="width: 100px;">بازدید</th>
                    <th style="width: 140px;">تاریخ انتشار</th>
                    <th style="width: 130px;">عملیات</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($data['articles'] as $index => $article): ?>
                <tr class="article-row">
                    <td>
                        <span style="background: var(--bg-main); padding: 0.25rem 0.5rem; border-radius: 6px; font-weight: 600; font-size: 0.8rem;">
                            <?php echo $index + 1; ?>
                        </span>
                    </td>
                    <td>
                        <?php if (!empty($article['featured_image'])): ?>
                            <img src="<?php echo URL . $article['featured_image']; ?>" alt="" style="width: 60px; height: 45px; object-fit: cover; border-radius: 8px; border: 1px solid var(--border-color);">
                        <?php else: ?>
                            <div style="width: 60px; height: 45px; background: linear-gradient(135deg, var(--primary-light), var(--bg-main)); border-radius: 8px; display: flex; align-items: center; justify-content: center;">
                                <svg viewBox="0 0 24 24" width="20" height="20" style="fill: var(--text-muted);"><path d="M21 19V5c0-1.1-.9-2-2-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2zM8.5 13.5l2.5 3.01L14.5 12l4.5 6H5l3.5-4.5z"/></svg>
                            </div>
                        <?php endif; ?>
                    </td>
                    <td>
                        <div style="display: flex; flex-direction: column; gap: 0.25rem;">
                            <a href="<?php echo URL; ?>article/show/<?php echo $article['slug']; ?>" target="_blank" style="color: var(--text-primary); text-decoration: none; font-weight: 600; transition: color 0.2s;">
                                <?php echo htmlspecialchars($article['title']); ?>
                            </a>
                            <?php if (!empty($article['excerpt'])): ?>
                                <span style="font-size: 0.8rem; color: var(--text-muted); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 300px;">
                                    <?php echo htmlspecialchars(mb_substr($article['excerpt'], 0, 60) . '...'); ?>
                                </span>
                            <?php endif; ?>
                        </div>
                    </td>
                    <td>
                        <?php if ($article['status'] === 'published'): ?>
                            <span class="badge badge-success" style="padding: 0.4rem 0.75rem; font-size: 0.75rem;">
                                <svg viewBox="0 0 24 24" width="12" height="12" style="fill: currentColor; margin-left: 0.25rem;"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>
                                منتشر شده
                            </span>
                        <?php else: ?>
                            <span class="badge badge-warning" style="padding: 0.4rem 0.75rem; font-size: 0.75rem;">
                                <svg viewBox="0 0 24 24" width="12" height="12" style="fill: currentColor; margin-left: 0.25rem;"><path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/></svg>
                                پیش‌نویس
                            </span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <div style="display: flex; align-items: center; gap: 0.5rem;">
                            <svg viewBox="0 0 24 24" width="16" height="16" style="fill: var(--text-muted);"><path d="M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5zm0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3z"/></svg>
                            <span style="font-weight: 600;"><?php echo number_format($article['views']); ?></span>
                        </div>
                    </td>
                    <td>
                        <div style="display: flex; flex-direction: column; gap: 0.125rem;">
                            <span style="font-size: 0.85rem; color: var(--text-secondary);">
                                <?php
                                $date = new DateTime($article['created_at']);
                                echo $date->format('Y/m/d');
                                ?>
                            </span>
                            <span style="font-size: 0.75rem; color: var(--text-muted);">
                                <?php echo $date->format('H:i'); ?>
                            </span>
                        </div>
                    </td>
                    <td>
                        <div class="actions">
                            <a href="<?php echo URL; ?>article/show/<?php echo $article['slug']; ?>" target="_blank" class="action-btn" style="background: rgba(6, 182, 212, 0.1); color: #06b6d4;" title="مشاهده">
                                <svg viewBox="0 0 24 24"><path fill="currentColor" d="M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5z"/></svg>
                            </a>
                            <a href="<?php echo URL; ?>admin/editArticle/<?php echo $article['id']; ?>" class="action-btn edit" title="ویرایش">
                                <svg viewBox="0 0 24 24"><path fill="currentColor" d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/></svg>
                            </a>
                            <button type="button" class="action-btn delete" onclick="deleteArticle(<?php echo $article['id']; ?>)" title="حذف">
                                <svg viewBox="0 0 24 24"><path fill="currentColor" d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg>
                            </button>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php else: ?>
    <div class="empty-state">
        <div style="width: 100px; height: 100px; background: linear-gradient(135deg, var(--primary-light), var(--bg-main)); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 1.5rem;">
            <svg viewBox="0 0 24 24" width="48" height="48" style="fill: var(--primary); opacity: 0.7;">
                <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6zm-1 11h-2v4H9v-4H7v-2h2V9h2v2h2v2z"/>
            </svg>
        </div>
        <h4 style="font-size: 1.25rem; margin-bottom: 0.5rem;">هنوز مقاله‌ای ثبت نشده است</h4>
        <p style="margin-bottom: 1.5rem;">اولین مقاله خود را ایجاد کنید و محتوای ارزشمند خود را به اشتراک بگذارید</p>
        <a href="<?php echo URL; ?>admin/editArticle" class="btn btn-primary">
            <svg viewBox="0 0 24 24" width="18" height="18"><path fill="currentColor" d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/></svg>
            ایجاد اولین مقاله
        </a>
    </div>
    <?php endif; ?>
</div>

<style>
    .article-row:hover td a {
        color: var(--primary) !important;
    }

    .action-btn {
        width: 34px;
        height: 34px;
        border-radius: var(--radius-sm);
        border: none;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: all 0.2s ease;
        text-decoration: none;
    }

    .action-btn svg {
        width: 16px;
        height: 16px;
        fill: currentColor;
    }

    .action-btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    }

    .action-btn.edit {
        background: var(--primary-light);
        color: var(--primary);
    }

    .action-btn.edit:hover {
        background: var(--primary);
        color: white;
    }

    .action-btn.delete {
        background: rgba(239, 68, 68, 0.1);
        color: var(--danger);
    }

    .action-btn.delete:hover {
        background: var(--danger);
        color: white;
    }

    #searchArticles:focus {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px var(--primary-light);
    }
</style>

<script>
// Delete article function
function deleteArticle(id) {
    if (confirm('آیا از حذف این مقاله اطمینان دارید؟\nاین عمل غیرقابل بازگشت است.')) {
        showLoading();
        fetch('<?php echo URL; ?>admin/deleteArticle/' + id, { method: 'POST' })
            .then(res => res.json())
            .then(result => {
                hideLoading();
                if (result.success) {
                    showToast('مقاله با موفقیت حذف شد', 'success');
                    setTimeout(() => location.reload(), 1000);
                } else {
                    showToast('خطا در حذف مقاله', 'error');
                }
            })
            .catch(() => {
                hideLoading();
                showToast('خطا در ارتباط با سرور', 'error');
            });
    }
}

// Search functionality
document.getElementById('searchArticles')?.addEventListener('input', function() {
    const searchTerm = this.value.toLowerCase();
    const rows = document.querySelectorAll('#articlesTable tbody tr');

    rows.forEach(row => {
        const title = row.querySelector('td:nth-child(3)')?.textContent.toLowerCase() || '';
        row.style.display = title.includes(searchTerm) ? '' : 'none';
    });
});
</script>

<?php
$content = ob_get_clean();
include dirname(__DIR__) . '/layout.php';
?>
