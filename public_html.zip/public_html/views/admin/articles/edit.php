<?php
$active = 'articles';
$isEdit = !empty($data['article']);
$article = $data['article'] ?? [];
ob_start();
?>

<style>
.article-form {
    display: grid;
    grid-template-columns: 2fr 1fr;
    gap: 2rem;
}

.article-form .main-content {
    display: flex;
    flex-direction: column;
    gap: 1.5rem;
}

.article-form .sidebar-content {
    display: flex;
    flex-direction: column;
    gap: 1.5rem;
}

.sidebar-card {
    background: var(--bg-light);
    border-radius: 16px;
    padding: 1.5rem;
}

.sidebar-card-title {
    font-weight: 700;
    color: var(--primary);
    margin-bottom: 1rem;
    padding-bottom: 0.75rem;
    border-bottom: 2px solid var(--secondary);
    font-size: 1rem;
}

.featured-image-upload {
    border: 2px dashed rgba(201, 160, 102, 0.3);
    border-radius: 12px;
    padding: 1.5rem;
    cursor: pointer;
    transition: all 0.3s ease;
    text-align: center;
}

.featured-image-upload:hover {
    border-color: var(--secondary);
    background: rgba(201, 160, 102, 0.05);
}

.image-preview {
    min-height: 150px;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
    gap: 0.75rem;
}

.image-preview img {
    max-width: 100%;
    max-height: 200px;
    border-radius: 8px;
    object-fit: cover;
}

.image-preview .placeholder {
    color: var(--text-light);
}

.image-preview .placeholder svg {
    fill: var(--text-light);
    margin-bottom: 0.5rem;
    display: block;
    margin: 0 auto 0.5rem;
}

.remove-image-btn {
    background: #ff4444;
    color: white;
    border: none;
    padding: 6px 12px;
    border-radius: 6px;
    cursor: pointer;
    font-size: 0.85rem;
    margin-top: 0.5rem;
}

.form-actions {
    display: flex;
    gap: 1rem;
    justify-content: flex-end;
    padding-top: 1.5rem;
    border-top: 1px solid rgba(201, 160, 102, 0.2);
}

@media (max-width: 1024px) {
    .article-form {
        grid-template-columns: 1fr;
    }
}
</style>

<div class="card">
    <div class="card-header">
        <h3 class="card-title">
            <svg viewBox="0 0 24 24"><path fill="currentColor" d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/></svg>
            <?php echo $isEdit ? 'ویرایش مقاله' : 'افزودن مقاله جدید'; ?>
        </h3>
        <a href="<?php echo URL; ?>admin/articles" class="btn btn-sm btn-outline">
            <svg viewBox="0 0 24 24" width="16" height="16"><path fill="currentColor" d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z"/></svg>
            بازگشت
        </a>
    </div>

    <form id="articleForm" style="padding: 1.5rem;">
        <input type="hidden" name="id" value="<?php echo $article['id'] ?? ''; ?>">

        <div class="article-form">
            <!-- Main Content -->
            <div class="main-content">
                <div class="form-group">
                    <label class="form-label">عنوان مقاله *</label>
                    <input type="text" class="form-control" name="title" id="article_title"
                           value="<?php echo htmlspecialchars($article['title'] ?? ''); ?>"
                           placeholder="عنوان مقاله را وارد کنید..."
                           required>
                    <span class="form-hint">عنوان جذاب و توصیفی که کاربران را به خواندن ترغیب کند</span>
                </div>

                <div class="form-group">
                    <label class="form-label">اسلاگ (انگلیسی - اختیاری)</label>
                    <input type="text" class="form-control" name="slug" id="article_slug"
                           value="<?php echo htmlspecialchars($article['slug'] ?? ''); ?>"
                           pattern="[a-z0-9\-]+" placeholder="article-title-here"
                           style="direction: ltr; text-align: left; font-family: monospace;">
                    <span class="form-hint">فقط حروف انگلیسی کوچک، اعداد و خط تیره. اگر خالی بگذارید، خودکار تولید می‌شود.</span>
                </div>

                <div class="form-group">
                    <label class="form-label">خلاصه مقاله</label>
                    <textarea class="form-control" name="excerpt" rows="3"
                              placeholder="یک خلاصه کوتاه برای نمایش در لیست مقالات..."><?php echo htmlspecialchars($article['excerpt'] ?? ''); ?></textarea>
                    <span class="form-hint">این متن در کارت مقاله و نتایج جستجو نمایش داده می‌شود (۱-۲ جمله)</span>
                </div>

                <div class="form-group">
                    <label class="form-label">محتوای مقاله *</label>
                    <textarea class="form-control" name="content" id="article_content"><?php echo $article['content'] ?? ''; ?></textarea>
                </div>
            </div>

            <!-- Sidebar -->
            <div class="sidebar-content">
                <!-- Publish Settings -->
                <div class="sidebar-card">
                    <div class="sidebar-card-title">وضعیت انتشار</div>
                    <div class="form-group" style="margin-bottom: 0;">
                        <select class="form-control" name="status" id="article_status">
                            <option value="draft" <?php echo ($article['status'] ?? 'draft') === 'draft' ? 'selected' : ''; ?>>پیش‌نویس</option>
                            <option value="published" <?php echo ($article['status'] ?? '') === 'published' ? 'selected' : ''; ?>>منتشر شده</option>
                        </select>
                    </div>
                </div>

                <!-- Featured Image -->
                <div class="sidebar-card">
                    <div class="sidebar-card-title">تصویر شاخص</div>
                    <div class="featured-image-upload" onclick="document.getElementById('featured_image_file').click()">
                        <input type="file" id="featured_image_file" accept="image/*" style="display:none;">
                        <input type="hidden" name="featured_image" id="featured_image" value="<?php echo $article['featured_image'] ?? ''; ?>">
                        <div class="image-preview" id="imagePreview">
                            <?php if (!empty($article['featured_image'])): ?>
                                <img src="<?php echo URL . $article['featured_image']; ?>" alt="">
                                <button type="button" class="remove-image-btn" onclick="event.stopPropagation(); removeImage();">حذف تصویر</button>
                            <?php else: ?>
                                <div class="placeholder">
                                    <svg viewBox="0 0 24 24" width="40" height="40"><path fill="currentColor" d="M19 7v2.99s-1.99.01-2 0V7h-3s.01-1.99 0-2h3V2h2v3h3v2h-3zm-3 4V8h-3V5H5c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2v-8h-3zM5 19l3-4 2 3 3-4 4 5H5z"/></svg>
                                    <span>کلیک کنید یا تصویر را بکشید</span>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- SEO Settings -->
                <div class="sidebar-card">
                    <div class="sidebar-card-title">تنظیمات SEO</div>

                    <div class="form-group">
                        <label class="form-label">عنوان SEO</label>
                        <input type="text" class="form-control" name="meta_title"
                               value="<?php echo htmlspecialchars($article['meta_title'] ?? ''); ?>"
                               placeholder="عنوان برای موتورهای جستجو">
                        <span class="form-hint">۵۰-۶۰ کاراکتر بهینه است</span>
                    </div>

                    <div class="form-group">
                        <label class="form-label">توضیحات SEO</label>
                        <textarea class="form-control" name="meta_description" rows="3"
                                  placeholder="توضیح کوتاه برای نتایج جستجو"><?php echo htmlspecialchars($article['meta_description'] ?? ''); ?></textarea>
                        <span class="form-hint">۱۵۰-۱۶۰ کاراکتر بهینه است</span>
                    </div>

                    <div class="form-group" style="margin-bottom: 0;">
                        <label class="form-label">کلمات کلیدی</label>
                        <input type="text" class="form-control" name="meta_keywords"
                               value="<?php echo htmlspecialchars($article['meta_keywords'] ?? ''); ?>"
                               placeholder="کلمه1، کلمه2، کلمه3">
                        <span class="form-hint">کلمات کلیدی را با کاما جدا کنید</span>
                    </div>
                </div>
            </div>
        </div>

        <div class="form-actions">
            <a href="<?php echo URL; ?>admin/articles" class="btn btn-outline">انصراف</a>
            <button type="submit" class="btn btn-primary">
                <svg viewBox="0 0 24 24" width="18" height="18" style="fill: currentColor; margin-left: 8px;"><path d="M17 3H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V7l-4-4zm-5 16c-1.66 0-3-1.34-3-3s1.34-3 3-3 3 1.34 3 3-1.34 3-3 3zm3-10H5V5h10v4z"/></svg>
                ذخیره مقاله
            </button>
        </div>
    </form>
</div>

<!-- CKEditor (Local) -->
<script src="<?php echo URL; ?>public/ckeditor/ckeditor/ckeditor.js"></script>
<script>
// راه‌اندازی CKEditor
CKEDITOR.replace('article_content', {
    language: 'fa',
    contentsLangDirection: 'rtl',
    height: 500,
    filebrowserUploadUrl: '<?php echo URL; ?>admin/uploadImage',
    filebrowserImageUploadUrl: '<?php echo URL; ?>admin/uploadImage',
    contentsCss: [
        '<?php echo URL; ?>public/assets/css/common.css'
    ],
    bodyClass: 'ckeditor-content',
    extraPlugins: 'justify,colorbutton,font',
    removeButtons: '',
    toolbar: [
        { name: 'document', items: ['Source'] },
        { name: 'clipboard', items: ['Cut', 'Copy', 'Paste', 'PasteText', '-', 'Undo', 'Redo'] },
        { name: 'editing', items: ['Find', 'Replace', '-', 'SelectAll'] },
        '/',
        { name: 'basicstyles', items: ['Bold', 'Italic', 'Underline', 'Strike', '-', 'RemoveFormat'] },
        { name: 'paragraph', items: ['NumberedList', 'BulletedList', '-', 'Outdent', 'Indent', '-', 'Blockquote', '-', 'JustifyRight', 'JustifyCenter', 'JustifyLeft', 'JustifyBlock'] },
        { name: 'links', items: ['Link', 'Unlink'] },
        { name: 'insert', items: ['Image', 'Table', 'HorizontalRule', 'SpecialChar'] },
        '/',
        { name: 'styles', items: ['Styles', 'Format', 'Font', 'FontSize'] },
        { name: 'colors', items: ['TextColor', 'BGColor'] },
        { name: 'tools', items: ['Maximize'] }
    ]
});

// تنظیم CKFinder برای آپلود تصویر
if (typeof CKFinder !== 'undefined') {
    CKFinder.setupCKEditor(null, '<?php echo URL; ?>public/ckeditor/ckeditor/ckfinder/');
}

// آپلود تصویر شاخص
document.getElementById('featured_image_file').addEventListener('change', async function(e) {
    const file = e.target.files[0];
    if (!file) return;

    // بررسی نوع فایل
    if (!file.type.startsWith('image/')) {
        showToast('لطفا فقط فایل تصویری انتخاب کنید', 'error');
        return;
    }

    // بررسی سایز (2MB)
    if (file.size > 2 * 1024 * 1024) {
        showToast('حجم فایل نباید بیشتر از 2 مگابایت باشد', 'error');
        return;
    }

    showLoading();
    const formData = new FormData();
    formData.append('file', file);

    try {
        const response = await fetch('<?php echo URL; ?>admin/uploadImage', {
            method: 'POST',
            body: formData
        });
        const result = await response.json();
        hideLoading();

        if (result.location) {
            const relativePath = result.location.replace('<?php echo URL; ?>', '');
            document.getElementById('featured_image').value = relativePath;
            document.getElementById('imagePreview').innerHTML = `
                <img src="${result.location}" alt="">
                <button type="button" class="remove-image-btn" onclick="event.stopPropagation(); removeImage();">حذف تصویر</button>
            `;
            showToast('تصویر با موفقیت آپلود شد', 'success');
        } else {
            showToast(result.error || 'خطا در آپلود', 'error');
        }
    } catch (error) {
        hideLoading();
        showToast('خطا در ارتباط با سرور', 'error');
    }
});

// حذف تصویر شاخص
function removeImage() {
    document.getElementById('featured_image').value = '';
    document.getElementById('imagePreview').innerHTML = `
        <div class="placeholder">
            <svg viewBox="0 0 24 24" width="40" height="40"><path fill="currentColor" d="M19 7v2.99s-1.99.01-2 0V7h-3s.01-1.99 0-2h3V2h2v3h3v2h-3zm-3 4V8h-3V5H5c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2v-8h-3zM5 19l3-4 2 3 3-4 4 5H5z"/></svg>
            <span>کلیک کنید یا تصویر را بکشید</span>
        </div>
    `;
}

// ارسال فرم
document.getElementById('articleForm').addEventListener('submit', async function(e) {
    e.preventDefault();

    // اعتبارسنجی
    const title = document.getElementById('article_title').value.trim();
    if (!title) {
        showToast('لطفا عنوان مقاله را وارد کنید', 'error');
        return;
    }

    showLoading();

    // دریافت محتوا از CKEditor
    for (var instance in CKEDITOR.instances) {
        CKEDITOR.instances[instance].updateElement();
    }

    const content = document.getElementById('article_content').value.trim();
    if (!content) {
        hideLoading();
        showToast('لطفا محتوای مقاله را وارد کنید', 'error');
        return;
    }

    try {
        const formData = new FormData(this);
        const response = await fetch('<?php echo URL; ?>admin/saveArticle', {
            method: 'POST',
            body: formData
        });
        const result = await response.json();
        hideLoading();

        if (result.success) {
            showToast('مقاله با موفقیت ذخیره شد', 'success');
            setTimeout(() => window.location.href = '<?php echo URL; ?>admin/articles', 1000);
        } else {
            showToast('خطا در ذخیره مقاله', 'error');
        }
    } catch (error) {
        hideLoading();
        showToast('خطا در ارتباط با سرور', 'error');
    }
});
</script>

<?php
$content = ob_get_clean();
include dirname(__DIR__) . '/layout.php';
?>
