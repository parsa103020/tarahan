<?php
$active = 'settings';
$pageTitle = 'تنظیمات سایت';
ob_start();

// Extract data
$settings = $data['settings'] ?? [];

// Group settings by category
$groupedSettings = [];
if (is_array($settings)) {
    foreach ($settings as $groupKey => $groupSettings) {
        $groupedSettings[$groupKey] = $groupSettings;
    }
}

// Group labels
$groupLabels = [
    'brand' => ['title' => 'اطلاعات برند', 'icon' => '<path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-7 3c1.93 0 3.5 1.57 3.5 3.5S13.93 13 12 13s-3.5-1.57-3.5-3.5S10.07 6 12 6zm7 13H5v-.23c0-.62.28-1.2.76-1.58C7.47 15.82 9.64 15 12 15s4.53.82 6.24 2.19c.48.38.76.97.76 1.58V19z"/>'],
    'contact' => ['title' => 'اطلاعات تماس', 'icon' => '<path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"/>'],
    'hours' => ['title' => 'ساعات کاری', 'icon' => '<path d="M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67z"/>'],
    'social' => ['title' => 'شبکه‌های اجتماعی', 'icon' => '<path d="M18 16.08c-.76 0-1.44.3-1.96.77L8.91 12.7c.05-.23.09-.46.09-.7s-.04-.47-.09-.7l7.05-4.11c.54.5 1.25.81 2.04.81 1.66 0 3-1.34 3-3s-1.34-3-3-3-3 1.34-3 3c0 .24.04.47.09.7L8.04 9.81C7.5 9.31 6.79 9 6 9c-1.66 0-3 1.34-3 3s1.34 3 3 3c.79 0 1.5-.31 2.04-.81l7.12 4.16c-.05.21-.08.43-.08.65 0 1.61 1.31 2.92 2.92 2.92s2.92-1.31 2.92-2.92c0-1.61-1.31-2.92-2.92-2.92zM18 4c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1zM6 13c-.55 0-1-.45-1-1s.45-1 1-1 1 .45 1 1-.45 1-1 1zm12 7.02c-.55 0-1-.45-1-1s.45-1 1-1 1 .45 1 1-.45 1-1 1z"/>'],
    'seo' => ['title' => 'سئو و متا', 'icon' => '<path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/>'],
    'general' => ['title' => 'تنظیمات عمومی', 'icon' => '<path d="M19.14 12.94c.04-.31.06-.63.06-.94 0-.31-.02-.63-.06-.94l2.03-1.58a.49.49 0 0 0 .12-.61l-1.92-3.32a.49.49 0 0 0-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54a.484.484 0 0 0-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96a.49.49 0 0 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.04.31-.06.63-.06.94s.02.63.06.94l-2.03 1.58a.49.49 0 0 0-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z"/>']
];

// Setting labels
$settingLabels = [
    'brand_name' => 'نام برند',
    'brand_full_name' => 'نام کامل شرکت',
    'brand_slogan' => 'شعار برند',
    'brand_location' => 'موقعیت',
    'brand_industry' => 'حوزه فعالیت',
    'phone_mobile' => 'تلفن همراه',
    'phone_landline' => 'تلفن ثابت',
    'email' => 'ایمیل',
    'address' => 'آدرس',
    'postal_code' => 'کد پستی',
    'working_days' => 'روزهای کاری',
    'working_hours' => 'ساعات کاری',
    'instagram' => 'اینستاگرام',
    'telegram' => 'تلگرام',
    'whatsapp' => 'واتساپ',
    'linkedin' => 'لینکدین',
    'meta_title' => 'عنوان متا',
    'meta_description' => 'توضیحات متا',
    'meta_keywords' => 'کلمات کلیدی'
];

// Setting hints
$settingHints = [
    'brand_name' => 'نام کوتاه برند که در لوگو و سربرگ نمایش داده می‌شود',
    'brand_full_name' => 'نام رسمی و کامل شرکت برای اسناد و فاکتورها',
    'brand_slogan' => 'جمله کوتاه و به‌یادماندنی که هویت برند را منتقل می‌کند',
    'brand_location' => 'شهر یا استان محل فعالیت شرکت',
    'brand_industry' => 'حوزه تخصصی فعالیت شرکت',
    'phone_mobile' => 'شماره موبایل اصلی برای تماس مشتریان',
    'phone_landline' => 'شماره تلفن ثابت دفتر با پیش‌شماره شهر',
    'email' => 'ایمیل رسمی شرکت برای مکاتبات',
    'address' => 'آدرس کامل دفتر شرکت با جزئیات',
    'postal_code' => 'کد پستی ۱۰ رقمی محل شرکت',
    'working_days' => 'روزهای هفته که شرکت فعال است',
    'working_hours' => 'ساعت شروع و پایان کار در روزهای کاری',
    'instagram' => 'نام کاربری اینستاگرام بدون @ (فقط نام)',
    'telegram' => 'آیدی تلگرام بدون @ یا لینک کانال',
    'whatsapp' => 'شماره واتساپ با فرمت بین‌المللی',
    'linkedin' => 'لینک صفحه شرکت در لینکدین',
    'meta_title' => 'عنوان سایت در نتایج گوگل (۵۰-۶۰ کاراکتر بهینه)',
    'meta_description' => 'توضیح کوتاه سایت در نتایج گوگل (۱۵۰-۱۶۰ کاراکتر بهینه)',
    'meta_keywords' => 'کلمات کلیدی مرتبط با کسب‌وکار، با کاما جدا شوند'
];

// Setting placeholders
$settingPlaceholders = [
    'brand_name' => 'طراحان باستان',
    'brand_full_name' => 'شرکت آرین طراحان باستان',
    'brand_slogan' => 'با ما غیرممکن وجود نداره',
    'brand_location' => 'همدان',
    'brand_industry' => 'تبلیغات و رویداد',
    'phone_mobile' => '۰۹۱۲۱۲۳۴۵۶۷',
    'phone_landline' => '۰۸۱-۳۸۲۵۱۲۳۴',
    'email' => 'info@example.com',
    'address' => 'همدان، خیابان بوعلی، ساختمان تجاری، طبقه ۳',
    'postal_code' => '۶۵۱۴۸۱۲۳۴۵',
    'working_days' => 'شنبه تا چهارشنبه',
    'working_hours' => '۹ صبح تا ۶ عصر',
    'instagram' => 'tarahan_bastan',
    'telegram' => 'tarahanbastan',
    'whatsapp' => '+989121234567',
    'linkedin' => 'https://linkedin.com/company/tarahan-bastan',
    'meta_title' => 'طراحان باستان | خدمات تبلیغات و رویداد در همدان',
    'meta_description' => 'شرکت طراحان باستان ارائه‌دهنده خدمات غرفه‌سازی، تبلیغات محیطی، برگزاری رویداد و...',
    'meta_keywords' => 'غرفه نمایشگاهی، تبلیغات محیطی، برگزاری همایش'
];
?>

<form id="settingsForm">
    <?php foreach ($groupLabels as $groupKey => $groupInfo): ?>
        <?php if (isset($groupedSettings[$groupKey])): ?>
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">
                        <svg viewBox="0 0 24 24"><?php echo $groupInfo['icon']; ?></svg>
                        <?php echo $groupInfo['title']; ?>
                    </h3>
                </div>
                <div class="row">
                    <?php foreach ($groupedSettings[$groupKey] as $setting): ?>
                        <div class="col-6">
                            <div class="form-group">
                                <label class="form-label" for="<?php echo $setting['setting_key']; ?>">
                                    <?php echo $settingLabels[$setting['setting_key']] ?? $setting['setting_key']; ?>
                                </label>
                                <?php if (in_array($setting['setting_key'], ['address', 'meta_description'])): ?>
                                    <textarea class="form-control" id="<?php echo $setting['setting_key']; ?>" name="settings[<?php echo $setting['setting_key']; ?>]" rows="3" placeholder="<?php echo $settingPlaceholders[$setting['setting_key']] ?? ''; ?>"><?php echo htmlspecialchars($setting['setting_value'] ?? ''); ?></textarea>
                                <?php else: ?>
                                    <input type="text" class="form-control" id="<?php echo $setting['setting_key']; ?>" name="settings[<?php echo $setting['setting_key']; ?>]" value="<?php echo htmlspecialchars($setting['setting_value'] ?? ''); ?>" placeholder="<?php echo $settingPlaceholders[$setting['setting_key']] ?? ''; ?>">
                                <?php endif; ?>
                                <?php if (isset($settingHints[$setting['setting_key']])): ?>
                                    <span class="form-hint"><?php echo $settingHints[$setting['setting_key']]; ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>
    <?php endforeach; ?>

    <div class="card" style="background: linear-gradient(135deg, var(--primary) 0%, var(--primary-light) 100%); color: white;">
        <div class="d-flex justify-between align-center">
            <div>
                <h3 style="margin-bottom: 0.5rem;">ذخیره تغییرات</h3>
                <p style="opacity: 0.8; font-size: 0.9rem;">پس از اعمال تغییرات، دکمه ذخیره را بزنید</p>
            </div>
            <button type="submit" class="btn btn-secondary">
                <svg viewBox="0 0 24 24"><path fill="currentColor" d="M17 3H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V7l-4-4zm-5 16c-1.66 0-3-1.34-3-3s1.34-3 3-3 3 1.34 3 3-1.34 3-3 3zm3-10H5V5h10v4z"/></svg>
                ذخیره تنظیمات
            </button>
        </div>
    </div>
</form>

<script>
    document.getElementById('settingsForm').addEventListener('submit', async function(e) {
        e.preventDefault();
        showLoading();

        try {
            const formData = new FormData(this);
            const response = await fetch('<?php echo URL; ?>admin/saveSettings', {
                method: 'POST',
                body: formData
            });
            const result = await response.json();

            hideLoading();

            if (result.success) {
                showToast('تنظیمات با موفقیت ذخیره شد', 'success');
            } else {
                showToast('خطا در ذخیره تنظیمات', 'error');
            }
        } catch (error) {
            hideLoading();
            showToast('خطا در ارتباط با سرور', 'error');
        }
    });
</script>

<?php
$content = ob_get_clean();
include dirname(__DIR__) . '/layout.php';
?>
