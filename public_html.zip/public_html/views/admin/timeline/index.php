<?php
$active = 'timeline';
$pageTitle = 'مدیریت تاریخچه';
ob_start();

// Extract data
$timeline = $data['timeline'] ?? [];
?>

<div class="card">
    <div class="card-header">
        <h3 class="card-title">
            <svg viewBox="0 0 24 24"><path fill="currentColor" d="M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67z"/></svg>
            تاریخچه شرکت
        </h3>
        <button type="button" class="btn btn-sm btn-secondary" onclick="openAddModal()">
            <svg viewBox="0 0 24 24" width="16" height="16"><path fill="currentColor" d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/></svg>
            افزودن رویداد
        </button>
    </div>
    <p class="form-hint" style="margin-bottom: 1rem;">رویدادهای مهم و نقاط عطف شرکت که در صفحه درباره ما نمایش داده می‌شوند. به ترتیب سال مرتب کنید.</p>

    <?php if (!empty($timeline)): ?>
        <div class="timeline-container">
            <?php foreach ($timeline as $item): ?>
                <div class="item-card timeline-item">
                    <div class="item-actions">
                        <button type="button" class="action-btn edit" onclick='editTimeline(<?php echo json_encode($item, JSON_HEX_APOS | JSON_HEX_QUOT); ?>)' title="ویرایش این رویداد">
                            <svg viewBox="0 0 24 24"><path fill="currentColor" d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/></svg>
                        </button>
                        <button type="button" class="action-btn delete" onclick="deleteTimeline(<?php echo $item['id']; ?>)" title="حذف این رویداد">
                            <svg viewBox="0 0 24 24"><path fill="currentColor" d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg>
                        </button>
                    </div>
                    <div class="timeline-year"><?php echo htmlspecialchars($item['year']); ?></div>
                    <div class="timeline-title"><?php echo htmlspecialchars($item['title']); ?></div>
                    <?php if (!empty($item['description'])): ?>
                        <div class="timeline-desc"><?php echo htmlspecialchars($item['description']); ?></div>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div class="empty-state">
            <svg viewBox="0 0 24 24">
                <path d="M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67z"/>
            </svg>
            <h4>تاریخچه‌ای ثبت نشده است</h4>
            <p>رویدادهای مهم شرکت را اینجا اضافه کنید تا در صفحه درباره ما نمایش داده شوند</p>
            <button type="button" class="btn btn-primary mt-2" onclick="openAddModal()">
                <svg viewBox="0 0 24 24" width="18" height="18"><path fill="currentColor" d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/></svg>
                افزودن اولین رویداد
            </button>
        </div>
    <?php endif; ?>
</div>

<style>
.timeline-container {
    display: flex;
    flex-direction: column;
    gap: 1rem;
}

.timeline-item {
    padding-right: 1.5rem;
    border-right: 3px solid var(--secondary);
}

.timeline-year {
    font-size: 1.5rem;
    font-weight: 800;
    color: var(--secondary);
    margin-bottom: 0.5rem;
}

.timeline-title {
    font-weight: 700;
    color: var(--text-primary);
    margin-bottom: 0.5rem;
    font-size: 1.05rem;
}

.timeline-desc {
    color: var(--text-secondary);
    font-size: 0.9rem;
    line-height: 1.7;
}
</style>

<!-- Add/Edit Modal -->
<div class="modal-overlay" id="addTimelineModal">
    <div class="modal">
        <div class="modal-header">
            <h3 class="modal-title" id="timelineModalTitle">افزودن رویداد جدید</h3>
            <button type="button" class="modal-close" onclick="closeModal('addTimelineModal')">
                <svg viewBox="0 0 24 24"><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg>
            </button>
        </div>
        <form id="timelineForm">
            <div class="modal-body">
                <input type="hidden" name="id" id="timeline_id">

                <div class="form-group">
                    <label class="form-label">سال رویداد *</label>
                    <input type="text" class="form-control" name="year" id="timeline_year" placeholder="۱۳۹۷" required>
                    <span class="form-hint">سال شمسی که رویداد در آن اتفاق افتاده است</span>
                </div>
                <div class="form-group">
                    <label class="form-label">عنوان رویداد *</label>
                    <input type="text" class="form-control" name="title" id="timeline_title" placeholder="مثال: تاسیس شرکت" required>
                    <span class="form-hint">یک عنوان کوتاه و گویا برای این رویداد</span>
                </div>
                <div class="form-group">
                    <label class="form-label">توضیحات</label>
                    <textarea class="form-control" name="description" id="timeline_description" rows="3" placeholder="شرح مختصری از این رویداد مهم..."></textarea>
                    <span class="form-hint">توضیح بیشتر درباره این رویداد (اختیاری)</span>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline" onclick="closeModal('addTimelineModal')">انصراف</button>
                <button type="submit" class="btn btn-primary">
                    <svg viewBox="0 0 24 24" width="18" height="18"><path fill="currentColor" d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>
                    ذخیره رویداد
                </button>
            </div>
        </form>
    </div>
</div>

<script>
    function openAddModal() {
        document.getElementById('timelineModalTitle').textContent = 'افزودن رویداد جدید';
        document.getElementById('timelineForm').reset();
        document.getElementById('timeline_id').value = '';
        openModal('addTimelineModal');
    }

    function editTimeline(item) {
        document.getElementById('timelineModalTitle').textContent = 'ویرایش رویداد';
        document.getElementById('timeline_id').value = item.id;
        document.getElementById('timeline_year').value = item.year;
        document.getElementById('timeline_title').value = item.title;
        document.getElementById('timeline_description').value = item.description || '';
        openModal('addTimelineModal');
    }

    function deleteTimeline(id) {
        confirmDelete('<?php echo URL; ?>admin/deleteTimelineItem/' + id, () => {
            location.reload();
        });
    }

    document.getElementById('timelineForm').addEventListener('submit', async function(e) {
        e.preventDefault();
        showLoading();

        try {
            const formData = new FormData(this);
            const response = await fetch('<?php echo URL; ?>admin/saveTimelineItem', {
                method: 'POST',
                body: formData
            });
            const result = await response.json();

            hideLoading();

            if (result.success) {
                showToast('رویداد با موفقیت ذخیره شد', 'success');
                setTimeout(() => location.reload(), 1000);
            } else {
                showToast('خطا در ذخیره', 'error');
            }
        } catch (error) {
            hideLoading();
            showToast('خطا در ارتباط با سرور', 'error');
        }
    });
</script>

<?php
$content = ob_get_clean();
include dirname(__DIR__) . '/layout.php';
?>
