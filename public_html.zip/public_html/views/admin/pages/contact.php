<?php
$active = 'contact';
$pageTitle = 'تنظیمات صفحه تماس';
ob_start();

// Extract data from $data array
$hero = $data['hero'] ?? [];
$faq = $data['faq'] ?? [];

// For page_content, data is already key=>value from getPageContent()
$heroContent = $hero;
?>

<form id="contactForm">
    <!-- Hero Section -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">
                <svg viewBox="0 0 24 24"><path fill="currentColor" d="M21 3H3c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h18c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H3V5h18v14z"/></svg>
                بخش هیرو
            </h3>
        </div>
        <div class="row">
            <div class="col-6">
                <div class="form-group">
                    <label class="form-label">متن نشان</label>
                    <input type="text" class="form-control" name="hero[badge]" value="<?php echo htmlspecialchars($heroContent['badge'] ?? ''); ?>" placeholder="تماس با ما">
                    <span class="form-hint">متن کوتاه بالای عنوان. مثال: <code>تماس با ما</code> یا <code>در خدمت شما هستیم</code></span>
                </div>
            </div>
            <div class="col-6">
                <div class="form-group">
                    <label class="form-label">عنوان اصلی</label>
                    <input type="text" class="form-control" name="hero[title]" value="<?php echo htmlspecialchars($heroContent['title'] ?? ''); ?>" placeholder="با ما در ارتباط باشید">
                    <span class="form-hint">عنوان اصلی صفحه تماس با ما</span>
                </div>
            </div>
            <div class="col-12">
                <div class="form-group">
                    <label class="form-label">زیرعنوان</label>
                    <textarea class="form-control" name="hero[subtitle]" rows="2" placeholder="سوالی دارید؟ می‌خواهید درباره پروژه‌تان صحبت کنیم؟ با ما تماس بگیرید..."><?php echo htmlspecialchars($heroContent['subtitle'] ?? ''); ?></textarea>
                    <span class="form-hint">توضیح کوتاه زیر عنوان - کاربر را به تماس تشویق کنید</span>
                </div>
            </div>
        </div>
    </div>

    <!-- FAQ Section -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">
                <svg viewBox="0 0 24 24"><path fill="currentColor" d="M11 18h2v-2h-2v2zm1-16C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm0-14c-2.21 0-4 1.79-4 4h2c0-1.1.9-2 2-2s2 .9 2 2c0 2-3 1.75-3 5h2c0-2.25 3-2.5 3-5 0-2.21-1.79-4-4-4z"/></svg>
                سوالات متداول صفحه تماس
            </h3>
            <a href="<?php echo URL; ?>admin/faq" class="btn btn-sm btn-outline">مدیریت سوالات</a>
        </div>
        <?php if (isset($faq) && count($faq) > 0): ?>
            <div style="display: flex; flex-direction: column; gap: 1rem;">
                <?php foreach ($faq as $item): ?>
                    <div style="background: var(--bg-light); padding: 1.5rem; border-radius: 12px;">
                        <div style="font-weight: 700; color: var(--primary); margin-bottom: 0.5rem;">
                            <?php echo htmlspecialchars($item['question']); ?>
                        </div>
                        <div style="font-size: 0.9rem; color: var(--text-light); line-height: 1.8;">
                            <?php echo htmlspecialchars($item['answer']); ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="empty-state">
                <p>سوالی ثبت نشده است</p>
                <a href="<?php echo URL; ?>admin/faq" class="btn btn-sm btn-primary mt-2">افزودن سوال متداول</a>
            </div>
        <?php endif; ?>
    </div>

    <!-- Contact Info Note -->
    <div class="card" style="background: rgba(201, 160, 102, 0.1); border: 1px solid rgba(201, 160, 102, 0.3);">
        <div class="d-flex align-center gap-1">
            <svg viewBox="0 0 24 24" width="24" height="24" style="fill: var(--secondary); flex-shrink: 0;">
                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"/>
            </svg>
            <div>
                <h4 style="color: var(--primary); margin-bottom: 0.25rem;">اطلاعات تماس</h4>
                <p style="color: var(--text-light); font-size: 0.9rem; margin: 0;">
                    برای ویرایش شماره تماس، ایمیل، آدرس و ساعات کاری به
                    <a href="<?php echo URL; ?>admin/settings" style="color: var(--secondary);">بخش تنظیمات</a>
                    مراجعه کنید.
                </p>
            </div>
        </div>
    </div>

    <!-- Save Button -->
    <div class="card" style="background: linear-gradient(135deg, var(--primary) 0%, var(--primary-light) 100%); color: white;">
        <div class="d-flex justify-between align-center">
            <div>
                <h3 style="margin-bottom: 0.5rem;">ذخیره تغییرات</h3>
                <p style="opacity: 0.8; font-size: 0.9rem;">پس از اعمال تغییرات، دکمه ذخیره را بزنید</p>
            </div>
            <button type="submit" class="btn btn-secondary">
                <svg viewBox="0 0 24 24"><path fill="currentColor" d="M17 3H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V7l-4-4zm-5 16c-1.66 0-3-1.34-3-3s1.34-3 3-3 3 1.34 3 3-1.34 3-3 3zm3-10H5V5h10v4z"/></svg>
                ذخیره صفحه تماس
            </button>
        </div>
    </div>
</form>

<script>
    document.getElementById('contactForm').addEventListener('submit', async function(e) {
        e.preventDefault();
        showLoading();

        try {
            const formData = new FormData(this);
            const response = await fetch('<?php echo URL; ?>admin/saveContact', {
                method: 'POST',
                body: formData
            });
            const result = await response.json();

            hideLoading();

            if (result.success) {
                showToast('صفحه تماس با موفقیت ذخیره شد', 'success');
            } else {
                showToast('خطا در ذخیره', 'error');
            }
        } catch (error) {
            hideLoading();
            showToast('خطا در ارتباط با سرور', 'error');
        }
    });
</script>

<?php
$content = ob_get_clean();
include dirname(__DIR__) . '/layout.php';
?>
