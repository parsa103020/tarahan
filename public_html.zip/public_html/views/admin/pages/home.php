<?php
$active = 'home';
$pageTitle = 'تنظیمات صفحه اصلی';
ob_start();

// Extract data from $data array
$hero = $data['hero'] ?? [];
$cta = $data['cta'] ?? [];
$stats = $data['stats'] ?? [];
$testimonials = $data['testimonials'] ?? [];
$process = $data['process'] ?? [];
?>

<form id="homeForm">
    <!-- Hero Section -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">
                <svg viewBox="0 0 24 24"><path fill="currentColor" d="M21 3H3c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h18c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H3V5h18v14z"/></svg>
                بخش هیرو (بالای صفحه)
            </h3>
        </div>
        <div class="row">
            <div class="col-6">
                <div class="form-group">
                    <label class="form-label">متن نشان (Badge)</label>
                    <input type="text" class="form-control" name="hero[badge]" value="<?php echo htmlspecialchars($hero['badge'] ?? ''); ?>" placeholder="بیش از ۱۰ سال تجربه">
                    <span class="form-hint">متن کوتاهی که در بالای عنوان اصلی نمایش داده می‌شود. مثال: <code>بیش از ۱۰ سال تجربه</code></span>
                </div>
            </div>
            <div class="col-6">
                <div class="form-group">
                    <label class="form-label">عنوان اصلی</label>
                    <input type="text" class="form-control" name="hero[title]" value="<?php echo htmlspecialchars($hero['title'] ?? ''); ?>" placeholder="با ما غیرممکن وجود نداره">
                    <span class="form-hint">عنوان بزرگ و اصلی که در Hero نمایش داده می‌شود. مثال: <code>با ما غیرممکن وجود نداره</code></span>
                </div>
            </div>
            <div class="col-12">
                <div class="form-group">
                    <label class="form-label">زیرعنوان</label>
                    <textarea class="form-control" name="hero[subtitle]" rows="2" placeholder="ما کنار شما می‌ایستیم و بهترین راه‌حل‌ها را برای کسب‌وکارتان پیدا می‌کنیم..."><?php echo htmlspecialchars($hero['subtitle'] ?? ''); ?></textarea>
                    <span class="form-hint">توضیح کوتاه زیر عنوان اصلی که خدمات شرکت را معرفی می‌کند</span>
                </div>
            </div>
            <div class="col-6">
                <div class="form-group">
                    <label class="form-label">متن دکمه اصلی</label>
                    <input type="text" class="form-control" name="hero[cta_primary_text]" value="<?php echo htmlspecialchars($hero['cta_primary_text'] ?? ''); ?>" placeholder="با ما تماس بگیرید">
                    <span class="form-hint">متن دکمه فراخوان اقدام. مثال: <code>با ما تماس بگیرید</code> یا <code>مشاوره رایگان</code></span>
                </div>
            </div>
            <div class="col-6">
                <div class="form-group">
                    <label class="form-label">لینک دکمه اصلی</label>
                    <input type="text" class="form-control" name="hero[cta_primary_link]" value="<?php echo htmlspecialchars($hero['cta_primary_link'] ?? ''); ?>" placeholder="/contact" style="direction: ltr;">
                    <span class="form-hint">آدرس صفحه مقصد دکمه. مثال: <code>/contact</code> یا <code>tel:09123456789</code></span>
                </div>
            </div>
        </div>
    </div>

    <!-- Stats Section -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">
                <svg viewBox="0 0 24 24"><path fill="currentColor" d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zM9 17H7v-7h2v7zm4 0h-2V7h2v10zm4 0h-2v-4h2v4z"/></svg>
                آمار و ارقام
            </h3>
            <a href="<?php echo URL; ?>admin/stats" class="btn btn-sm btn-outline">مدیریت آمار</a>
        </div>
        <p class="form-hint" style="margin-bottom: 1rem;">این آمار در صفحه اصلی نمایش داده می‌شود. برای ویرایش روی دکمه "مدیریت آمار" کلیک کنید.</p>
        <?php if (isset($stats) && count($stats) > 0): ?>
            <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 1rem;">
                <?php foreach ($stats as $stat): ?>
                    <div style="background: var(--bg-main); padding: 1rem; border-radius: 12px; text-align: center; border: 1px solid var(--border-color);">
                        <div style="font-size: 2rem; font-weight: 800; color: var(--primary);"><?php echo $stat['stat_prefix'] ?? ''; ?><?php echo htmlspecialchars($stat['stat_value']); ?><?php echo $stat['stat_suffix'] ?? ''; ?></div>
                        <div style="color: var(--text-muted); font-size: 0.9rem;"><?php echo htmlspecialchars($stat['stat_label']); ?></div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="empty-state">
                <p>آماری ثبت نشده است</p>
                <a href="<?php echo URL; ?>admin/stats" class="btn btn-sm btn-primary mt-2">افزودن آمار</a>
            </div>
        <?php endif; ?>
    </div>

    <!-- Testimonials Section -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">
                <svg viewBox="0 0 24 24"><path fill="currentColor" d="M6 17c0-2 4-3.1 6-3.1s6 1.1 6 3.1v1H6v-1zM12 12c-1.7 0-3-1.3-3-3s1.3-3 3-3 3 1.3 3 3-1.3 3-3 3z"/></svg>
                نظرات مشتریان
            </h3>
            <a href="<?php echo URL; ?>admin/testimonials" class="btn btn-sm btn-outline">مدیریت نظرات</a>
        </div>
        <?php if (isset($testimonials) && count($testimonials) > 0): ?>
            <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 1rem;">
                <?php foreach ($testimonials as $testimonial): ?>
                    <div style="background: var(--bg-light); padding: 1.5rem; border-radius: 12px;">
                        <p style="color: var(--text-dark); line-height: 1.8; margin-bottom: 1rem;">"<?php echo htmlspecialchars($testimonial['content']); ?>"</p>
                        <div style="display: flex; align-items: center; gap: 0.75rem;">
                            <div style="width: 40px; height: 40px; background: var(--primary); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-weight: 700;">
                                <?php echo mb_substr($testimonial['author_name'], 0, 1, 'UTF-8'); ?>
                            </div>
                            <div>
                                <div style="font-weight: 600;"><?php echo htmlspecialchars($testimonial['author_name']); ?></div>
                                <div style="font-size: 0.8rem; color: var(--text-light);"><?php echo htmlspecialchars($testimonial['author_position'] ?? ''); ?></div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="empty-state">
                <p>نظری ثبت نشده است</p>
                <a href="<?php echo URL; ?>admin/testimonials" class="btn btn-sm btn-primary mt-2">افزودن نظر مشتری</a>
            </div>
        <?php endif; ?>
    </div>

    <!-- Process Steps -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">
                <svg viewBox="0 0 24 24"><path fill="currentColor" d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6zm-1 11h-2v4H9v-4H7v-2h2V9h2v2h2v2z"/></svg>
                فرآیند کار
            </h3>
            <a href="<?php echo URL; ?>admin/process" class="btn btn-sm btn-outline">مدیریت فرآیند</a>
        </div>
        <?php if (isset($process) && count($process) > 0): ?>
            <div style="display: flex; flex-wrap: wrap; gap: 1rem;">
                <?php foreach ($process as $step): ?>
                    <div style="flex: 1; min-width: 200px; background: var(--bg-light); padding: 1.5rem; border-radius: 12px; text-align: center;">
                        <div style="width: 40px; height: 40px; background: var(--secondary); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: var(--primary); font-weight: 800; margin: 0 auto 1rem;">
                            <?php echo $step['step_number']; ?>
                        </div>
                        <div style="font-weight: 600; margin-bottom: 0.5rem;"><?php echo htmlspecialchars($step['title']); ?></div>
                        <div style="font-size: 0.85rem; color: var(--text-light);"><?php echo htmlspecialchars($step['description'] ?? ''); ?></div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="empty-state">
                <p>مرحله‌ای ثبت نشده است</p>
                <a href="<?php echo URL; ?>admin/process" class="btn btn-sm btn-primary mt-2">افزودن مراحل کار</a>
            </div>
        <?php endif; ?>
    </div>

    <!-- CTA Section -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">
                <svg viewBox="0 0 24 24"><path fill="currentColor" d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/></svg>
                بخش CTA انتهایی
            </h3>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="form-group">
                    <label class="form-label">عنوان</label>
                    <input type="text" class="form-control" name="cta[title]" value="<?php echo htmlspecialchars($cta['title'] ?? ''); ?>" placeholder="آماده همکاری هستید؟">
                    <span class="form-hint">عنوان بخش CTA در انتهای صفحه. مثال: <code>آماده همکاری هستید؟</code></span>
                </div>
            </div>
            <div class="col-12">
                <div class="form-group">
                    <label class="form-label">توضیحات</label>
                    <textarea class="form-control" name="cta[subtitle]" rows="2" placeholder="با ما تماس بگیرید تا درباره پروژه‌تان صحبت کنیم..."><?php echo htmlspecialchars($cta['subtitle'] ?? ''); ?></textarea>
                    <span class="form-hint">متن توضیحی کوتاه زیر عنوان CTA</span>
                </div>
            </div>
            <div class="col-6">
                <div class="form-group">
                    <label class="form-label">متن دکمه</label>
                    <input type="text" class="form-control" name="cta[button_text]" value="<?php echo htmlspecialchars($cta['button_text'] ?? ''); ?>" placeholder="شروع همکاری">
                    <span class="form-hint">متن دکمه CTA. مثال: <code>شروع همکاری</code> یا <code>درخواست مشاوره</code></span>
                </div>
            </div>
            <div class="col-6">
                <div class="form-group">
                    <label class="form-label">لینک دکمه</label>
                    <input type="text" class="form-control" name="cta[button_link]" value="<?php echo htmlspecialchars($cta['button_link'] ?? ''); ?>" placeholder="/contact" style="direction: ltr;">
                    <span class="form-hint">آدرس مقصد دکمه. مثال: <code>/contact</code></span>
                </div>
            </div>
        </div>
    </div>

    <!-- Save Button -->
    <div class="card" style="background: linear-gradient(135deg, var(--primary) 0%, var(--primary-light) 100%); color: white;">
        <div class="d-flex justify-between align-center">
            <div>
                <h3 style="margin-bottom: 0.5rem;">ذخیره تغییرات</h3>
                <p style="opacity: 0.8; font-size: 0.9rem;">پس از اعمال تغییرات، دکمه ذخیره را بزنید</p>
            </div>
            <button type="submit" class="btn btn-secondary">
                <svg viewBox="0 0 24 24"><path fill="currentColor" d="M17 3H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V7l-4-4zm-5 16c-1.66 0-3-1.34-3-3s1.34-3 3-3 3 1.34 3 3-1.34 3-3 3zm3-10H5V5h10v4z"/></svg>
                ذخیره صفحه اصلی
            </button>
        </div>
    </div>
</form>

<script>
    document.getElementById('homeForm').addEventListener('submit', async function(e) {
        e.preventDefault();
        showLoading();

        try {
            const formData = new FormData(this);
            const response = await fetch('<?php echo URL; ?>admin/saveHome', {
                method: 'POST',
                body: formData
            });
            const result = await response.json();

            hideLoading();

            if (result.success) {
                showToast('صفحه اصلی با موفقیت ذخیره شد', 'success');
            } else {
                showToast('خطا در ذخیره', 'error');
            }
        } catch (error) {
            hideLoading();
            showToast('خطا در ارتباط با سرور', 'error');
        }
    });
</script>

<?php
$content = ob_get_clean();
include dirname(__DIR__) . '/layout.php';
?>
