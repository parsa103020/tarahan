<?php
$active = 'about';
$pageTitle = 'تنظیمات صفحه درباره ما';
ob_start();

// Extract data from $data array
$hero = $data['hero'] ?? [];
$manifesto = $data['manifesto'] ?? [];
$cta = $data['cta'] ?? [];
$timeline = $data['timeline'] ?? [];
$values = $data['values'] ?? [];
$stats = $data['stats'] ?? [];

// For page_content, data is already key=>value from getPageContent()
$heroContent = $hero;
$manifestoContent = $manifesto;
$ctaContent = $cta;
?>

<form id="aboutForm">
    <!-- Hero Section -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">
                <svg viewBox="0 0 24 24"><path fill="currentColor" d="M21 3H3c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h18c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H3V5h18v14z"/></svg>
                بخش هیرو
            </h3>
        </div>
        <div class="row">
            <div class="col-6">
                <div class="form-group">
                    <label class="form-label">متن نشان</label>
                    <input type="text" class="form-control" name="hero[badge]" value="<?php echo htmlspecialchars($heroContent['badge'] ?? ''); ?>" placeholder="داستان ما">
                    <span class="form-hint">متن کوتاه بالای عنوان. مثال: <code>داستان ما</code> یا <code>درباره طراحان باستان</code></span>
                </div>
            </div>
            <div class="col-6">
                <div class="form-group">
                    <label class="form-label">عنوان اصلی</label>
                    <input type="text" class="form-control" name="hero[title]" value="<?php echo htmlspecialchars($heroContent['title'] ?? ''); ?>" placeholder="با افتخار در کنار شما">
                    <span class="form-hint">عنوان اصلی صفحه درباره ما</span>
                </div>
            </div>
            <div class="col-12">
                <div class="form-group">
                    <label class="form-label">زیرعنوان</label>
                    <textarea class="form-control" name="hero[subtitle]" rows="2" placeholder="از سال ۱۳۹۷ با افتخار در خدمت کسب‌وکارهای ایرانی هستیم..."><?php echo htmlspecialchars($heroContent['subtitle'] ?? ''); ?></textarea>
                    <span class="form-hint">توضیح کوتاه درباره شرکت</span>
                </div>
            </div>
        </div>
    </div>

    <!-- Timeline Section -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">
                <svg viewBox="0 0 24 24"><path fill="currentColor" d="M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67z"/></svg>
                تاریخچه شرکت
            </h3>
            <a href="<?php echo URL; ?>admin/timeline" class="btn btn-sm btn-outline">مدیریت تاریخچه</a>
        </div>
        <?php if (isset($timeline) && count($timeline) > 0): ?>
            <div style="display: flex; flex-wrap: wrap; gap: 1rem;">
                <?php foreach ($timeline as $item): ?>
                    <div style="flex: 1; min-width: 200px; background: var(--bg-light); padding: 1.5rem; border-radius: 12px;">
                        <div style="font-size: 1.5rem; font-weight: 800; color: var(--secondary); margin-bottom: 0.5rem;">
                            <?php echo htmlspecialchars($item['year']); ?>
                        </div>
                        <div style="font-weight: 600; margin-bottom: 0.5rem;"><?php echo htmlspecialchars($item['title']); ?></div>
                        <div style="font-size: 0.85rem; color: var(--text-light);"><?php echo htmlspecialchars($item['description'] ?? ''); ?></div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="empty-state">
                <p>تاریخچه‌ای ثبت نشده است</p>
                <a href="<?php echo URL; ?>admin/timeline" class="btn btn-sm btn-primary mt-2">افزودن تاریخچه</a>
            </div>
        <?php endif; ?>
    </div>

    <!-- Values Section -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">
                <svg viewBox="0 0 24 24"><path fill="currentColor" d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>
                ارزش‌های شرکت
            </h3>
            <a href="<?php echo URL; ?>admin/values" class="btn btn-sm btn-outline">مدیریت ارزش‌ها</a>
        </div>
        <?php if (isset($values) && count($values) > 0): ?>
            <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 1rem;">
                <?php foreach ($values as $value): ?>
                    <div style="background: var(--bg-light); padding: 1.5rem; border-radius: 12px;">
                        <div style="font-weight: 700; color: var(--primary); margin-bottom: 0.5rem;"><?php echo htmlspecialchars($value['title']); ?></div>
                        <div style="font-size: 0.9rem; color: var(--text-light);"><?php echo htmlspecialchars($value['description'] ?? ''); ?></div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="empty-state">
                <p>ارزشی ثبت نشده است</p>
                <a href="<?php echo URL; ?>admin/values" class="btn btn-sm btn-primary mt-2">افزودن ارزش</a>
            </div>
        <?php endif; ?>
    </div>

    <!-- Manifesto Section -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">
                <svg viewBox="0 0 24 24"><path fill="currentColor" d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6zm2 16H8v-2h8v2zm0-4H8v-2h8v2zm-3-5V3.5L18.5 9H13z"/></svg>
                مانیفست برند
            </h3>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="form-group">
                    <label class="form-label">عنوان</label>
                    <input type="text" class="form-control" name="manifesto[title]" value="<?php echo htmlspecialchars($manifestoContent['title'] ?? ''); ?>" placeholder="چرا طراحان باستان؟">
                    <span class="form-hint">عنوان بخش مانیفست. مثال: <code>چرا طراحان باستان؟</code></span>
                </div>
            </div>
            <div class="col-12">
                <div class="form-group">
                    <label class="form-label">متن مانیفست</label>
                    <textarea class="form-control" name="manifesto[content]" rows="4" placeholder="ما معتقدیم که هر کسب‌وکاری داستان منحصر به فردی دارد..."><?php echo htmlspecialchars($manifestoContent['content'] ?? ''); ?></textarea>
                    <span class="form-hint">متن اصلی مانیفست برند - داستان و ارزش‌های شرکت را بیان کنید</span>
                </div>
            </div>
        </div>
    </div>

    <!-- CTA Section -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">
                <svg viewBox="0 0 24 24"><path fill="currentColor" d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/></svg>
                بخش CTA انتهایی
            </h3>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="form-group">
                    <label class="form-label">عنوان</label>
                    <input type="text" class="form-control" name="cta[title]" value="<?php echo htmlspecialchars($ctaContent['title'] ?? ''); ?>" placeholder="می‌خواهید بیشتر بدانید؟">
                    <span class="form-hint">عنوان بخش CTA انتهای صفحه</span>
                </div>
            </div>
            <div class="col-12">
                <div class="form-group">
                    <label class="form-label">توضیحات</label>
                    <textarea class="form-control" name="cta[subtitle]" rows="2" placeholder="با ما تماس بگیرید و درباره پروژه‌تان صحبت کنیم..."><?php echo htmlspecialchars($ctaContent['subtitle'] ?? ''); ?></textarea>
                    <span class="form-hint">متن توضیحی زیر عنوان CTA</span>
                </div>
            </div>
        </div>
    </div>

    <!-- Save Button -->
    <div class="card" style="background: linear-gradient(135deg, var(--primary) 0%, var(--primary-light) 100%); color: white;">
        <div class="d-flex justify-between align-center">
            <div>
                <h3 style="margin-bottom: 0.5rem;">ذخیره تغییرات</h3>
                <p style="opacity: 0.8; font-size: 0.9rem;">پس از اعمال تغییرات، دکمه ذخیره را بزنید</p>
            </div>
            <button type="submit" class="btn btn-secondary">
                <svg viewBox="0 0 24 24"><path fill="currentColor" d="M17 3H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V7l-4-4zm-5 16c-1.66 0-3-1.34-3-3s1.34-3 3-3 3 1.34 3 3-1.34 3-3 3zm3-10H5V5h10v4z"/></svg>
                ذخیره صفحه درباره ما
            </button>
        </div>
    </div>
</form>

<script>
    document.getElementById('aboutForm').addEventListener('submit', async function(e) {
        e.preventDefault();
        showLoading();

        try {
            const formData = new FormData(this);
            const response = await fetch('<?php echo URL; ?>admin/saveAbout', {
                method: 'POST',
                body: formData
            });
            const result = await response.json();

            hideLoading();

            if (result.success) {
                showToast('صفحه درباره ما با موفقیت ذخیره شد', 'success');
            } else {
                showToast('خطا در ذخیره', 'error');
            }
        } catch (error) {
            hideLoading();
            showToast('خطا در ارتباط با سرور', 'error');
        }
    });
</script>

<?php
$content = ob_get_clean();
include dirname(__DIR__) . '/layout.php';
?>
