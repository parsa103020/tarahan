<?php
$active = 'process';
$pageTitle = 'مدیریت فرآیند کار';
ob_start();

// Extract data
$process = $data['process'] ?? [];
?>

<div class="card">
    <div class="card-header">
        <h3 class="card-title">
            <svg viewBox="0 0 24 24"><path fill="currentColor" d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6zm-1 11h-2v4H9v-4H7v-2h2V9h2v2h2v2z"/></svg>
            فرآیند کار
        </h3>
        <button type="button" class="btn btn-sm btn-secondary" onclick="openAddModal()">
            <svg viewBox="0 0 24 24" width="16" height="16"><path fill="currentColor" d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/></svg>
            افزودن مرحله
        </button>
    </div>
    <p class="form-hint" style="margin-bottom: 1rem;">مراحل همکاری با مشتریان که در صفحه اصلی نمایش داده می‌شوند. پیشنهاد: ۴ تا ۶ مرحله اصلی</p>

    <?php if (!empty($process)): ?>
        <div class="process-grid">
            <?php foreach ($process as $step): ?>
                <div class="item-card process-item">
                    <div class="item-actions">
                        <button type="button" class="action-btn edit" onclick='editProcess(<?php echo json_encode($step, JSON_HEX_APOS | JSON_HEX_QUOT); ?>)' title="ویرایش این مرحله">
                            <svg viewBox="0 0 24 24"><path fill="currentColor" d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/></svg>
                        </button>
                        <button type="button" class="action-btn delete" onclick="deleteProcess(<?php echo $step['id']; ?>)" title="حذف این مرحله">
                            <svg viewBox="0 0 24 24"><path fill="currentColor" d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg>
                        </button>
                    </div>
                    <div class="step-number"><?php echo $step['step_number']; ?></div>
                    <div class="step-title"><?php echo htmlspecialchars($step['title']); ?></div>
                    <?php if (!empty($step['description'])): ?>
                        <div class="step-desc"><?php echo htmlspecialchars($step['description']); ?></div>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div class="empty-state">
            <svg viewBox="0 0 24 24">
                <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6zm-1 11h-2v4H9v-4H7v-2h2V9h2v2h2v2z"/>
            </svg>
            <h4>مرحله‌ای ثبت نشده است</h4>
            <p>مراحل فرآیند کار با مشتریان را اضافه کنید تا در صفحه اصلی نمایش داده شوند</p>
            <button type="button" class="btn btn-primary mt-2" onclick="openAddModal()">
                <svg viewBox="0 0 24 24" width="18" height="18"><path fill="currentColor" d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/></svg>
                افزودن اولین مرحله
            </button>
        </div>
    <?php endif; ?>
</div>

<style>
.process-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
    gap: 1.5rem;
}

.process-item {
    text-align: center;
    padding-left: 4rem;
    padding-top: 3rem;
}

.step-number {
    width: 60px;
    height: 60px;
    background: linear-gradient(135deg, var(--secondary), #f87171);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 1rem;
    font-size: 1.5rem;
    font-weight: 800;
    color: white;
}

.step-title {
    font-weight: 700;
    color: var(--primary);
    margin-bottom: 0.5rem;
    font-size: 1.1rem;
}

.step-desc {
    color: var(--text-secondary);
    font-size: 0.9rem;
    line-height: 1.7;
}
</style>

<!-- Add/Edit Modal -->
<div class="modal-overlay" id="addProcessModal">
    <div class="modal">
        <div class="modal-header">
            <h3 class="modal-title" id="processModalTitle">افزودن مرحله جدید</h3>
            <button type="button" class="modal-close" onclick="closeModal('addProcessModal')">
                <svg viewBox="0 0 24 24"><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg>
            </button>
        </div>
        <form id="processForm">
            <div class="modal-body">
                <input type="hidden" name="id" id="process_id">
                <input type="hidden" name="page" value="home">

                <div class="form-group">
                    <label class="form-label">شماره مرحله *</label>
                    <input type="number" class="form-control" name="step_number" id="process_step_number" min="1" placeholder="۱" required>
                    <span class="form-hint">عدد ترتیب این مرحله در فرآیند. مثال: <code>۱</code>، <code>۲</code>، <code>۳</code></span>
                </div>
                <div class="form-group">
                    <label class="form-label">عنوان مرحله *</label>
                    <input type="text" class="form-control" name="title" id="process_title" placeholder="مثال: مشاوره اولیه" required>
                    <span class="form-hint">عنوان کوتاه و گویا برای این مرحله</span>
                </div>
                <div class="form-group">
                    <label class="form-label">توضیحات</label>
                    <textarea class="form-control" name="description" id="process_description" rows="3" placeholder="شرح مختصری از این مرحله و کارهایی که انجام می‌شود..."></textarea>
                    <span class="form-hint">توضیح کوتاه درباره این مرحله (اختیاری)</span>
                </div>
                <div class="form-group">
                    <label class="form-label">آیکون</label>
                    <input type="text" class="form-control" name="icon" id="process_icon" placeholder="chat">
                    <span class="form-hint">نام آیکون (اختیاری) - در نسخه فعلی شماره مرحله نمایش داده می‌شود</span>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline" onclick="closeModal('addProcessModal')">انصراف</button>
                <button type="submit" class="btn btn-primary">
                    <svg viewBox="0 0 24 24" width="18" height="18"><path fill="currentColor" d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>
                    ذخیره مرحله
                </button>
            </div>
        </form>
    </div>
</div>

<script>
    function openAddModal() {
        document.getElementById('processModalTitle').textContent = 'افزودن مرحله جدید';
        document.getElementById('processForm').reset();
        document.getElementById('process_id').value = '';
        openModal('addProcessModal');
    }

    function editProcess(step) {
        document.getElementById('processModalTitle').textContent = 'ویرایش مرحله';
        document.getElementById('process_id').value = step.id;
        document.getElementById('process_step_number').value = step.step_number;
        document.getElementById('process_title').value = step.title;
        document.getElementById('process_description').value = step.description || '';
        document.getElementById('process_icon').value = step.icon || '';
        openModal('addProcessModal');
    }

    function deleteProcess(id) {
        confirmDelete('<?php echo URL; ?>admin/deleteProcessStep/' + id, () => {
            location.reload();
        });
    }

    document.getElementById('processForm').addEventListener('submit', async function(e) {
        e.preventDefault();
        showLoading();

        try {
            const formData = new FormData(this);
            const response = await fetch('<?php echo URL; ?>admin/saveProcessStep', {
                method: 'POST',
                body: formData
            });
            const result = await response.json();

            hideLoading();

            if (result.success) {
                showToast('مرحله با موفقیت ذخیره شد', 'success');
                setTimeout(() => location.reload(), 1000);
            } else {
                showToast('خطا در ذخیره', 'error');
            }
        } catch (error) {
            hideLoading();
            showToast('خطا در ارتباط با سرور', 'error');
        }
    });
</script>

<?php
$content = ob_get_clean();
include dirname(__DIR__) . '/layout.php';
?>
