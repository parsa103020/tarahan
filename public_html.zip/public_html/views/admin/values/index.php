<?php
$active = 'values';
$pageTitle = 'مدیریت ارزش‌ها';
ob_start();

// Extract data
$values = $data['values'] ?? [];
?>

<div class="card">
    <div class="card-header">
        <h3 class="card-title">
            <svg viewBox="0 0 24 24"><path fill="currentColor" d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>
            ارزش‌های شرکت
        </h3>
        <button type="button" class="btn btn-sm btn-secondary" onclick="openAddModal()">
            <svg viewBox="0 0 24 24" width="16" height="16"><path fill="currentColor" d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/></svg>
            افزودن ارزش
        </button>
    </div>
    <p class="form-hint" style="margin-bottom: 1rem;">ارزش‌های اصلی و باورهای شرکت که در صفحه درباره ما نمایش داده می‌شوند. پیشنهاد: ۴ تا ۶ ارزش کلیدی</p>

    <?php if (!empty($values)): ?>
        <div class="values-grid">
            <?php foreach ($values as $value): ?>
                <div class="item-card value-item">
                    <div class="item-actions">
                        <button type="button" class="action-btn edit" onclick='editValue(<?php echo json_encode($value, JSON_HEX_APOS | JSON_HEX_QUOT); ?>)' title="ویرایش این ارزش">
                            <svg viewBox="0 0 24 24"><path fill="currentColor" d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/></svg>
                        </button>
                        <button type="button" class="action-btn delete" onclick="deleteValue(<?php echo $value['id']; ?>)" title="حذف این ارزش">
                            <svg viewBox="0 0 24 24"><path fill="currentColor" d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg>
                        </button>
                    </div>
                    <div class="value-icon">
                        <svg viewBox="0 0 24 24" width="24" height="24">
                            <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/>
                        </svg>
                    </div>
                    <div class="value-title"><?php echo htmlspecialchars($value['title']); ?></div>
                    <?php if (!empty($value['description'])): ?>
                        <div class="value-desc"><?php echo htmlspecialchars($value['description']); ?></div>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div class="empty-state">
            <svg viewBox="0 0 24 24">
                <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/>
            </svg>
            <h4>ارزشی ثبت نشده است</h4>
            <p>ارزش‌های اصلی شرکت را اضافه کنید تا در صفحه درباره ما نمایش داده شوند</p>
            <button type="button" class="btn btn-primary mt-2" onclick="openAddModal()">
                <svg viewBox="0 0 24 24" width="18" height="18"><path fill="currentColor" d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/></svg>
                افزودن اولین ارزش
            </button>
        </div>
    <?php endif; ?>
</div>

<style>
.values-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: 1.5rem;
}

.value-item {
    padding-left: 4rem;
}

.value-icon {
    width: 50px;
    height: 50px;
    background: linear-gradient(135deg, var(--secondary), #f87171);
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 1rem;
}

.value-icon svg {
    fill: white;
}

.value-title {
    font-weight: 700;
    color: var(--primary);
    margin-bottom: 0.5rem;
    font-size: 1.1rem;
}

.value-desc {
    color: var(--text-secondary);
    font-size: 0.9rem;
    line-height: 1.7;
}
</style>

<!-- Add/Edit Modal -->
<div class="modal-overlay" id="addValueModal">
    <div class="modal">
        <div class="modal-header">
            <h3 class="modal-title" id="valueModalTitle">افزودن ارزش جدید</h3>
            <button type="button" class="modal-close" onclick="closeModal('addValueModal')">
                <svg viewBox="0 0 24 24"><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg>
            </button>
        </div>
        <form id="valueForm">
            <div class="modal-body">
                <input type="hidden" name="id" id="value_id">

                <div class="form-group">
                    <label class="form-label">عنوان ارزش *</label>
                    <input type="text" class="form-control" name="title" id="value_title" placeholder="مثال: صداقت و شفافیت" required>
                    <span class="form-hint">یک عنوان کوتاه و گویا برای این ارزش</span>
                </div>
                <div class="form-group">
                    <label class="form-label">توضیحات</label>
                    <textarea class="form-control" name="description" id="value_description" rows="4" placeholder="توضیح کوتاهی درباره این ارزش و اهمیت آن در شرکت..."></textarea>
                    <span class="form-hint">شرح مختصری از این ارزش و نحوه پیاده‌سازی آن در شرکت (اختیاری)</span>
                </div>
                <div class="form-group">
                    <label class="form-label">آیکون</label>
                    <input type="text" class="form-control" name="icon" id="value_icon" placeholder="heart">
                    <span class="form-hint">نام آیکون (اختیاری) - در نسخه فعلی آیکون پیش‌فرض نمایش داده می‌شود</span>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline" onclick="closeModal('addValueModal')">انصراف</button>
                <button type="submit" class="btn btn-primary">
                    <svg viewBox="0 0 24 24" width="18" height="18"><path fill="currentColor" d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>
                    ذخیره ارزش
                </button>
            </div>
        </form>
    </div>
</div>

<script>
    function openAddModal() {
        document.getElementById('valueModalTitle').textContent = 'افزودن ارزش جدید';
        document.getElementById('valueForm').reset();
        document.getElementById('value_id').value = '';
        openModal('addValueModal');
    }

    function editValue(value) {
        document.getElementById('valueModalTitle').textContent = 'ویرایش ارزش';
        document.getElementById('value_id').value = value.id;
        document.getElementById('value_title').value = value.title;
        document.getElementById('value_description').value = value.description || '';
        document.getElementById('value_icon').value = value.icon || '';
        openModal('addValueModal');
    }

    function deleteValue(id) {
        confirmDelete('<?php echo URL; ?>admin/deleteValue/' + id, () => {
            location.reload();
        });
    }

    document.getElementById('valueForm').addEventListener('submit', async function(e) {
        e.preventDefault();
        showLoading();

        try {
            const formData = new FormData(this);
            const response = await fetch('<?php echo URL; ?>admin/saveValue', {
                method: 'POST',
                body: formData
            });
            const result = await response.json();

            hideLoading();

            if (result.success) {
                showToast('ارزش با موفقیت ذخیره شد', 'success');
                setTimeout(() => location.reload(), 1000);
            } else {
                showToast('خطا در ذخیره', 'error');
            }
        } catch (error) {
            hideLoading();
            showToast('خطا در ارتباط با سرور', 'error');
        }
    });
</script>

<?php
$content = ob_get_clean();
include dirname(__DIR__) . '/layout.php';
?>
