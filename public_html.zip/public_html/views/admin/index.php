<?php
$active = 'index';
$pageTitle = 'داشبورد';
ob_start();

// Extract stats
$stats = $data['stats'] ?? [];
$recentMessages = $data['recentMessages'] ?? [];
$services = $data['services'] ?? [];
?>

<!-- Welcome Section -->
<div class="card" style="background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%); color: white; margin-bottom: 1.5rem;">
    <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 1rem;">
        <div>
            <h2 style="font-size: 1.5rem; font-weight: 700; margin-bottom: 0.5rem;">
                سلام <?php echo $_SESSION['admin_name'] ?? 'کاربر'; ?>
            </h2>
            <p style="opacity: 0.8; font-size: 0.95rem;">
                به پنل مدیریت طراحان باستان خوش آمدید
            </p>
        </div>
        <div style="display: flex; gap: 0.75rem;">
            <a href="<?php echo URL; ?>" target="_blank" class="btn" style="background: rgba(255,255,255,0.15); color: white; backdrop-filter: blur(10px);">
                <svg viewBox="0 0 24 24" width="18" height="18"><path fill="currentColor" d="M19 19H5V5h7V3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14c1.1 0 2-.9 2-2v-7h-2v7zM14 3v2h3.59l-9.83 9.83 1.41 1.41L19 6.41V10h2V3h-7z"/></svg>
                مشاهده سایت
            </a>
        </div>
    </div>
</div>

<!-- Stats Grid -->
<div class="stats-grid">
    <div class="stat-card" title="تعداد خدماتی که در سایت فعال هستند">
        <div class="stat-icon primary">
            <svg viewBox="0 0 24 24"><path fill="currentColor" d="M20 6h-4V4c0-1.11-.89-2-2-2h-4c-1.11 0-2 .89-2 2v2H4c-1.11 0-1.99.89-1.99 2L2 19c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V8c0-1.11-.89-2-2-2zm-6 0h-4V4h4v2z"/></svg>
        </div>
        <div class="stat-info">
            <h3><?php echo $stats['services'] ?? 7; ?></h3>
            <p>خدمات فعال</p>
        </div>
    </div>

    <div class="stat-card" title="پیام‌هایی که هنوز خوانده نشده‌اند">
        <div class="stat-icon secondary">
            <svg viewBox="0 0 24 24"><path fill="currentColor" d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2z"/></svg>
        </div>
        <div class="stat-info">
            <h3><?php echo $stats['newMessages'] ?? 0; ?></h3>
            <p>پیام‌های جدید</p>
        </div>
    </div>

    <div class="stat-card" title="تعداد نظرات ثبت‌شده از مشتریان">
        <div class="stat-icon success">
            <svg viewBox="0 0 24 24"><path fill="currentColor" d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/></svg>
        </div>
        <div class="stat-info">
            <h3><?php echo $stats['testimonials'] ?? 0; ?></h3>
            <p>نظرات مشتریان</p>
        </div>
    </div>

    <div class="stat-card" title="مجموع تمام پیام‌های دریافتی">
        <div class="stat-icon info">
            <svg viewBox="0 0 24 24"><path fill="currentColor" d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2z"/></svg>
        </div>
        <div class="stat-info">
            <h3><?php echo $stats['totalMessages'] ?? 0; ?></h3>
            <p>کل پیام‌ها</p>
        </div>
    </div>
</div>

<div class="row">
    <!-- Recent Messages -->
    <div class="col-6">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">
                    <svg viewBox="0 0 24 24"><path fill="currentColor" d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2z"/></svg>
                    آخرین پیام‌ها
                </h3>
                <a href="<?php echo URL; ?>admin/messages" class="btn btn-sm btn-outline">مشاهده همه</a>
            </div>
            <?php if (!empty($recentMessages)): ?>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>نام</th>
                                <th>موضوع</th>
                                <th>تاریخ</th>
                                <th>وضعیت</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($recentMessages as $message): ?>
                                <tr style="cursor: pointer;" onclick="window.location='<?php echo URL; ?>admin/viewMessage/<?php echo $message['id']; ?>'">
                                    <td style="font-weight: 600;"><?php echo htmlspecialchars($message['name']); ?></td>
                                    <td><?php echo htmlspecialchars($message['subject'] ?? '-'); ?></td>
                                    <td style="font-size: 0.85rem; color: var(--text-muted);">
                                        <?php echo date('Y/m/d', strtotime($message['created_at'])); ?>
                                    </td>
                                    <td>
                                        <?php if ($message['is_read']): ?>
                                            <span class="badge badge-success">خوانده شده</span>
                                        <?php else: ?>
                                            <span class="badge badge-warning">جدید</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <svg viewBox="0 0 24 24" width="48" height="48" style="fill: var(--text-muted); opacity: 0.5; margin-bottom: 1rem;">
                        <path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2z"/>
                    </svg>
                    <h4>هنوز پیامی دریافت نشده است</h4>
                    <p>پیام‌های فرم تماس اینجا نمایش داده می‌شوند</p>
                    <p style="font-size: 0.8rem; color: var(--text-muted); margin-top: 0.5rem;">وقتی کاربران از صفحه تماس پیام ارسال کنند، اینجا نمایش داده می‌شود</p>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Services List -->
    <div class="col-6">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">
                    <svg viewBox="0 0 24 24"><path fill="currentColor" d="M20 6h-4V4c0-1.11-.89-2-2-2h-4c-1.11 0-2 .89-2 2v2H4c-1.11 0-1.99.89-1.99 2L2 19c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V8c0-1.11-.89-2-2-2zm-6 0h-4V4h4v2z"/></svg>
                    خدمات
                </h3>
                <a href="<?php echo URL; ?>admin/services" class="btn btn-sm btn-outline">مدیریت</a>
            </div>
            <?php if (!empty($services)): ?>
                <div class="services-list" style="display: flex; flex-direction: column; gap: 0.75rem;">
                    <?php foreach ($services as $service): ?>
                        <a href="<?php echo URL; ?>admin/editService/<?php echo $service['id']; ?>" class="service-item" style="display: flex; align-items: center; gap: 1rem; padding: 1rem; background: var(--bg-main); border-radius: 10px; text-decoration: none; color: inherit; transition: all 0.2s ease; border: 1px solid var(--border-color);">
                            <div style="width: 45px; height: 45px; background: linear-gradient(135deg, var(--primary), #818cf8); border-radius: 10px; display: flex; align-items: center; justify-content: center; color: white; font-weight: 700;">
                                <?php echo mb_substr($service['title'], 0, 1, 'UTF-8'); ?>
                            </div>
                            <div style="flex: 1;">
                                <div style="font-weight: 600; color: var(--text-primary);"><?php echo htmlspecialchars($service['title']); ?></div>
                                <div style="font-size: 0.8rem; color: var(--text-muted);"><?php
                                    $desc = $service['short_description'] ?? '';
                                    echo htmlspecialchars($desc ? mb_substr($desc, 0, 40, 'UTF-8') . '...' : 'بدون توضیح');
                                ?></div>
                            </div>
                            <span style="padding: 0.25rem 0.5rem; background: <?php echo $service['is_active'] ? 'rgba(16,185,129,0.1)' : 'rgba(239,68,68,0.1)'; ?>; color: <?php echo $service['is_active'] ? 'var(--success)' : 'var(--danger)'; ?>; border-radius: 6px; font-size: 0.7rem; font-weight: 600;">
                                <?php echo $service['is_active'] ? 'فعال' : 'غیرفعال'; ?>
                            </span>
                        </a>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <p>خدماتی یافت نشد</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Quick Links -->
<div class="card">
    <div class="card-header">
        <h3 class="card-title">
            <svg viewBox="0 0 24 24"><path fill="currentColor" d="M13 3h-2v10h2V3zm4.83 2.17l-1.42 1.42A6.92 6.92 0 0119 12c0 3.87-3.13 7-7 7s-7-3.13-7-7c0-2.47 1.29-4.65 3.24-5.89l-1.42-1.42A8.962 8.962 0 003 12c0 4.96 4.04 9 9 9s9-4.04 9-9c0-3.18-1.65-5.98-4.17-7.83z"/></svg>
            دسترسی سریع
        </h3>
    </div>
    <div class="quick-links" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 1rem;">
        <a href="<?php echo URL; ?>admin/home" class="quick-link" style="display: flex; flex-direction: column; align-items: center; gap: 0.5rem; padding: 1.5rem 1rem; background: var(--bg-main); border-radius: 12px; text-decoration: none; color: inherit; transition: all 0.2s ease; text-align: center; border: 1px solid var(--border-color);">
            <div style="width: 50px; height: 50px; background: linear-gradient(135deg, #6366f1, #818cf8); border-radius: 12px; display: flex; align-items: center; justify-content: center;">
                <svg viewBox="0 0 24 24" width="24" height="24" style="fill: white;"><path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/></svg>
            </div>
            <span style="font-weight: 600; font-size: 0.9rem;">صفحه اصلی</span>
            <span style="font-size: 0.75rem; color: var(--text-muted);">ویرایش هیرو و آمار</span>
        </a>

        <a href="<?php echo URL; ?>admin/about" class="quick-link" style="display: flex; flex-direction: column; align-items: center; gap: 0.5rem; padding: 1.5rem 1rem; background: var(--bg-main); border-radius: 12px; text-decoration: none; color: inherit; transition: all 0.2s ease; text-align: center; border: 1px solid var(--border-color);">
            <div style="width: 50px; height: 50px; background: linear-gradient(135deg, #e94560, #f87171); border-radius: 12px; display: flex; align-items: center; justify-content: center;">
                <svg viewBox="0 0 24 24" width="24" height="24" style="fill: white;"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"/></svg>
            </div>
            <span style="font-weight: 600; font-size: 0.9rem;">درباره ما</span>
            <span style="font-size: 0.75rem; color: var(--text-muted);">تاریخچه و ارزش‌ها</span>
        </a>

        <a href="<?php echo URL; ?>admin/contact" class="quick-link" style="display: flex; flex-direction: column; align-items: center; gap: 0.5rem; padding: 1.5rem 1rem; background: var(--bg-main); border-radius: 12px; text-decoration: none; color: inherit; transition: all 0.2s ease; text-align: center; border: 1px solid var(--border-color);">
            <div style="width: 50px; height: 50px; background: linear-gradient(135deg, #10b981, #34d399); border-radius: 12px; display: flex; align-items: center; justify-content: center;">
                <svg viewBox="0 0 24 24" width="24" height="24" style="fill: white;"><path d="M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/></svg>
            </div>
            <span style="font-weight: 600; font-size: 0.9rem;">تماس با ما</span>
            <span style="font-size: 0.75rem; color: var(--text-muted);">هیرو و سوالات متداول</span>
        </a>

        <a href="<?php echo URL; ?>admin/articles" class="quick-link" style="display: flex; flex-direction: column; align-items: center; gap: 0.5rem; padding: 1.5rem 1rem; background: var(--bg-main); border-radius: 12px; text-decoration: none; color: inherit; transition: all 0.2s ease; text-align: center; border: 1px solid var(--border-color);">
            <div style="width: 50px; height: 50px; background: linear-gradient(135deg, #f59e0b, #fbbf24); border-radius: 12px; display: flex; align-items: center; justify-content: center;">
                <svg viewBox="0 0 24 24" width="24" height="24" style="fill: white;"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-5 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z"/></svg>
            </div>
            <span style="font-weight: 600; font-size: 0.9rem;">مقالات</span>
            <span style="font-size: 0.75rem; color: var(--text-muted);">مدیریت وبلاگ</span>
        </a>

        <a href="<?php echo URL; ?>admin/settings" class="quick-link" style="display: flex; flex-direction: column; align-items: center; gap: 0.5rem; padding: 1.5rem 1rem; background: var(--bg-main); border-radius: 12px; text-decoration: none; color: inherit; transition: all 0.2s ease; text-align: center; border: 1px solid var(--border-color);">
            <div style="width: 50px; height: 50px; background: linear-gradient(135deg, #8b5cf6, #a78bfa); border-radius: 12px; display: flex; align-items: center; justify-content: center;">
                <svg viewBox="0 0 24 24" width="24" height="24" style="fill: white;"><path d="M19.14 12.94c.04-.31.06-.63.06-.94 0-.31-.02-.63-.06-.94l2.03-1.58a.49.49 0 0 0 .12-.61l-1.92-3.32a.49.49 0 0 0-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54a.484.484 0 0 0-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96a.49.49 0 0 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.04.31-.06.63-.06.94s.02.63.06.94l-2.03 1.58a.49.49 0 0 0-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z"/></svg>
            </div>
            <span style="font-weight: 600; font-size: 0.9rem;">تنظیمات</span>
            <span style="font-size: 0.75rem; color: var(--text-muted);">اطلاعات تماس و سایت</span>
        </a>
    </div>
</div>

<style>
    .service-item:hover {
        border-color: var(--primary) !important;
        transform: translateX(-5px);
        box-shadow: 0 4px 15px rgba(99, 102, 241, 0.1);
    }
    .quick-link:hover {
        border-color: var(--primary) !important;
        transform: translateY(-3px);
        box-shadow: 0 8px 25px rgba(0,0,0,0.1);
    }
</style>

<?php
$content = ob_get_clean();
include 'layout.php';
?>
