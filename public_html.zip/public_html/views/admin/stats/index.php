<?php
$active = 'stats';
$pageTitle = 'مدیریت آمار و ارقام';
ob_start();

// Extract data
$homeStats = $data['homeStats'] ?? [];
$aboutStats = $data['aboutStats'] ?? [];
?>

<div class="card">
    <div class="card-header">
        <h3 class="card-title">
            <svg viewBox="0 0 24 24"><path fill="currentColor" d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zM9 17H7v-7h2v7zm4 0h-2V7h2v10zm4 0h-2v-4h2v4z"/></svg>
            آمار صفحه اصلی
        </h3>
        <button type="button" class="btn btn-sm btn-secondary" onclick="openAddModal()">
            <svg viewBox="0 0 24 24" width="16" height="16"><path fill="currentColor" d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/></svg>
            افزودن آمار
        </button>
    </div>
    <p class="form-hint" style="margin-bottom: 1rem;">آمار و ارقامی که در بخش «دستاوردها» صفحه اصلی نمایش داده می‌شوند. پیشنهاد: ۳ تا ۴ آمار کلیدی اضافه کنید.</p>

    <?php if (!empty($homeStats)): ?>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th style="width: 50px;">#</th>
                        <th>مقدار</th>
                        <th>عنوان</th>
                        <th>پیشوند</th>
                        <th>پسوند</th>
                        <th style="width: 120px;">عملیات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($homeStats as $index => $stat): ?>
                        <tr>
                            <td><?php echo $index + 1; ?></td>
                            <td style="font-weight: 700; font-size: 1.25rem; color: var(--primary);">
                                <?php echo htmlspecialchars($stat['stat_value']); ?>
                            </td>
                            <td><?php echo htmlspecialchars($stat['stat_label']); ?></td>
                            <td><?php echo htmlspecialchars($stat['stat_prefix'] ?? '-'); ?></td>
                            <td><?php echo htmlspecialchars($stat['stat_suffix'] ?? '-'); ?></td>
                            <td>
                                <div class="actions">
                                    <button type="button" class="action-btn edit" onclick='editStat(<?php echo json_encode($stat, JSON_HEX_APOS | JSON_HEX_QUOT); ?>)' title="ویرایش این آمار">
                                        <svg viewBox="0 0 24 24"><path fill="currentColor" d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/></svg>
                                    </button>
                                    <button type="button" class="action-btn delete" onclick="deleteStat(<?php echo $stat['id']; ?>)" title="حذف این آمار">
                                        <svg viewBox="0 0 24 24"><path fill="currentColor" d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <div class="empty-state">
            <svg viewBox="0 0 24 24">
                <path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zM9 17H7v-7h2v7zm4 0h-2V7h2v10zm4 0h-2v-4h2v4z"/>
            </svg>
            <h4>آماری ثبت نشده است</h4>
            <p>آمار و ارقام شرکت را اضافه کنید تا در صفحه اصلی نمایش داده شوند</p>
            <button type="button" class="btn btn-primary mt-2" onclick="openAddModal()">
                <svg viewBox="0 0 24 24" width="18" height="18"><path fill="currentColor" d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/></svg>
                افزودن اولین آمار
            </button>
        </div>
    <?php endif; ?>
</div>

<!-- Add/Edit Modal -->
<div class="modal-overlay" id="addStatModal">
    <div class="modal">
        <div class="modal-header">
            <h3 class="modal-title" id="statModalTitle">افزودن آمار جدید</h3>
            <button type="button" class="modal-close" onclick="closeModal('addStatModal')">
                <svg viewBox="0 0 24 24"><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg>
            </button>
        </div>
        <form id="statForm">
            <div class="modal-body">
                <input type="hidden" name="id" id="stat_id">
                <input type="hidden" name="page" value="home">

                <div class="form-group">
                    <label class="form-label">مقدار عددی *</label>
                    <input type="text" class="form-control" name="stat_value" id="stat_value" placeholder="۵۰۰" required>
                    <span class="form-hint">عدد اصلی که می‌خواهید نمایش داده شود. مثال: <code>۵۰۰</code> یا <code>۲۵</code></span>
                </div>
                <div class="form-group">
                    <label class="form-label">عنوان آمار *</label>
                    <input type="text" class="form-control" name="stat_label" id="stat_label" placeholder="پروژه موفق" required>
                    <span class="form-hint">توضیح کوتاه آمار. مثال: پروژه موفق، مشتری راضی، سال تجربه</span>
                </div>
                <div class="row">
                    <div class="col-6">
                        <div class="form-group">
                            <label class="form-label">پیشوند</label>
                            <input type="text" class="form-control" name="stat_prefix" id="stat_prefix" placeholder="+">
                            <span class="form-hint">قبل از عدد. مثال: <code>+</code></span>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group">
                            <label class="form-label">پسوند</label>
                            <input type="text" class="form-control" name="stat_suffix" id="stat_suffix" placeholder="عدد">
                            <span class="form-hint">بعد از عدد. مثال: <code>%</code> یا <code>سال</code></span>
                        </div>
                    </div>
                </div>
                <div class="alert alert-info" style="font-size: 0.85rem;">
                    <strong>نتیجه نمایش:</strong>
                    <span id="statPreview" style="font-weight: 700; color: var(--primary); font-size: 1.1rem;">+۵۰۰ پروژه</span>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline" onclick="closeModal('addStatModal')">انصراف</button>
                <button type="submit" class="btn btn-primary">
                    <svg viewBox="0 0 24 24" width="18" height="18"><path fill="currentColor" d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>
                    ذخیره آمار
                </button>
            </div>
        </form>
    </div>
</div>

<script>
    function openAddModal() {
        document.getElementById('statModalTitle').textContent = 'افزودن آمار جدید';
        document.getElementById('statForm').reset();
        document.getElementById('stat_id').value = '';
        updatePreview();
        openModal('addStatModal');
    }

    function editStat(stat) {
        document.getElementById('statModalTitle').textContent = 'ویرایش آمار';
        document.getElementById('stat_id').value = stat.id;
        document.getElementById('stat_value').value = stat.stat_value;
        document.getElementById('stat_label').value = stat.stat_label;
        document.getElementById('stat_prefix').value = stat.stat_prefix || '';
        document.getElementById('stat_suffix').value = stat.stat_suffix || '';
        updatePreview();
        openModal('addStatModal');
    }

    function deleteStat(id) {
        confirmDelete('<?php echo URL; ?>admin/deleteStat/' + id, () => {
            location.reload();
        });
    }

    function updatePreview() {
        const prefix = document.getElementById('stat_prefix').value || '';
        const value = document.getElementById('stat_value').value || '۰';
        const suffix = document.getElementById('stat_suffix').value || '';
        const label = document.getElementById('stat_label').value || '';
        document.getElementById('statPreview').textContent = prefix + value + suffix + ' ' + label;
    }

    // Live preview
    ['stat_prefix', 'stat_value', 'stat_suffix', 'stat_label'].forEach(id => {
        document.getElementById(id).addEventListener('input', updatePreview);
    });

    document.getElementById('statForm').addEventListener('submit', async function(e) {
        e.preventDefault();
        showLoading();

        try {
            const formData = new FormData(this);
            const response = await fetch('<?php echo URL; ?>admin/saveStat', {
                method: 'POST',
                body: formData
            });
            const result = await response.json();

            hideLoading();

            if (result.success) {
                showToast('آمار با موفقیت ذخیره شد', 'success');
                setTimeout(() => location.reload(), 1000);
            } else {
                showToast('خطا در ذخیره: ' + (result.error || 'نامشخص'), 'error');
                console.error('Save error:', result.error);
            }
        } catch (error) {
            hideLoading();
            showToast('خطا در ارتباط با سرور', 'error');
        }
    });
</script>

<?php
$content = ob_get_clean();
include dirname(__DIR__) . '/layout.php';
?>
