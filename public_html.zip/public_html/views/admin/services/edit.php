<?php
$active = 'services';
$pageTitle = 'ویرایش خدمت';
ob_start();

// Extract data from $data array
$service = $data['service'] ?? [];
$features = $data['features'] ?? [];
$process = $data['process'] ?? [];
$faq = $data['faq'] ?? [];
$stats = $data['stats'] ?? [];
$items = $data['items'] ?? [];

// If no service, redirect back
if (empty($service)) {
    echo '<script>window.location.href = "' . URL . 'admin/services";</script>';
    exit;
}
?>

<div class="d-flex justify-between align-center mb-3">
    <a href="<?php echo URL; ?>admin/services" class="btn btn-outline">
        <svg viewBox="0 0 24 24" width="18" height="18"><path fill="currentColor" d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z"/></svg>
        بازگشت به لیست
    </a>
    <a href="<?php echo URL; ?>service/<?php echo $service['slug']; ?>" target="_blank" class="btn btn-secondary">
        <svg viewBox="0 0 24 24" width="18" height="18"><path fill="currentColor" d="M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5z"/></svg>
        مشاهده صفحه
    </a>
</div>

<!-- Tabs -->
<div class="tabs" style="display: flex; gap: 0.5rem; margin-bottom: 1.5rem; overflow-x: auto; padding-bottom: 0.5rem;">
    <button class="tab-btn active" data-tab="general">اطلاعات کلی</button>
    <button class="tab-btn" data-tab="hero">بخش هیرو</button>
    <button class="tab-btn" data-tab="features">ویژگی‌ها</button>
    <button class="tab-btn" data-tab="process">فرآیند کار</button>
    <button class="tab-btn" data-tab="faq">سوالات متداول</button>
    <button class="tab-btn" data-tab="stats">آمار</button>
    <button class="tab-btn" data-tab="items">زیرخدمات</button>
</div>

<form id="serviceForm">
    <input type="hidden" name="id" value="<?php echo $service['id']; ?>">

    <!-- General Tab -->
    <div class="tab-content active" id="tab-general">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">
                    <svg viewBox="0 0 24 24"><path fill="currentColor" d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"/></svg>
                    اطلاعات کلی خدمت
                </h3>
            </div>
            <div class="row">
                <div class="col-6">
                    <div class="form-group">
                        <label class="form-label">عنوان خدمت</label>
                        <input type="text" class="form-control" name="title" value="<?php echo htmlspecialchars($service['title']); ?>" placeholder="طراحی و ساخت غرفه نمایشگاهی">
                        <span class="form-hint">عنوان اصلی خدمت که در سایت نمایش داده می‌شود</span>
                    </div>
                </div>
                <div class="col-6">
                    <div class="form-group">
                        <label class="form-label">نامک (Slug)</label>
                        <input type="text" class="form-control" name="slug" value="<?php echo htmlspecialchars($service['slug']); ?>" style="direction: ltr;" placeholder="booth">
                        <span class="form-hint">آدرس انگلیسی خدمت در URL. مثال: <code>booth</code> برای آدرس <code>/service/booth</code></span>
                    </div>
                </div>
                <div class="col-6">
                    <div class="form-group">
                        <label class="form-label">آیکون</label>
                        <input type="text" class="form-control" name="icon" value="<?php echo htmlspecialchars($service['icon'] ?? ''); ?>" placeholder="booth">
                        <span class="form-hint">نام آیکون SVG (اختیاری) - برای نمایش در کارت خدمات</span>
                    </div>
                </div>
                <div class="col-6">
                    <div class="form-group">
                        <label class="form-label">وضعیت</label>
                        <select class="form-control" name="is_active">
                            <option value="1" <?php echo $service['is_active'] ? 'selected' : ''; ?>>فعال</option>
                            <option value="0" <?php echo !$service['is_active'] ? 'selected' : ''; ?>>غیرفعال</option>
                        </select>
                        <span class="form-hint">خدمات غیرفعال در سایت نمایش داده نمی‌شوند</span>
                    </div>
                </div>
                <div class="col-12">
                    <div class="form-group">
                        <label class="form-label">توضیح کوتاه</label>
                        <textarea class="form-control" name="short_description" rows="2" placeholder="توضیح کوتاهی درباره این خدمت که در لیست خدمات نمایش داده می‌شود..."><?php echo htmlspecialchars($service['short_description'] ?? ''); ?></textarea>
                        <span class="form-hint">این متن در کارت خدمات صفحه اصلی و لیست خدمات نشان داده می‌شود (۱-۲ جمله)</span>
                    </div>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <h3 class="card-title">
                    <svg viewBox="0 0 24 24"><path fill="currentColor" d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/></svg>
                    تنظیمات سئو
                </h3>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="form-group">
                        <label class="form-label">عنوان متا (Meta Title)</label>
                        <input type="text" class="form-control" name="meta_title" value="<?php echo htmlspecialchars($service['meta_title'] ?? ''); ?>" placeholder="طراحی و ساخت غرفه نمایشگاهی | طراحان باستان">
                        <span class="form-hint">عنوانی که در نتایج گوگل نمایش داده می‌شود. پیشنهاد: ۵۰-۶۰ کاراکتر</span>
                    </div>
                </div>
                <div class="col-12">
                    <div class="form-group">
                        <label class="form-label">توضیحات متا (Meta Description)</label>
                        <textarea class="form-control" name="meta_description" rows="2" placeholder="طراحان باستان با بیش از ۱۰ سال تجربه، ارائه‌دهنده خدمات حرفه‌ای در زمینه..."><?php echo htmlspecialchars($service['meta_description'] ?? ''); ?></textarea>
                        <span class="form-hint">توضیحی که زیر عنوان در نتایج گوگل نمایش داده می‌شود. پیشنهاد: ۱۵۰-۱۶۰ کاراکتر</span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Hero Tab -->
    <div class="tab-content" id="tab-hero">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">
                    <svg viewBox="0 0 24 24"><path fill="currentColor" d="M21 3H3c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h18c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H3V5h18v14z"/></svg>
                    بخش هیرو
                </h3>
            </div>
            <div class="row">
                <div class="col-6">
                    <div class="form-group">
                        <label class="form-label">متن نشان (Badge)</label>
                        <input type="text" class="form-control" name="hero_badge" value="<?php echo htmlspecialchars($service['hero_badge'] ?? ''); ?>" placeholder="بیش از ۱۰۰ پروژه موفق">
                        <span class="form-hint">متن کوتاه بالای عنوان اصلی</span>
                    </div>
                </div>
                <div class="col-6">
                    <div class="form-group">
                        <label class="form-label">آیکون نشان</label>
                        <input type="text" class="form-control" name="hero_badge_icon" value="<?php echo htmlspecialchars($service['hero_badge_icon'] ?? ''); ?>" placeholder="star">
                        <span class="form-hint">نام آیکون SVG برای کنار متن نشان</span>
                    </div>
                </div>
                <div class="col-6">
                    <div class="form-group">
                        <label class="form-label">خط اول عنوان</label>
                        <input type="text" class="form-control" name="hero_title_line1" value="<?php echo htmlspecialchars($service['hero_title_line1'] ?? ''); ?>" placeholder="طراحی و ساخت">
                        <span class="form-hint">بخش اول عنوان بزرگ (معمولاً با رنگ متفاوت)</span>
                    </div>
                </div>
                <div class="col-6">
                    <div class="form-group">
                        <label class="form-label">خط دوم عنوان</label>
                        <input type="text" class="form-control" name="hero_title_line2" value="<?php echo htmlspecialchars($service['hero_title_line2'] ?? ''); ?>" placeholder="غرفه نمایشگاهی">
                        <span class="form-hint">بخش دوم عنوان بزرگ</span>
                    </div>
                </div>
                <div class="col-12">
                    <div class="form-group">
                        <label class="form-label">زیرعنوان</label>
                        <textarea class="form-control" name="hero_subtitle" rows="2" placeholder="توضیح کامل‌تر درباره خدمت که زیر عنوان اصلی نمایش داده می‌شود..."><?php echo htmlspecialchars($service['hero_subtitle'] ?? ''); ?></textarea>
                        <span class="form-hint">متن توضیحی زیر عنوان (۲-۳ جمله)</span>
                    </div>
                </div>
                <div class="col-6">
                    <div class="form-group">
                        <label class="form-label">متن دکمه اصلی</label>
                        <input type="text" class="form-control" name="cta_primary_text" value="<?php echo htmlspecialchars($service['cta_primary_text'] ?? ''); ?>" placeholder="مشاوره رایگان">
                        <span class="form-hint">متن دکمه فراخوان اصلی</span>
                    </div>
                </div>
                <div class="col-6">
                    <div class="form-group">
                        <label class="form-label">لینک دکمه اصلی</label>
                        <input type="text" class="form-control" name="cta_primary_link" value="<?php echo htmlspecialchars($service['cta_primary_link'] ?? ''); ?>" style="direction: ltr;" placeholder="/contact">
                        <span class="form-hint">آدرس مقصد دکمه. مثال: <code>/contact</code></span>
                    </div>
                </div>
                <div class="col-6">
                    <div class="form-group">
                        <label class="form-label">متن دکمه ثانویه</label>
                        <input type="text" class="form-control" name="cta_secondary_text" value="<?php echo htmlspecialchars($service['cta_secondary_text'] ?? ''); ?>" placeholder="نمونه‌کارها">
                        <span class="form-hint">متن دکمه دوم (اختیاری)</span>
                    </div>
                </div>
                <div class="col-6">
                    <div class="form-group">
                        <label class="form-label">لینک دکمه ثانویه</label>
                        <input type="text" class="form-control" name="cta_secondary_link" value="<?php echo htmlspecialchars($service['cta_secondary_link'] ?? ''); ?>" style="direction: ltr;" placeholder="#portfolio">
                        <span class="form-hint">می‌تواند لینک خارجی یا انکر باشد</span>
                    </div>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <h3 class="card-title">
                    <svg viewBox="0 0 24 24"><path fill="currentColor" d="M19 5v14H5V5h14m0-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-4.86 8.86l-3 3.87L9 13.14 6 17h12l-3.86-5.14z"/></svg>
                    پروژه برجسته
                </h3>
            </div>
            <p class="form-hint" style="margin-bottom: 1rem;">یک نمونه کار برجسته را انتخاب کنید تا در بخش هیرو نمایش داده شود.</p>
            <div class="row">
                <div class="col-6">
                    <div class="form-group">
                        <label class="form-label">عنوان پروژه</label>
                        <input type="text" class="form-control" name="featured_project_title" value="<?php echo htmlspecialchars($service['featured_project_title'] ?? ''); ?>" placeholder="غرفه شرکت پتروشیمی - نمایشگاه صنعت">
                        <span class="form-hint">نام پروژه‌ای که می‌خواهید نمایش دهید</span>
                    </div>
                </div>
                <div class="col-6">
                    <div class="form-group">
                        <label class="form-label">تصویر پروژه</label>
                        <div class="image-uploader" data-input="featured_project_image" data-category="services">
                            <input type="hidden" name="featured_project_image" id="featured_project_image" value="<?php echo htmlspecialchars($service['featured_project_image'] ?? ''); ?>">
                            <div class="image-preview-wrapper">
                                <?php if (!empty($service['featured_project_image'])): ?>
                                    <img src="<?php echo URL . $service['featured_project_image']; ?>" alt="پیش‌نمایش" class="image-preview">
                                    <button type="button" class="remove-image-btn" onclick="removeImage(this)">&times;</button>
                                <?php else: ?>
                                    <div class="image-placeholder">
                                        <svg viewBox="0 0 24 24" width="40" height="40"><path fill="currentColor" d="M19 5v14H5V5h14m0-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-4.86 8.86l-3 3.87L9 13.14 6 17h12l-3.86-5.14z"/></svg>
                                        <span>تصویری انتخاب نشده</span>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="image-upload-actions">
                                <button type="button" class="btn btn-sm btn-outline" onclick="openImageUploader(this)">
                                    <svg viewBox="0 0 24 24" width="16" height="16"><path fill="currentColor" d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/></svg>
                                    انتخاب تصویر
                                </button>
                                <small class="text-muted d-block mt-1">ابعاد پیشنهادی: 800×600 پیکسل | حداکثر حجم: 5MB</small>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12">
                    <div class="form-group">
                        <label class="form-label">توضیحات پروژه</label>
                        <textarea class="form-control" name="featured_project_description" rows="3" placeholder="توضیح کوتاهی درباره این پروژه و چالش‌هایی که حل شد..."><?php echo htmlspecialchars($service['featured_project_description'] ?? ''); ?></textarea>
                        <span class="form-hint">توضیح مختصر درباره پروژه برجسته</span>
                    </div>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <h3 class="card-title">
                    <svg viewBox="0 0 24 24"><path fill="currentColor" d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/></svg>
                    بخش CTA انتهایی
                </h3>
            </div>
            <p class="form-hint" style="margin-bottom: 1rem;">بخش فراخوان اقدام در انتهای صفحه خدمت - کاربر را به تماس یا درخواست مشاوره ترغیب کنید.</p>
            <div class="row">
                <div class="col-12">
                    <div class="form-group">
                        <label class="form-label">عنوان CTA</label>
                        <input type="text" class="form-control" name="cta_final_title" value="<?php echo htmlspecialchars($service['cta_final_title'] ?? ''); ?>" placeholder="آماده شروع پروژه‌تان هستید؟">
                        <span class="form-hint">عنوان جذاب که کاربر را به اقدام ترغیب کند</span>
                    </div>
                </div>
                <div class="col-6">
                    <div class="form-group">
                        <label class="form-label">زیرعنوان CTA</label>
                        <textarea class="form-control" name="cta_final_subtitle" rows="2" placeholder="با ما تماس بگیرید تا درباره پروژه‌تان صحبت کنیم..."><?php echo htmlspecialchars($service['cta_final_subtitle'] ?? ''); ?></textarea>
                        <span class="form-hint">توضیح کوتاه زیر عنوان CTA</span>
                    </div>
                </div>
                <div class="col-6">
                    <div class="form-group">
                        <label class="form-label">متن دکمه CTA</label>
                        <input type="text" class="form-control" name="cta_final_button" value="<?php echo htmlspecialchars($service['cta_final_button'] ?? ''); ?>" placeholder="درخواست مشاوره رایگان">
                        <span class="form-hint">متن دکمه فراخوان اقدام</span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Features Tab -->
    <div class="tab-content" id="tab-features">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">
                    <svg viewBox="0 0 24 24"><path fill="currentColor" d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/></svg>
                    ویژگی‌های خدمت
                </h3>
                <button type="button" class="btn btn-sm btn-secondary" onclick="addFeature()">
                    <svg viewBox="0 0 24 24" width="16" height="16"><path fill="currentColor" d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/></svg>
                    افزودن ویژگی
                </button>
            </div>
            <p class="form-hint" style="margin-bottom: 1rem;">ویژگی‌های منحصربه‌فرد این خدمت که آن را از رقبا متمایز می‌کند. مثال: «کیفیت بالا»، «تحویل سریع»، «ضمانت خدمات»</p>
            <div id="featuresList">
                <?php if (isset($features) && count($features) > 0): ?>
                    <?php foreach ($features as $index => $feature): ?>
                        <div class="feature-item" style="background: var(--bg-light); padding: 1rem; border-radius: 12px; margin-bottom: 1rem;">
                            <div class="row">
                                <div class="col-6">
                                    <div class="form-group mb-0">
                                        <label class="form-label">عنوان</label>
                                        <input type="text" class="form-control" name="features[<?php echo $index; ?>][title]" value="<?php echo htmlspecialchars($feature['title']); ?>">
                                        <input type="hidden" name="features[<?php echo $index; ?>][id]" value="<?php echo $feature['id']; ?>">
                                    </div>
                                </div>
                                <div class="col-4">
                                    <div class="form-group mb-0">
                                        <label class="form-label">آیکون</label>
                                        <input type="text" class="form-control" name="features[<?php echo $index; ?>][icon]" value="<?php echo htmlspecialchars($feature['icon'] ?? ''); ?>">
                                    </div>
                                </div>
                                <div class="col-2" style="display: flex; align-items: flex-end;">
                                    <button type="button" class="btn btn-sm btn-danger" onclick="this.closest('.feature-item').remove()" style="width: 100%;">
                                        <svg viewBox="0 0 24 24" width="16" height="16"><path fill="currentColor" d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg>
                                    </button>
                                </div>
                                <div class="col-12 mt-2">
                                    <div class="form-group mb-0">
                                        <label class="form-label">توضیحات</label>
                                        <textarea class="form-control" name="features[<?php echo $index; ?>][description]" rows="2"><?php echo htmlspecialchars($feature['description'] ?? ''); ?></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Process Tab -->
    <div class="tab-content" id="tab-process">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">
                    <svg viewBox="0 0 24 24"><path fill="currentColor" d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6zm-1 11h-2v4H9v-4H7v-2h2V9h2v2h2v2z"/></svg>
                    مراحل انجام کار
                </h3>
                <button type="button" class="btn btn-sm btn-secondary" onclick="addProcess()">
                    <svg viewBox="0 0 24 24" width="16" height="16"><path fill="currentColor" d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/></svg>
                    افزودن مرحله
                </button>
            </div>
            <p class="form-hint" style="margin-bottom: 1rem;">مراحل انجام کار را به ترتیب تعریف کنید تا مشتری بداند چه فرآیندی را طی می‌کند. مثال: «۱. مشاوره اولیه»، «۲. طراحی»، «۳. اجرا»، «۴. تحویل»</p>
            <div id="processList">
                <?php if (isset($process) && count($process) > 0): ?>
                    <?php foreach ($process as $index => $step): ?>
                        <div class="process-item" style="background: var(--bg-light); padding: 1rem; border-radius: 12px; margin-bottom: 1rem;">
                            <div class="row">
                                <div class="col-3">
                                    <div class="form-group mb-0">
                                        <label class="form-label">شماره مرحله</label>
                                        <input type="number" class="form-control" name="process[<?php echo $index; ?>][step_number]" value="<?php echo $step['step_number']; ?>">
                                        <input type="hidden" name="process[<?php echo $index; ?>][id]" value="<?php echo $step['id']; ?>">
                                    </div>
                                </div>
                                <div class="col-5">
                                    <div class="form-group mb-0">
                                        <label class="form-label">عنوان</label>
                                        <input type="text" class="form-control" name="process[<?php echo $index; ?>][title]" value="<?php echo htmlspecialchars($step['title']); ?>">
                                    </div>
                                </div>
                                <div class="col-2">
                                    <div class="form-group mb-0">
                                        <label class="form-label">آیکون</label>
                                        <input type="text" class="form-control" name="process[<?php echo $index; ?>][icon]" value="<?php echo htmlspecialchars($step['icon'] ?? ''); ?>">
                                    </div>
                                </div>
                                <div class="col-2" style="display: flex; align-items: flex-end;">
                                    <button type="button" class="btn btn-sm btn-danger" onclick="this.closest('.process-item').remove()" style="width: 100%;">
                                        <svg viewBox="0 0 24 24" width="16" height="16"><path fill="currentColor" d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg>
                                    </button>
                                </div>
                                <div class="col-12 mt-2">
                                    <div class="form-group mb-0">
                                        <label class="form-label">توضیحات</label>
                                        <textarea class="form-control" name="process[<?php echo $index; ?>][description]" rows="2"><?php echo htmlspecialchars($step['description'] ?? ''); ?></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- FAQ Tab -->
    <div class="tab-content" id="tab-faq">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">
                    <svg viewBox="0 0 24 24"><path fill="currentColor" d="M11 18h2v-2h-2v2zm1-16C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm0-14c-2.21 0-4 1.79-4 4h2c0-1.1.9-2 2-2s2 .9 2 2c0 2-3 1.75-3 5h2c0-2.25 3-2.5 3-5 0-2.21-1.79-4-4-4z"/></svg>
                    سوالات متداول
                </h3>
                <button type="button" class="btn btn-sm btn-secondary" onclick="addFaq()">
                    <svg viewBox="0 0 24 24" width="16" height="16"><path fill="currentColor" d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/></svg>
                    افزودن سوال
                </button>
            </div>
            <p class="form-hint" style="margin-bottom: 1rem;">سوالات رایجی که مشتریان درباره این خدمت می‌پرسند را اضافه کنید. این بخش به سئو و اعتمادسازی کمک می‌کند.</p>
            <div id="faqList">
                <?php if (isset($faq) && count($faq) > 0): ?>
                    <?php foreach ($faq as $index => $item): ?>
                        <div class="faq-item" style="background: var(--bg-light); padding: 1rem; border-radius: 12px; margin-bottom: 1rem;">
                            <div class="row">
                                <div class="col-10">
                                    <div class="form-group">
                                        <label class="form-label">سوال</label>
                                        <input type="text" class="form-control" name="faq[<?php echo $index; ?>][question]" value="<?php echo htmlspecialchars($item['question']); ?>">
                                        <input type="hidden" name="faq[<?php echo $index; ?>][id]" value="<?php echo $item['id']; ?>">
                                    </div>
                                </div>
                                <div class="col-2" style="display: flex; align-items: center;">
                                    <button type="button" class="btn btn-sm btn-danger" onclick="this.closest('.faq-item').remove()" style="width: 100%;">
                                        <svg viewBox="0 0 24 24" width="16" height="16"><path fill="currentColor" d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg>
                                    </button>
                                </div>
                                <div class="col-12">
                                    <div class="form-group mb-0">
                                        <label class="form-label">پاسخ</label>
                                        <textarea class="form-control" name="faq[<?php echo $index; ?>][answer]" rows="3"><?php echo htmlspecialchars($item['answer']); ?></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Stats Tab -->
    <div class="tab-content" id="tab-stats">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">
                    <svg viewBox="0 0 24 24"><path fill="currentColor" d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zM9 17H7v-7h2v7zm4 0h-2V7h2v10zm4 0h-2v-4h2v4z"/></svg>
                    آمار و ارقام
                </h3>
                <button type="button" class="btn btn-sm btn-secondary" onclick="addStat()">
                    <svg viewBox="0 0 24 24" width="16" height="16"><path fill="currentColor" d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/></svg>
                    افزودن آمار
                </button>
            </div>
            <p class="form-hint" style="margin-bottom: 1rem;">آمار و دستاوردهای مرتبط با این خدمت. مثال: «+۱۵۰ پروژه موفق»، «۱۰ سال تجربه»، «رضایت ۹۸٪ مشتریان»</p>
            <div id="statsList">
                <?php if (isset($stats) && count($stats) > 0): ?>
                    <?php foreach ($stats as $index => $stat): ?>
                        <div class="stat-item" style="background: var(--bg-light); padding: 1rem; border-radius: 12px; margin-bottom: 1rem;">
                            <div class="row">
                                <div class="col-4">
                                    <div class="form-group mb-0">
                                        <label class="form-label">مقدار</label>
                                        <input type="text" class="form-control" name="stats[<?php echo $index; ?>][stat_value]" value="<?php echo htmlspecialchars($stat['stat_value']); ?>">
                                        <input type="hidden" name="stats[<?php echo $index; ?>][id]" value="<?php echo $stat['id']; ?>">
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="form-group mb-0">
                                        <label class="form-label">عنوان</label>
                                        <input type="text" class="form-control" name="stats[<?php echo $index; ?>][stat_label]" value="<?php echo htmlspecialchars($stat['stat_label']); ?>">
                                    </div>
                                </div>
                                <div class="col-2" style="display: flex; align-items: flex-end;">
                                    <button type="button" class="btn btn-sm btn-danger" onclick="this.closest('.stat-item').remove()" style="width: 100%;">
                                        <svg viewBox="0 0 24 24" width="16" height="16"><path fill="currentColor" d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg>
                                    </button>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Items Tab -->
    <div class="tab-content" id="tab-items">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">
                    <svg viewBox="0 0 24 24"><path fill="currentColor" d="M4 6H2v14c0 1.1.9 2 2 2h14v-2H4V6zm16-4H8c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-1 9h-4v4h-2v-4H9V9h4V5h2v4h4v2z"/></svg>
                    زیرخدمات
                </h3>
                <button type="button" class="btn btn-sm btn-secondary" onclick="addItem()">
                    <svg viewBox="0 0 24 24" width="16" height="16"><path fill="currentColor" d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/></svg>
                    افزودن زیرخدمت
                </button>
            </div>
            <p class="form-hint" style="margin-bottom: 1rem;">خدمات فرعی یا انواع مختلف این خدمت. مثال برای غرفه: «غرفه دوطبقه»، «غرفه استاندارد»، «غرفه VIP»</p>
            <div id="itemsList">
                <?php if (isset($items) && count($items) > 0): ?>
                    <?php foreach ($items as $index => $item): ?>
                        <div class="sub-item" style="background: var(--bg-light); padding: 1rem; border-radius: 12px; margin-bottom: 1rem;">
                            <div class="row">
                                <div class="col-6">
                                    <div class="form-group">
                                        <label class="form-label">عنوان</label>
                                        <input type="text" class="form-control" name="items[<?php echo $index; ?>][title]" value="<?php echo htmlspecialchars($item['title']); ?>">
                                        <input type="hidden" name="items[<?php echo $index; ?>][id]" value="<?php echo $item['id']; ?>">
                                    </div>
                                </div>
                                <div class="col-4">
                                    <div class="form-group">
                                        <label class="form-label">آیکون</label>
                                        <input type="text" class="form-control" name="items[<?php echo $index; ?>][icon]" value="<?php echo htmlspecialchars($item['icon'] ?? ''); ?>">
                                    </div>
                                </div>
                                <div class="col-2" style="display: flex; align-items: center;">
                                    <button type="button" class="btn btn-sm btn-danger" onclick="this.closest('.sub-item').remove()" style="width: 100%;">
                                        <svg viewBox="0 0 24 24" width="16" height="16"><path fill="currentColor" d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg>
                                    </button>
                                </div>
                                <div class="col-12">
                                    <div class="form-group mb-0">
                                        <label class="form-label">توضیحات</label>
                                        <textarea class="form-control" name="items[<?php echo $index; ?>][description]" rows="2"><?php echo htmlspecialchars($item['description'] ?? ''); ?></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Save Button -->
    <div class="card" style="background: linear-gradient(135deg, var(--primary) 0%, var(--primary-light) 100%); color: white;">
        <div class="d-flex justify-between align-center">
            <div>
                <h3 style="margin-bottom: 0.5rem;">ذخیره تغییرات</h3>
                <p style="opacity: 0.8; font-size: 0.9rem;">پس از اعمال تغییرات، دکمه ذخیره را بزنید</p>
            </div>
            <button type="submit" class="btn btn-secondary">
                <svg viewBox="0 0 24 24"><path fill="currentColor" d="M17 3H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V7l-4-4zm-5 16c-1.66 0-3-1.34-3-3s1.34-3 3-3 3 1.34 3 3-1.34 3-3 3zm3-10H5V5h10v4z"/></svg>
                ذخیره خدمت
            </button>
        </div>
    </div>
</form>

<style>
    .tabs {
        background: white;
        padding: 0.5rem;
        border-radius: 12px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.05);
    }
    .tab-btn {
        padding: 0.75rem 1.5rem;
        border: none;
        background: transparent;
        border-radius: 8px;
        font-family: inherit;
        font-size: 0.9rem;
        font-weight: 600;
        color: var(--text-light);
        cursor: pointer;
        transition: all 0.3s ease;
        white-space: nowrap;
    }
    .tab-btn:hover {
        background: var(--bg-light);
        color: var(--text-dark);
    }
    .tab-btn.active {
        background: var(--primary);
        color: white;
    }
    .tab-content {
        display: none;
    }
    .tab-content.active {
        display: block;
    }

    /* Image Uploader Styles */
    .image-uploader {
        border: 2px dashed var(--border-color);
        border-radius: 12px;
        padding: 1rem;
        text-align: center;
        background: var(--bg-light);
        transition: all 0.3s ease;
    }
    .image-uploader:hover {
        border-color: var(--primary);
    }
    .image-preview-wrapper {
        position: relative;
        min-height: 120px;
        display: flex;
        align-items: center;
        justify-content: center;
        margin-bottom: 0.75rem;
    }
    .image-preview {
        max-width: 100%;
        max-height: 200px;
        border-radius: 8px;
        object-fit: cover;
    }
    .image-placeholder {
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 0.5rem;
        color: var(--text-light);
    }
    .image-placeholder svg {
        opacity: 0.5;
    }
    .remove-image-btn {
        position: absolute;
        top: 5px;
        left: 5px;
        width: 28px;
        height: 28px;
        border-radius: 50%;
        background: var(--danger);
        color: white;
        border: none;
        font-size: 18px;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: transform 0.2s;
    }
    .remove-image-btn:hover {
        transform: scale(1.1);
    }
    .image-upload-actions {
        text-align: center;
    }
    .text-muted {
        color: var(--text-light);
        font-size: 0.8rem;
    }

    /* Image Upload Modal */
    .image-upload-modal {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0,0,0,0.6);
        z-index: 1100;
        align-items: center;
        justify-content: center;
        padding: 1rem;
    }
    .image-upload-modal.active {
        display: flex;
    }
    .image-upload-modal-content {
        background: white;
        border-radius: 16px;
        max-width: 500px;
        width: 100%;
        overflow: hidden;
    }
    .image-upload-modal-header {
        padding: 1.25rem 1.5rem;
        border-bottom: 1px solid var(--border-color);
        display: flex;
        align-items: center;
        justify-content: space-between;
    }
    .image-upload-modal-header h3 {
        margin: 0;
        font-size: 1.1rem;
    }
    .image-upload-modal-body {
        padding: 1.5rem;
    }
    .drop-zone {
        border: 2px dashed var(--border-color);
        border-radius: 12px;
        padding: 3rem 2rem;
        text-align: center;
        transition: all 0.3s ease;
        cursor: pointer;
    }
    .drop-zone:hover, .drop-zone.dragover {
        border-color: var(--primary);
        background: rgba(var(--primary-rgb), 0.05);
    }
    .drop-zone svg {
        margin-bottom: 1rem;
        opacity: 0.6;
    }
    .drop-zone p {
        margin: 0;
        color: var(--text-light);
    }
    .drop-zone input[type="file"] {
        display: none;
    }
    .upload-progress {
        margin-top: 1rem;
        display: none;
    }
    .upload-progress.active {
        display: block;
    }
    .progress-bar {
        height: 6px;
        background: var(--bg-light);
        border-radius: 3px;
        overflow: hidden;
    }
    .progress-bar-fill {
        height: 100%;
        background: var(--primary);
        border-radius: 3px;
        width: 0%;
        transition: width 0.3s ease;
    }
    .upload-status {
        font-size: 0.85rem;
        color: var(--text-light);
        margin-top: 0.5rem;
        text-align: center;
    }
    .image-upload-modal-footer {
        padding: 1rem 1.5rem;
        border-top: 1px solid var(--border-color);
        display: flex;
        justify-content: flex-end;
        gap: 0.5rem;
    }
</style>

<!-- Image Upload Modal -->
<div class="image-upload-modal" id="imageUploadModal">
    <div class="image-upload-modal-content">
        <div class="image-upload-modal-header">
            <h3>آپلود تصویر</h3>
            <button type="button" class="modal-close" onclick="closeImageUploadModal()">
                <svg viewBox="0 0 24 24"><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg>
            </button>
        </div>
        <div class="image-upload-modal-body">
            <div class="drop-zone" id="dropZone">
                <svg viewBox="0 0 24 24" width="48" height="48"><path fill="currentColor" d="M19.35 10.04C18.67 6.59 15.64 4 12 4 9.11 4 6.6 5.64 5.35 8.04 2.34 8.36 0 10.91 0 14c0 3.31 2.69 6 6 6h13c2.76 0 5-2.24 5-5 0-2.64-2.05-4.78-4.65-4.96zM14 13v4h-4v-4H7l5-5 5 5h-3z"/></svg>
                <p>فایل را اینجا بکشید یا کلیک کنید</p>
                <p style="font-size: 0.8rem; margin-top: 0.5rem;">JPG, PNG, GIF, WebP (حداکثر 5MB)</p>
                <input type="file" id="imageFileInput" accept="image/jpeg,image/png,image/gif,image/webp">
            </div>
            <div class="upload-progress" id="uploadProgress">
                <div class="progress-bar">
                    <div class="progress-bar-fill" id="progressBarFill"></div>
                </div>
                <div class="upload-status" id="uploadStatus">در حال آپلود...</div>
            </div>
        </div>
        <div class="image-upload-modal-footer">
            <button type="button" class="btn btn-outline" onclick="closeImageUploadModal()">انصراف</button>
        </div>
    </div>
</div>

<script>
    // Image Uploader Variables
    let currentUploader = null;
    let currentInputId = null;
    let currentCategory = 'services';

    // Tab Switching
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
            document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
            btn.classList.add('active');
            document.getElementById('tab-' + btn.dataset.tab).classList.add('active');
        });
    });

    // Image Uploader Functions
    function openImageUploader(button) {
        const uploader = button.closest('.image-uploader');
        currentUploader = uploader;
        currentInputId = uploader.dataset.input;
        currentCategory = uploader.dataset.category || 'services';
        document.getElementById('imageUploadModal').classList.add('active');
    }

    function closeImageUploadModal() {
        document.getElementById('imageUploadModal').classList.remove('active');
        document.getElementById('uploadProgress').classList.remove('active');
        document.getElementById('progressBarFill').style.width = '0%';
        currentUploader = null;
        currentInputId = null;
    }

    function removeImage(button) {
        const uploader = button.closest('.image-uploader');
        const inputId = uploader.dataset.input;
        const previewWrapper = uploader.querySelector('.image-preview-wrapper');

        // Clear input value
        document.getElementById(inputId).value = '';

        // Reset preview
        previewWrapper.innerHTML = `
            <div class="image-placeholder">
                <svg viewBox="0 0 24 24" width="40" height="40"><path fill="currentColor" d="M19 5v14H5V5h14m0-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-4.86 8.86l-3 3.87L9 13.14 6 17h12l-3.86-5.14z"/></svg>
                <span>تصویری انتخاب نشده</span>
            </div>
        `;
    }

    function uploadFile(file) {
        if (!file || !currentUploader) return;

        const formData = new FormData();
        formData.append('file', file);
        formData.append('category', currentCategory);

        const progressEl = document.getElementById('uploadProgress');
        const progressBar = document.getElementById('progressBarFill');
        const statusEl = document.getElementById('uploadStatus');

        progressEl.classList.add('active');
        statusEl.textContent = 'در حال آپلود...';

        const xhr = new XMLHttpRequest();

        xhr.upload.addEventListener('progress', (e) => {
            if (e.lengthComputable) {
                const percent = Math.round((e.loaded / e.total) * 100);
                progressBar.style.width = percent + '%';
                statusEl.textContent = `در حال آپلود... ${percent}%`;
            }
        });

        xhr.addEventListener('load', () => {
            try {
                const response = JSON.parse(xhr.responseText);
                if (response.success) {
                    // Update input value
                    document.getElementById(currentInputId).value = response.path;

                    // Update preview
                    const previewWrapper = currentUploader.querySelector('.image-preview-wrapper');
                    previewWrapper.innerHTML = `
                        <img src="${response.location}" alt="پیش‌نمایش" class="image-preview">
                        <button type="button" class="remove-image-btn" onclick="removeImage(this)">&times;</button>
                    `;

                    statusEl.textContent = 'آپلود موفق!';
                    setTimeout(() => closeImageUploadModal(), 800);
                } else {
                    statusEl.textContent = response.error || 'خطا در آپلود';
                    progressBar.style.background = 'var(--danger)';
                }
            } catch (e) {
                statusEl.textContent = 'خطا در پردازش پاسخ';
            }
        });

        xhr.addEventListener('error', () => {
            statusEl.textContent = 'خطا در ارتباط با سرور';
            progressBar.style.background = 'var(--danger)';
        });

        xhr.open('POST', '<?php echo URL; ?>admin/uploadImage');
        xhr.send(formData);
    }

    // Drop Zone Events
    const dropZone = document.getElementById('dropZone');
    const fileInput = document.getElementById('imageFileInput');

    dropZone.addEventListener('click', () => fileInput.click());

    dropZone.addEventListener('dragover', (e) => {
        e.preventDefault();
        dropZone.classList.add('dragover');
    });

    dropZone.addEventListener('dragleave', () => {
        dropZone.classList.remove('dragover');
    });

    dropZone.addEventListener('drop', (e) => {
        e.preventDefault();
        dropZone.classList.remove('dragover');
        const file = e.dataTransfer.files[0];
        if (file && file.type.startsWith('image/')) {
            uploadFile(file);
        }
    });

    fileInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (file) {
            uploadFile(file);
        }
    });

    // Close modal on outside click
    document.getElementById('imageUploadModal').addEventListener('click', (e) => {
        if (e.target.id === 'imageUploadModal') {
            closeImageUploadModal();
        }
    });

    // Add Functions
    let featureIndex = <?php echo isset($features) ? count($features) : 0; ?>;
    let processIndex = <?php echo isset($process) ? count($process) : 0; ?>;
    let faqIndex = <?php echo isset($faq) ? count($faq) : 0; ?>;
    let statIndex = <?php echo isset($stats) ? count($stats) : 0; ?>;
    let itemIndex = <?php echo isset($items) ? count($items) : 0; ?>;

    function addFeature() {
        const html = `
            <div class="feature-item" style="background: var(--bg-light); padding: 1rem; border-radius: 12px; margin-bottom: 1rem;">
                <div class="row">
                    <div class="col-6">
                        <div class="form-group mb-0">
                            <label class="form-label">عنوان</label>
                            <input type="text" class="form-control" name="features[${featureIndex}][title]">
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="form-group mb-0">
                            <label class="form-label">آیکون</label>
                            <input type="text" class="form-control" name="features[${featureIndex}][icon]">
                        </div>
                    </div>
                    <div class="col-2" style="display: flex; align-items: flex-end;">
                        <button type="button" class="btn btn-sm btn-danger" onclick="this.closest('.feature-item').remove()" style="width: 100%;">
                            <svg viewBox="0 0 24 24" width="16" height="16"><path fill="currentColor" d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg>
                        </button>
                    </div>
                    <div class="col-12 mt-2">
                        <div class="form-group mb-0">
                            <label class="form-label">توضیحات</label>
                            <textarea class="form-control" name="features[${featureIndex}][description]" rows="2"></textarea>
                        </div>
                    </div>
                </div>
            </div>
        `;
        document.getElementById('featuresList').insertAdjacentHTML('beforeend', html);
        featureIndex++;
    }

    function addProcess() {
        const html = `
            <div class="process-item" style="background: var(--bg-light); padding: 1rem; border-radius: 12px; margin-bottom: 1rem;">
                <div class="row">
                    <div class="col-3">
                        <div class="form-group mb-0">
                            <label class="form-label">شماره مرحله</label>
                            <input type="number" class="form-control" name="process[${processIndex}][step_number]" value="${processIndex + 1}">
                        </div>
                    </div>
                    <div class="col-5">
                        <div class="form-group mb-0">
                            <label class="form-label">عنوان</label>
                            <input type="text" class="form-control" name="process[${processIndex}][title]">
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group mb-0">
                            <label class="form-label">آیکون</label>
                            <input type="text" class="form-control" name="process[${processIndex}][icon]">
                        </div>
                    </div>
                    <div class="col-2" style="display: flex; align-items: flex-end;">
                        <button type="button" class="btn btn-sm btn-danger" onclick="this.closest('.process-item').remove()" style="width: 100%;">
                            <svg viewBox="0 0 24 24" width="16" height="16"><path fill="currentColor" d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg>
                        </button>
                    </div>
                    <div class="col-12 mt-2">
                        <div class="form-group mb-0">
                            <label class="form-label">توضیحات</label>
                            <textarea class="form-control" name="process[${processIndex}][description]" rows="2"></textarea>
                        </div>
                    </div>
                </div>
            </div>
        `;
        document.getElementById('processList').insertAdjacentHTML('beforeend', html);
        processIndex++;
    }

    function addFaq() {
        const html = `
            <div class="faq-item" style="background: var(--bg-light); padding: 1rem; border-radius: 12px; margin-bottom: 1rem;">
                <div class="row">
                    <div class="col-10">
                        <div class="form-group">
                            <label class="form-label">سوال</label>
                            <input type="text" class="form-control" name="faq[${faqIndex}][question]">
                        </div>
                    </div>
                    <div class="col-2" style="display: flex; align-items: center;">
                        <button type="button" class="btn btn-sm btn-danger" onclick="this.closest('.faq-item').remove()" style="width: 100%;">
                            <svg viewBox="0 0 24 24" width="16" height="16"><path fill="currentColor" d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg>
                        </button>
                    </div>
                    <div class="col-12">
                        <div class="form-group mb-0">
                            <label class="form-label">پاسخ</label>
                            <textarea class="form-control" name="faq[${faqIndex}][answer]" rows="3"></textarea>
                        </div>
                    </div>
                </div>
            </div>
        `;
        document.getElementById('faqList').insertAdjacentHTML('beforeend', html);
        faqIndex++;
    }

    function addStat() {
        const html = `
            <div class="stat-item" style="background: var(--bg-light); padding: 1rem; border-radius: 12px; margin-bottom: 1rem;">
                <div class="row">
                    <div class="col-4">
                        <div class="form-group mb-0">
                            <label class="form-label">مقدار</label>
                            <input type="text" class="form-control" name="stats[${statIndex}][stat_value]">
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group mb-0">
                            <label class="form-label">عنوان</label>
                            <input type="text" class="form-control" name="stats[${statIndex}][stat_label]">
                        </div>
                    </div>
                    <div class="col-2" style="display: flex; align-items: flex-end;">
                        <button type="button" class="btn btn-sm btn-danger" onclick="this.closest('.stat-item').remove()" style="width: 100%;">
                            <svg viewBox="0 0 24 24" width="16" height="16"><path fill="currentColor" d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg>
                        </button>
                    </div>
                </div>
            </div>
        `;
        document.getElementById('statsList').insertAdjacentHTML('beforeend', html);
        statIndex++;
    }

    function addItem() {
        const html = `
            <div class="sub-item" style="background: var(--bg-light); padding: 1rem; border-radius: 12px; margin-bottom: 1rem;">
                <div class="row">
                    <div class="col-6">
                        <div class="form-group">
                            <label class="form-label">عنوان</label>
                            <input type="text" class="form-control" name="items[${itemIndex}][title]">
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="form-group">
                            <label class="form-label">آیکون</label>
                            <input type="text" class="form-control" name="items[${itemIndex}][icon]">
                        </div>
                    </div>
                    <div class="col-2" style="display: flex; align-items: center;">
                        <button type="button" class="btn btn-sm btn-danger" onclick="this.closest('.sub-item').remove()" style="width: 100%;">
                            <svg viewBox="0 0 24 24" width="16" height="16"><path fill="currentColor" d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg>
                        </button>
                    </div>
                    <div class="col-12">
                        <div class="form-group mb-0">
                            <label class="form-label">توضیحات</label>
                            <textarea class="form-control" name="items[${itemIndex}][description]" rows="2"></textarea>
                        </div>
                    </div>
                </div>
            </div>
        `;
        document.getElementById('itemsList').insertAdjacentHTML('beforeend', html);
        itemIndex++;
    }

    // Form Submit
    document.getElementById('serviceForm').addEventListener('submit', async function(e) {
        e.preventDefault();
        showLoading();

        try {
            const formData = new FormData(this);
            const response = await fetch('<?php echo URL; ?>admin/saveService/<?php echo $service['id']; ?>', {
                method: 'POST',
                body: formData
            });
            const result = await response.json();

            hideLoading();

            if (result.success) {
                showToast('خدمت با موفقیت ذخیره شد', 'success');
            } else {
                showToast('خطا در ذخیره خدمت', 'error');
            }
        } catch (error) {
            hideLoading();
            showToast('خطا در ارتباط با سرور', 'error');
        }
    });
</script>

<?php
$content = ob_get_clean();
include dirname(__DIR__) . '/layout.php';
?>
