<?php
$active = 'services';
$pageTitle = 'مدیریت خدمات';
ob_start();

// Extract data
$services = $data['services'] ?? [];
?>

<div class="card">
    <div class="card-header">
        <h3 class="card-title">
            <svg viewBox="0 0 24 24"><path fill="currentColor" d="M20 6h-4V4c0-1.11-.89-2-2-2h-4c-1.11 0-2 .89-2 2v2H4c-1.11 0-1.99.89-1.99 2L2 19c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V8c0-1.11-.89-2-2-2zm-6 0h-4V4h4v2z"/></svg>
            لیست خدمات
        </h3>
    </div>
    <p class="form-hint" style="margin-bottom: 1.5rem;">در این بخش می‌توانید خدمات شرکت را مشاهده و ویرایش کنید. برای فعال/غیرفعال کردن یا تغییر توضیحات هر خدمت، روی دکمه «ویرایش» کلیک کنید.</p>

    <div class="services-grid" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(320px, 1fr)); gap: 1.5rem;">
        <?php if (isset($services) && count($services) > 0): ?>
            <?php foreach ($services as $service): ?>
                <div class="service-card" style="background: var(--bg-light); border-radius: 16px; overflow: hidden; transition: all 0.3s ease;">
                    <div style="padding: 1.5rem;">
                        <div style="display: flex; align-items: center; gap: 1rem; margin-bottom: 1rem;">
                            <div style="width: 50px; height: 50px; background: linear-gradient(135deg, var(--primary), var(--primary-light)); border-radius: 12px; display: flex; align-items: center; justify-content: center; color: white; font-size: 1.5rem; font-weight: 800;">
                                <?php echo mb_substr($service['title'], 0, 1, 'UTF-8'); ?>
                            </div>
                            <div style="flex: 1;">
                                <h4 style="margin: 0 0 0.25rem; font-weight: 700; color: var(--text-dark);"><?php echo htmlspecialchars($service['title']); ?></h4>
                                <span style="font-size: 0.8rem; color: var(--text-light);">/service/<?php echo htmlspecialchars($service['slug']); ?></span>
                            </div>
                            <span style="padding: 0.25rem 0.75rem; background: <?php echo $service['is_active'] ? 'rgba(40,167,69,0.1)' : 'rgba(220,53,69,0.1)'; ?>; color: <?php echo $service['is_active'] ? 'var(--success)' : 'var(--danger)'; ?>; border-radius: 20px; font-size: 0.75rem; font-weight: 600;">
                                <?php echo $service['is_active'] ? 'فعال' : 'غیرفعال'; ?>
                            </span>
                        </div>
                        <p style="margin: 0 0 1rem; color: var(--text-light); font-size: 0.9rem; line-height: 1.6;">
                            <?php echo htmlspecialchars($service['short_description'] ?? 'بدون توضیحات'); ?>
                        </p>
                        <div style="display: flex; gap: 0.5rem;">
                            <a href="<?php echo URL; ?>admin/editService/<?php echo $service['id']; ?>" class="btn btn-sm btn-primary" style="flex: 1;">
                                <svg viewBox="0 0 24 24" width="16" height="16"><path fill="currentColor" d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/></svg>
                                ویرایش
                            </a>
                            <a href="<?php echo URL; ?>service/<?php echo $service['slug']; ?>" target="_blank" class="btn btn-sm btn-outline">
                                <svg viewBox="0 0 24 24" width="16" height="16"><path fill="currentColor" d="M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5zm0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3z"/></svg>
                                مشاهده
                            </a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="empty-state" style="grid-column: 1 / -1;">
                <svg viewBox="0 0 24 24" width="64" height="64">
                    <path d="M20 6h-4V4c0-1.11-.89-2-2-2h-4c-1.11 0-2 .89-2 2v2H4c-1.11 0-1.99.89-1.99 2L2 19c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V8c0-1.11-.89-2-2-2zm-6 0h-4V4h4v2z"/>
                </svg>
                <h4>خدماتی یافت نشد</h4>
                <p>برای شروع، ابتدا دیتابیس را راه‌اندازی کنید</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<style>
    .service-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 30px rgba(0,0,0,0.1);
    }
</style>

<?php
$content = ob_get_clean();
include dirname(__DIR__) . '/layout.php';
?>
