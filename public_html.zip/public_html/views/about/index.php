<?php
/**
 * TARAHAN BASTAN - ABOUT US PAGE
 * Masterpiece Edition v6.0
 * Concept: The Golden Heritage (Architects of Legacy)
 * Note: Title, meta, fonts loaded in header.php
 */
?>

<!-- Page-specific libraries (WOW.js & Animate.css) -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" integrity="sha512-c42qTSw/wPZ3/5LBzD+Bw5f7bSF2oxou6wEb+I/lqeaKV5FDIfMvvRp772y4jcJLKuGUOpbJMdg/BTl50fJYAw==" crossorigin="anonymous" referrerpolicy="no-referrer" media="print" onload="this.media='all'">
<script src="https://cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.min.js" integrity="sha512-Eak/29OTpb36LLo2r47IpVzPBLXnAMPAVypbSZiZ4Qkf8p/7S/XRG5xp7OKWPPYfJT6metI+IORkR5G8F900+g==" crossorigin="anonymous" referrerpolicy="no-referrer" defer></script>

<style>
    /* ═══════════════════════════════════════════════════════════════════════════
       💎 MASTERPIECE VARIABLES (Synced with v6.0)
       ═══════════════════════════════════════════════════════════════════════════ */
    :root {
        --font-primary: 'YekanBakh', sans-serif;
        
        /* 🎨 Palette: The Royal Studio */
        --color-brown-deep: #2D1810;
        --color-brown-rich: #4A2C1A;
        
        --color-gold-pure: #D4A020;
        --color-gold-metallic: #B8890F;
        --color-gold-glow: #FFD700;
        
        --color-orange-vital: #F58500;
        --color-orange-burn: #FF4500;
        
        --bg-paper: #F9F7F2;
        --bg-cream: #F5EFE6;
        
        /* 🌌 Gradients with DEPTH */
        --grad-gold-luxury: linear-gradient(135deg, #CCA045 0%, #FFE082 50%, #B88A30 100%);
        --grad-gold-text: linear-gradient(to bottom, #D4A020, #8F6B15);
        --grad-card-glass: linear-gradient(145deg, rgba(255,255,255,0.95) 0%, rgba(255,248,235,0.85) 100%);
        --grad-card-back: linear-gradient(135deg, #2D1810 0%, #4A2C1A 100%);
        
        /* 🌑 Ultra Shadows */
        --shadow-layer-1: 0 10px 30px -5px rgba(45, 24, 16, 0.1);
        --shadow-layer-2: 0 25px 60px -10px rgba(45, 24, 16, 0.15);
        --shadow-neon: 0 0 20px rgba(212, 160, 32, 0.4);
        --shadow-inset-gold: inset 0 0 0 1px rgba(212, 160, 32, 0.2), inset 0 2px 10px rgba(255,255,255,0.5);
    }

    /* ═══════════════════════════════════════════════════════════════════════════
       🛠 GLOBAL RESET
       ═══════════════════════════════════════════════════════════════════════════ */
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    body {
        background-color: var(--bg-paper);
        color: var(--color-brown-deep);
        font-family: var(--font-primary) !important;
        line-height: 1.9;
        overflow-x: hidden;
    }

    h1, h2, h3, h4, h5, h6, p, span, div, a, button {
        font-family: var(--font-primary) !important;
    }

    .ltr-number {
        direction: ltr;
        display: inline-block;
        unicode-bidi: embed;
        font-family: sans-serif;
    }

    /* Noise Texture Overlay */
    .global-texture {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.65' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3e%3crect width='100%25' height='100%25' filter='url(%23noiseFilter)' opacity='0.03'/%3E%3C/svg%3E");
        pointer-events: none;
        z-index: 9999;
        mix-blend-mode: multiply;
    }

    .container-master {
        max-width: 1360px;
        margin: 0 auto;
        padding: 0 30px;
        position: relative;
        z-index: 2;
    }

    /* ═══════════════════════════════════════════════════════════════════════════
       1. HERO SECTION: ARCHITECTS OF LEGACY
       ═══════════════════════════════════════════════════════════════════════════ */
    .hero-master {
        position: relative;
        min-height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
        background: radial-gradient(circle at center, #FFFDF5 0%, #F2E6D8 100%);
        overflow: hidden;
        padding: 150px 0 100px;
    }

    /* 3D Geometry */
    .hero-geometry {
        position: absolute;
        inset: 0;
        perspective: 1000px;
        pointer-events: none;
    }

    .geo-shape {
        position: absolute;
        transform-style: preserve-3d;
        animation: floatRotate 25s infinite linear;
        opacity: 0.6;
    }

    .geo-cube {
        width: 120px;
        height: 120px;
        border: 1px solid rgba(212, 160, 32, 0.3);
        position: absolute;
    }

    .shape-1 { top: 15%; left: 10%; animation-duration: 30s; }
    .shape-2 { bottom: 15%; right: 10%; animation-duration: 35s; animation-direction: reverse; }
    .shape-3 { top: 50%; left: 50%; width: 600px; height: 600px; border: 1px dashed rgba(212, 160, 32, 0.1); border-radius: 50%; transform: translate(-50%, -50%); animation: spin 60s linear infinite; }

    @keyframes floatRotate {
        0% { transform: translateY(0) rotateX(0) rotateY(0); }
        50% { transform: translateY(-40px) rotateX(180deg) rotateY(90deg); }
        100% { transform: translateY(0) rotateX(360deg) rotateY(180deg); }
    }

    @keyframes spin { from { transform: translate(-50%, -50%) rotate(0deg); } to { transform: translate(-50%, -50%) rotate(360deg); } }

    .hero-content-wrapper {
        position: relative;
        z-index: 10;
        text-align: center;
        max-width: 1000px;
    }

    .hero-badge-royal {
        display: inline-flex;
        align-items: center;
        gap: 12px;
        background: rgba(255,255,255,0.9);
        backdrop-filter: blur(10px);
        padding: 12px 30px;
        border-radius: 60px;
        border: 1px solid var(--color-gold-pure);
        box-shadow: 0 10px 20px rgba(212, 160, 32, 0.15);
        margin-bottom: 40px;
    }

    .hero-title-master {
        font-size: clamp(3rem, 7vw, 5.5rem);
        line-height: 1.1;
        font-weight: 900;
        color: var(--color-brown-deep);
        margin-bottom: 30px;
    }

    .hero-title-highlight {
        background: var(--grad-gold-luxury);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        position: relative;
        display: inline-block;
    }
    
    .hero-title-highlight::after {
        content: attr(data-text);
        position: absolute;
        left: 0;
        top: 0;
        z-index: -1;
        -webkit-text-stroke: 8px rgba(212, 160, 32, 0.1);
        opacity: 0.5;
    }

    .hero-desc-master {
        font-size: 1.25rem;
        color: var(--color-brown-rich);
        max-width: 750px;
        margin: 0 auto 50px;
        line-height: 1.8;
    }

    /* ═══════════════════════════════════════════════════════════════════════════
       2. HISTORY: THE DOUBLE-LAYERED TIMELINE
       ═══════════════════════════════════════════════════════════════════════════ */
    .timeline-section {
        padding: 150px 0;
        background: linear-gradient(to bottom, #fff 0%, #F9F7F2 100%);
        position: relative;
    }

    .section-title-master {
        font-size: 3rem;
        font-weight: 900;
        color: var(--color-brown-deep);
        text-align: center;
        margin-bottom: 20px;
    }

    .section-subtitle-master {
        font-size: 1.2rem;
        text-align: center;
        color: var(--color-brown-rich);
        margin-bottom: 80px;
    }

    .ascension-path {
        position: relative;
        max-width: 1100px;
        margin: 0 auto;
    }

    .ascension-spine {
        position: absolute;
        left: 50%;
        top: 0;
        bottom: 0;
        width: 6px;
        background: linear-gradient(to bottom, var(--color-gold-pure), var(--color-orange-vital), var(--color-brown-deep));
        transform: translateX(-50%);
        border-radius: 10px;
        z-index: 1;
        box-shadow: 0 0 20px rgba(212, 160, 32, 0.3);
    }

    .ascension-step {
        position: relative;
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 120px;
        z-index: 5;
    }

    .ascension-step:nth-child(odd) { flex-direction: row-reverse; }

    .step-card-wrapper {
        width: 45%;
        position: relative;
        perspective: 1000px;
    }

    .step-layer-back {
        position: absolute;
        top: 20px;
        left: 20px;
        width: 100%;
        height: 100%;
        background: var(--grad-card-back);
        border-radius: 30px;
        z-index: 1;
        opacity: 0.8;
        transform: rotateZ(-2deg);
        transition: transform 0.5s ease;
    }
    
    .step-layer-front {
        position: relative;
        background: var(--grad-card-glass);
        backdrop-filter: blur(20px);
        border: 1px solid rgba(255,255,255,0.8);
        border-radius: 30px;
        padding: 40px;
        z-index: 2;
        box-shadow: var(--shadow-layer-2);
        transform-style: preserve-3d;
        transition: transform 0.5s ease;
    }

    .step-card-wrapper:hover .step-layer-back { transform: rotateZ(-4deg) translate(-10px, 10px); }
    .step-card-wrapper:hover .step-layer-front { transform: translateY(-10px); }

    .step-number-giant {
        position: absolute;
        top: -40px;
        font-size: 6rem;
        font-weight: 900;
        color: rgba(212, 160, 32, 0.15);
        z-index: 0;
        line-height: 1;
        font-family: sans-serif; /* For Numbers */
        pointer-events: none;
    }
    
    .ascension-step:nth-child(odd) .step-number-giant { right: -20px; }
    .ascension-step:nth-child(even) .step-number-giant { left: -20px; }

    .step-connector {
        position: absolute;
        left: 50%;
        top: 50%;
        transform: translate(-50%, -50%);
        width: 24px;
        height: 24px;
        background: var(--color-gold-pure);
        border: 4px solid #fff;
        border-radius: 50%;
        box-shadow: 0 0 0 4px var(--color-gold-pure);
        z-index: 10;
    }

    .step-title {
        font-size: 1.8rem;
        font-weight: 900;
        color: var(--color-brown-deep);
        margin-bottom: 15px;
        position: relative;
        z-index: 1;
    }

    .step-desc {
        font-size: 1rem;
        color: #666;
        line-height: 1.8;
        position: relative;
        z-index: 1;
    }

    /* ═══════════════════════════════════════════════════════════════════════════
       3. VALUES: STACKED CARDS
       ═══════════════════════════════════════════════════════════════════════════ */
    .values-section {
        padding: 100px 0;
        background: var(--bg-cream);
    }

    .services-grid-master {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
        gap: 40px;
    }

    .service-stack {
        position: relative;
        height: 100%;
        transition: transform 0.4s ease;
    }

    .service-stack::before {
        content: '';
        position: absolute;
        top: 15px;
        left: 15px;
        right: -15px;
        bottom: -15px;
        background: rgba(212, 160, 32, 0.1);
        border-radius: 30px;
        z-index: 0;
        transition: all 0.4s ease;
    }

    .service-card-front {
        position: relative;
        background: #fff;
        border-radius: 30px;
        padding: 50px 30px;
        z-index: 1;
        height: 100%;
        border: 1px solid rgba(0,0,0,0.05);
        box-shadow: var(--shadow-layer-1);
        overflow: hidden;
        text-align: center;
    }

    .service-card-front::after {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 6px;
        background: var(--grad-gold-luxury);
    }

    .service-stack:hover { transform: translateY(-10px); }
    .service-stack:hover::before { top: 25px; left: 25px; background: rgba(245, 133, 0, 0.15); }

    .service-icon-box {
        width: 80px;
        height: 80px;
        background: var(--bg-cream);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 30px;
        box-shadow: var(--shadow-inset-gold);
    }

    .service-icon-box svg {
        width: 40px;
        height: 40px;
        color: var(--color-orange-vital);
    }

    /* ═══════════════════════════════════════════════════════════════════════════
       4. STATS: TREASURY OF ACHIEVEMENTS
       ═══════════════════════════════════════════════════════════════════════════ */
    .stats-section {
        padding: 100px 0;
        background: var(--color-brown-deep);
        color: #fff;
        position: relative;
        overflow: hidden;
    }

    .stats-section::before {
        content: '';
        position: absolute;
        inset: 0;
        background-image: url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23D4A020' fill-opacity='0.05'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E");
    }

    .stats-grid-gold {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 30px;
        position: relative;
        z-index: 2;
    }

    .stat-box-gold {
        background: rgba(255, 255, 255, 0.05);
        border: 1px solid rgba(212, 160, 32, 0.2);
        border-radius: 24px;
        padding: 40px 20px;
        text-align: center;
        backdrop-filter: blur(10px);
        transition: all 0.3s;
    }

    .stat-box-gold:hover {
        background: rgba(212, 160, 32, 0.1);
        transform: scale(1.05);
        border-color: var(--color-gold-pure);
    }

    .stat-num-gold {
        font-size: 3.5rem;
        font-weight: 900;
        color: var(--color-gold-glow);
        margin-bottom: 10px;
        font-family: sans-serif;
    }

    .stat-label-gold {
        font-size: 1.1rem;
        color: rgba(255, 255, 255, 0.8);
    }

    /* ═══════════════════════════════════════════════════════════════════════════
       5. PROMISE / MANIFESTO
       ═══════════════════════════════════════════════════════════════════════════ */
    .manifesto-section {
        padding: 120px 0;
        background: #fff;
        text-align: center;
    }

    .manifesto-box {
        max-width: 900px;
        margin: 0 auto;
        padding: 60px;
        border: 2px solid var(--color-gold-pure);
        border-radius: 40px;
        position: relative;
    }

    .manifesto-box::before {
        content: '👑';
        position: absolute;
        top: -30px;
        left: 50%;
        transform: translateX(-50%);
        font-size: 3rem;
        background: #fff;
        padding: 0 20px;
    }

    /* ═══════════════════════════════════════════════════════════════════════════
       RESPONSIVE
       ═══════════════════════════════════════════════════════════════════════════ */
    @media (max-width: 992px) {
        .ascension-spine { left: 30px; }
        .ascension-step, .ascension-step:nth-child(odd) { 
            flex-direction: column; 
            align-items: flex-start; 
            padding-left: 70px; 
        }
        .step-card-wrapper { width: 100%; }
        .step-connector { left: 30px; }
        .step-number-giant {
            font-size: 4rem;
            top: -20px;
            right: 10px !important;
            left: auto !important;
        }
        .hero-title-master { font-size: 3rem; }
    }
</style>

<!-- GLOBAL NOISE TEXTURE -->
<div class="global-texture"></div>

<!-- 1. HERO: ARCHITECTS OF LEGACY -->
<section class="hero-master" aria-label="معرفی طراحان باستان">
    <div class="hero-geometry" aria-hidden="true">
        <div class="geo-shape shape-1"><div class="geo-cube"></div></div>
        <div class="geo-shape shape-2"><div class="geo-cube"></div></div>
        <div class="geo-shape shape-3"></div>
    </div>

    <div class="hero-content-wrapper container-master">
        <div class="hero-badge-royal wow animate__fadeInDown">
            <i class="wow animate__pulse infinite">⭐</i>
            <span>بیش از یک دهه تجربه</span>
        </div>

        <h1 class="hero-title-master wow animate__fadeInUp" data-wow-delay="0.2s">
            ما داستان شما را<br>
            <span class="hero-title-highlight" data-text="جاودانه">جاودانه</span> می‌کنیم
        </h1>

        <p class="hero-desc-master wow animate__fadeInUp" data-wow-delay="0.4s">
            از سال ۱۳۹۲، طراحان باستان نه فقط یک شرکت تبلیغاتی، بلکه خالق هویت‌های ماندگار بوده است.
            ما معتقدیم هر کسب‌وکار، امپراطوری بالقوه‌ای است که نیاز به معماری درست دارد.
        </p>

        <div class="wow animate__fadeInUp" data-wow-delay="0.6s">
            <a href="#contact" style="background: var(--grad-gold-luxury); color: #fff; padding: 18px 45px; border-radius: 50px; font-weight: 900; text-decoration: none; box-shadow: 0 15px 40px rgba(212, 160, 32, 0.4); display: inline-block;">
                شروع همکاری
            </a>
        </div>
    </div>
</section>

<!-- 2. HISTORY: THE DOUBLE-LAYERED TIMELINE -->
<section class="timeline-section" aria-labelledby="timeline-heading">
    <div class="container-master">
        <h2 class="section-title-master wow animate__fadeInUp" id="timeline-heading">سفر در زمان</h2>
        <p class="section-subtitle-master wow animate__fadeInUp">نقاط عطف امپراطوری طراحان باستان</p>

        <div class="ascension-path">
            <div class="ascension-spine" aria-hidden="true"></div>

            <?php if (!empty($data['timeline'])): foreach ($data['timeline'] as $item): ?>
            <article class="ascension-step wow animate__fadeInUp">
                <div class="step-connector" aria-hidden="true"></div>
                <div class="step-card-wrapper">
                    <div class="step-layer-back" aria-hidden="true"></div>
                    <div class="step-layer-front">
                        <div class="step-number-giant" aria-hidden="true"><span class="ltr-number"><?= htmlspecialchars($item['year'] ?? '', ENT_QUOTES, 'UTF-8') ?></span></div>
                        <h3 class="step-title"><?= htmlspecialchars($item['title'] ?? '', ENT_QUOTES, 'UTF-8') ?></h3>
                        <p class="step-desc"><?= htmlspecialchars($item['description'] ?? '', ENT_QUOTES, 'UTF-8') ?></p>
                    </div>
                </div>
            </article>
            <?php endforeach; endif; ?>
        </div>
    </div>
</section>

<!-- 3. PILLARS: STACKED VALUES -->
<section class="values-section" aria-labelledby="values-heading">
    <div class="container-master">
        <h2 class="section-title-master wow animate__fadeInUp" id="values-heading">ستون‌های قدرت ما</h2>
        <p class="section-subtitle-master wow animate__fadeInUp">اصولی که روی آن‌ها ایستاده‌ایم</p>

        <div class="services-grid-master">
            <?php if (!empty($data['values'])): $delay = 0.1; foreach ($data['values'] as $value): ?>
            <article class="service-stack wow animate__fadeInUp" data-wow-delay="<?= $delay ?>s">
                <div class="service-card-front">
                    <div class="service-icon-box" aria-hidden="true">
                        <?= $value['icon'] ?? '' ?>
                    </div>
                    <h3 class="step-title"><?= htmlspecialchars($value['title'] ?? '', ENT_QUOTES, 'UTF-8') ?></h3>
                    <p class="step-desc"><?= htmlspecialchars($value['description'] ?? '', ENT_QUOTES, 'UTF-8') ?></p>
                </div>
            </article>
            <?php $delay += 0.1; endforeach; endif; ?>
        </div>
    </div>
</section>

<!-- 4. STATS: TREASURY OF ACHIEVEMENTS -->
<section class="stats-section">
    <div class="container-master">
        <div class="section-title-master" style="color: #fff; margin-bottom: 50px;">افتخارات ما</div>
        
        <div class="stats-grid-gold">
            <?php if (!empty($data['stats'])): $delay = 0; foreach ($data['stats'] as $stat): ?>
            <div class="stat-box-gold wow animate__zoomIn" <?= $delay > 0 ? "data-wow-delay=\"{$delay}s\"" : '' ?>>
                <div class="stat-num-gold"><?= $stat['prefix'] ?? '' ?><span class="ltr-number"><?= $stat['stat_value'] ?></span><?= $stat['suffix'] ?? '' ?></div>
                <div class="stat-label-gold"><?= $stat['stat_label'] ?></div>
            </div>
            <?php $delay += 0.1; endforeach; endif; ?>
        </div>
    </div>
</section>

<!-- 5. SERVICES LINKS (Simplified Stack) -->
<section style="padding: 100px 0; background: #fff;">
    <div class="container-master">
        <div class="section-title-master">دپارتمان‌های ما</div>
        <div class="services-grid-master" style="margin-top: 50px;">
            <a href="<?= URL ?>service/idea" class="service-link-card">
                <div class="service-stack wow animate__fadeInUp">
                    <div class="service-card-front" style="display: flex; align-items: center; justify-content: space-between; padding: 30px;">
                        <h3 class="step-title" style="margin: 0; font-size: 1.4rem;">مشاوره و ایده</h3>
                        <span style="color: var(--color-gold-pure); font-size: 2rem;" aria-hidden="true">&larr;</span>
                    </div>
                </div>
            </a>

            <a href="<?= URL ?>service/ads" class="service-link-card">
                <div class="service-stack wow animate__fadeInUp" data-wow-delay="0.1s">
                    <div class="service-card-front" style="display: flex; align-items: center; justify-content: space-between; padding: 30px;">
                        <h3 class="step-title" style="margin: 0; font-size: 1.4rem;">تبلیغات محیطی</h3>
                        <span style="color: var(--color-gold-pure); font-size: 2rem;" aria-hidden="true">&larr;</span>
                    </div>
                </div>
            </a>

            <a href="<?= URL ?>service/event" class="service-link-card">
                <div class="service-stack wow animate__fadeInUp" data-wow-delay="0.2s">
                    <div class="service-card-front" style="display: flex; align-items: center; justify-content: space-between; padding: 30px;">
                        <h3 class="step-title" style="margin: 0; font-size: 1.4rem;">برگزاری رویداد</h3>
                        <span style="color: var(--color-gold-pure); font-size: 2rem;" aria-hidden="true">&larr;</span>
                    </div>
                </div>
            </a>
        </div>
    </div>
</section>

<!-- 6. MANIFESTO / PROMISE -->
<section class="manifesto-section">
    <div class="container-master">
        <div class="manifesto-box wow animate__pulse">
            <h2 class="section-title-master" style="font-size: 2.5rem;">وعده طراحان باستان</h2>
            <p class="hero-desc-master" style="margin-bottom: 0;">
                ما متعهدیم که با تمام توان در کنار شما باشیم.
                از اولین جلسه مشاوره تا تحویل نهایی پروژه، ما شریک رویاهای شما هستیم.
                موفقیت شما، تنها معیار سنجش موفقیت ماست.
            </p>
        </div>
    </div>
</section>

<!-- 7. CTA -->
<section style="padding: 100px 0; background: var(--bg-paper);" id="contact">
    <div class="container-master">
        <div style="
            background: var(--grad-gold-luxury);
            border-radius: 50px;
            padding: 80px 50px;
            text-align: center;
            position: relative;
            overflow: hidden;
            box-shadow: 0 30px 80px -10px rgba(212, 160, 32, 0.5);
        " class="wow animate__zoomIn">
            
            <h2 style="font-size: 3rem; color: #fff; margin-bottom: 30px; text-shadow: 0 2px 10px rgba(0,0,0,0.1);">
                آماده خلق یک شاهکار هستید؟
            </h2>
            <p style="font-size: 1.3rem; color: rgba(255,255,255,0.9); max-width: 700px; margin: 0 auto 50px;">
                یک تماس ساده می‌تواند آغازگر بزرگترین تغییر در کسب‌وکار شما باشد.
            </p>
            
            <div style="display: flex; gap: 20px; justify-content: center; flex-wrap: wrap;">
                <a href="<?= URL ?>contact" style="
                    background: #fff;
                    color: var(--color-orange-vital);
                    font-size: 1.3rem;
                    font-weight: 900;
                    padding: 20px 50px;
                    border-radius: 20px;
                    text-decoration: none;
                    box-shadow: 0 10px 30px rgba(0,0,0,0.1);
                ">
                    تماس با ما
                </a>
                <a href="<?= URL ?>" style="
                    background: rgba(255,255,255,0.2);
                    border: 2px solid rgba(255,255,255,0.5);
                    color: #fff;
                    font-size: 1.3rem;
                    font-weight: 900;
                    padding: 18px 40px;
                    border-radius: 20px;
                    text-decoration: none;
                ">
                    نمونه کارها
                </a>
            </div>
        </div>
    </div>
</section>

<script>
    new WOW().init();
    
    // Counters for Stats
    const observerOptions = {
        threshold: 0.5
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const counters = entry.target.querySelectorAll('.ltr-number');
                counters.forEach(counter => {
                    const target = parseInt(counter.innerText);
                    let current = 0;
                    const increment = Math.ceil(target / 50);
                    const timer = setInterval(() => {
                        current += increment;
                        if (current >= target) {
                            current = target;
                            clearInterval(timer);
                        }
                        counter.innerText = current;
                    }, 30);
                });
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);

    const statsSection = document.querySelector('.stats-grid-gold');
    if(statsSection) observer.observe(statsSection);
</script>