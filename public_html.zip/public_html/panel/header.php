<!DOCTYPE html>
<html lang="en">
<head>
    <base href="<?= U ?>">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width">
    <title>طراحان باستان</title>
    <link rel="stylesheet" href="view/assets/reset.css">
    <link rel="icon" href="view/assets/icon1.jpg" type="image/x-icon">
    <link rel="stylesheet" href="view/assets/LineProgressbar/jquery.lineProgressbar.min.css">
    <link rel="stylesheet" href="view/assets/calendar/js-persian-cal.css">
    <link rel="stylesheet" href="view/assets/wow/css/libs/animate.css" type="text/css">
    <link href="view/assets/uploadfile/uploadfile.css" rel="stylesheet">
    <script src="view/assets/jquery-3.3.1.min.js"></script>
    <script type="text/javascript" src="view/assets/LineProgressbar/jquery.lineProgressbar.js"></script>
    <script type="text/javascript" src="view/assets/wow/dist/wow.min.js"></script>
    <script>new WOW().init();</script>
    <style>


        /* General Styles */
        @font-face {
            font-family: BYekan;
            src: url(view/assets/fonts/BYekan.eot) format('eot'),
            url(view/assets/fonts/BYekan.woff) format('woff'),
            url(view/assets/fonts/BYekan.ttf) format('truetype')
        }

        @font-face {
            font-family: Nazanin;
            src: url(view/assets/fonts/Nazanin.eot) format('eot'),
            url(view/assets/fonts/Nazanin.woff) format('woff'),
            url(view/assets/fonts/Nazanin.ttf) format('truetype')
        }

        @font-face {
            font-family: IRANSans;
            font-style: normal;
            font-weight: normal;
            src: url(view/assets/fonts/BRoya.eot) format('eot'),
            url(view/assets/fonts/BRoya.woff) format('woff'),
            url(view/assets/fonts/BRoya.ttf) format('truetype')
        }

        @font-face {
            font-family: mapno;
            font-style: normal;
            font-weight: normal;
            src: url(view/assets/fonts/vazir/Vazir-FD.eot) format('eot'),
            url(view/assets/fonts/vazir/Vazir-FD.woff) format('woff'),
            url(view/assets/fonts/vazir/Vazir-FD.ttf) format('truetype')
        }

        @font-face {
            font-family: mapnoS;
            font-style: normal;
            font-weight: normal;
            src: url(view/assets/fonts/vazir/Vazir-Thin-FD.eot) format('eot'),
            url(view/assets/fonts/vazir/Vazir-Thin-FD.woff) format('woff'),
            url(view/assets/fonts/vazir/Vazir-Thin-FD.ttf) format('truetype')
        }

        body {
            background-color: #dafffd;
        }

        body * {
            font-family: Byekan;
        }

        a:active, a:focus {
            outline: none;
            ie-dummy: expression(this.hideFocus=true);
        }

        .none {
            display: none;
        }

        *:focus{
            outline: none;
        }

        html, body, #main, p, span {
            direction: rtl;
            text-align: right;
            font-family: Byekan;
            font-size: 13px;
        }

        .inline_block {
            display: inline-block !important;
        }

        .submit {
            display: inline-block;
            width: 100px;
            background-color: #08102f;
            height: 35px;
            box-sizing: border-box;
            padding-top: 10px;
            text-align: center !important;
            cursor: pointer;
            color: white;
            border-radius: 4px;
            border: 1px solid #08102f !important;
        }

        .submit:hover, .submit2:hover, .submit3:hover {
            box-shadow: 0 0 6px 0 #083e46;
            transition: 0.4s;
        }

        .none {
            display: none;
        }

        a {
            color: #162738;
            text-decoration: none;
            cursor: pointer;
            font-size: 13px;
            font-family: Byekan;
        }

        h1, h2, h3, h4 {
            font-family: BYekan !important;
            color: #34495e;
        }

        .clear {
            clear: both;
        }

        ul {
            list-style: none;
            font-size: 0;

        }

        .fwc {
            width: 1200px;
            margin: 0 auto;
        }

        .clear {
            clear: both;
        }

    </style>
</head>
<body>
<div id="main">
    <!-- Menu -->


