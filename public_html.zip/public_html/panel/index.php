<?php


include ('view/assets/jdf/jdf.php');
require 'core/config.php';
require 'core/app.php';
require 'core/model.php';
require 'core/controller.php';

new App;