<?php

class laser extends Controller
{
    public $userId;

    function __construct()
    {
        parent::__construct();
        Model::sessionInit();
        $login = Model::sessionGet('login');
        $noe = Model::sessionGet('noe');
        if (isset($login) && isset($noe) && $login == true && $noe == 'laser') {
            $this->userId = Model::sessionGet('id');
        } else {
             $location = U . 'index/index';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
        }
    }

    function index()
    {
        $user = $this->model->getUser($this->userId);
        $msg = $this->model->getMsg($this->userId);
        $nemodar = $this->model->getDetail($this->userId);
        $new = $this->model->getNewOrder();
        $old = $this->model->getOldOrder();
        Model::sessionSet('message', count($msg));
        Model::sessionSet('new', $new);
        $data = [$user, $msg, $nemodar, $new, $old];
        $this->view('laser/index', $data, '', 1);
    }

    function seen()
    {
        if (isset($_POST)) {
            $seen = $_POST['seen'];
            $this->model->seenMsg($seen, $this->userId);
        }
    }


    function manag()
    {
        $msg = $this->model->getMsg($this->userId);
        $new = $this->model->getNewOrder();
        Model::sessionSet('message', count($msg));
        Model::sessionSet('new', $new);
        $order = $this->model->getOrder();
        $data = [$order];
        $this->view('laser/manage', $data, '', 1);
    }

    function changStatus($id)
    {
        $id=Model::sanitize($id);
        $this->model->changStatus($id, $this->userId);
         $location = U . 'laser/manag';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function editone($id)
    {
        $id=Model::sanitize($id);
        $order = $this->model->getOneOrder($id);
        $level = $this->model->getLevel($id);
        $plaxi = $this->model->getPlaxi($id);
        $laser = $this->model->getLaser($id);
        $color = $this->model->getColor();
        $jens = $this->model->getJens();
        $setting = $this->model->getSetting();
        $data = [$order, $level, $plaxi, $laser, $color, $jens, $setting];
        $this->view('laser/editOne', $data, '', 1);
    }

    function setChange($id)
    {
        $id=Model::sanitize($id);
        if (isset($_POST)) {
            @$next = Model::sanitize($_POST['next']);
            $this->model->setChange($this->userId, $id, $next);
        }
        $location = U . 'laser/manag';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function des($id)
    {
        $id=Model::sanitize($id);
        if (isset($_POST['des'])) {
            @$dis = Model::sanitize($_POST['des']);
            @$tool = Model::sanitize($_POST['tool']);
            @$weight = Model::sanitize($_POST['weight']);
            @$height = Model::sanitize($_POST['heghit']);
            @$tedad = Model::sanitize($_POST['tedad']);
            @$color = Model::sanitize($_POST['color']);
            @$jens = Model::sanitize($_POST['jens']);
            @$time = Model::sanitize($_POST['time']);
            @$price1 = Model::sanitize($_POST['price']);
            @$price2 = Model::sanitize($_POST['price2']);
            //echo $dis;
            $this->model->des($this->userId, $id, $tool, $weight, $height, $tedad, $color, $jens, $time, $price1, $price2, $dis);
        }
        $location = U . 'laser/editone/'.$id;
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function edit()
    {
        $user = $this->model->getUser($this->userId);
        $data = [$user];
        $this->view('laser/editUser', $data, '', 1);
    }

    function editUser1()
    {
        if (isset($_POST)) {
            $form = Model::sanitize($_POST);
            $this->model->editUser1($this->userId, $form);
        }
        $location = U . 'laser/edit';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function editUser2()
    {
        if (isset($_FILES['file'])) {
            $form = $_FILES['file'];
            $this->model->editUser2($this->userId, $form);
        }
        $location = U . 'laser/edit';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function editUser3()
    {
        if (isset($_POST)) {
            $pass0 = Model::sanitize($_POST['pass0']);
            $pass1 = Model::sanitize($_POST['pass1']);
            $pass2 = Model::sanitize($_POST['pass2']);
            if ($pass1 == $pass2) {
                $this->model->editPass($this->userId, $pass0, $pass1);
            }
        }
        $location = U . 'laser/edit';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function anbar()
    {
        $user = $this->model->getUser($this->userId);
        $plaxi = $this->model->getPlaxi();
        $jens = $this->model->getJens();
        $color = $this->model->getColor();
        $setting = $this->model->getSetting();
        $data = [$user, $plaxi, $jens, $color, $setting];
        $this->view('laser/anbar', $data, '', 1);
    }

    function editPlaxi()
    {
        if (isset($_POST)) {
            $one = Model::sanitize($_POST['1']);
            $two = Model::sanitize($_POST['2']);
            $thery = Model::sanitize($_POST['3']);
            $for = Model::sanitize($_POST['4']);
            $five = Model::sanitize($_POST['5']);
            $six = Model::sanitize($_POST['6']);
            $seven = Model::sanitize($_POST['7']);
            $eight = Model::sanitize($_POST['8']);
            $nin = Model::sanitize($_POST['9']);
            $ten = Model::sanitize($_POST['10']);
            $this->model->editPlaxi($one, $two, $thery, $for, $five, $six, $seven, $eight, $nin, $ten);
        }
        $location = U . 'laser/anbar';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function addJens()
    {
        if (isset($_POST)) {
            $name = Model::sanitize($_POST['name']);
            $this->model->addJens($name);
        }
        $location = U . 'laser/anbar';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function deletJens($id)
    {
        $id=Model::sanitize($id);
        $this->model->delJens($id);
        $location = U . 'laser/anbar';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function addColor()
    {
        if (isset($_POST)) {
            $name = Model::sanitize($_POST['name']);
            $this->model->addColor($name);
        }
        $location = U . 'laser/anbar';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function deletColor($id)
    {
        $id=Model::sanitize($id);
        $this->model->delColor($id);
        $location = U . 'laser/anbar';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function setting()
    {
        if (isset($_POST)) {
            $minet = Model::sanitize($_POST['minet']);
            $zarib = Model::sanitize($_POST['zarib']);
            $this->model->editSetting($minet,$zarib);
        }
        $location = U . 'laser/anbar';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function logOut()
    {
        unset($_SESSION['login']);
        unset($_SESSION['noe']);
        $location = U . 'index/index';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

}
