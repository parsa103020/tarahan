<?php

class respect extends Controller
{
    public $userId;

    function __construct()
    {
        parent::__construct();
        Model::sessionInit();
        $login = Model::sessionGet('login');
        $noe = Model::sessionGet('noe');
        if (isset($login) && isset($noe) && $login == true && $noe == 'respect') {
            $this->userId = Model::sessionGet('id');
        } else {
             $location = U . 'index/index';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
        }
    }


    function index()
    {
        $user = $this->model->getUser($this->userId);
        $msg = $this->model->getMsg($this->userId);
        $nemodar = $this->model->getDetail($this->userId);
        Model::sessionSet('message', count($msg));
        $data = [$user, $msg, $nemodar];
        $this->view('respect/index', $data, '', 1);
    }

    function seen()
    {
        if (isset($_POST)) {
            $seen = Model::sanitize($_POST['seen']);
            $this->model->seenMsg($seen, $this->userId);
        }
    }

    function insert()
    {
        $cousomer_hag = $this->model->getCusHag();
        $cousomer_hog = $this->model->getCusHog();
        $servic = $this->model->getServic();
        $special = $this->model->getSServic();
        $ashnai = $this->model->getAsh();
        $data = [$servic, $cousomer_hag, $cousomer_hog, $special, $ashnai];
        $this->view('respect/insert', $data, '', 1);
    }

    function searchCus1()
    {
        if (isset($_POST)) {
            $search = Model::sanitize($_POST['search']);
            $result = $this->model->searchCus1($search);
            $data = [$result];
            $this->view('respect/cus1', $data, 1, 1);
        }
    }

    function searchCus2()
    {
        if (isset($_POST)) {
            $search = Model::sanitize($_POST['search']);
            $result = $this->model->searchCus2($search);
            $data = [$result];
            $this->view('respect/cus2', $data, 1, 1);
        }
    }

    function insertRes()
    {
        if (isset($_POST)) {
            $data = Model::sanitize($_POST);
            $da = $this->model->insertRes($this->userId, $data);
            Model::sessionSet('factor', $da[1]);
            echo $da[0];
        }
    }

    function print($id)
    {
        $id = Model::sanitize($id);
        $orders = $this->model->getOneFactor($id);
        $factor = $this->model->gFactor($id);
        $data = [$orders, $factor];
        $this->view('respect/print', $data, '', 1);
    }

    function insertHagh()
    {
        if (isset($_POST)) {
            $data = Model::sanitize($_POST);
            $this->model->insertHagh($this->userId, $data);
        }
        $location = U . 'respect/insert';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function insertHogh()
    {
        if (isset($_POST)) {
            $data = Model::sanitize($_POST);
            $this->model->insertHogh($this->userId, $data);
        }
                $location = U . 'respect/insert';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }


    function insertAsh()
    {
        if (isset($_POST)) {
            $data = Model::sanitize($_POST);
            $this->model->insertAsh($data);
        }
                $location = U . 'respect/insert';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function manag()
    {
        $order = $this->model->getOrder();
        $data = [$order];
        $this->view('respect/manage', $data, '', 1);
    }

    function showTime()
    {
        $time = Model::sanitize($_POST['time']);
        $time = Model::jaliliDate($time);
        echo $time;
    }

    function editone($id)
    {
        $id = Model::sanitize($id);
        $order = $this->model->getOneOrder($id);
        $level = $this->model->getLevel($id);
        $data = [$order, $level];
        $this->view('respect/editOne', $data, '', 1);
    }

    function setChange($id)
    {
        if (isset($_POST)) {
            @$mony = Model::sanitize($_POST['mony']);
            $mony = str_replace(',', '', $mony);
            @$next = Model::sanitize($_POST['next']);
            $this->model->setChange($id, $mony, $next);
        }
                $location = U . 'respect/manag';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function upload($id)
    {
        if (isset($_FILES)) {
            @$file = $_FILES['myfile'];
            $msg = $this->model->upload1($id, $file);
            $data = [$msg];
            $this->view('respect/editOne', $data, 1, 1);
        } else {
                    $location = U . 'respect/editone/'.$id;
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
        }
    }

    function edit()
    {
        $user = $this->model->getUser($this->userId);
        $data = [$user];
        $this->view('respect/editUser', $data, '', 1);
    }

    function editUser1()
    {
        if (isset($_POST)) {
            $form = Model::sanitize($_POST);
            $this->model->editUser1($this->userId, $form);
        }
                $location = U . 'respect/edit';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function editUser2()
    {
        if (isset($_FILES['file'])) {
            $form = $_FILES['file'];
            $this->model->editUser2($this->userId, $form);
        }
                $location = U . 'respect/edit';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function editUser3()
    {
        if (isset($_POST)) {
            $pass0 = Model::sanitize($_POST['pass0']);
            $pass1 = Model::sanitize($_POST['pass1']);
            $pass2 = Model::sanitize($_POST['pass2']);
            if ($pass1 == $pass2) {
                $this->model->editPass($this->userId, $pass0, $pass1);
            }
        }
                $location = U . 'respect/edit';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function logout()
    {
        unset($_SESSION['login']);
        unset($_SESSION['noe']);
                $location = U . 'index/index';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }

    }

    function factors()
    {
        $data = [];
        $this->view('respect/factors', $data, '', 1);
    }

    function searchFactor()
    {
        $key = Model::sanitize($_POST['key']);
        $factor = $this->model->searchFactor($key);
        $data = [$factor];
        $this->view('respect/searchFactor', $data, 1, 1);
    }

    function oneFactor($id)
    {
        $id = Model::sanitize($id);
        $factor = $this->model->getOrderByFactorId($id);
        $noe = $factor[0]['noe'];
        $cus = $factor[0]['costumer'];
        $number = $this->model->getNumberCos($cus, $noe);
        $level = $this->model->getLevel();
        $fac = $this->model->geFactorFromFactor($id);
        $data = [$factor, $level, $fac, $number];
        $this->view('respect/oneFactor', $data, '', 1);
    }

    function addPayvast()
    {
        $orderId = $_POST['id'];
        $text = $_POST['text'];
        $this->model->upPeyvast($orderId, $text);
    }

    function getPayvast()
    {
        $id = $_POST['id'];
        $order = $this->model->getOneOrder($id);
        $text = $order['payvast'];
        echo $text;
    }

    function cos()
    {
        $cos = $this->model->getAllCos();
        $data = [$cos];
        $this->view('respect/costumer', $data, '', 1);

    }

    function customer()
    {
        $data = [];
        $this->view('respect/customer', $data, '', 1);

    }

    function searchCustomer()
    {
        $key = $_POST['key'];
        $cus = $this->model->searchCustomer($key);
        $data = [$cus];
        $this->view('respect/boxSearchCustomer', $data, 1, 1);
    }

    function getHoghCus()
    {
        $id = $_POST['id'];
        $cus = $this->model->getHoghCus($id);
        $data = [$cus];
        $this->view('respect/editHogh', $data, 1, 1);
    }

    function getHaghCus()
    {
        $id = $_POST['id'];
        $cus = $this->model->getHaghCus($id);
        $data = [$cus];
        $this->view('respect/editHagh', $data, 1, 1);
    }

    function formEditHogh()
    {
        $id = $_POST['id'];
        $company = $_POST['company'];
        $manager = $_POST['manager'];
        $cod_eco = $_POST['cod_eco'];
        $mobile_manager = $_POST['mobile_manager'];
        $sabt = $_POST['sabt'];
        $email = $_POST['email'];
        $telegram = $_POST['telegram'];
        $address = $_POST['address'];
        $this->model->formEditHogh($company, $manager, $cod_eco, $mobile_manager, $sabt, $email, $telegram, $address, $id);
                $location = U . 'respect/customer';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function formEditHagh()
    {
        $id = $_POST['id'];
        $name = $_POST['name'];
        $mobile = $_POST['mobile'];
        $telegram = $_POST['telegram'];
        $email = $_POST['email'];
        $address = $_POST['address'];
        $this->model->formEditHagh($name, $mobile, $telegram, $email, $address, $id);
                $location = U . 'respect/customer';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }


    function editFacotr()
    {
        $id = $_POST['id'];
        $text = $_POST['text'];
        $this->model->editFacotr($id, $text);
                $location = U . 'manag';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }


}





