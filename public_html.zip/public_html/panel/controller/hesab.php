<?php

class hesab extends Controller
{
    public $userId;

    function __construct()
    {
        parent::__construct();
        Model::sessionInit();
        $login = Model::sessionGet('login');
        $noe = Model::sessionGet('noe');
        if (isset($login) && isset($noe) && $login == true && $noe == 'hesab') {
            $this->userId = Model::sessionGet('id');
        } else {
             $location = U . 'index/index';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
        }
    }

    function index()
    {
        $this->model->getSetting();
        $user = $this->model->getUser($this->userId);
        $nemodar = $this->model->getDetail($this->userId);
        $new = $this->model->getNewOrder();
        $msg = $this->model->getMsg($this->userId);
        Model::sessionSet('message', count($msg));
        Model::sessionSet('new', $new);
        $data = [$user, $nemodar, $new, $msg];
        $this->view('hesab/index', $data, '', 1);
    }

    function manag()
    {
        $new = $this->model->getNewOrder();
        $msg = $this->model->getMsg($this->userId);
        Model::sessionSet('message', count($msg));
        Model::sessionSet('new', $new);
        $order = $this->model->getOrder();
        $data = [$order];
        $this->view('hesab/manage', $data, '', 1);
    }

    function editone($id)
    {
        $id = Model::sanitize($id);
        $order = $this->model->getOneOrder($id);
        $level = $this->model->getLevel($id);
        $print = $this->model->getOneOrderPrint($id);
        $data = [$order, $level, $print];
        $this->view('hesab/editOne', $data, '', 1);
    }

    function setChange($id)
    {
        $id = Model::sanitize($id);
        if (isset($_POST)) {
            @$next = Model::sanitize($_POST['next']);
            @$mony = Model::sanitize($_POST['mony']);
            @$dis = Model::sanitize($_POST['dis']);
            $this->model->setChange($this->userId, $id, $next, $mony, $dis);
        }
         $location = U . 'hesab/manag';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }


    function edit($id)
    {
        $id = Model::sanitize($id);
        if ($id != 0) {
            $Id = $id;
        } else {
            $Id = $this->userId;
        }
        $user = $this->model->getUser($Id);
        $data = [$user];
        $this->view('hesab/editUser', $data, '', 1);
    }

    function editPersonel($Id)
    {
        $Id = Model::sanitize($Id);
        $user = $this->model->getUser($Id);
        $data = [$user];
        $this->view('hesab/per31', $data, '', 1);
    }

    function editUser1($id)
    {
        $id = Model::sanitize($id);
        if (isset($_POST)) {
            $form = Model::sanitize($_POST);
            $this->model->editUser1($id, $form);
        }
        $location = U . 'hesab/edit/'.$id;
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function editPer1($id)
    {
        $id = Model::sanitize($id);
        if (isset($_POST)) {
            $form = Model::sanitize($_POST);
            $this->model->editUser1($id, $form);
        }
        $location = U . 'hesab/editPersonel/'. $id;
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function editUser2($id)
    {
        $id = Model::sanitize($id);
        if (isset($_FILES['file'])) {
            $form = $_FILES['file'];
            $this->model->editUser2($id, $form);
        }
         $location = U . 'hesab/edit';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function editPer2($id)
    {
        $id = Model::sanitize($id);
        if (isset($_FILES['file'])) {
            $form = $_FILES['file'];
            $this->model->editUser2($id, $form);
        }
         $location = U . 'hesab/editPersonel/'. $id;
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function editUser3($id)
    {
        $id = Model::sanitize($id);
        if (isset($_POST)) {
            $pass0 = Model::sanitize($_POST['pass0']);
            $pass1 = Model::sanitize($_POST['pass1']);
            $pass2 = Model::sanitize($_POST['pass2']);
            if ($pass1 == $pass2) {
                $this->model->editPass($id, $pass0, $pass1);
            }
        }
         $location = U . 'hesab/edit'. $id;
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function editPersonel3($id)
    {
        $id = Model::sanitize($id);
        if (isset($_POST)) {
            $pass1 = Model::sanitize($_POST['pass1']);
            $pass2 = Model::sanitize($_POST['pass2']);
            if ($pass1 == $pass2) {
                $this->model->editPer3($id, $pass1);
            }
        }
         $location = U . 'hesab/editPersonel/'. $id;
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function logOut()
    {
        unset($_SESSION['login']);
        unset($_SESSION['noe']);
        $location = U . 'index/index';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function report()
    {
        $order = $this->model->getAllOrder();
        $data = [$order];
        $this->view('hesab/report', $data, '', 1);
    }

    function oneRespect($id)
    {
        $id = Model::sanitize($id);
        $order = $this->model->getOneOrder($id);
        $level = $this->model->getLevel($id);
        $print = $this->model->getOneOrderPrint($id);
        $data = [$order, $level, $print];
        $this->view('hesab/oneRespect', $data, '', 1);
    }

    function report2()
    {
        if (isset($_POST['start'])) {
            $start = Model::sanitize($_POST['start']);
            $end = Model::sanitize($_POST['end']);
            $order = $this->model->report2($start, $end);
            $data = [$order];
            $this->view('hesab/report1', $data, 1, 1);
        }
    }

    function report3()
    {
        if (isset($_POST['start'])) {
            $start = Model::sanitize($_POST['start']);
            $end = Model::sanitize($_POST['end']);
            $order = $this->model->report3($start, $end);
            $data = [$order];
            $this->view('hesab/report1', $data, 1, 1);
        }
    }

    function report4()
    {
        if (isset($_POST['start'])) {
            $start = Model::sanitize($_POST['start']);
            $end = Model::sanitize($_POST['end']);
            $order = $this->model->report4($start, $end);
            $data = [$order];
            $this->view('hesab/report1', $data, 1, 1);
        }
    }

    function sRespect()
    {
        if (isset($_POST['id'])) {
            $id = Model::sanitize($_POST['id']);
            $order = $this->model->sRespect($id);
            $data = [$order];
            $this->view('hesab/report1', $data, 1, 1);
        }
    }

    function sFactor()
    {
        if (isset($_POST['id'])) {
            $id = Model::sanitize($_POST['id']);
            $order = $this->model->sFactor($id);
            $data = [$order];
            $this->view('hesab/report1', $data, 1, 1);
        }
    }

    function rep()
    {
        if ($_POST['id']) {
            $id = Model::sanitize($_POST['id']);
            // for id =1
            $order = $this->model->getAllOrder();

            if ($id == 1) {
                $data = [$order];
                $this->view('hesab/report1', $data, 1, 1);
            }
            if ($id == 2) {
                $data = [];
                $this->view('hesab/report2', $data, 1, 1);
            }
            if ($id == 3) {
                $data = [];
                $this->view('hesab/report3', $data, 1, 1);
            }
            if ($id == 4) {
                $data = [];
                $this->view('hesab/report4', $data, 1, 1);
            }
            if ($id == 5) {
                $data = [];
                $this->view('hesab/sFactor', $data, 1, 1);
            }
            if ($id == 6) {
                $data = [];
                $this->view('hesab/sRespect', $data, 1, 1);
            }
        }
    }

    function per()
    {
        $per = $this->model->getPer();
        $per1 = $this->model->per1();
        $data = [$per, $per1];
        $this->view('hesab/per', $data, '', 1);
    }

    function person()
    {
        if ($_POST['id']) {
            $id = Model::sanitize($_POST['id']);
            if ($id == 1) {
                $per = $this->model->getPer();
                $per1 = $this->model->per1();
                $data = [$per, $per1];
                $this->view('hesab/per1', $data, 1, 1);
            }
            if ($id == 2) {
                $per2 = $this->model->per2();
                $data = [$per2];
                $this->view('hesab/per2', $data, 1, 1);
            }
            if ($id == 3) {
                $users = $this->model->users();
                $data = [$users];
                $this->view('hesab/per3', $data, 1, 1);
            }
        }
    }

    function msg()
    {
        $users = $this->model->users();
        $data = [$users, $this->userId];
        $this->view('hesab/message', $data, '', 1);
    }

    function showMsg()
    {
        $id = Model::sanitize($_POST['id']);
        $msg = $this->model->showMsg($id);
        $data = [$msg];
        $this->view('hesab/showMsg', $data, 1, 1);
    }

    function insertNewMsg()
    {
        $id = Model::sanitize($_POST['user']);
        $msg = Model::sanitize($_POST['msg']);
        $this->model->insertMsg($this->userId, $id, $msg);
    }

    function remember()
    {
        $rem = $this->model->remember();
        $data = [$rem];
        $this->view('hesab/remember', $data, '', 1);
    }

    function insertRem()
    {
        $rem = Model::sanitize($_POST['rem']);
        $this->model->insertRem($rem);
        header('location:' . U . 'hesab/remember');
         $location = U . 'hesab/remember';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function del()
    {
        $id = Model::sanitize($_POST['id']);
        $this->model->removeUser($id);
        $users = $this->model->users();
        $data = [$users];
        $this->view('hesab/per3', $data, 1, 1);

    }

    function factors()
    {
        $data = [];
        $this->view('hesab/factors', $data, '', 1);
    }

    function searchFactor()
    {
        $key = Model::sanitize($_POST['key']);
        $start = Model::sanitize($_POST['start']);
        $end = Model::sanitize($_POST['end']);
        $factor = $this->model->searchFactor($key,$start,$end);
        $data = [$factor];
        $this->view('hesab/searchFactor', $data, 1, 1);
    }

    function oneFactor($id)
    {
        $id = Model::sanitize($id);
        $factor = $this->model->getOrderByFactorId($id);
        $level = $this->model->getLevel();
        $fac = $this->model->geFactorFromFactor($id);
        $data = [$factor, $level, $fac];
        $this->view('hesab/oneFactor', $data, '', 1);
    }

    function print($id)
    {
        $id = Model::sanitize($id);

        $order = $this->model->getOneOrder($id);
        $level = $this->model->getLevel($id);
        $factor = $this->model->getOrderByFactorId($id);
        $fac = $this->model->geFactorFromFactor($id);
        $print = $this->model->getPrint($id);
        $data = [$factor, $fac, $print, $order, $level];
        $this->view('hesab/print', $data, '', 1);
    }


    function document($id)
    {
        $id = Model::sanitize($id);
        $factor = $this->model->getOrderByFactorId($id);
        $level = $this->model->getLevel();
        $fac = $this->model->geFactorFromFactor($id);
        $data = [$factor, $level, $fac];
        $this->view('hesab/document', $data, '', 1);
    }

    function noshow($id)
    {
        $id = Model::sanitize($id);
        $this->model->noShow($id);
         $location = U . 'hesab/manag';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }


    function seen()
    {
        if (isset($_POST)) {
            $seen = Model::sanitize($_POST['seen']);
            $this->model->seenMsg($seen, $this->userId);
        }
    }

    function hesab()
    {
        $data = [];
        $this->view('hesab/hesab', $data, '', 1);
    }

    function bayegani()
    {
        $bayegani = $this->model->getBayegani();
        $data = [$bayegani];
        $this->view('hesab/bayegani', $data, '', 1);
    }


    function heasbChap()
    {
        $start = Model::sanitize($_POST['start']);
        $end = Model::sanitize($_POST['end']);
        $fac = $this->model->getHesabChap($start, $end);
        $data = [$fac];
        Model::sessionSet('start', $start);
        Model::sessionSet('end', $end);
        $this->view('hesab/hesab1', $data, 1, 1);
    }

    function hesab2()
    {
        $start = Model::sessionGet('start');
        $end = Model::sessionGet('end');
        $fac = $this->model->getHesabChap($start, $end);
        $data = [$fac];
        $this->view('hesab/hesab2', $data, 1, 1);
    }


    function setting()
    {
        $setting = $this->model->getsetting2();
        $data = [$setting];
        $this->view('hesab/setting', $data, '', 1);
    }

    function editSetting()
    {
        if (isset($_POST)) {
            $baner = Model::sanitize($_POST['baner']);
            $flax = Model::sanitize($_POST['flax']);
            $vinil = Model::sanitize($_POST['vinil']);
            $mesh = Model::sanitize($_POST['mesh']);
            $valed = Model::sanitize($_POST['valed']);
            $life = Model::sanitize($_POST['life']);
            $this->model->editSetting($baner, $flax, $vinil, $mesh, $valed, $life);
        }
         $location = U . 'hesab/setting';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }

    }


}
