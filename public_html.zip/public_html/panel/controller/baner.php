<?php

class baner extends Controller
{
    public $userId;

    function __construct()
    {
        parent::__construct();
        Model::sessionInit();
        $login = Model::sessionGet('login');
        $noe = Model::sessionGet('noe');
        if (isset($login) && isset($noe) && $login == true && $noe == 'baner') {
            $this->userId = Model::sessionGet('id');
        } else {
             $location = U . 'index/index';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
        }
    }

    function index()
    {
        $user = $this->model->getUser($this->userId);
        $nemodar = $this->model->getDetail($this->userId);
        $old = $this->model->getOldOrder();
        $msg = $this->model->getMsg($this->userId);
        $new = $this->model->getNewOrder();
        Model::sessionSet('message', count($msg));
        Model::sessionSet('new', $new);
        $data = [$user, $msg, $nemodar, $new, $old];
        $this->view('baner/index', $data, '', 1);
    }

    function seen()
    {
        if (isset($_POST)) {
            $seen = Model::sanitize($_POST['seen']);
            $this->model->seenMsg($seen, $this->userId);
        }
    }

    function manag()
    {
        $msg = $this->model->getMsg($this->userId);
        $new = $this->model->getNewOrder();
        Model::sessionSet('message', count($msg));
        Model::sessionSet('new', $new);
        $order = $this->model->getOrder();
        $data = [$order];
        $this->view('baner/manage', $data, '', 1);
    }

    function changStatus($id)
    {
        $id = Model::sanitize($id);
        $this->model->changStatus($id, $this->userId);
         $location = U . 'baner/manag';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function editone($id)
    {
        $id = Model::sanitize($id);
        $setting = $this->model->getSetting();
        $order = $this->model->getOneOrder($id);
        $level = $this->model->getLevel($id);
        $print = $this->model->getOneOrderPrint($id);
        $data = [$order, $level, $print, $setting];
        $this->view('baner/editOne', $data, '', 1);
    }

    function setChange($id)
    {
        $id = Model::sanitize($id);
        if (isset($_POST)) {
            @$next = Model::sanitize($_POST['next']);
            $this->model->setChange($this->userId, $id, $next);
        }
        $location = U . 'baner/manag';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function des($id)
    {
        $id = Model::sanitize($id);
        if (isset($_POST['des'])) {
            @$dis = Model::sanitize($_POST['des']);
            @$tool = Model::sanitize($_POST['tool']);
            @$arz = Model::sanitize($_POST['arz']);
            @$tool0 = Model::sanitize($_POST['tool0']);
            @$tedad = Model::sanitize($_POST['tedad']);
            @$sefidi = Model::sanitize($_POST['sefidi']);
            @$mangene = Model::sanitize($_POST['mangene']);
            @$life = Model::sanitize($_POST['life']);
            @$darbast = Model::sanitize($_POST['darbast']);
            @$space = Model::sanitize($_POST['space']);
            @$nasb = Model::sanitize($_POST['nasb']);
            @$valed = Model::sanitize($_POST['valed']);
            @$noe = Model::sanitize($_POST['noe']);
            @$mony = Model::sanitize($_POST['mony']);
            $this->model->des($this->userId, $id, $mony, $dis, $tool, $arz, $tool0, $sefidi,
                $mangene, $life, $valed, $noe, $tedad, $darbast, $space, $nasb);
        }
        $location = U . 'baner/editone/'.$id;
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function edit()
    {
        $user = $this->model->getUser($this->userId);
        $data = [$user];
        $this->view('baner/editUser', $data, '', 1);
    }

    function editUser1()
    {
        if (isset($_POST)) {
            $form = Model::sanitize($_POST);
            $this->model->editUser1($this->userId, $form);
        }
        $location = U . 'baner/edit';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function editUser2()
    {
        if (isset($_FILES['file'])) {
            $form = $_FILES['file'];
            $this->model->editUser2($this->userId, $form);
        }
        $location = U . 'baner/edit';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function editUser3()
    {
        if (isset($_POST)) {
            $pass0 = Model::sanitize($_POST['pass0']);
            $pass1 = Model::sanitize($_POST['pass1']);
            $pass2 = Model::sanitize($_POST['pass2']);
            if ($pass1 == $pass2) {
                $this->model->editPass($this->userId, $pass0, $pass1);
            }
        }
        $location = U . 'baner/edit';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function anbar()
    {
        $user = $this->model->getUser($this->userId);
        $data = [$user];
        $this->view('baner/anbar', $data, '', 1);
    }

    function rol()
    {
        if (isset($_POST)) {
            $weight = Model::sanitize($_POST['weight']);
            $noe = Model::sanitize($_POST['noe']);
            $height = Model::sanitize($_POST['height']);
            $num = Model::sanitize($_POST['num']);
            $this->model->rol($this->userId, $weight, $height, $num, $noe);
        }
        $location = U . 'baner/anbar';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function logOut()
    {
        unset($_SESSION['login']);
        unset($_SESSION['noe']);
        $location = U . 'index/index';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function setting()
    {
        $user = $this->model->getUser($this->userId);
        $setting = $this->model->getSetting();
        $data = [$user, $setting];
        $this->view('baner/setting', $data, '', 1);
    }

    function deletArz($id)
    {
        $id = Model::sanitize($id);
        $this->model->delArz($id);
        $location = U . 'baner/setting';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function addArz()
    {
        if (isset($_POST)) {
            $name = Model::sanitize($_POST['name']);
            $this->model->addArz($name);
        }
        $location = U . 'baner/setting';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function new()
    {
        if (isset($_POST)) {
            $weight = Model::sanitize($_POST['weight']);
            $height = Model::sanitize($_POST['height']);
            $noe = Model::sanitize($_POST['noe']);
            $this->model->new($this->userId, $weight, $height, $noe);
        }
        $location = U . 'baner/anbar';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function newPlaxi()
    {
        if (isset($_POST)) {
            $zekh = Model::sanitize($_POST['zekh']);
            $weight = Model::sanitize($_POST['weight']);
            $height = Model::sanitize($_POST['height']);
            $color = Model::sanitize($_POST['color']);
            $this->model->newPlaxi($this->userId, $zekh, $weight, $height, $color);
        }
        $location = U . 'baner/anbar';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }
}
