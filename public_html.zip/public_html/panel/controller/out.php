<?php

class out extends Controller
{
    public $userId;

    function __construct()
    {
        parent::__construct();
        Model::sessionInit();
        $login = Model::sessionGet('login');
        $noe = Model::sessionGet('noe');
        if (isset($login) && isset($noe) && $login == true && $noe == 'out') {
            $this->userId = Model::sessionGet('id');
        } else {
             $location = U . 'index/index';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
        }
    }

    function index()
    {
        $this->model->getNewTahvil();
        $user = $this->model->getUser($this->userId);
        $msg = $this->model->getMsg($this->userId);
        $nemodar = $this->model->getDetail($this->userId);
        $new = $this->model->getNewOrder();
        $old = $this->model->getOldOrder();
        Model::sessionSet('message', count($msg));
        Model::sessionSet('new', $new);
        $data = [$user, $msg, $nemodar, $new, $old];
        $this->view('out/index', $data, '', 1);
    }

    function seen()
    {
        if (isset($_POST)) {
            $seen = Model::sanitize($_POST['seen']);
            $this->model->seenMsg($seen, $this->userId);
        }
    }


    function manag()
    {
        $msg = $this->model->getMsg($this->userId);
        $new = $this->model->getNewOrder();
        Model::sessionSet('message', count($msg));
        Model::sessionSet('new', $new);
        $order = $this->model->getOrder();
        $data = [$order];
        $this->view('out/manage', $data, '', 1);
    }

    function end()
    {
        $this->model->getNewTahvil();
        $data = [];
        $this->view('out/end', $data, '', 1);
    }

    function search()
    {
        $key = $_POST['key'];
        $order = $this->model->searchOrder($key);
        $data = [$order];
        $this->view('out/end1', $data, 1, 1);
    }

    function tahvil()
    {
        $id = $_POST['ids'];
        $name = $_POST['name'];
        $this->model->tahvil($id, $name);
        $location = U . 'out/end';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function changStatus($id)
    {
        $id = Model::sanitize($id);
        $this->model->changStatus($id, $this->userId);
        header('location:' . U . 'out/manag');
    }

    function editone($id)
    {
        $id = Model::sanitize($id);
        $order = $this->model->getOneOrder($id);
        $level = $this->model->getLevel($id);
        $print = $this->model->getOneOrderPrint($id);
        $data = [$order, $level, $print];
        $this->view('out/editOne', $data, '', 1);
    }

    function setChange($id)
    {
        $id = Model::sanitize($id);
        if (isset($_POST)) {
            @$next = Model::sanitize($_POST['next']);
            @$mony = Model::sanitize($_POST['mony']);
            $this->model->setChange($this->userId, $id, $next, $mony);
        }
         $location = U . 'out/manag';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function des($id)
    {
        $id = Model::sanitize($id);
        if (isset($_POST['des'])) {
            @$dis = Model::sanitize($_POST['des']);
            @$gole = Model::sanitize($_POST['gole']);
            @$mony = Model::sanitize($_POST['price']);
            @$mony = str_replace(',', '', $mony);
            $this->model->des($this->userId, $id, $mony, $dis, $gole);
        }
         $location = U . 'out/editone/'.$id;
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function edit()
    {
        $user = $this->model->getUser($this->userId);
        $data = [$user];
        $this->view('out/editUser', $data, '', 1);
    }

    function editUser1()
    {
        if (isset($_POST)) {
            $form = Model::sanitize($_POST);
            $this->model->editUser1($this->userId, $form);
        }
         $location = U . 'out/edit';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function editUser2()
    {
        if (isset($_FILES['file'])) {
            $form = $_FILES['file'];
            $this->model->editUser2($this->userId, $form);
        }
         $location = U . 'out/edit';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function editUser3()
    {
        if (isset($_POST)) {
            $pass0 = Model::sanitize($_POST['pass0']);
            $pass1 = Model::sanitize($_POST['pass1']);
            $pass2 = Model::sanitize($_POST['pass2']);
            if ($pass1 == $pass2) {
                $this->model->editPass($this->userId, $pass0, $pass1);
            }
        }
         $location = U . 'out/edit';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function logOut()
    {
        unset($_SESSION['login']);
        unset($_SESSION['noe']);
         $location = U . 'index/index';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

}
