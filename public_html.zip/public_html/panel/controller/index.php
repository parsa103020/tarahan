<?php

class index extends Controller
{
    public $userId;

    function __construct()
        {
            parent::__construct();
            Model::sessionInit();
        }

    function index()
    {
        $data = [];
        $this->view('index/index', $data);
    }
    
    function sw()
    {
        
        $data = [];
        $this->view('sw.txt', $data);
    }

    function login()
    {
        if (isset($_POST['user']) && !empty($_POST['user'])) {
            $user = Model::sanitize($_POST['user']);
            $pass = Model::sanitize($_POST['pass']);
            $msg = $this->model->login($user, $pass);
            $data = [$msg];
            $this->view('index/msg', $data, 1, 1);
        }
    }


}
