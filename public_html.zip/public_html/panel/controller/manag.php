<?php

class manag extends Controller
{
    public $userId;

    function __construct()
    {
        parent::__construct();
        Model::sessionInit();

        $login = Model::sessionGet('login');
        $noe = Model::sessionGet('noe');
        if (isset($login) && isset($noe) && $login == true && $noe == 'manag') {
            $this->userId = Model::sessionGet('id');
        } else {
            $location = U . 'index/index';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
        }
    }

    function index()
    {

        $user = $this->model->getUser($this->userId);
        $nemodar = $this->model->getDetail($this->userId);
        $new = $this->model->getNewOrder();
        Model::sessionSet('new', $new);
        $data = [$user, $nemodar, $new];
        $this->view('manag/index', $data, '', 1);
    }

    function getRem()
    {
        if (isset($_POST)) {
            $rem = $this->model->getRem();
            $data = [$rem];
            $this->view('manag/msg', $data, 1, 1);
        }
    }

    function check()
    {
        if (isset($_POST)) {
            $id = $_POST['id'];
            $this->model->checkRem($id);
        }
    }


    function manag()
    {
        $new = $this->model->getNewOrder();
        Model::sessionSet('new', $new);
        $order = $this->model->getOrder();
        $data = [$order];
        $this->view('manag/manage', $data, '', 1);
    }

    function editone($id)
    {
        $id = Model::sanitize($id);
        $order = $this->model->getOneOrder($id);
        $cosId = $order['costumer'];
        $noeC = $order['Noe'];
        $costumer = $this->model->getCostumer($cosId, $noeC);
        $level = $this->model->getLevel($id);
        $print = $this->model->getOneOrderPrint($id);
        $data = [$order, $level, $print, $costumer];
        $this->view('manag/editOne', $data, '', 1);
    }

    function setChange($id)
    {
        $id = Model::sanitize($id);
        if (isset($_POST)) {
            @$fee_metr = Model::sanitize($_POST['fee_metr']);
            @$fee_perti = Model::sanitize($_POST['fee_perti']);
            @$fee_sefidi = Model::sanitize($_POST['fee_sefidi']);
            @$fee_valed = Model::sanitize($_POST['fee_valed']);
            @$fee_man = Model::sanitize($_POST['fee_man']);
            @$fee_life = Model::sanitize($_POST['fee_life']);
            @$fee_design = Model::sanitize($_POST['fee_design']);
            @$next = Model::sanitize($_POST['next']);
            @$maliat = Model::sanitize($_POST['maliat']);
            @$mony = Model::sanitize($_POST['mony']);
            @$sood = Model::sanitize($_POST['sood']);
            @$percent = Model::sanitize($_POST['percent']);
            @$dis = Model::sanitize($_POST['dis']);
            $this->model->setChange($this->userId, $id, $next, $mony, $dis, $maliat, $fee_metr, $fee_perti, $fee_sefidi, $fee_valed, $fee_man, $fee_life, $fee_design, $sood, $percent);
        }
         $location = U . 'manag/manag';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }


    function edit($id)
    {
        $id = Model::sanitize($id);
        if ($id != 0) {
            $Id = $id;
        } else {
            $Id = $this->userId;
        }
        $user = $this->model->getUser($Id);
        $data = [$user];
        $this->view('manag/editUser', $data, '', 1);
    }

    function editPersonel($Id)
    {
        $Id = Model::sanitize($Id);
        $user = $this->model->getUser($Id);
        $data = [$user];
        $this->view('manag/per31', $data, '', 1);
    }

    function editUser1($id)
    {
        $id = Model::sanitize($id);
        if (isset($_POST)) {
            $form = Model::sanitize($_POST);
            $this->model->editUser1($id, $form);
        }
         $location = U . 'manag/edit/'.$id;
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function editPer1($id)
    {
        $id = Model::sanitize($id);
        if (isset($_POST)) {
            $form = $_POST;
            $this->model->editUser1($id, $form);
        }
         $location = U . 'manag/editPersonal/'.$id;
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function editUser2($id)
    {
        $id = Model::sanitize($id);
        if (isset($_FILES['file'])) {
            $form = $_FILES['file'];
            $this->model->editUser2($id, $form);
        }

         $location = U . 'manag/edit/'.$id;
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function editPer2($id)
    {
        $id = Model::sanitize($id);
        if (isset($_FILES['file'])) {
            $form = $_FILES['file'];
            $this->model->editUser2($id, $form);
        }
         $location = U . 'manag/editPersonal/'.$id;
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function editUser3($id)
    {
        $id = Model::sanitize($id);
        if (isset($_POST)) {
            $pass0 = Model::sanitize($_POST['pass0']);
            $pass1 = Model::sanitize($_POST['pass1']);
            $pass2 = Model::sanitize($_POST['pass2']);
            if ($pass1 == $pass2) {
                $this->model->editPass($id, $pass0, $pass1);
            }
        }
         $location = U . 'manag/edit/'.$id;
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function editPersonel3($id)
    {
        $id = Model::sanitize($id);
        if (isset($_POST)) {
            $pass1 = Model::sanitize($_POST['pass1']);
            $pass2 = Model::sanitize($_POST['pass2']);
            if ($pass1 == $pass2) {
                $this->model->editPer3($id, $pass1);
            }
        }
         $location = U . 'manag/editPersonal/'.$id;
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function logOut()
    {
        unset($_SESSION['login']);
        unset($_SESSION['noe']);
         $location = U . 'index/index';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function report()
    {
        $order = $this->model->getDayOrder();
        $data = [$order];
        $this->view('manag/report', $data, '', 1);
    }

    function oneRespect($id)
    {
        $id = Model::sanitize($id);
        $order = $this->model->getOneOrder($id);
        $level = $this->model->getLevel($id);
        $print = $this->model->getOneOrderPrint($id);
        $data = [$order, $level, $print];
        $this->view('manag/oneRespect', $data, '', 1);
    }

    function report2()
    {
        if (isset($_POST['start'])) {
            $start = Model::sanitize($_POST['start']);
            $end = Model::sanitize($_POST['end']);
            $order = $this->model->report2($start, $end);
            $data = [$order];
            $this->view('manag/report00', $data, 1, 1);
        }
    }

    function report3()
    {
        if (isset($_POST['start'])) {
            $start = Model::sanitize($_POST['start']);
            $end = Model::sanitize($_POST['end']);
            $order = $this->model->report3($start, $end);
            $data = [$order];
            $this->view('manag/report1', $data, 1, 1);
        }
    }

    function report4()
    {
        if (isset($_POST['start'])) {
            $start = Model::sanitize($_POST['start']);
            $end = Model::sanitize($_POST['end']);
            $order = $this->model->report4($start, $end);
            $data = [$order];
            $this->view('manag/report1', $data, 1, 1);
        }
    }

    function sRespect()
    {
        if (isset($_POST['id'])) {
            $id = Model::sanitize($_POST['id']);
            $order = $this->model->sRespect($id);
            $data = [$order];
            $this->view('manag/report1', $data, 1, 1);
        }
    }

    function sFactor()
    {
        if (isset($_POST['id'])) {
            $id = Model::sanitize($_POST['id']);
            $order = $this->model->sFactor($id);
            $data = [$order];
            $this->view('manag/report1', $data, 1, 1);
        }
    }

    function rep()
    {
        if ($_POST['id']) {
            $id = Model::sanitize($_POST['id']);
            // for id =1
            $order = $this->model->getDayOrder();

            if ($id == 1) {
                $data = [$order];
                $this->view('manag/report0', $data, 1, 1);
            }
            if ($id == 2) {
                $data = [];
                $this->view('manag/report2', $data, 1, 1);
            }
            if ($id == 3) {
                $data = [];
                $this->view('manag/report3', $data, 1, 1);
            }
            if ($id == 4) {
                $data = [];
                $this->view('manag/report4', $data, 1, 1);
            }
            if ($id == 5) {
                $data = [];
                $this->view('manag/sFactor', $data, 1, 1);
            }
            if ($id == 6) {
                $data = [];
                $this->view('manag/sRespect', $data, 1, 1);
            }
        }
    }

    function per()
    {
        $per = $this->model->getPer();
        $per1 = $this->model->per1();
        $data = [$per, $per1];
        $this->view('manag/per', $data, '', 1);
    }

    function person()
    {
        if ($_POST['id']) {
            $id = Model::sanitize($_POST['id']);
            if ($id == 1) {
                $per = $this->model->getPer();
                $per1 = $this->model->per1();
                $data = [$per, $per1];
                $this->view('manag/per1', $data, 1, 1);
            }
            if ($id == 2) {
                $per2 = $this->model->per2();
                $data = [$per2];
                $this->view('manag/per2', $data, 1, 1);
            }
            if ($id == 3) {
                $users = $this->model->users();
                $data = [$users];
                $this->view('manag/per3', $data, 1, 1);
            }
        }
    }

    function msg()
    {
        $users = $this->model->users();
        $data = [$users, $this->userId];
        $this->view('manag/message', $data, '', 1);
    }

    function showMsg()
    {
        $id = Model::sanitize($_POST['id']);
        $msg = $this->model->showMsg($id);
        $data = [$msg];
        $this->view('manag/showMsg', $data, 1, 1);
    }

    function insertNewMsg()
    {
        $id = Model::sanitize($_POST['user']);
        $msg = Model::sanitize($_POST['msg']);
        $this->model->insertMsg($this->userId, $id, $msg);
    }

    function remember()
    {
        $rem = $this->model->remember();
        $data = [$rem];
        $this->view('manag/remember', $data, '', 1);
    }

    function insertRem()
    {
        $rem = Model::sanitize($_POST['rem']);
        $this->model->insertRem($rem);
         $location = U . 'manag/remember';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function del()
    {
        $id = Model::sanitize($_POST['id']);
        $this->model->removeUser($id);
        $users = $this->model->users();
        $data = [$users];
        $this->view('manag/per3', $data, 1, 1);

    }

    function setting()
    {
        $user = $this->model->getUser($this->userId);
        $plaxi = $this->model->getPlaxi();
        $setting = $this->model->getSetting();
        $digital = $this->model->getPriceDigital();
        $data = [$user, $plaxi, $setting, $digital];
        $this->view('manag/edit', $data, '', 1);
    }

    function editPlaxi()
    {
        if (isset($_POST)) {
            $one = Model::sanitize($_POST['1']);
            $two = Model::sanitize($_POST['2']);
            $thery = Model::sanitize($_POST['3']);
            $for = Model::sanitize($_POST['4']);
            $five = Model::sanitize($_POST['5']);
            $six = Model::sanitize($_POST['6']);
            $seven = Model::sanitize($_POST['7']);
            $eight = Model::sanitize($_POST['8']);
            $nin = Model::sanitize($_POST['9']);
            $ten = Model::sanitize($_POST['10']);
            $this->model->editPlaxi($one, $two, $thery, $for, $five, $six, $seven, $eight, $nin, $ten);
        }
         $location = U . 'manag/setting';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function editSetting()
    {
        if (isset($_POST)) {
            $minet = Model::sanitize($_POST['minet']);
            $zarib = Model::sanitize($_POST['zarib']);
            $this->model->editSetting($minet, $zarib);
        }
         $location = U . 'manag/setting';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function pish()
    {
        $data = [];
        $this->view('manag/pish', $data, '', '');
    }

    function pish2()
    {
        $day = $_POST['day'];
        $doc = $this->model->getPish($day);
        $data = [$doc];
        $this->view('manag/pish2', $data, 1, 1);
    }

    function addDigital()
    {
        if (isset($_POST)) {
            $name = Model::sanitize($_POST['name']);
            $price = Model::sanitize($_POST['price']);
            $paper = Model::sanitize($_POST['paper']);
            $this->model->addDigital($name, $price, $paper);
        }
         $location = U . 'manag/setting';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function deletDig($id)
    {
        $this->model->deletDig($id);
         $location = U . 'manag/setting';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function msgs()
    {
        $data = [];
        $this->view('manag/msgs', $data, '', 1);
    }

    function sendMsgs()
    {
        $text = $_POST['text'];
        $this->model->sendMsgs($text);
         $location = U . 'manag/msgs';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function editDig()
    {
        if (isset($_POST)) {
            $id = Model::sanitize($_POST['id']);
            $name = Model::sanitize($_POST['name']);
            $price = Model::sanitize($_POST['price']);
            $paper = Model::sanitize($_POST['paper']);
            $this->model->editDigital($id, $name, $price, $paper);
        }
         $location = U . 'manag/setting';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function laghv()
    {
        if (isset($_POST)) {
            @$id = Model::sanitize($_POST['id']);
            @$next = Model::sanitize($_POST['next']);
            @$dis = Model::sanitize($_POST['dis']);
            $this->model->laghv($this->userId, $id, $next, $dis);
        }
         $location = U . 'manag/manag';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }
    
    

    function peygiri()
    {
        $data = [];
        $this->view('manag/peygiri', $data, '', 1);
    }

    function searchFactor()
    {
        $key = Model::sanitize($_POST['key']);
        $factor = $this->model->searchFactor($key);
        $data = [$factor];
        $this->view('manag/searchFactor', $data, 1, 1);
    }

    function oneFactor($id)
    {
        $id = Model::sanitize($id);
        $factor = $this->model->getOrderByFactorId($id);
        $noe = $factor[0]['noe'];
        $cus = $factor[0]['costumer'];
        $number = $this->model->getNumberCos($cus, $noe);
        $level = $this->model->getLevel();
        $fac = $this->model->geFactorFromFactor($id);
        $data = [$factor, $level, $fac, $number];
        $this->view('manag/oneFactor', $data, '', 1);
    }

}
