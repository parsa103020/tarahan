<?php

class other extends Controller
{
    public $userId;

    function __construct()
    {
        parent::__construct();
        Model::sessionInit();
        $login = Model::sessionGet('login');
        $noe = Model::sessionGet('noe');
        if (isset($login) && isset($noe) && $login == true && $noe == 'other') {
            $this->userId = Model::sessionGet('id');
        } else {
            $location = U . 'index/index';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
        }
    }

    function index()
    {
        $user = $this->model->getUser($this->userId);
        $msg = $this->model->getMsg($this->userId);
        $nemodar = $this->model->getDetail($this->userId);
        $new = $this->model->getNewOrder();
        $old = $this->model->getOldOrder();
        Model::sessionSet('message', count($msg));
        Model::sessionSet('new', $new);
        $data = [$user, $msg, $nemodar, $new, $old];
        $this->view('other/index', $data, '', 1);
    }

    function seen()
    {
        if (isset($_POST)) {
            $seen = Model::sanitize($_POST['seen']);
            $this->model->seenMsg($seen, $this->userId);
        }
    }


    function manag()
    {
        $msg = $this->model->getMsg($this->userId);
        $new = $this->model->getNewOrder();
        Model::sessionSet('message', count($msg));
        Model::sessionSet('new', $new);
        $order = $this->model->getOrder();
        $data = [$order];
        $this->view('other/manage', $data, '', 1);
    }

    function changStatus($id)
    {
        $id = Model::sanitize($id);
        $this->model->changStatus($id, $this->userId);
        $location = U . 'other/manag';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function editone($id)
    {
        $id = Model::sanitize($id);
        $order = $this->model->getOneOrder($id);
        $kagaz = $this->model->getkagaz();
        $digital = $this->model->getDigital();
        $level = $this->model->getLevel($id);
        $print = $this->model->getOneOrderPrint($id);
        $data = [$order, $level, $print, $kagaz, $digital];
        $this->view('other/editOne', $data, '', 1);
    }

    function setChange($id)
    {
        $id = Model::sanitize($id);
        if (isset($_POST)) {
            @$next = Model::sanitize($_POST['next']);
            $this->model->setChange($this->userId, $id, $next);
        }
        $location = U . 'other/manag';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function des($id)
    {
        $id = Model::sanitize($id);
        if (isset($_POST['des'])) {
            @$dis = Model::sanitize($_POST['des']);
            @$text = Model::sanitize($_POST['text']);
            @$tedad = Model::sanitize($_POST['tedad']);
            @$paper = Model::sanitize($_POST['paper']);
            @$mony = Model::sanitize($_POST['mony']);
            $dis .= '. توضیحات فنی : ' . $text;
            $this->model->des($this->userId, $id, $mony, $dis, $tedad, $paper);
        }
        $location = U . 'other/editopne/'.$id;
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }
    function des2($id)
    {
        $id = Model::sanitize($id);
        if (isset($_POST['des'])) {
            @$dis = Model::sanitize($_POST['des']);
            @$text = Model::sanitize($_POST['text']);
            @$tedad = Model::sanitize($_POST['tedad']);
            @$price1 = Model::sanitize($_POST['price1']);
            @$paper = Model::sanitize($_POST['paper']);
            @$mony = Model::sanitize($_POST['mony']);
            $dis .= '. توضیحات فنی : ' . $text;
            $this->model->des2($this->userId, $id, $mony, $dis, $tedad, $paper,$price1);
        }
        $location = U . 'other/editone/'.$id;
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function edit()
    {
        $user = $this->model->getUser($this->userId);
        $data = [$user];
        $this->view('other/editUser', $data, '', 1);
    }

    function editUser1()
    {
        if (isset($_POST)) {
            $form = Model::sanitize($_POST);
            $this->model->editUser1($this->userId, $form);
        }
        $location = U . 'other/edit';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function editUser2()
    {
        if (isset($_FILES['file'])) {
            $form = $_FILES['file'];
            $this->model->editUser2($this->userId, $form);
        }
        $location = U . 'other/edit';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function editUser3()
    {
        if (isset($_POST)) {
            $pass0 = Model::sanitize($_POST['pass0']);
            $pass1 = Model::sanitize($_POST['pass1']);
            $pass2 = Model::sanitize($_POST['pass2']);
            if ($pass1 == $pass2) {
                $this->model->editPass($this->userId, $pass0, $pass1);
            }
        }
        $location = U . 'other/edit';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function anbar()
    {

        $user = $this->model->getUser($this->userId);
        $fac = $this->model->getF();
        $tahrir = $this->model->getA('تحریر');
        $glase = $this->model->getA('گلاسه');
        $koted = $this->model->getA('کتد');
        $katan = $this->model->getA('کتان');
        $graf = $this->model->getA('گراف');
        $data = [$user, $tahrir, $glase, $koted, $katan, $graf,$fac];
        $this->view('other/anbar', $data, '', 1);
    }

    function rol()
    {
        if (isset($_POST)) {
            $weight = Model::sanitize($_POST['weight']);
            $height = Model::sanitize($_POST['height']);
            $num = Model::sanitize($_POST['num']);
            $noe = Model::sanitize($_POST['noe']);
            $this->model->rol($this->userId, $weight, $height, $num, $noe);
        }
        $location = U . 'other/anbar';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function logOut()
    {
        unset($_SESSION['login']);
        unset($_SESSION['noe']);
        $location = U . 'index/index';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function adAnbar($item)
    {
        $noe = $_POST['gm'];
        $number = $_POST['num'];
        $this->model->adAnbar($this->userId,$item, $noe, $number);
        $location = U . 'other/anbar';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

}
