<?php

class design extends Controller
{
    public $userId;

    function __construct()
    {
        parent::__construct();
        Model::sessionInit();
        $login = Model::sessionGet('login');
        $noe = Model::sessionGet('noe');
        if (isset($login) && isset($noe) && $login == true && $noe == 'design') {
            $this->userId = Model::sessionGet('id');
        } else {
            $location = U . 'index/index';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
        }
    }

    function index()
    {
        $user = $this->model->getUser($this->userId);
        $nemodar = $this->model->getDetail($this->userId);
        $old = $this->model->getOldOrder();
        $msg = $this->model->getMsg($this->userId);
        $new = $this->model->getNewOrder();
        Model::sessionSet('message', count($msg));
        Model::sessionSet('new', $new);
        $data = [$user, $msg, $nemodar, $new, $old];
        // print_r($nemodar);
        $this->view('design/index', $data, '', 1);
    }

    function seen()
    {
        if (isset($_POST)) {
            $seen = $_POST['seen'];
            $this->model->seenMsg($seen, $this->userId);
        }
    }


    function manag()
    {
        $msg = $this->model->getMsg($this->userId);
        $new = $this->model->getNewOrder();
        Model::sessionSet('message', count($msg));
        Model::sessionSet('new', $new);
        $order = $this->model->getOrder();
        $data = [$order];
        $this->view('design/manage', $data, '', 1);
    }

    function changeStatus($id)
    {
        $id = Model::sanitize($id);
        $name = $_POST['name'];
        $this->model->changStatus($id, $name);
        $location = U . 'design/editOne/' . $id;
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function ok($id)
    {
        $id = Model::sanitize($id);
        $this->model->ok($id);
        $location = U . 'design/manag/';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function editone($id)
    {
        $id = Model::sanitize($id);
        $order = $this->model->getOneOrder($id);
        $user = $this->model->getUserDesign();
        $level = $this->model->getLevel($id);
        $cos = $order['costumer'];
        $noe = $order['noe'];
        $num = $this->model->getNumberCos($cos, $noe);
        $data = [$order, $level, $user, $num];
        $this->view('design/editOne', $data, '', 1);
    }

    function setChange($id)
    {
        $id = Model::sanitize($id);
        if (isset($_POST)) {
            @$next = Model::sanitize($_POST['next']);
            @$dis = Model::sanitize($_POST['des']);
            @$mony = Model::sanitize($_POST['mony']);
            @$mony = str_replace(',', '', $mony);
            $this->model->des($this->userId, $id, $mony, $dis);
            $this->model->setChange($this->userId, $id, 0, $next);
        }
        header('location:' . U . 'design/manag');
    }

    function upload($id)
    {
        $id = Model::sanitize($id);
        if (isset($_FILES)) {
            @$file = $_FILES['myfile'];
            $msg = $this->model->upload1($id, $file);
            $data = [$msg];
            $this->view('design/editOne', $data, 1, 1);
        } else {
             $location = U . 'design/editone/'.$id;
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
        }
    }

    function des($id)
    {
        $id = Model::sanitize($id);
        if (isset($_POST['des'])) {
            @$dis = Model::sanitize($_POST['des']);
            @$mony = Model::sanitize($_POST['mony']);
            @$mony = str_replace(',', '', $mony);
            $this->model->des($this->userId, $id, $mony, $dis);
        }
         $location = U . 'design/editone/'.$id;
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function edit()
    {
        $user = $this->model->getUser($this->userId);
        $data = [$user];
        $this->view('design/editUser', $data, '', 1);
    }

    function editUser1()
    {
        if (isset($_POST)) {
            $form = Model::sanitize($_POST);
            $this->model->editUser1($this->userId, $form);
        }
         $location = U . 'design/edit';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function editUser2()
    {
        if (isset($_FILES['file'])) {
            $form = $_FILES['file'];
            $this->model->editUser2($this->userId, $form);
        }
        header('location:' . U . 'design/edit');
         $location = U . 'design/edit';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function editUser3()
    {
        if (isset($_POST)) {
            $pass0 = Model::sanitize($_POST['pass0']);
            $pass1 = Model::sanitize($_POST['pass1']);
            $pass2 = Model::sanitize($_POST['pass2']);
            if ($pass1 == $pass2) {
                $this->model->editPass($this->userId, $pass0, $pass1);
            }
        }
         $location = U . 'design/edit';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

    function logOut()
    {
        unset($_SESSION['login']);
        unset($_SESSION['noe']);
         $location = U . 'index/index';
            if (!headers_sent()) {
                header('Location: ' . $location);
                exit;
            } else {
                echo '<script type="text/javascript">';
                echo 'window.location.href="' . $location . '";';
                echo '</script>';
                echo '<noscript>';
                echo '<meta http-equiv="refresh" content="0;url=' . $location . '" />';
                echo '</noscript>';
                exit;
            }
    }

}
