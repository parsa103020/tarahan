<?php

class model_baner extends Model
{
    //ALTER TABLE factor_hagh AUTO_INCREMENT = 1000000000;
    public $format = 'Y/n/j H:j';

    function __construct()
    {
        Model::sessionInit();
        parent::__construct();
    }
    
    function getMsg($id)
{
    $sql = "select * from msg where resive=? and seen=?";
    $stmt = self::$conn->prepare($sql);
    $stmt->bindValue(1, $id);
    $stmt->bindValue(2, 0);
    $stmt->execute();
    $result = $stmt->fetchAll();
    return $result;
}

    function seenMsg($seen, $id)
    {
    $sql = 'update msg set seen=? WHERE resive=?';
    $stmt = self::$conn->prepare($sql);
    $stmt->bindValue(1, $seen);
    $stmt->bindValue(2, $id);
    $stmt->execute();
    }

/**
 * بهینه‌سازی شده - فقط سفارشاتی که آخرین مرحله‌شان "چاپ" است
 */
    
    function getOrder()
{
    // حذف کامل pre-filter و اتکا به منطق PHP
    $sql = "SELECT * FROM orders ORDER BY id DESC LIMIT 2000";
    
    $stmt = self::$conn->prepare($sql);
    $stmt->execute();
    $result = $stmt->fetchAll();
    
    // فیلتر دقیق: فقط سفارشاتی که آخرین مرحله‌شان "چاپ" است
    foreach ($result as $key => $row) {
        $level = @unserialize($row['level']);
        if (!is_array($level) || count($level) == 0) {
            unset($result[$key]);
            continue;
        }
        
        // بررسی آخرین مرحله (نه کل تاریخچه!)
        $lastLevel = end($level);
        if (!isset($lastLevel[2]) || $lastLevel[2] != 'چاپ') {
            unset($result[$key]);
        }
    }
    
    return array_values($result);
}

    function getUser($id)
    {
        $sql = "select * from user where id=? and noe=?";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->bindValue(2, 'baner');
        $stmt->execute();
        $result = $stmt->fetch();
        return $result;
    }

    /**
     * بهینه‌سازی شده - از fetchAll به محاسبه مستقیم در دیتابیس
     * قبلاً همه داده‌ها را می‌خواند، حالا فقط آمار محاسبه می‌کند
     */
    function getDetail($id)
    {
        // به جای خواندن همه رکوردها، فقط 6 ماه اخیر را می‌خوانیم
        $now = jdate('n');
        $sixMonthsAgo = jdate('Y/n/j', strtotime('-6 months'));
        
        $sql = "select start_d from orders where baner=? and start_d >= ?";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->bindValue(2, $sixMonthsAgo);
        $stmt->execute();
        $result = $stmt->fetchAll();
        
        $one = $now - 1;
        $two = $one - 1;
        $thery = $two - 1;
        $for = $thery - 1;
        $five = $for - 1;
        $now = round($now);
        $moon = [$five, $for, $thery, $two, $one, $now];
        $now2 = $one2 = $two2 = $thery2 = $for2 = $five2 = 0;
        
        foreach ($result as $row) {
            $time = $row['start_d'];
            $time = explode('/', $time);
            @$month = $time[1];
            if ($now == $month) {
                ++$now2;
            }
            if ($one == $month) {
                ++$one2;
            }
            if ($two == $month) {
                ++$two2;
            }
            if ($thery == $month) {
                ++$thery2;
            }
            if ($for == $month) {
                ++$for2;
            }
            if ($five == $month) {
                ++$five2;
            }
        }
        $tedad = [$five2, $for2, $thery2, $two2, $one2, $now2];
        $data = [$moon, $tedad];
        return $data;
    }

 

    /**
     * بهینه‌سازی شده - استفاده از COUNT در SQL
     * قبلاً همه رکوردها را می‌خواند فقط برای شمارش
     */
    function getNewOrder()
    {
        $sql = "SELECT COUNT(*) as count FROM orders WHERE status = ?";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, 'ارسال به واحد چاپ');
        $stmt->execute();
        $result = $stmt->fetch();
        return $result['count'];
    }

    /**
     * بهینه‌سازی شده - استفاده از COUNT در SQL
     * قبلاً همه رکوردها را می‌خواند فقط برای شمارش
     */
    function getOldOrder()
    {
        $sql = "SELECT COUNT(*) as count FROM orders WHERE status = ?";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, 'در مرحله چاپ');
        $stmt->execute();
        $result = $stmt->fetch();
        return $result['count'];
    }

    function changStatus($id, $user)
    {
        $sql = 'update orders set status=?,design=? WHERE id=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, 'در مرحله چاپ');
        $stmt->bindValue(2, $user);
        $stmt->bindValue(3, $id);
        $stmt->execute();
    }

    function getOneOrder($id)
    {
        $sql = "select * from orders where id=?";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->execute();
        $result = $stmt->fetch();
        return $result;
    }

    function getOneOrderPrint($id)
    {
        $sql = "select * from print where orderid=?";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->execute();
        $result = $stmt->fetch();
        return $result;
    }

    function getLevel()
    {
        $sql = "select * from level";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    function setChange($user, $id, $next)
    {
        $sql = "select * from orders where id=?";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->execute();
        $result = $stmt->fetch();
        $level = unserialize($result['level']);
        $nowtime = Model::jaliliDate($this->format, time());
        $arr = [$nowtime, $id, $next];
        $level[] = $arr;
        $level = serialize($level);
        $status = "ارسال به واحد " . $next;
        $sql = 'update orders set level=?,now=?,status=?,baner=? WHERE id=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $level);
        $stmt->bindValue(2, $next);
        $stmt->bindValue(3, $status);
        $stmt->bindValue(4, $user);
        $stmt->bindValue(5, $id);
        $stmt->execute();
        if ($next != 'مدیر داخلی' && $next != 'مدیریت') {
            $sql = 'select * from orders where id=?';
            $stmt = self::$conn->prepare($sql);
            $stmt->bindValue(1, $id);
            $stmt->execute();
            $result = $stmt->fetch();
            if ($result['factor'] > 1000000000) {
                $noe = "hagh";
            } else {
                $noe = "hogh";
            }
            $costumer = $result['costumer'];
            $this->sendEmail2($noe, $costumer, $next, $id);
        }
        $this->emailPersonel($id, $next);
    }

    function sendEmail2($noe, $id, $next, $sefaresh)
    {
        if ($noe == 'hagh') {
            $user = $this->getCusOneHagh($id);
            $nameUser = $user['name'] . ' ' . $user['last'];
            $email = $user['email'];
            $number = $user['mobile'];
        } else {
            $user = $this->getCusOneHogh($id);
            $email = $user['email'];
            $number = $user['mobile_manager'];
            $nameUser = $user['company'];
        }

        $start = time();
        $format = 'Y/n/j';
        $start_d = Model::jaliliDate($format, $start);

        $to = $email;
        $subject = 'وضعیت سفارش در طراحان باستان';
        $from_name = 'طراحان باستان';
        $from_email = 'tarahanbastan.ir';

        $textsms = 'مشتری گرامی، ' . $nameUser . ' سفارش شما به شماره ی سفارش ' . $sefaresh . '  به واحد ' . '  ' . $next . '  ' . '  طراحان باستان ارسال شد  ';
        $textsms .= 'تاریخ ارسال پیام : ' . $start_d;
        $message = '<html><meta charset="UTF-8"><meta name="viewport" content="width=device-width"><body>';
        $message .= '<div style="width: 95%;position: relative;padding-bottom:20px;
margin: auto;background-color: #fffddf;border-radius: 10px 10px 0 0;box-sizing: border-box">';
        $message .= '<div style="text-align: center;width:100%;box-sizing: border-box;min-width: 250px; color: #62680e;
line-height: 23px;font-family: Arial;font-size: 16px;border-radius: 10px 10px 0 0; background-color: #fff98f;padding: 10px;margin: 0 auto 10px auto;">
به طراحان باستان خوش آمدید</div>';
        $message .= '<div style="text-align: center;width: 95%;line-height: 23px;font-family: Arial;font-size: 15px;margin: auto; color: #343434"> 
مشتری گرامی، ' . $nameUser . ' سفارش شما به شماره ی سفارش ' . $sefaresh . '  به واحد ' . $next . ' طراحان باستان ارسال شد ';
        $message .= " .  تاریخ ارسال پیام : " . $start_d;
        $message .= '</div>';
        $message .= '</div>';
//echo $message;
        $this->html_mail($to, $subject, $message, array('from_email' => $from_email, 'from_name' => $from_name));
        $this->SMS($number, $textsms);
    }

    /**
     * بهینه‌سازی شده - استفاده از TRANSACTION برای کاهش تعداد کوئری‌ها
     */
    function des($userId, $id, $mony, $dis, $tool, $arz, $perti, $sefidi, $mangene, $life, $valed, $noe, $tedad, $darbast, $space, $nasb)
    {
        $metr = $tool * $arz * $tedad;
        
        // استفاده از Transaction برای اطمینان از یکپارچگی داده‌ها
        self::$conn->beginTransaction();
        
        try {
            $sql = "select * from orders where id=?";
            $stmt = self::$conn->prepare($sql);
            $stmt->bindValue(1, $id);
            $stmt->execute();
            $result = $stmt->fetch();
            
            if (is_array($result)) {
                $des = unserialize($result['dis']);
            } else {
                $des = [];
            }
            
            $nowtime = Model::jaliliDate($this->format, time());
            $user = $this->getUser($userId);
            $user = $user['name'] . ' ' . $user['last'];

            $dis = $dis . ' ،توضیحات فنی :  طول  : ,' . $tool . ' عرض  : ' . $arz . ' 
            ، تعداد : ' . $tedad . ' ، متراژ: ' . round(($metr / 10000), 2) . ' ، پرتی : ' . round(($perti), 2)
            .' داربست : ' . $darbast . ' ، اسپیس: ' . $space . ' ، نصب : ' . $nasb;
            
            $arr = ['چاپ', $nowtime, $user, $mony, $dis];
            $des[] = $arr;
            $des = serialize($des);
            
            $sql = 'update orders set dis=? WHERE id=?';
            $stmt = self::$conn->prepare($sql);
            $stmt->bindValue(1, $des);
            $stmt->bindValue(2, $id);
            $stmt->execute();
            
            // insert in print
            $baner = round(($metr / 10000), 2) + round(($perti), 2);
            $sql = "select COUNT(*) as cnt from print where orderid=?";
            $stmt = self::$conn->prepare($sql);
            $stmt->bindValue(1, $id);
            $stmt->execute();
            $cnt = $stmt->fetch();
            
            if ($cnt['cnt'] == 0) {
                $user = $this->getUser($userId);
                $user = $user['name'] . ' ' . $user['last'];
                $format = 'Y/n/j';
                $time = time();
                $time_d = Model::jaliliDate($format, $time);
                $sql = 'insert into print 
                (orderid,noe,sefidi,perti_es,mangene,life,valed,metr,time,time_d,user,
                perti_operator,perti_device,tedad,tool_b,arz_b,tool_d,arz_d,life1,life2,
                darbast,space,nasb)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)';
                $stmt = self::$conn->prepare($sql);
                $stmt->bindValue(1, $id);
                $stmt->bindValue(2, $noe);
                $stmt->bindValue(3, $sefidi);
                $stmt->bindValue(4, 0);
                $stmt->bindValue(5, $mangene);
                $stmt->bindValue(6, $life);
                $stmt->bindValue(7, $valed);
                $stmt->bindValue(8, $metr);
                $stmt->bindValue(9, $time);
                $stmt->bindValue(10, $time_d);
                $stmt->bindValue(11, $user);
                $stmt->bindValue(12, 0);
                $stmt->bindValue(13, round(($perti), 2));
                $stmt->bindValue(14, $tedad);
                $stmt->bindValue(15, $tool);
                $stmt->bindValue(16, $arz);
                $stmt->bindValue(17, $baner);
                $stmt->bindValue(18, 0);
                $stmt->bindValue(19, 0);
                $stmt->bindValue(20, 0);
                $stmt->bindValue(21, $darbast);
                $stmt->bindValue(22, $space);
                $stmt->bindValue(23, $nasb);
                $stmt->execute();
            }
            
            self::$conn->commit();
        } catch (Exception $e) {
            self::$conn->rollBack();
            throw $e;
        }
    }

    function editUser1($id, $form)
    {
        $name = $form['name'];
        $last = $form['last'];
        $mobile = $form['mobile'];
        $email = $form['email'];
        $sql = 'update user set name=?,last=?,mobile=?,email=? WHERE id=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $name);
        $stmt->bindValue(2, $last);
        $stmt->bindValue(3, $mobile);
        $stmt->bindValue(4, $email);
        $stmt->bindValue(5, $id);
        $stmt->execute();
        Model::sessionSet('msg1', 1);
    }

    function editUser2($id, $file)
    {
        $fileName = $file['name'];
        $ext = pathinfo($fileName, PATHINFO_EXTENSION);
        $name = "image." . $ext;

        $fileSize = $file['size'];
        $fileTmp = $file['tmp_name'];
        $fileType = $file['type'];
        $fileError = $file['error'];
        $uploadOk = 1;
        $targetMain = 'image/user/' . $id . '/';

        if (!file_exists($targetMain)) {
            mkdir($targetMain);
        }
        if ($ext !== "jpg" and $ext !== "jpeg" and $ext !== "png") {
            $uploadOk = 0;
        }

        if (!empty($fileSize) and !empty($fileName) and !empty($fileType) and $uploadOk == 1) {
            $dir = $targetMain . 'image.png';
            $dir_100 = $targetMain . '100_image.png';
            if (file_exists($dir)) {
                unlink($dir);
            }
            if (file_exists($dir_100)) {
                unlink($dir_100);
            }
            if ($fileSize > 5242880) {
                $uploadOk = 0;
            }
            if ($uploadOk == 1) {
                $target = $targetMain . $name;
                move_uploaded_file($fileTmp, $target);
                $target100 = $targetMain . '100_' . $name;
                $this->create_thumbnail($target, $target100, 150, 150);
                $sql = 'update user set image=? WHERE id=?';
                $stmt = self::$conn->prepare($sql);
                $stmt->bindValue(1, $name);
                $stmt->bindValue(2, $id);
                $stmt->execute();
            }
        }
    }

    function editPass($userId, $pass0, $pass1)
    {
        $user = $this->getUser($userId);
        $oldHashPass = $user['pass'];
        if (password_verify($pass0, $oldHashPass)) {
            $newHashPass = password_hash($pass1, PASSWORD_DEFAULT);
            $sql = 'update user set pass=? where id=?';
            $stmt = self::$conn->prepare($sql);
            $stmt->bindValue(1, $newHashPass);
            $stmt->bindValue(2, $userId);
            $stmt->execute();
            $msg = "رمز عبور با موفقیت تغییر یافت :)";
        } else {
            $msg = "رمز عبور قدیم نادرست است :|";
        }
        Model::sessionSet('msg2', $msg);
    }

    function rol($userId, $weight, $height, $num, $noe)
    {
        $user = $this->getUser($userId);
        $user = $user['name'] . ' ' . $user['last'];
        $format = 'Y/n/j';
        $time = time();
        $time_d = Model::jaliliDate($format, $time);
        $sql = 'insert into rol (noe,weight,height,tedad,user,time,time_d) VALUES (?,?,?,?,?,?,?)';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $noe);
        $stmt->bindValue(2, $weight);
        $stmt->bindValue(3, $height);
        $stmt->bindValue(4, $num);
        $stmt->bindValue(5, $user);
        $stmt->bindValue(6, $time);
        $stmt->bindValue(7, $time_d);
        $stmt->execute();
        $rol = "ثبت گزارش با موفقیت انجام شد .";
        Model::sessionSet('rol', $rol);
    }

    function getSetting()
    {
        $sql = "select * from baner_weight";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    function delArz($id)
    {
        $sql = 'delete from baner_weight where id=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->execute();
    }

    function addArz($name)
    {
        $sql = 'insert into baner_weight (name) VALUES (?)';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $name);
        $stmt->execute();
    }

    function new($userId, $weight, $height, $noe)
    {
        $metr= $height*$weight;
        $user = $this->getUser($userId);
        $user = $user['name'] . ' ' . $user['last'];
        $format = 'Y/n/j';
        $time = time();
        $time_d = Model::jaliliDate($format, $time);
        $sql = 'insert into anbar (noe,weight,height,metr,user,tim,tim_d) VALUES (?,?,?,?,?,?,?)';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $noe);
        $stmt->bindValue(2, $weight);
        $stmt->bindValue(3, $height);
        $stmt->bindValue(4, $metr);
        $stmt->bindValue(5, $user);
        $stmt->bindValue(6, $time);
        $stmt->bindValue(7, $time_d);
        $stmt->execute();
        $rol = "ثبت ورودی با موفقیت انجام شد .";
        Model::sessionSet('rol2', $rol);
    }

    function newPlaxi($userId, $zekh,$weight, $height, $color)
    {
        $user = $this->getUser($userId);
        $user = $user['name'] . ' ' . $user['last'];
        echo $zekh.'-'.$height.'-'.$weight.'-'.$color.'-'.$user;
        $format = 'Y/n/j';
        $time = time();
        $time_d = Model::jaliliDate($format, $time);
        $sql = 'insert into plaxi (zekh,weight,height,color,user,tim,tim_d) VALUES (?,?,?,?,?,?,?)';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $zekh);
        $stmt->bindValue(2, $weight);
        $stmt->bindValue(3, $height);
        $stmt->bindValue(4, $color);
        $stmt->bindValue(5, $user);
        $stmt->bindValue(6, $time);
        $stmt->bindValue(7, $time_d);
        $stmt->execute();
        $rol = "ثبت ورودی با موفقیت انجام شد .";
        Model::sessionSet('rol3', $rol);
    }
}