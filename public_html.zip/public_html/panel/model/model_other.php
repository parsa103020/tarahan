<?php

class model_other extends Model
{
    //ALTER TABLE factor_hagh AUTO_INCREMENT = 1000000000;
    public $format = 'Y/n/j H:i';

    function __construct()
    {
        Model::sessionInit();
        parent::__construct();
    }

    function getUser($id)
    {
        $sql = "select * from user where id=? and noe=?";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->bindValue(2, 'other');
        $stmt->execute();
        $result = $stmt->fetch();
        return $result;
    }


    function getkagaz()
    {
        $sql = "select * from print_kagaz";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    function getDetail($id)
    {
        $sql = "select * from orders where riso=?";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->execute();
        $result = $stmt->fetchAll();
        $now = jdate('n');
        $one = $now - 1;
        $two = $one - 1;
        $thery = $two - 1;
        $for = $thery - 1;
        $five = $for - 1;
        $now = round($now);
        $moon = [$five, $for, $thery, $two, $one, $now];
        $now2 = $one2 = $two2 = $thery2 = $for2 = $five2 = 0;
        foreach ($result as $row) {
            $time = $row['start_d'];
            $time = explode('/', $time);
            @$month = $time[1];
            if ($now == $month) {
                ++$now2;
            }
            if ($one == $month) {
                ++$one2;
            }
            if ($two == $month) {
                ++$two2;
            }
            if ($thery == $month) {
                ++$thery2;
            }
            if ($for == $month) {
                ++$for2;
            }
            if ($five == $month) {
                ++$five2;
            }
        }
        $tedad = [$five2, $for2, $thery2, $two2, $one2, $now2];
        $data = [$moon, $tedad];
        return $data;
    }

    function getMsg($id)
    {
        $sql = "select * from msg where resive=? and seen=?";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->bindValue(2, 0);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    function seenMsg($seen, $id)
    {
        $sql = 'update msg set seen=? WHERE resive=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $seen);
        $stmt->bindValue(2, $id);
        $stmt->execute();
    }

    function getOrder()
    {
        $sql = "select * from orders ORDER by id desc";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        foreach ($result as $key => $row) {
            @$next = end(unserialize($row['level']))[2];
            if ($next != 'چاپ دیجیتال') {
                unset($result[$key]);
            }
        }
        return $result;
    }

    function getNewOrder()
    {
        $sql = "select * from orders";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        $tedad = 0;
        foreach ($result as $key => $row) {
            if ($row['status'] === 'ارسال به واحد چاپ دیجیتال') {
                $tedad++;
            }
        }
        return $tedad;
    }

    function getOldOrder()
    {
        $sql = "select * from orders";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        $tedad = 0;
        foreach ($result as $key => $row) {
            if ($row['status'] === 'در مرحله چاپ دیجیتال') {
                $tedad++;
            }
        }
        return $tedad;
    }

    function changStatus($id, $user)
    {
        $sql = 'update orders set status=?,design=? WHERE id=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, 'در مرحله چاپ دیجیتال');
        $stmt->bindValue(2, $user);
        $stmt->bindValue(3, $id);
        $stmt->execute();
    }

    function getOneOrder($id)
    {
        $sql = "select * from orders where id=?";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->execute();
        $result = $stmt->fetch();
        return $result;
    }

    function getOneOrderPrint($id)
    {
        $sql = "select * from print where orderid=?";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->execute();
        $result = $stmt->fetch();
        return $result;
    }

    function getLevel()
    {
        $sql = "select * from level";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    function setChange($user, $id, $next)
    {
        $sql = "select * from orders where id=?";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->execute();
        $result = $stmt->fetch();
        $level = unserialize($result['level']);
        $nowtime = Model::jaliliDate($this->format, time());
        $arr = [$nowtime, $id, $next];
        $level[] = $arr;
        $level = serialize($level);
        $status = "ارسال به واحد " . $next;
        $sql = 'update orders set level=?,now=?,status=?,riso=? WHERE id=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $level);
        $stmt->bindValue(2, $next);
        $stmt->bindValue(3, $status);
        $stmt->bindValue(4, $user);
        $stmt->bindValue(5, $id);
        $stmt->execute();
        if ($next != 'مدیر داخلی' && $next != 'مدیریت') {
            $sql = 'select * from orders where id=?';
            $stmt = self::$conn->prepare($sql);
            $stmt->bindValue(1, $id);
            $stmt->execute();
            $result = $stmt->fetch();
            if ($result['factor'] > 1000000000) {
                $noe = "hagh";
            } else {
                $noe = "hogh";
            }
            $costumer = $result['costumer'];
            $this->sendEmail2($noe, $costumer, $next, $id);
        }
        $this->emailPersonel($id, $next);
    }

    function sendEmail2($noe, $id, $next, $sefaresh)
    {
        if ($noe == 'hagh') {
            $user = $this->getCusOneHagh($id);
            $nameUser = $user['name'] . ' ' . $user['last'];
            $email = $user['email'];
            $number = $user['mobile'];
        } else {
            $user = $this->getCusOneHogh($id);
            $email = $user['email'];
            $number = $user['mobile_manager'];
            $nameUser = $user['company'];
        }

        $start = time();
        $format = 'Y/n/j';
        $start_d = Model::jaliliDate($format, $start);

        $to = $email;
        $subject = 'وضعیت سفارش در طراحان باستان';
        $from_name = 'طراحان باستان';
        $from_email = 'tarahanbastan.ir';

        $textsms = 'مشتری گرامی، ' . $nameUser . ' سفارش شما به شماره ی سفارش ' . $sefaresh . '  به واحد ' . '  ' . $next . '  ' . '  طراحان باستان ارسال شد  ';
        $textsms .= 'تاریخ ارسال پیام : ' . $start_d;
        $message = '<html><meta charset="UTF-8"><meta name="viewport" content="width=device-width"><body>';
        $message .= '<div style="width: 95%;position: relative;padding-bottom:20px;
margin: auto;background-color: #fffddf;border-radius: 10px 10px 0 0;box-sizing: border-box">';
        $message .= '<div style="text-align: center;width:100%;box-sizing: border-box;min-width: 250px; color: #62680e;
line-height: 23px;font-family: Arial;font-size: 16px;border-radius: 10px 10px 0 0; background-color: #fff98f;padding: 10px;margin: 0 auto 10px auto;">
به طراحان باستان خوش آمدید</div>';
        $message .= '<div style="text-align: center;width: 95%;line-height: 23px;font-family: Arial;font-size: 15px;margin: auto; color: #343434"> 
مشتری گرامی، ' . $nameUser . ' سفارش شما به شماره ی سفارش ' . $sefaresh . '  به واحد ' . $next . ' طراحان باستان ارسال شد ';
        $message .= " .  تاریخ ارسال پیام : " . $start_d;
        $message .= '</div>';
        $message .= '</div>';
//echo $message;
        $this->html_mail($to, $subject, $message, array('from_email' => $from_email, 'from_name' => $from_name));
        $this->SMS($number, $textsms);
    }


    function des($userId, $id, $mony, $dis, $tedad, $name)
    {
        $sql = "select * from orders where id=?";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->execute();
        $result = $stmt->fetch();
        if (is_array($result)) {
            $des = unserialize($result['dis']);
        } else {
            $des = [];
        }
        $name = explode(',', $name);
        $paper = $name[1];
        $noe = $name[2];
        $nowtime = Model::jaliliDate($this->format, time());
        $user = $this->getUser($userId);
        $user = $user['name'] . ' ' . $user['last'];
        $dis = $dis . ' ، توضیحات فنی : ' . '  ، تعداد: ' . $tedad . ' ، تعرفه : ' . $paper;
        $arr = ['چاپ دیجیتال', $nowtime, $user, $mony, $dis];
        $des[] = $arr;
        $des = serialize($des);
        $sql = 'update orders set dis=? WHERE id=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $des);
        $stmt->bindValue(2, $id);
        $stmt->execute();
        $sql = 'insert into digital_anbar (name,paper,tedad,price) VALUES (?,?,?,?)';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $noe);
        $stmt->bindValue(2, $paper);
        $stmt->bindValue(3, $tedad);
        $stmt->bindValue(4, $mony);
        $stmt->execute();

    }



    function des2($userId, $id, $mony, $dis, $tedad, $paper,$price1)
    {
        $time = Model::jaliliDate('Y/n/j H:i',time());
        $sql = "select * from orders where id=?";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->execute();
        $result = $stmt->fetch();
        if (is_array($result)) {
            $des = unserialize($result['dis']);
        } else {
            $des = [];
        }

        $nowtime = Model::jaliliDate($this->format, time());
        $user = $this->getUser($userId);
        $user = $user['name'] . ' ' . $user['last'];
        $dis = $dis  . '  ، تعداد: ' . $tedad . ' ، نوع کاغذ : ' . $paper . ' ، قیمت چاپ : ' . $price1;
        $arr = ['چاپ دیجیتال', $nowtime, $user, $mony, $dis];
        $des[] = $arr;
        $des = serialize($des);
        $sql = 'update orders set dis=? WHERE id=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $des);
        $stmt->bindValue(2, $id);
        $stmt->execute();
        $sql = 'insert into riso (kagaz,tedad,price_chap,des,price,tim,orderid) VALUES (?,?,?,?,?,?,?)';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $paper);
        $stmt->bindValue(2, $tedad);
        $stmt->bindValue(3, $price1);
        $stmt->bindValue(4, $dis);
        $stmt->bindValue(5, $mony);
        $stmt->bindValue(6, $time);
        $stmt->bindValue(7, $id);
        $stmt->execute();
    }



    function editUser1($id, $form)
    {
        $name = $form['name'];
        $last = $form['last'];
        $mobile = $form['mobile'];
        $email = $form['email'];
        $sql = 'update user set name=?,last=?,mobile=?,email=? WHERE id=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $name);
        $stmt->bindValue(2, $last);
        $stmt->bindValue(3, $mobile);
        $stmt->bindValue(4, $email);
        $stmt->bindValue(5, $id);
        $stmt->execute();
        Model::sessionSet('msg1', 1);
    }

    function editUser2($id, $file)
    {
        $fileName = $file['name'];
        $ext = pathinfo($fileName, PATHINFO_EXTENSION);
        $name = "image." . $ext;

        $fileSize = $file['size'];
        $fileTmp = $file['tmp_name'];
        $fileType = $file['type'];
        $fileError = $file['error'];
        $uploadOk = 1;
        $targetMain = 'image/user/' . $id . '/';

        if (!file_exists($targetMain)) {
            mkdir($targetMain);
        }
        if ($ext !== "jpg" and $ext !== "jpeg" and $ext !== "png") {
            $uploadOk = 0;
        }

        if (!empty($fileSize) and !empty($fileName) and !empty($fileType) and $uploadOk == 1) {
            $dir = $targetMain . 'image.png';
            $dir_100 = $targetMain . '100_image.png';
            if (file_exists($dir)) {
                unlink($dir);
            }
            if (file_exists($dir_100)) {
                unlink($dir_100);
            }
            if ($fileSize > 5242880) {
                $uploadOk = 0;
            }
            if ($uploadOk == 1) {
                $target = $targetMain . $name;
                move_uploaded_file($fileTmp, $target);
                $target100 = $targetMain . '100_' . $name;
                $this->create_thumbnail($target, $target100, 150, 150);
                $sql = 'update user set image=? WHERE id=?';
                $stmt = self::$conn->prepare($sql);
                $stmt->bindValue(1, $name);
                $stmt->bindValue(2, $id);
                $stmt->execute();
            }
        }
    }

    function editPass($userId, $pass0, $pass1)
    {
        $user = $this->getUser($userId);
        $oldHashPass = $user['pass'];
        if (password_verify($pass0, $oldHashPass)) {
            $newHashPass = password_hash($pass1, PASSWORD_DEFAULT);
            $sql = 'update user set pass=? where id=?';
            $stmt = self::$conn->prepare($sql);
            $stmt->bindValue(1, $newHashPass);
            $stmt->bindValue(2, $userId);
            $stmt->execute();
            $msg = "رمز عبور با موفقیت تغییر یافت :)";
        } else {
            $msg = "رمز عبور قدیم نادرست است :|";
        }
        Model::sessionSet('msg2', $msg);
    }

    function rol($userId, $weight, $height, $num, $noe)
    {
        $user = $this->getUser($userId);
        $user = $user['name'] . ' ' . $user['last'];
        $format = 'Y/n/j';
        $time = time();
        $time_d = Model::jaliliDate($format, $time);
        $sql = 'insert into rol (noe,weight,height,tedad,user,time,time_d) VALUES (?,?,?,?,?,?,?)';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $noe);
        $stmt->bindValue(2, $weight);
        $stmt->bindValue(3, $height);
        $stmt->bindValue(4, $num);
        $stmt->bindValue(5, $user);
        $stmt->bindValue(6, $time);
        $stmt->bindValue(7, $time_d);
        $stmt->execute();
        $rol = "ثبت گزارش با موفقیت انجام شد .";
        Model::sessionSet('rol', $rol);
    }

    function getDigital()
    {
        $sql = "select * from digital_price";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;

    }

    function getA($name)
    {
        $sql = "select * from digital_price where noe=? ";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $name);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    function getF()
    {
        $sql = "select * from anbar2 ORDER BY id desc limit 5";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }


    function adAnbar($userId, $item, $noe, $number)
    {
        if ($item == 1) {
            $name = "گلاسه";
        } elseif ($item == 2) {
            $name = "تحریر";
        } elseif ($item == 3) {
            $name = "کتد";
        } elseif ($item == 4) {
            $name = "کتان";
        } elseif ($item == 5) {
            $name = "گراف";
        }
        $user = $this->getUser($userId);
        $user = $user['name'] . ' ' . $user['last'];
        $format = 'Y/n/j';
        $time = time();
        $time_d = Model::jaliliDate($format, $time);
        $sql = 'insert into anbar2 (name,noe,tedad,tim,tim_d,user) VALUES (?,?,?,?,?,?)';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $name);
        $stmt->bindValue(2, $noe);
        $stmt->bindValue(3, $number);
        $stmt->bindValue(4, $time);
        $stmt->bindValue(5, $time_d);
        $stmt->bindValue(6, $user);
        $stmt->execute();
        $rol = " ثبت  $name  با موفقیت انجام شد . ";
        Model::sessionSet('anbar', $rol);

    }


}

