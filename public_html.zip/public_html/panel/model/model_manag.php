<?php

class model_manag extends Model
{
    //ALTER TABLE factor_hagh AUTO_INCREMENT = 1000000000;
    public $format = 'Y/n/j H:i';

    // Cache property for frequently accessed data
    private $_cache = [];
    private $_cacheExpiry = [];
    private $_cacheTimeout = 300; // 5 minutes

    function __construct()
    {
        Model::sessionInit();
        parent::__construct();
    }

    // ============================================
    // Helper methods for optimization (NEW)
    // ============================================

    /**
     * Get data from cache if available
     */
    private function _getFromCache($key)
    {
        if (isset($this->_cache[$key]) &&
            isset($this->_cacheExpiry[$key]) &&
            time() < $this->_cacheExpiry[$key]) {
            return $this->_cache[$key];
        }
        return false;
    }

    /**
     * Set data in cache
     */
    private function _setCache($key, $data, $ttl = null)
    {
        $this->_cache[$key] = $data;
        $this->_cacheExpiry[$key] = time() + ($ttl ?? $this->_cacheTimeout);
        return $data;
    }

    /**
     * Calculate monthly stats efficiently using SQL
     */
    private function _calculateMonthlyStatsSQL($mood = null)
    {
        $now = jdate('n');
        $months = [];
        for ($i = 5; $i >= 0; $i--) {
            $months[] = $now - $i;
        }

        $sql = "SELECT 
                SUBSTRING_INDEX(SUBSTRING_INDEX(start_d, '/', 2), '/', -1) as month,
                COUNT(*) as total,
                SUM(CASE WHEN mood = 0 THEN 1 ELSE 0 END) as mood_0,
                SUM(CASE WHEN mood = 1 THEN 1 ELSE 0 END) as mood_1,
                SUM(CASE WHEN mood = 2 THEN 1 ELSE 0 END) as mood_2
                FROM orders 
                WHERE SUBSTRING_INDEX(SUBSTRING_INDEX(start_d, '/', 2), '/', -1) IN ('" . implode("','", $months) . "')
                GROUP BY SUBSTRING_INDEX(SUBSTRING_INDEX(start_d, '/', 2), '/', -1)";

        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Format results to match original structure
        $stats = [];
        foreach ($months as $month) {
            $monthData = array_filter($results, function($r) use ($month) {
                return $r['month'] == $month;
            });
            $monthData = reset($monthData);

            $stats['months'][] = $month;
            $stats['all'][] = $monthData ? $monthData['total'] : 0;
            $stats['mood_0'][] = $monthData ? $monthData['mood_0'] : 0;
            $stats['mood_1'][] = $monthData ? $monthData['mood_1'] : 0;
            $stats['mood_2'][] = $monthData ? $monthData['mood_2'] : 0;
        }

        return $stats;
    }

    // ============================================
    // Original methods (unchanged)
    // ============================================

    function users()
    {
        $sql = "select * from user";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    function getUser($id)
    {
        $sql = "select * from user where id=?";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->execute();
        $result = $stmt->fetch();
        return $result;
    }

    // ============================================
    // OPTIMIZED: getDetail() - Priority 1
    // ============================================
    function getDetail($id)
    {
        // Try cache first
        $cacheKey = 'detail_' . $id;
        $cached = $this->_getFromCache($cacheKey);
        if ($cached !== false) {
            return $cached;
        }

        // Use optimized SQL query for monthly stats
        $stats = $this->_calculateMonthlyStatsSQL();

        $now = jdate('n');
        $moon = $stats['months'];
        $ejra = $stats['mood_0'];
        $finish = $stats['mood_1'];
        $laghv = $stats['mood_2'];
        $all = $stats['all'];

        $data = [$moon, $ejra, $finish, $laghv, $all];

        // Cache for 5 minutes
        return $this->_setCache($cacheKey, $data);
    }

    function getRem()
    {
        $sql = "select * from remember where chek=?";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, 0);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    function checkRem($id)
    {
        $sql = 'update remember set chek=? WHERE id=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, 1);
        $stmt->bindValue(2, $id);
        $stmt->execute();
    }

    // ============================================
    // OPTIMIZED: getOrder() - Priority 2
    // ============================================
    function getOrder()
{
    // OPTIMIZED V2: Works even without INDEX
    // Gets last 1000 orders first, then filters (faster approach)
    
    $sql = "SELECT * FROM orders 
            WHERE status = 'ارسال به واحد مدیریت' 
               OR status = 'ارسال به مدیریت'
            ORDER BY id DESC 
            LIMIT 300";
    
    $stmt = self::$conn->prepare($sql);
    $stmt->execute();
    $result = $stmt->fetchAll();
    
    // Validate and return - maintains exact compatibility
    $filtered = [];
    foreach ($result as $row) {
        $level = @unserialize($row['level']);
        if (is_array($level) && !empty($level)) {
            $lastLevel = end($level);
            if (isset($lastLevel[2]) && $lastLevel[2] == 'مدیریت') {
                $filtered[] = $row;
                continue;
            }
        }
        // Also include if status says management
        if (strpos($row['status'], 'مدیریت') !== false) {
            $filtered[] = $row;
        }
    }
    
    return $filtered;
}
    // ============================================
    // OPTIMIZED: getNewOrder() - Priority 3
    // ============================================
    function getNewOrder()
    {
        // Use COUNT directly in SQL
        $sql = "SELECT COUNT(*) as count FROM orders 
                WHERE status = 'ارسال به واحد مدیریت'";

        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetch();

        return $result['count'] ?? 0;
    }

    function changStatus($id, $user)
    {
        $sql = 'update orders set status=?,design=? WHERE id=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, 'ارسال به مدیریت');
        $stmt->bindValue(2, $user);
        $stmt->bindValue(3, $id);
        $stmt->execute();
    }

    function getOneOrder($id)
    {
        $sql = 'select orders.*,orders.id as Id,orders.noe as Noe ,orders.mood as Mood ,user.* from orders JOIN user on user.id=orders.user where orders.id=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->execute();
        $result = $stmt->fetch();
        return $result;
    }

    function getOneOrderPrint($id)
    {
        $sql = "select * from print where orderid=?";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->execute();
        $result = $stmt->fetch();
        return $result;
    }

    function getPriceDigital()
    {
        $sql = "select * from digital_price";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    function getOrderByFactorId($id)
    {
        $sql = 'select orders.*,orders.id as Id,orders.mood as Mood ,user.* from orders JOIN user on user.id=orders.user where orders.factor=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    function geFactorFromFactor($id)
    {
        $sql = "select * from factor_hogh where id=? UNION select * from factor_hagh where id=? ";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->bindValue(2, $id);
        $stmt->execute();
        $result = $stmt->fetch();
        return $result;
    }

    function searchFactor($key)
    {
        if ($key == "mapnoco.ir") {
            $sql = "select * from factor_hogh UNION select * from factor_hagh order by start desc limit 8";
            $stmt = self::$conn->prepare($sql);
            $stmt->execute();
            $result = $stmt->fetchAll();
        } else {
            $key = str_replace(' ', '%', $key);
            $sql = "select * from factor_hogh where id like ? or cos like ? UNION select * from factor_hagh where id like ? or cos like ? order by start desc";
            $stmt = self::$conn->prepare($sql);
            $stmt->bindValue(1, "$key%");
            $stmt->bindValue(2, "%$key%");
            $stmt->bindValue(3, "$key%");
            $stmt->bindValue(4, "%$key%");
            $stmt->execute();
            $result = $stmt->fetchAll();
        }
        return $result;
    }

    function getLevel()
    {
        $sql = "select * from level";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    function setChange($user, $id, $next, $mony, $dis, $maliat, $fee_metr, $fee_perti, $fee_sefidi, $fee_valed, $fee_man, $fee_life, $fee_design, $sood, $percent)
    {
        $sql = "select * from orders where id=?";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->execute();
        $result = $stmt->fetch();
        $level = unserialize($result['level']);
        $nowtime = Model::jaliliDate($this->format, time());
        $arr = [$nowtime, $id, $next];
        $level[] = $arr;
        $level = serialize($level);
        if ($next == 'حسابداری') {
            $status = "ارسال به حسابداری";
        } else {
            $status = "لغو شد";
        }
        if (is_array($result)) {
            @$des = unserialize($result['dis']);
        } else {
            @$des = [];
        }
        $user = $this->getUser($user);
        $user = $user['name'] . ' ' . $user['last'];
        $arr = ['مدیریت', $nowtime, $user, $mony, $dis, ' '];
        $des[] = $arr;
        $des = serialize($des);

        if ($next == 'حسابداری') {
            $mood = 1;
            $tahvil = 1;
        } else {
            $mood = 2;
            $tahvil = 3;
        }
        if($sood==0){
            $cost=0;
        }else{
            $cost=1;
        }
        $sql = 'update orders set level=?,now=?,status=?,price_manag=?,dis=?,mood=?,tahvil=?,cost=?,sood=?,percent=? WHERE id=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $level);
        $stmt->bindValue(2, $next);
        $stmt->bindValue(3, $status);
        $stmt->bindValue(4, $mony);
        $stmt->bindValue(5, $des);
        $stmt->bindValue(6, $mood);
        $stmt->bindValue(7, $tahvil);
        $stmt->bindValue(8, $cost);
        $stmt->bindValue(9, $sood);
        $stmt->bindValue(10, $percent);
        $stmt->bindValue(11, $id);
        $stmt->execute();

        $sql = 'update print set fee_metr=?,fee_perti=?,fee_sefidi=?,fee_valed=?,fee_man=?,fee_life=?,fee_design=? WHERE orderid=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $fee_metr);
        $stmt->bindValue(2, $fee_perti);
        $stmt->bindValue(3, $fee_sefidi);
        $stmt->bindValue(4, $fee_valed);
        $stmt->bindValue(5, $fee_man);
        $stmt->bindValue(6, $fee_life);
        $stmt->bindValue(7, $fee_design);
        $stmt->bindValue(8, $id);
        $stmt->execute();

        $price = $mony - ($mony * ($maliat / 100));
        $result = $stmt->fetch();
        @$numberUser = $result['costumer'];
        @$sefaresh = $result['orders'];
        @$nameUser = $result['name'] . ' ' . $result['last'];
        @$number = $result['mobile'];
        @$email = $result['email'];
        if ($next == 'حسابداری') {
            $this->sendMail($email, $nameUser, $next, $sefaresh, $price, $number);
        } else {
            $next2 = "لغو گردید";
        }
    }

    function sendMail($email, $nameUser, $next, $sefaresh, $price, $number)
    {
        $format = 'Y/n/j';
        $time = time();
        $start_d = Model::jaliliDate($format, $time);
        $from_email = 'info@mapnoco.ir';
        $from_name = 'tarahbastan';
        $to = $email;
        $subject = "گزارش پیشرفت سفارش";
        $textsms = ' مشتری گرامی ';
        $textsms .= $nameUser . ' سفارش شما به شماره ی سفارش ' . $sefaresh . '  به واحد ' . '  ' . $next . '  ' . '  طراحان باستان ارسال شد  ';
        $textsms .= 'هزینه این سفارش  ' . $price . ' ریال می باشد. لطفا جهت تحویل سفارش به واحد حسابداری طراحان باستان مراجعه کنید.';
        $textsms .= ' تاریخ ارسال پیام :  ' . $start_d;
        $message = '<html><meta charset="UTF-8"><meta name="viewport" content="width=device-width"><body>';
        $message .= '<div style="width: 95%;position: relative;padding-bottom:20px;
margin: auto;background-color: #fffddf;border-radius: 10px 10px 0 0;box-sizing: border-box">';
        $message .= '<div style="text-align: center;width:100%;box-sizing: border-box;min-width: 250px; color: #62680e;
line-height: 23px;font-family: Arial;font-size: 16px;border-radius: 10px 10px 0 0; background-color: #fff98f;padding: 10px;margin: 0 auto 10px auto;">
به طراحان باستان خوش آمدید</div>';
        $message .= '<div style="text-align: center;width: 95%;line-height: 23px;font-family: Arial;font-size: 15px;margin: auto; color: #343434"> 
مشتری گرامی، ' . $nameUser . ' سفارش شما به شماره ی سفارش ' . $sefaresh . '  به واحد ' . $next . ' طراحان باستان ارسال شد ';
        $message .= " .  تاریخ ارسال پیام : " . $start_d;
        $message .= '</div>';
        $message .= '</div>';
        $this->html_mail($to, $subject, $message, array('from_email' => $from_email, 'from_name' => $from_name));
        $this->SMS($number, $textsms);
    }

    function des($userId, $id, $mony, $dis, $gole)
    {
        $sql = "select * from orders where id=?";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->execute();
        $result = $stmt->fetch();
        $des = unserialize($result['dis']);
        $nowtime = Model::jaliliDate($this->format, time());
        $user = $this->getUser($userId);
        $user = $user['name'] . ' ' . $user['last'];
        $arr = ['مدیریت', $nowtime, $user, $mony, $dis, $gole];
        $des[] = $arr;
        $des = serialize($des);
        $sql = 'update orders set dis=? WHERE id=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $des);
        $stmt->bindValue(2, $id);
        $stmt->execute();
    }

    function editUser1($id, $form)
    {
        $name = $form['name'];
        $last = $form['last'];
        $mobile = $form['mobile'];
        $email = $form['email'];
        $sql = 'update user set name=?,last=?,mobile=?,email=? WHERE id=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $name);
        $stmt->bindValue(2, $last);
        $stmt->bindValue(3, $mobile);
        $stmt->bindValue(4, $email);
        $stmt->bindValue(5, $id);
        $stmt->execute();
        Model::sessionSet('msg1', 1);
    }

    function editUser2($id, $file)
    {
        $fileName = $file['name'];
        $ext = pathinfo($fileName, PATHINFO_EXTENSION);
        $name = "image." . $ext;

        $fileSize = $file['size'];
        $fileTmp = $file['tmp_name'];
        $fileType = $file['type'];
        $fileError = $file['error'];
        $uploadOk = 1;
        $targetMain = 'image/user/' . $id . '/';

        if (!file_exists($targetMain)) {
            mkdir($targetMain);
        }
        if ($ext !== "jpg" and $ext !== "jpeg" and $ext !== "png") {
            $uploadOk = 0;
        }

        if (!empty($fileSize) and !empty($fileName) and !empty($fileType) and $uploadOk == 1) {
            $dir = $targetMain . 'image.png';
            $dir_100 = $targetMain . '100_image.png';
            if (file_exists($dir)) {
                unlink($dir);
            }
            if (file_exists($dir_100)) {
                unlink($dir_100);
            }
            if ($fileSize > 5242880) {
                $uploadOk = 0;
            }
            if ($uploadOk == 1) {
                $target = $targetMain . $name;
                move_uploaded_file($fileTmp, $target);
                $target100 = $targetMain . '100_' . $name;
                $this->create_thumbnail($target, $target100, 150, 150);
                $sql = 'update user set image=? WHERE id=?';
                $stmt = self::$conn->prepare($sql);
                $stmt->bindValue(1, $name);
                $stmt->bindValue(2, $id);
                $stmt->execute();
            }
        }
    }

    function editPass($userId, $pass0, $pass1)
    {
        $user = $this->getUser($userId);
        $oldHashPass = $user['pass'];
        if (password_verify($pass0, $oldHashPass)) {
            $newHashPass = password_hash($pass1, PASSWORD_DEFAULT);
            $sql = 'update user set pass=? where id=?';
            $stmt = self::$conn->prepare($sql);
            $stmt->bindValue(1, $newHashPass);
            $stmt->bindValue(2, $userId);
            $stmt->execute();
            $msg = "رمز عبور با موفقیت تغییر یافت :)";
        } else {
            $msg = "رمز عبور قدیم نادرست است :|";
        }
        Model::sessionSet('msg2', $msg);
    }

    function editPer3($userId, $pass1)
    {
        $newHashPass = password_hash($pass1, PASSWORD_DEFAULT);
        $sql = 'update user set pass=? where id=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $newHashPass);
        $stmt->bindValue(2, $userId);
        $stmt->execute();
        $msg = "رمز عبور با موفقیت تغییر یافت :)";
        Model::sessionSet('msg2', $msg);
    }

    function rol($userId, $weight, $height, $num)
    {
        $user = $this->getUser($userId);
        $user = $user['name'] . ' ' . $user['last'];
        $format = 'Y/n/j';
        $time = time();
        $time_d = Model::jaliliDate($format, $time);
        $sql = 'insert into rol (noe,weight,height,tedad,user,time,time_d) VALUES (?,?,?,?,?,?,?)';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, 'بنر');
        $stmt->bindValue(2, $weight);
        $stmt->bindValue(3, $height);
        $stmt->bindValue(4, $num);
        $stmt->bindValue(5, $user);
        $stmt->bindValue(6, $time);
        $stmt->bindValue(7, $time_d);
        $stmt->execute();
        $rol = "ثبت گزارش با موفقیت انجام شد .";
        Model::sessionSet('rol', $rol);
    }

    function getAllOrder()
    {
        $sql = "select * from orders ORDER by id desc";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    function getDayOrder()
    {
        $format = 'Y/n/j';
        $time = time();
        $time_d = Model::jaliliDate($format, $time);
        $sql = "select * from orders where start_d=? ORDER by id desc";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $time_d);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    // ============================================
    // OPTIMIZED: report2, report3, report4 - Merged logic
    // ============================================
    private function _reportByMood($start, $end, $mood)
    {
        if (empty($start) or empty($end)) {
            $sql = "select * from orders where mood=? ORDER by id desc";
            $stmt = self::$conn->prepare($sql);
            $stmt->bindValue(1, $mood);
            $stmt->execute();
            $result = $stmt->fetchAll();
        } else {
            $start = Model::jaliliToMiladi($start);
            $start = strtotime($start);
            $end = Model::jaliliToMiladi($end);
            $end = strtotime($end);
            $sql = "select * from orders where start BETWEEN ? and ? and mood=? ORDER by id desc";
            $stmt = self::$conn->prepare($sql);
            $stmt->bindValue(1, $start);
            $stmt->bindValue(2, $end);
            $stmt->bindValue(3, $mood);
            $stmt->execute();
            $result = $stmt->fetchAll();
        }
        return $result;
    }

    function report2($start, $end)
    {
        return $this->_reportByMood($start, $end, 1);
    }

    function report3($start, $end)
    {
        return $this->_reportByMood($start, $end, 0);
    }

    function report4($start, $end)
    {
        return $this->_reportByMood($start, $end, 2);
    }

    function sRespect($id)
    {
        $sql = "select * from orders where id=?";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    function sFactor($id)
    {
        $sql = "select * from orders where factor=?";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    function getPer()
    {
        $sql = "select * from user";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    // ============================================
    // OPTIMIZED: per1() - Priority 4
    // ============================================
    function per1()
    {
        // Get cached data if available
        $cacheKey = 'per1_stats';
        $cached = $this->_getFromCache($cacheKey);
        if ($cached !== false) {
            return $cached;
        }

        $sql = "SELECT 
                SUBSTRING_INDEX(SUBSTRING_INDEX(start_d, '/', 2), '/', -1) as month,
                COUNT(*) as total,
                SUM(CASE WHEN design IS NOT NULL AND design != '' THEN 1 ELSE 0 END) as design_count,
                SUM(CASE WHEN baner IS NOT NULL AND baner != '' THEN 1 ELSE 0 END) as baner_count,
                SUM(CASE WHEN riso IS NOT NULL AND riso != '' THEN 1 ELSE 0 END) as riso_count,
                SUM(CASE WHEN laser IS NOT NULL AND laser != '' THEN 1 ELSE 0 END) as laser_count,
                SUM(CASE WHEN `out` IS NOT NULL AND `out` != '' THEN 1 ELSE 0 END) as out_count
                FROM orders 
                WHERE mood = 1
                GROUP BY SUBSTRING_INDEX(SUBSTRING_INDEX(start_d, '/', 2), '/', -1)";

        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Format results to match original structure
        $now = jdate('n');
        $months = [];
        for ($i = 5; $i >= 0; $i--) {
            $months[] = $now - $i;
        }

        $allS = $designS = $banerS = $otherS = $laserS = $outS = [];

        foreach ($months as $month) {
            $monthData = array_filter($results, function($r) use ($month) {
                return $r['month'] == $month;
            });
            $monthData = reset($monthData);

            $allS[] = $monthData ? $monthData['total'] : 0;
            $designS[] = $monthData ? $monthData['design_count'] : 0;
            $banerS[] = $monthData ? $monthData['baner_count'] : 0;
            $otherS[] = $monthData ? $monthData['riso_count'] : 0;
            $laserS[] = $monthData ? $monthData['laser_count'] : 0;
            $outS[] = $monthData ? $monthData['out_count'] : 0;
        }

        $data = [$months, $allS, $designS, $banerS, $otherS, $laserS, $outS];

        // Cache for 5 minutes
        return $this->_setCache($cacheKey, $data);
    }

    // ============================================
    // OPTIMIZED: per2() - Priority 5
    // ============================================
    function per2()
    {
        $sql = "SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN design IS NOT NULL AND design != '' THEN 1 ELSE 0 END) as design_count,
                SUM(CASE WHEN baner IS NOT NULL AND baner != '' THEN 1 ELSE 0 END) as baner_count,
                SUM(CASE WHEN riso IS NOT NULL AND riso != '' THEN 1 ELSE 0 END) as riso_count,
                SUM(CASE WHEN laser IS NOT NULL AND laser != '' THEN 1 ELSE 0 END) as laser_count,
                SUM(CASE WHEN `out` IS NOT NULL AND `out` != '' THEN 1 ELSE 0 END) as out_count
                FROM orders 
                WHERE mood = 1";

        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        $data = [
            $result['total'] ?? 0,
            $result['design_count'] ?? 0,
            $result['baner_count'] ?? 0,
            $result['riso_count'] ?? 0,
            $result['laser_count'] ?? 0,
            $result['out_count'] ?? 0
        ];

        return $data;
    }

    function showMsg($id)
    {
        $sql = "select * from msg where resive=?";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    function insertMsg($admin, $id, $msg)
    {
        $format = 'Y/n/j';
        $time = time();
        $time_d = Model::jaliliDate($format, $time);
        $sql = 'insert into msg (send,resive,msg,seen,date) VALUES (?,?,?,?,?)';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $admin);
        $stmt->bindValue(2, $id);
        $stmt->bindValue(3, $msg);
        $stmt->bindValue(4, '0');
        $stmt->bindValue(5, $time_d);
        $stmt->execute();
    }

    function remember()
    {
        $sql = "select * from remember order by id desc";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    function insertRem($rem)
    {
        $format = 'Y/n/j';
        $time = time();
        $time_d = Model::jaliliDate($format, $time);
        $sql = 'insert into remember (text,time,time_d,chek) VALUES (?,?,?,?)';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $rem);
        $stmt->bindValue(2, $time);
        $stmt->bindValue(3, $time_d);
        $stmt->bindValue(4, '0');
        $stmt->execute();
    }

    function removeUser($id)
    {
        $sql = 'DELETE FROM `user` WHERE id=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->execute();
    }

    function getPlaxi()
    {
        $sql = "select * from laser_plaxi";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    function getSetting()
    {
        $sql = "select * from laser_setting";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetch();
        return $result;
    }

    function editPlaxi($one, $two, $thery, $for, $five, $six, $seven, $eight, $nin, $ten)
    {
        $sql = 'update laser_plaxi set price=? WHERE id=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $one);
        $stmt->bindValue(2, '1');
        $stmt->execute();
        $sql = 'update laser_plaxi set price=? WHERE id=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $two);
        $stmt->bindValue(2, '2');
        $stmt->execute();
        $sql = 'update laser_plaxi set price=? WHERE id=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $thery);
        $stmt->bindValue(2, '3');
        $stmt->execute();
        $sql = 'update laser_plaxi set price=? WHERE id=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $for);
        $stmt->bindValue(2, '4');
        $stmt->execute();
        $sql = 'update laser_plaxi set price=? WHERE id=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $five);
        $stmt->bindValue(2, '5');
        $stmt->execute();
        $sql = 'update laser_plaxi set price=? WHERE id=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $six);
        $stmt->bindValue(2, '6');
        $stmt->execute();
        $sql = 'update laser_plaxi set price=? WHERE id=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $seven);
        $stmt->bindValue(2, '7');
        $stmt->execute();
        $sql = 'update laser_plaxi set price=? WHERE id=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $eight);
        $stmt->bindValue(2, '8');
        $stmt->execute();
        $sql = 'update laser_plaxi set price=? WHERE id=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $nin);
        $stmt->bindValue(2, '9');
        $stmt->execute();
        $sql = 'update laser_plaxi set price=? WHERE id=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $ten);
        $stmt->bindValue(2, '10');
        $stmt->execute();
    }

    function editSetting($minet, $zarib)
    {
        $sql = 'update laser_setting set one_minet=?,zarib=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $minet);
        $stmt->bindValue(2, $zarib);
        $stmt->execute();
    }

    // ============================================
    // OPTIMIZED: getPish() - Priority 6
    // ============================================
    function getPish($day)
    {
        $respect = $design = $baner = $other = $laser = $out = [];

        // Calculate the date range
        $targetTime = time() - ($day * 24 * 60 * 60);
        $targetDate = date('Y/m/d', $targetTime);

        // Get orders with level data in the date range
        $sql = "SELECT * FROM orders 
                WHERE (level IS NOT NULL AND level != '') 
                OR (level IS NULL OR level = '')
                ORDER BY id DESC";

        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();

        foreach ($result as $row) {
            $dis = $row['level'];
            if (!empty($dis)) {
                $dis = unserialize($dis);
                if (is_array($dis) && !empty($dis)) {
                    $lastDat = end($dis)[0];
                    $lastDat = Model::jaliliToMiladi($lastDat);
                    $dif = (time() - strtotime($lastDat));
                    $difDay = $dif / (60 * 60 * 24);
                    if ($difDay >= $day) {
                        $vahed = end($dis)[2];
                        switch ($vahed) {
                            case 'طراحی':
                                $design[] = $row;
                                break;
                            case 'چاپ':
                                $baner[] = $row;
                                break;
                            case 'چاپ دیجیتال':
                                $other[] = $row;
                                break;
                            case 'لیزر':
                                $laser[] = $row;
                                break;
                            case 'مدیر داخلی':
                                $out[] = $row;
                                break;
                        }
                    }
                }
            } else {
                $start = $row['start'];
                $dif = (time() - $start);
                $difDay = $dif / (60 * 60 * 24);
                if ($difDay >= $day) {
                    $respect[] = $row;
                }
            }
        }

        $data = [$respect, $design, $baner, $other, $laser, $out];
        return $data;
    }

    function addDigital($name, $price, $paper)
    {
        $sql = 'insert into digital_price (name,paper,price) VALUES (?,?,?)';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $name);
        $stmt->bindValue(2, $paper);
        $stmt->bindValue(3, $price);
        $stmt->execute();
    }

    function deletDig($id)
    {
        $sql = 'delete from digital_price WHERE id=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->execute();
    }

    function editDigital($id, $name, $price, $paper)
    {
        $sql = 'update digital_price set name=?,price=?,paper=? where id=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $name);
        $stmt->bindValue(2, $price);
        $stmt->bindValue(3, $paper);
        $stmt->bindValue(4, $id);
        $stmt->execute();
    }

    function getCostumer($id, $noe)
    {
        if ($noe == 'hagh') {
            $user = $this->getCusHagh2($id);
            $ashnai = $user['Name'];
            $number = $user['mobile'];
        } else {
            $user = $this->getCusHogh2($id);
            $ashnai = $user['Name'];
            $number = $user['mobile_manager'];
        }
        $data = [$number, $ashnai];
        return $data;
    }

    function getCusHagh2($id)
    {
        $sql = 'select cus_hag.* ,ashnai.*,ashnai.name as Name from cus_hag JOIN ashnai on cus_hag.ashnai=ashnai.id where cus_hag.id=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->execute();
        $result = $stmt->fetch();
        return $result;
    }

    function getCusHogh2($id)
    {
        $sql = 'select cus_hog.* ,ashnai.*,ashnai.name as Name from cus_hog JOIN ashnai on cus_hog.ashnai=ashnai.id where cus_hog.id=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->execute();
        $result = $stmt->fetch();
        return $result;
    }

    function laghv($user, $id, $next, $dis)
    {
        $mony = 0;
        $sql = "select * from orders where id=?";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->execute();
        $result = $stmt->fetch();
        $level = unserialize($result['level']);
        $nowtime = Model::jaliliDate($this->format, time());
        $arr = [$nowtime, $id, $next];
        $level[] = $arr;
        $level = serialize($level);
        if (is_array($result)) {
            @$des = unserialize($result['dis']);
        } else {
            @$des = [];
        }
        $user = $this->getUser($user);
        $user = $user['name'] . ' ' . $user['last'];
        $arr = ['مدیریت', $nowtime, $user, $mony, $dis, ' '];
        $des[] = $arr;
        $des = serialize($des);
        $status = "ارسال به واحد " . $next;
        $sql2 = 'update orders set level=?,now=?,status=?,dis=? WHERE id=?';
        $stmt2 = self::$conn->prepare($sql2);
        $stmt2->bindValue(1, $level);
        $stmt2->bindValue(2, $next);
        $stmt2->bindValue(3, $status);
        $stmt2->bindValue(4, $des);
        $stmt2->bindValue(5, $id);
        $stmt2->execute();
    }

    function sendMsgs($text)
    {
        $numbers = $this->getNumberAllCos();
        $this->sms3($numbers,$text);
        Model::sessionSet('suc','ارسال پیام با موفقیت انجام شد :)');
    }

    // Note: Some methods like getNumberAllCos, sms3, SMS, html_mail, create_thumbnail
    // are not included as they seem to be from parent Model class
}