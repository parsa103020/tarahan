<?php

class model_laser extends Model
{
    //ALTER TABLE factor_hagh AUTO_INCREMENT = 1000000000;
    public $format = 'Y/n/j H:i';

    function __construct()
    {
        Model::sessionInit();
        parent::__construct();
    }

    function getUser($id)
    {
        $sql = "select * from user where id=? and noe=?";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->bindValue(2, 'laser');
        $stmt->execute();
        $result = $stmt->fetch();
        return $result;
    }

    function getDetail($id)
    {
        $sql = "select * from orders where laser=?";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->execute();
        $result = $stmt->fetchAll();
        $now = jdate('n');
        $one = $now - 1;
        $two = $one - 1;
        $thery = $two - 1;
        $for = $thery - 1;
        $five = $for - 1;
        $now = round($now);
        $moon = [$five, $for, $thery, $two, $one, $now];
        $now2 = $one2 = $two2 = $thery2 = $for2 = $five2 = 0;
        foreach ($result as $row) {
            $time = $row['start_d'];
            $time = explode('/', $time);
            @$month = $time[1];
            if ($now == $month) {
                ++$now2;
            }
            if ($one == $month) {
                ++$one2;
            }
            if ($two == $month) {
                ++$two2;
            }
            if ($thery == $month) {
                ++$thery2;
            }
            if ($for == $month) {
                ++$for2;
            }
            if ($five == $month) {
                ++$five2;
            }
        }
        $tedad = [$five2, $for2, $thery2, $two2, $one2, $now2];
        $data = [$moon, $tedad];
        return $data;
    }

    function getMsg($id)
    {
        $sql = "select * from msg where resive=? and seen=?";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->bindValue(2, 0);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    function seenMsg($seen, $id)
    {
        $sql = 'update msg set seen=? WHERE resive=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $seen);
        $stmt->bindValue(2, $id);
        $stmt->execute();
    }

    function getOrder()
    {
        $sql = "select * from orders ORDER by id desc";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        foreach ($result as $key => $row) {
            @$next = end(unserialize($row['level']))[2];
            if ($next != 'لیزر') {
                unset($result[$key]);
            }
        }
        return $result;
    }

    function getNewOrder()
    {
        $sql = "select * from orders";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        $tedad = 0;
        foreach ($result as $key => $row) {
            if ($row['status'] === 'ارسال به واحد لیزر') {
                $tedad++;
            }
        }
        return $tedad;
    }

    function getPlaxi()
    {
        $sql = "select * from laser_plaxi";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    function getColor()
    {
        $sql = "select * from laser_color";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    function getSetting()
    {
        $sql = "select * from laser_setting";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetch();
        return $result;
    }

    function getJens()
    {
        $sql = "select * from laser_jens";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    function getLaser($id)
    {
        $sql = "select * from laser where orderid=?";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->execute();
        $result = $stmt->fetch();
        return $result;
    }

    function getOldOrder()
    {
        $sql = "select * from orders";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        $tedad = 0;
        foreach ($result as $key => $row) {
            if ($row['status'] === 'در مرحله اجرا') {
                $tedad++;
            }
        }
        return $tedad;
    }

    function changStatus($id, $user)
    {
        $sql = 'update orders set status=?,laser=? WHERE id=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, 'در مرحله اجرا');
        $stmt->bindValue(2, $user);
        $stmt->bindValue(3, $id);
        $stmt->execute();
    }

    function getOneOrder($id)
    {
        $sql = "select * from orders where id=?";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->execute();
        $result = $stmt->fetch();
        return $result;
    }

    function getOneOrderPrint($id)
    {
        $sql = "select * from print where orderid=?";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->execute();
        $result = $stmt->fetch();
        return $result;
    }

    function getLevel()
    {
        $sql = "select * from level";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    function setChange($user, $id, $next)
    {
        $sql = "select * from orders where id=?";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->execute();
        $result = $stmt->fetch();
        $level = unserialize($result['level']);
        $nowtime = Model::jaliliDate($this->format, time());
        $arr = [$nowtime, $id, $next];
        $level[] = $arr;
        $level = serialize($level);
        $status = "ارسال به واحد " . $next;
        $sql = 'update orders set level=?,now=?,status=?,baner=? WHERE id=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $level);
        $stmt->bindValue(2, $next);
        $stmt->bindValue(3, $status);
        $stmt->bindValue(4, $user);
        $stmt->bindValue(5, $id);
        $stmt->execute();
        if ($next != 'مدیر داخلی' && $next != 'مدیریت') {
            $sql = 'select * from orders where id=?';
            $stmt = self::$conn->prepare($sql);
            $stmt->bindValue(1, $id);
            $stmt->execute();
            $result = $stmt->fetch();
            if ($result['factor'] > 1000000000) {
                $noe = "hagh";
            } else {
                $noe = "hogh";
            }
            $costumer = $result['costumer'];
            $this->sendEmail2($noe, $costumer, $next, $id);
        }
        $this->emailPersonel($id, $next);
    }


    function sendEmail2($noe, $id, $next, $sefaresh)
    {
        if ($noe == 'hagh') {
            $user = $this->getCusOneHagh($id);
            $nameUser = $user['name'] . ' ' . $user['last'];
            $email = $user['email'];
            $number = $user['mobile'];
        } else {
            $user = $this->getCusOneHogh($id);
            $email = $user['email'];
            $number = $user['mobile_manager'];
            $nameUser = $user['company'];
        }

        $start = time();
        $format = 'Y/n/j';
        $start_d = Model::jaliliDate($format, $start);

        $to = $email;
        $subject = 'وضعیت سفارش در طراحان باستان';
        $from_name = 'طراحان باستان';
        $from_email = 'tarahanbastan.ir';

        $textsms = 'مشتری گرامی، ' . $nameUser . ' سفارش شما به شماره ی سفارش ' . $sefaresh . '  به واحد ' . '  ' . $next . '  ' . '  طراحان باستان ارسال شد  ';
        $textsms .= 'تاریخ ارسال پیام : ' . $start_d;
        $message = '<html><meta charset="UTF-8"><meta name="viewport" content="width=device-width"><body>';
        $message .= '<div style="width: 95%;position: relative;padding-bottom:20px;
margin: auto;background-color: #fffddf;border-radius: 10px 10px 0 0;box-sizing: border-box">';
        $message .= '<div style="text-align: center;width:100%;box-sizing: border-box;min-width: 250px; color: #62680e;
line-height: 23px;font-family: Arial;font-size: 16px;border-radius: 10px 10px 0 0; background-color: #fff98f;padding: 10px;margin: 0 auto 10px auto;">
به طراحان باستان خوش آمدید</div>';
        $message .= '<div style="text-align: center;width: 95%;line-height: 23px;font-family: Arial;font-size: 15px;margin: auto; color: #343434"> 
مشتری گرامی، ' . $nameUser . ' سفارش شما به شماره ی سفارش ' . $sefaresh . '  به واحد ' . $next . ' طراحان باستان ارسال شد ';
        $message .= " .  تاریخ ارسال پیام : " . $start_d;
        $message .= '</div>';
        $message .= '</div>';
//echo $message;
        $this->html_mail($to, $subject, $message, array('from_email' => $from_email, 'from_name' => $from_name));
        $this->SMS($number, $textsms);
    }

    function des($userId, $id, $tool, $weight, $height, $tedad, $color, $jens, $time, $price1, $price2, $dis)
    {
        $sql = "select * from orders where id=?";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->execute();
        $result = $stmt->fetch();
        if (is_array($result)) {
            $des = unserialize($result['dis']);
        } else {
            $des = [];
        }
        $zekh = explode('|', $height)[0];
        $dis .= ' موارد فنی :  ' . ' ، طول: ' . $tool . ' ، عرض : ' . $weight . ' ، ضخامت: ' . $zekh . ' ، تعداد: ' . $tedad . ' ، رنگ: ' . $color . ' ، جنس: ' . $jens . ' ، زمان: ' . $time;
        $dis .= ' ، هزینه با ده درصد پرت: ' . $price1 . ' ، هزینه با احتساب بالاسری: ' . $price2;
        $nowtime = Model::jaliliDate($this->format, time());
        $user = $this->getUser($userId);
        $user = $user['name'] . ' ' . $user['last'];
        $price2 = str_replace('.', '', $price2);
        $arr = ['لیزر', $nowtime, $user, $price2, $dis];
        $des[] = $arr;
        $des = serialize($des);
        $sql = 'update orders set dis=? WHERE id=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $des);
        $stmt->bindValue(2, $id);
        $stmt->execute();
        //insert in print
        $sql = "select * from laser where orderid=?";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->execute();
        $result = $stmt->fetchAll();
        if (is_array($result)) {
            if (count($result) == 0) {
                $user = $this->getUser($userId);
                $user = $user['name'] . ' ' . $user['last'];
                $format = 'Y/n/j';
                $date = time();
                $date_d = Model::jaliliDate($format, $date);
                $sql = 'insert into laser (orderid,tool,weight,height,time,price,price2,color,jens,date,date_d,tedad,user)
                        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)';
                $stmt = self::$conn->prepare($sql);
                $stmt->bindValue(1, $id);
                $stmt->bindValue(2, $tool);
                $stmt->bindValue(3, $weight);
                $stmt->bindValue(4, $zekh);
                $stmt->bindValue(5, $time);
                $stmt->bindValue(6, $price1);
                $stmt->bindValue(7, $price2);
                $stmt->bindValue(8, $color);
                $stmt->bindValue(9, $jens);
                $stmt->bindValue(10, $date);
                $stmt->bindValue(11, $date_d);
                $stmt->bindValue(12, $tedad);
                $stmt->bindValue(13, $user);
                $stmt->execute();
            }
        }
    }

    function editUser1($id, $form)
    {
        $name = $form['name'];
        $last = $form['last'];
        $mobile = $form['mobile'];
        $email = $form['email'];
        $sql = 'update user set name=?,last=?,mobile=?,email=? WHERE id=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $name);
        $stmt->bindValue(2, $last);
        $stmt->bindValue(3, $mobile);
        $stmt->bindValue(4, $email);
        $stmt->bindValue(5, $id);
        $stmt->execute();
        Model::sessionSet('msg1', 1);
    }

    function editUser2($id, $file)
    {
        $fileName = $file['name'];
        $ext = pathinfo($fileName, PATHINFO_EXTENSION);
        $name = "image." . $ext;

        $fileSize = $file['size'];
        $fileTmp = $file['tmp_name'];
        $fileType = $file['type'];
        $fileError = $file['error'];
        $uploadOk = 1;
        $targetMain = 'image/user/' . $id . '/';

        if (!file_exists($targetMain)) {
            mkdir($targetMain);
        }
        if ($ext !== "jpg" and $ext !== "jpeg" and $ext !== "png") {
            $uploadOk = 0;
        }

        if (!empty($fileSize) and !empty($fileName) and !empty($fileType) and $uploadOk == 1) {
            $dir = $targetMain . 'image.png';
            $dir_100 = $targetMain . '100_image.png';
            if (file_exists($dir)) {
                unlink($dir);
            }
            if (file_exists($dir_100)) {
                unlink($dir_100);
            }
            if ($fileSize > 5242880) {
                $uploadOk = 0;
            }
            if ($uploadOk == 1) {
                $target = $targetMain . $name;
                move_uploaded_file($fileTmp, $target);
                $target100 = $targetMain . '100_' . $name;
                $this->create_thumbnail($target, $target100, 150, 150);
                $sql = 'update user set image=? WHERE id=?';
                $stmt = self::$conn->prepare($sql);
                $stmt->bindValue(1, $name);
                $stmt->bindValue(2, $id);
                $stmt->execute();
            }
        }
    }

    function editPass($userId, $pass0, $pass1)
    {
        $user = $this->getUser($userId);
        $oldHashPass = $user['pass'];
        if (password_verify($pass0, $oldHashPass)) {
            $newHashPass = password_hash($pass1, PASSWORD_DEFAULT);
            $sql = 'update user set pass=? where id=?';
            $stmt = self::$conn->prepare($sql);
            $stmt->bindValue(1, $newHashPass);
            $stmt->bindValue(2, $userId);
            $stmt->execute();
            $msg = "رمز عبور با موفقیت تغییر یافت :)";
        } else {
            $msg = "رمز عبور قدیم نادرست است :|";
        }
        Model::sessionSet('msg2', $msg);
    }

    function editPlaxi($one, $two, $thery, $for, $five, $six, $seven, $eight, $nin, $ten)
    {
        $sql = 'update laser_plaxi set price=? WHERE id=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $one);
        $stmt->bindValue(2, '1');
        $stmt->execute();
        $sql = 'update laser_plaxi set price=? WHERE id=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $two);
        $stmt->bindValue(2, '2');
        $stmt->execute();
        $sql = 'update laser_plaxi set price=? WHERE id=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $thery);
        $stmt->bindValue(2, '3');
        $stmt->execute();
        $sql = 'update laser_plaxi set price=? WHERE id=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $for);
        $stmt->bindValue(2, '4');
        $stmt->execute();
        $sql = 'update laser_plaxi set price=? WHERE id=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $five);
        $stmt->bindValue(2, '5');
        $stmt->execute();
        $sql = 'update laser_plaxi set price=? WHERE id=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $six);
        $stmt->bindValue(2, '6');
        $stmt->execute();
        $sql = 'update laser_plaxi set price=? WHERE id=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $seven);
        $stmt->bindValue(2, '7');
        $stmt->execute();
        $sql = 'update laser_plaxi set price=? WHERE id=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $eight);
        $stmt->bindValue(2, '8');
        $stmt->execute();
        $sql = 'update laser_plaxi set price=? WHERE id=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $nin);
        $stmt->bindValue(2, '9');
        $stmt->execute();
        $sql = 'update laser_plaxi set price=? WHERE id=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $ten);
        $stmt->bindValue(2, '10');
        $stmt->execute();
    }


    function addJens($name)
    {
        $sql = 'insert into laser_jens (name) VALUES (?)';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $name);
        $stmt->execute();
    }

    function delJens($id)
    {
        $sql = 'delete from laser_jens where id=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->execute();
    }


    function addColor($name)
    {
        $sql = 'insert into laser_color (name) VALUES (?)';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $name);
        $stmt->execute();
    }

    function delColor($id)
    {
        $sql = 'delete from laser_color where id=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->execute();
    }

    function editSetting($minet, $zarib)
    {
        $sql = 'update laser_setting set one_minet=?,zarib=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $minet);
        $stmt->bindValue(2, $zarib);
        $stmt->execute();
    }

}

