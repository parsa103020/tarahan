<?php

class model_design extends Model
{
    //ALTER TABLE factor_hagh AUTO_INCREMENT = 1000000000;
    public $format = 'Y/n/j H:i';

    function __construct()
    {
        Model::sessionInit();
        parent::__construct();
    }

    function getUser($id)
    {
        $sql = "select * from user where id=? and noe=?";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->bindValue(2, 'design');
        $stmt->execute();
        $result = $stmt->fetch();
        return $result;
    }

 
    function getUserDesign()
    {
        $sql = "select * from design_user";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    function getUserDesign2()
    {
        $sql = "select * from design_user order by id ASC ";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    function getDetail()
    {
        $user = $this->getUserDesign();
        $sql = "select * from orders";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        $now = jdate('n');
        $one = $now - 1;
        $two = $one - 1;
        $thery = $two - 1;
        $for = $thery - 1;
        $five = $for - 1;
        $now = round($now);
        $moon = [$five, $for, $thery, $two, $one, $now];
        foreach ($user as $key => $row) {
            $now2[$key] = $one2[$key] = $two2[$key] = $thery2[$key] = $for2[$key] = $five2[$key] = 0;
            $users[] = $row['name'];
        }
        foreach ($result as $row) {
            $design = $row['design'];
            $time = $row['start_d'];
            $time = explode('/', $time);
            @$month = $time[1];
            if ($now == $month) {
                foreach ($user as $key2 => $row2) {
                    if ($design == $row2['name']) {
                        ++$now2[$key2];
                    }
                }
            }
            if ($one == $month) {
                foreach ($user as $key2 => $row2) {
                    if ($design == $row2['name']) {
                        ++$one2[$key2];
                    }
                }
            }
            if ($two == $month) {
                foreach ($user as $key2 => $row2) {
                    if ($design == $row2['name']) {
                        ++$two2[$key2];
                    }
                }
            }
            if ($thery == $month) {
                foreach ($user as $key2 => $row2) {
                    if ($design == $row2['name']) {
                        ++$thery2[$key2];
                    }
                }
            }
            if ($for == $month) {
                foreach ($user as $key2 => $row2) {
                    if ($design == $row2['name']) {
                        ++$for2[$key2];
                    }
                }
            }
            if ($five == $month) {
                foreach ($user as $key2 => $row2) {
                    if ($design == $row2['name']) {
                        ++$five2[$key2];
                    }
                };
            }
        }
        $tedad = [$five2, $for2, $thery2, $two2, $one2, $now2];
        $data = [$moon, $tedad, $users];
        return $data;
    }

    function getMsg($id)
    {
        $sql = "select * from msg where resive=? and seen=?";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->bindValue(2, 0);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    function seenMsg($seen, $id)
    {
        $sql = 'update msg set seen=? WHERE resive=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $seen);
        $stmt->bindValue(2, $id);
        $stmt->execute();
    }

    function getOrder()
    {
        $sql = "select * from orders ORDER by id desc";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        foreach ($result as $key => $row) {
            @$next = end(unserialize($row['level']))[2];
            if ($next != 'طراحی') {
                unset($result[$key]);
            }
        }
        return $result;
    }

    function getNewOrder()
    {
        $sql = "select * from orders";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        $tedad = 0;
        foreach ($result as $key => $row) {
            if ($row['status'] === 'ارسال به واحد طراحی') {
                $tedad++;
            }
        }
        return $tedad;
    }

    function getOldOrder()
    {
        $sql = "select * from orders";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        $tedad = 0;
        foreach ($result as $key => $row) {
            if ($row['status'] === 'در مرحله طراحی') {
                $tedad++;
            }
        }
        return $tedad;
    }

    function changStatus($id, $user)
    {
        $sql = 'update orders set status=?,design=? WHERE id=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $user);
        $stmt->bindValue(2, $user);
        $stmt->bindValue(3, $id);
        $stmt->execute();
    }

    function getOneOrder($id)
    {
        $sql = "select * from orders where id=?";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->execute();
        $result = $stmt->fetch();
        return $result;
    }

    function getLevel()
    {
        $sql = "select * from level";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    function upload1($id, $file)
    {
        $msg = "فایل آپلود نشده است :|";
        $fileName = $file['name'];
        $ext = pathinfo($fileName, PATHINFO_EXTENSION);
        $name = 'design.' . $ext;
        $fileSize = $file['size'];
        $fileTmp = $file['tmp_name'];
        $uploadOk = 1;
        $targetMain = 'image/order/' . $id . '/';

        if (!file_exists($targetMain)) {
            mkdir($targetMain);
        }

        if (isset($file['name'])) {
            if ($ext != 'jpg' and $ext != 'JPG' and $ext != 'jpeg' and $ext != 'JPEG' and $ext != 'png' and $ext != 'PNG' and $ext != 'gif' and $ext != 'pdf'
                and $ext != 'psd' and $ext != 'tif' and $ext != 'psb' and $ext != 'cdr') {
                $uploadOk = 0;
            }
            if ($fileSize > 209715200) {
                $uploadOk = 0;
            }

            if ($uploadOk == 1) {
                $target = $targetMain . $name;
                move_uploaded_file($fileTmp, $target);
                $sql = 'update orders set file_design=? WHERE id=?';
                $stmt = self::$conn->prepare($sql);
                $stmt->bindValue(1, $name);
                $stmt->bindValue(2, $id);
                $stmt->execute();
                $msg = "فایل آپلود شده است :)";
            }
        }
        return $msg;
    }

    function ok($id)
    {
        $sql2 = 'update orders set status=? WHERE id=?';
        $stmt = self::$conn->prepare($sql2);
        $stmt->bindValue(1, "منتظر تایید مشتری");
        $stmt->bindValue(2, $id);
        $stmt->execute();
        $sql = 'select * from orders where id=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->execute();
        $result = $stmt->fetch();
        if ($result['factor'] > 1000000000) {
            $noe = "hagh";
        } else {
            $noe = "hogh";
        }
        $costumer = $result['costumer'];

        $this->sendEmail3($noe, $costumer, $id);
    }

    function setChange($user, $id, $mony, $next)
    {
        $sql = "select * from orders where id=?";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->execute();
        $result = $stmt->fetch();
        $level = unserialize($result['level']);
        $nowtime = Model::jaliliDate($this->format, time());
        $arr = [$nowtime, $id, $next];
        $level[] = $arr;
        $level = serialize($level);
        $status = "ارسال به واحد " . $next;
        $sql = 'update orders set price_design=?,level=?,now=?,status=? WHERE id=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $mony);
        $stmt->bindValue(2, $level);
        $stmt->bindValue(3, $next);
        $stmt->bindValue(4, $status);
        $stmt->bindValue(5, $id);
        $stmt->execute();
        if ($next != 'مدیر داخلی' && $next != 'مدیریت') {
            $sql = 'select * from orders where id=?';
            $stmt = self::$conn->prepare($sql);
            $stmt->bindValue(1, $id);
            $stmt->execute();
            $result = $stmt->fetch();
            if ($result['factor'] > 1000000000) {
                $noe = "hagh";
            } else {
                $noe = "hogh";
            }
            $costumer = $result['costumer'];
            $this->sendEmail2($noe, $costumer, $next, $id);
        }
        $this->emailPersonel($id, $next);
    }

    function sendEmail2($noe, $id, $next, $sefaresh)
    {
        if ($noe == 'hagh') {
            $user = $this->getCusOneHagh($id);
            $nameUser = $user['name'] . ' ' . $user['last'];
            $email = $user['email'];
            $number = $user['mobile'];
        } else {
            $user = $this->getCusOneHogh($id);
            $email = $user['email'];
            $number = $user['mobile_manager'];
            $nameUser = $user['company'];
        }

        $start = time();
        $format = 'Y/n/j';
        $start_d = Model::jaliliDate($format, $start);

        $to = $email;
        $subject = 'وضعیت سفارش در طراحان باستان';
        $from_name = 'طراحان باستان';
        $from_email = 'tarahanbastan.ir';

        $textsms = 'مشتری گرامی، ' . $nameUser . ' سفارش شما به شماره ی سفارش ' . $sefaresh . '  به واحد ' . '  ' . $next . '  ' . '  طراحان باستان ارسال شد  ';
        $textsms .= 'تاریخ ارسال پیام : ' . $start_d;
        $message = '<html><meta charset="UTF-8"><meta name="viewport" content="width=device-width"><body>';
        $message .= '<div style="width: 95%;position: relative;padding-bottom:20px;
margin: auto;background-color: #fffddf;border-radius: 10px 10px 0 0;box-sizing: border-box">';
        $message .= '<div style="text-align: center;width:100%;box-sizing: border-box;min-width: 250px; color: #62680e;
line-height: 23px;font-family: Arial;font-size: 16px;border-radius: 10px 10px 0 0; background-color: #fff98f;padding: 10px;margin: 0 auto 10px auto;">
به طراحان باستان خوش آمدید</div>';
        $message .= '<div style="text-align: center;width: 95%;line-height: 23px;font-family: Arial;font-size: 15px;margin: auto; color: #343434"> 
مشتری گرامی، ' . $nameUser . ' سفارش شما به شماره ی سفارش ' . $sefaresh . '  به واحد ' . $next . ' طراحان باستان ارسال شد ';
        $message .= " .  تاریخ ارسال پیام : " . $start_d;
        $message .= '</div>';
        $message .= '</div>';
//echo $message;
        $this->html_mail($to, $subject, $message, array('from_email' => $from_email, 'from_name' => $from_name));
        $this->SMS($number, $textsms);
    }

    function sendEmail3($noe, $id, $sefaresh)
    {
        if ($noe == 'hagh') {
            $user = $this->getCusOneHagh($id);
            $nameUser = $user['name'] . ' ' . $user['last'];
            $email = $user['email'];
            $number = $user['mobile'];
        } else {
            $user = $this->getCusOneHogh($id);
            $email = $user['email'];
            $number = $user['mobile_manager'];
            $nameUser = $user['company'];
        }

        $start = time();
        $format = 'Y/n/j';
        $start_d = Model::jaliliDate($format, $start);

        $to = $email;
        $subject = 'وضعیت سفارش در طراحان باستان';
        $from_name = 'طراحان باستان';
        $from_email = 'tarahanbastan.ir';

        $textsms = 'مشتری گرامی، ' . $nameUser . ' طراحی سفارش شما به شماره ی سفارش ' . $sefaresh . '  به پایان رسید، لطفا به واحد طراحی شرکت مراجعه یا در تلگرام مشاهده بفرمایید.   ';
        $textsms .= 'تاریخ ارسال پیام : ' . $start_d;
        $message = '<html><meta charset="UTF-8"><meta name="viewport" content="width=device-width"><body>';
        $message .= '<div style="width: 95%;position: relative;padding-bottom:20px;
margin: auto;background-color: #fffddf;border-radius: 10px 10px 0 0;box-sizing: border-box">';
        $message .= '<div style="text-align: center;width:100%;box-sizing: border-box;min-width: 250px; color: #62680e;
line-height: 23px;font-family: Arial;font-size: 16px;border-radius: 10px 10px 0 0; background-color: #fff98f;padding: 10px;margin: 0 auto 10px auto;">
به طراحان باستان خوش آمدید</div>';
        $message .= '<div style="text-align: center;width: 95%;line-height: 23px;font-family: Arial;font-size: 15px;margin: auto; color: #343434"> 
مشتری گرامی، ' . $nameUser . ' طراحی سفارش شما به شماره ی سفارش  ' . $sefaresh . '  به پایان رسید، لطفا به واحد طراحی شرکت مراجعه یا طراحی  در تلگرام مشاهده بفرمایید.  ';
        $message .= " .  تاریخ ارسال پیام : " . $start_d;
        $message .= '</div>';
        $message .= '</div>';
//echo $message;
        $this->html_mail($to, $subject, $message, array('from_email' => $from_email, 'from_name' => $from_name));
        $this->SMS($number, $textsms);
    }

    function des($userId, $id, $mony, $dis)
    {
        $sql = "select * from orders where id=?";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->execute();
        $result = $stmt->fetch();
        if (is_array($result)) {
            $des = unserialize($result['dis']);
        } else {
            $des = [];
        }
        $send = Model::jaliliDate($this->format, time());
        $user = $this->getUser($userId);
        $user = $user['name'] . ' ' . $user['last'];
        $arr = ['طراحی', $send, $user, $mony, $dis];
        $des[] = $arr;
        $des = serialize($des);
        $sql = 'update orders set dis=? WHERE id=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $des);
        $stmt->bindValue(2, $id);
        $stmt->execute();
    }

    function editUser1($id, $form)
    {
        $name = $form['name'];
        $last = $form['last'];
        $mobile = $form['mobile'];
        $email = $form['email'];
        $sql = 'update user set name=?,last=?,mobile=?,email=? WHERE id=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $name);
        $stmt->bindValue(2, $last);
        $stmt->bindValue(3, $mobile);
        $stmt->bindValue(4, $email);
        $stmt->bindValue(5, $id);
        $stmt->execute();
        Model::sessionSet('msg1', 1);
    }

    function editUser2($id, $file)
    {
        $fileName = $file['name'];
        $ext = pathinfo($fileName, PATHINFO_EXTENSION);
        $name = "image." . $ext;


        $fileSize = $file['size'];
        $fileTmp = $file['tmp_name'];
        $fileType = $file['type'];
        $fileError = $file['error'];
        $uploadOk = 1;
        $targetMain = 'image/user/' . $id . '/';

        if (!file_exists($targetMain)) {
            mkdir($targetMain);
        }
        if ($ext !== "jpg" and $ext !== "jpeg" and $ext !== "png") {
            $uploadOk = 0;
        }

        if (!empty($fileSize) and !empty($fileName) and !empty($fileType) and $uploadOk == 1) {
            $dir = $targetMain . 'image.png';
            $dir_100 = $targetMain . '100_image.png';
            if (file_exists($dir)) {
                unlink($dir);
            }
            if (file_exists($dir_100)) {
                unlink($dir_100);
            }
            if ($fileSize > 5242880) {
                $uploadOk = 0;
            }
            if ($uploadOk == 1) {
                $target = $targetMain . $name;
                move_uploaded_file($fileTmp, $target);
                $target100 = $targetMain . '100_' . $name;
                $this->create_thumbnail($target, $target100, 150, 150);
                $sql = 'update user set image=? WHERE id=?';
                $stmt = self::$conn->prepare($sql);
                $stmt->bindValue(1, $name);
                $stmt->bindValue(2, $id);
                $stmt->execute();
            }
        }
    }

    function editPass($userId, $pass0, $pass1)
    {
        $user = $this->getUser($userId);
        $oldHashPass = $user['pass'];
        if (password_verify($pass0, $oldHashPass)) {
            $newHashPass = password_hash($pass1, PASSWORD_DEFAULT);
            $sql = 'update user set pass=? where id=?';
            $stmt = self::$conn->prepare($sql);
            $stmt->bindValue(1, $newHashPass);
            $stmt->bindValue(2, $userId);
            $stmt->execute();
            $msg = "رمز عبور با موفقیت تغییر یافت :)";
        } else {
            $msg = "رمز عبور قدیم نادرست است :|";
        }
        Model::sessionSet('msg2', $msg);
    }
}
