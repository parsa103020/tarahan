<?php

class model_index extends Model
{
    function __construct()
    {
        Model::sessionInit();
        parent::__construct();
    }

    function login($user, $pass)
    {
        Model::sessionSet('login', false);
        $msg = " ";
        $sql = 'select * from user where user=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $user);
        $stmt->execute();
        $result = $stmt->fetchAll();
        if (count($result) > 0) {
            $hash = @$result[0]['pass'];
            if (password_verify($pass, $hash)) {
                $noe = $result[0]['noe'];
                $id = $result[0]['id'];
                $activLogin = $result[0]['active'];
                if ($activLogin == 0) {
                    $ok = 0;
                    $msg = "حساب شما غیرفعال شده است !";
                } else {
                    Model::sessionSet('login', true);
                    Model::sessionSet('noe', $noe);
                    Model::sessionSet('id', $id);
                    if ($noe === "respect") {
                        $ok = 1;
                    } elseif ($noe === "manag") {
                        $ok = 2;
                    } elseif ($noe === "design") {
                        $ok = 3;
                    } elseif ($noe === "other") {
                        $ok = 4;
                    } elseif ($noe === "baner") {
                        $ok = 5;
                    } elseif ($noe === "laser") {
                        $ok = 6;
                    } elseif ($noe === "out") {
                        $ok = 7;
                    } elseif ($noe === "hesab") {
                        $ok = 8;
                    }
                }
            } else {
                $ok = 0;
                $msg = "نام کاربری یا رمز ورود اشتباه است !";
            }
        } else {
            $ok = 0;
            $msg = "نام کاربری یا رمز ورود اشتباه است !";
        }
        $data = [$ok, $msg];
        return $data;
    }

    function register($user, $pass)
    {
        $msg = " ";
        $sql = 'select * from mpo_user where mpo_username=?';
        $stmt = $this->conn->prepare($sql);
        $stmt->bindValue(1, $user);
        $stmt->execute();
        $result = $stmt->fetchAll();
        if (count($result) > 0) {
            $msg = "This email has already been registered";
            $ok = 0;
        } else {
            $hash = password_hash($pass, PASSWORD_DEFAULT);
            $sql = "insert into mpo_user (mpo_username,mpo_pass,mpo_noe,mpo_block,mpo_email,mpo_mpo,mpo_activLogin)
 VALUES (?,?,?,?,?,?,?)";
            $login = 'MxvD32D' . time() . 'Xv';
            $stmt = $this->conn->prepare($sql);
            $stmt->bindValue(1, $user);
            $stmt->bindValue(2, $hash);
            $stmt->bindValue(3, "user");
            $stmt->bindValue(4, 0);
            $stmt->bindValue(5, $user);
            $stmt->bindValue(6, $login);
            $stmt->bindValue(7, 0);
            $stmt->execute();
            $ok = 1;
            //get user for set session
            $sql = 'select * from mpo_user where mpo_username=?';
            $stmt = $this->conn->prepare($sql);
            $stmt->bindValue(1, $user);
            $stmt->execute();
            $result = $stmt->fetch();
            $id = $result['mpo_id'];
            $mpo = U . 'index/activePanel/' . $id . '/' . $result['mpo_mpo'];
            $email = $result['mpo_email'];


            $to = $email;
            $subject = 'Active account in Talent Sport';
            $from_name = 'Talent Sport';
            $from_email = 'register@talent-sports.com';


            $message = '<html><body>';
            $message .= '<div style="width: 95%;position: relative;padding-bottom:20px;
margin: auto;background-color: #e6fdff;border-radius: 10px 10px 0 0;box-sizing: border-box">';
            $message .= '<div style="text-align: center;width:100%;box-sizing: border-box;min-width: 250px; color: white;
line-height: 23px;font-family: Arial;font-size: 16px;border-radius: 10px 10px 0 0; background-color: red;padding: 10px;margin: 0 auto 10px auto;">
Wellcome to Talent Sports</div>';
            $message .= '<div style="text-align: center;width: 95%;line-height: 23px;font-family: Arial;font-size: 15px;margin: auto; color: #343434">
Please click on this link to active your account : ';
            $message .= $mpo;
            $message .= '</div>';
            $message .= '</div>';
//echo $message;
            $this->html_mail($to, $subject, $message, array('from_email' => $from_email, 'from_name' => $from_name));


            //$this->sendEmail($user, $msgMail, $subject = 'Register Account');

            $msg = "Sign up successfully, Please click on the activation link in your email";
        }
        $data = [$ok, $msg];
        return $data;
    }


    function html_mail($to, $subject, $message, $options)
    {
        if (isset($options['from_name'])) {
            $headers = "From: " . $options['from_name'] . "<" . $options['from_email'] . ">" . "\r\n";
        }
        $headers = '';
        $headers .= "Reply-To: " . strip_tags($_POST['req-email']) . "\r\n";
        $headers .= "CC: register@talent-sports.com\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";

        mail($to, $subject, $message, $headers);
    }


    function sendEmail($email, $msg, $subject = 'Register Account')
    {
        include 'view/assets/phpmailer/class.phpmailer.php';
        $mail = new PHPMailer();
        // send email by protocle smtp
        $mail->isSMTP();
        //intodns.com => MX records => name host marbut be smtp
        $mail->Host = 'talentsp@ariamehr.dnswebhot.com';
        $mail->SMTPAuth = true;
        //creat email accont by cpanel and insert username and password
        $mail->Username = USER_EMAIL;
        $mail->Password = PASS_EMAIL;

        // for security
        $mail->SMTPSecure = 'ssl';

        //set port SMTP
        //yougetsignal.com
        $mail->Port = 465;

        // set subject email
        $mail->Subject = $subject;
        //set from sender email
        $mail->From = USER_EMAIL;
        //set charset utf-8 for farsi
        $mail->CharSet = 'utf-8';
        $mail->FromName = 'Talent Sports';
        //if you want send email by html ans css text
        $mail->ContentType = 'text/html;charset=utf-8';
        //if client dont see $messagehtml he see $messagetext
        $messagehtml = '';
        $messagetext = $msg;

        $mail->isHTML(true);

        //add address email
        $mail->addAddress($email);
        $mail->Body = $messagehtml;
        $mail->AltBody = $messagetext;
        $mail->send();
        $mail->smtpClose();

    }

    function chekRegister($id, $mpo)
    {
        $sql = 'select * from mpo_user where mpo_id=?';
        $stmt = $this->conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->execute();
        $result = $stmt->fetch();
        $mpoOld = $result['mpo_mpo'];
        $noe = $result['mpo_noe'];
        if ($mpoOld == $mpo) {
            $sql = 'update mpo_user set mpo_activLogin=? where mpo_id=?';
            $stmt = $this->conn->prepare($sql);
            $stmt->bindValue(1, 1);
            $stmt->bindValue(2, $id);
            $stmt->execute();
            Model::sessionSet('login', true);
            Model::sessionSet('noe', $noe);
            Model::sessionSet('id', $id);
            header('location:' . U . 'user/index');
        } else {
            header('location:' . U . 'index/index');
        }
    }

}