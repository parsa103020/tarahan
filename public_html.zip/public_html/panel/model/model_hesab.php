<?php

class model_hesab extends Model
{
    //ALTER TABLE factor_hagh AUTO_INCREMENT = 1000000000;
    public $format = 'Y/n/j';

    // Cache layer برای جلوگیری از محاسبات تکراری
    private $cache = [];
    private static $userCache = [];
    private static $levelCache = [];

    function __construct()
    {
        Model::sessionInit();
        parent::__construct();
    }

    function users()
    {
        if (!empty(self::$userCache)) {
            return self::$userCache;
        }

        $sql = "select * from user";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        self::$userCache = $result;
        return $result;
    }

    function getUser($id)
    {
        if (isset(self::$userCache[$id])) {
            return self::$userCache[$id];
        }

        $sql = "select * from user where id=?";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->execute();
        $result = $stmt->fetch();
        self::$userCache[$id] = $result;
        return $result;
    }

    function getDetail($id)
    {
        // بهینه‌سازی با استفاده از GROUP BY و SQL aggregation
        $now = jdate('n');
        $months = [];
        for ($i = 5; $i >= 0; $i--) {
            $months[] = $now - $i;
        }
        $months = array_map('round', $months);

        // یک کوئری برای همه محاسبات
        $sql = "SELECT 
                    MONTH(STR_TO_DATE(start_d, '%Y/%m/%d')) as month,
                    mood,
                    COUNT(*) as count
                FROM orders 
                WHERE MONTH(STR_TO_DATE(start_d, '%Y/%m/%d')) IN (" . implode(',', $months) . ")
                GROUP BY MONTH(STR_TO_DATE(start_d, '%Y/%m/%d')), mood
                LIMIT 600";

        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $results = $stmt->fetchAll();

        // Initialize arrays
        $ejra = array_fill(0, 6, 0);
        $finish = array_fill(0, 6, 0);
        $laghv = array_fill(0, 6, 0);
        $all = array_fill(0, 6, 0);

        foreach ($results as $row) {
            $monthIndex = array_search($row['month'], $months);
            if ($monthIndex !== false) {
                $all[$monthIndex] += $row['count'];

                switch ($row['mood']) {
                    case 0:
                        $ejra[$monthIndex] = $row['count'];
                        break;
                    case 1:
                        $finish[$monthIndex] = $row['count'];
                        break;
                    case 2:
                        $laghv[$monthIndex] = $row['count'];
                        break;
                }
            }
        }

        // حفظ ساختار خروجی اصلی
        return [$months, $ejra, $finish, $laghv, $all];
    }

    function getMsg($id)
    {
        $sql = "select * from msg where resive=? and seen=?";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->bindValue(2, 0);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    function getOrder()
    {
        $sql = "select * from orders where hesab_show=? ORDER by id desc";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, 0);
        $stmt->execute();
        $result = $stmt->fetchAll();

        // استفاده از cache برای بهینه‌سازی unserialize
        $filtered = [];
        foreach ($result as $key => $row) {
            // Cache unserialize results
            $cacheKey = 'level_' . $row['id'];
            if (!isset($this->cache[$cacheKey])) {
                $level = @unserialize($row['level']);
                $this->cache[$cacheKey] = $level;
            } else {
                $level = $this->cache[$cacheKey];
            }

            // بررسی آخرین مرحله
            if (is_array($level) && !empty($level)) {
                $lastLevel = end($level);
                if (isset($lastLevel[2]) && $lastLevel[2] == 'حسابداری') {
                    // فقط سفارشاتی که آخرین مرحله‌شان حسابداری است
                    $filtered[] = $row;
                }
            }
        }

        return $filtered;
    }

    function getNewOrder()
    {
        // بهینه‌سازی: استفاده از COUNT در SQL
        $sql = "SELECT COUNT(*) as count FROM orders 
                WHERE hesab_show=? AND status='ارسال به حسابداری'";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, 0);
        $stmt->execute();
        $result = $stmt->fetch();
        return (int)$result['count'];
    }

    function getBayegani()
    {
        // اضافه کردن LIMIT برای جلوگیری از بارگذاری همه رکوردها
        $sql = "select * from orders WHERE hesab_show=? order by bayegani DESC LIMIT 500";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, 1);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    function changStatus($id, $user)
    {
        $sql = 'update orders set status=?,design=? WHERE id=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, 'ارسال به بیرون');
        $stmt->bindValue(2, $user);
        $stmt->bindValue(3, $id);
        $stmt->execute();
    }

    function getOneOrder($id)
    {
        $sql = 'select orders.*,orders.id as Id,orders.mood as Mood ,user.* from orders JOIN user on user.id=orders.user where orders.id=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->execute();
        $result = $stmt->fetch();
        return $result;
    }

    function getOneOrderPrint($id)
    {
        $sql = "select * from print where orderid=?";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->execute();
        $result = $stmt->fetch();
        return $result;
    }

    function getLevel()
    {
        if (!empty(self::$levelCache)) {
            return self::$levelCache;
        }

        $sql = "select * from level";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        self::$levelCache = $result;
        return $result;
    }

    function setChange($user, $id, $next, $mony, $dis)
    {
        $sql = "select * from orders where id=?";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->execute();
        $result = $stmt->fetch();
        $level = unserialize($result['level']);
        $nowtime = Model::jaliliDate($this->format, time());
        $arr = [$nowtime, $id, $next];
        $level[] = $arr;
        $level = serialize($level);
        if ($next == 'حسابداری') {
            $status = "ارسال به حسابداری";
        } else {
            $status = "لغو شد";
        }
        if (is_array($result)) {
            @$des = unserialize($result['dis']);
        } else {
            @$des = [];
        }
        $user = $this->getUser($user);
        $user = $user['name'] . ' ' . $user['last'];
        $arr = ['بیرون', $nowtime, $user, $mony, $dis, ' '];
        $des[] = $arr;
        $des = serialize($des);

        if ($next == 'حسابداری') {
            $mood = 1;
        } else {
            $mood = 2;
        }
        $sql = 'update orders set level=?,now=?,status=?,price_manag=?,dis=?,mood=? WHERE id=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $level);
        $stmt->bindValue(2, $next);
        $stmt->bindValue(3, $status);
        $stmt->bindValue(4, $mony);
        $stmt->bindValue(5, $des);
        $stmt->bindValue(6, $mood);
        $stmt->bindValue(7, $id);
        $stmt->execute();

        $this->emailPersonel($id, $next);
    }

    function des($userId, $id, $mony, $dis, $gole)
    {
        $sql = "select * from orders where id=?";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->execute();
        $result = $stmt->fetchAll();
        $des = unserialize($result['dis']);
        $nowtime = Model::jaliliDate($this->format, time());
        $user = $this->getUser($userId);
        $user = $user['name'] . ' ' . $user['last'];
        $arr = ['بیرون', $nowtime, $user, $mony, $dis, $gole];
        $des[] = $arr;
        $des = serialize($des);
        $sql = 'update orders set dis=? WHERE id=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $des);
        $stmt->bindValue(2, $id);
        $stmt->execute();
    }

    function editUser1($id, $form)
    {
        $name = $form['name'];
        $last = $form['last'];
        $mobile = $form['mobile'];
        $email = $form['email'];
        $sql = 'update user set name=?,last=?,mobile=?,email=? WHERE id=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $name);
        $stmt->bindValue(2, $last);
        $stmt->bindValue(3, $mobile);
        $stmt->bindValue(4, $email);
        $stmt->bindValue(5, $id);
        $stmt->execute();
        Model::sessionSet('msg1', 1);
        // Clear cache
        unset(self::$userCache[$id]);
    }

    function editUser2($id, $file)
    {
        $fileName = $file['name'];
        $ext = pathinfo($fileName, PATHINFO_EXTENSION);
        $name = "image." . $ext;

        $fileSize = $file['size'];
        $fileTmp = $file['tmp_name'];
        $fileType = $file['type'];
        $fileError = $file['error'];
        $uploadOk = 1;
        $targetMain = 'image/user/' . $id . '/';

        if (!file_exists($targetMain)) {
            mkdir($targetMain);
        }
        if ($ext !== "jpg" and $ext !== "jpeg" and $ext !== "png") {
            $uploadOk = 0;
        }

        if (!empty($fileSize) and !empty($fileName) and !empty($fileType) and $uploadOk == 1) {
            $dir = $targetMain . 'image.png';
            $dir_100 = $targetMain . '100_image.png';
            if (file_exists($dir)) {
                unlink($dir);
            }
            if (file_exists($dir_100)) {
                unlink($dir_100);
            }
            if ($fileSize > 5242880) {
                $uploadOk = 0;
            }
            if ($uploadOk == 1) {
                $target = $targetMain . $name;
                move_uploaded_file($fileTmp, $target);
                $target100 = $targetMain . '100_' . $name;
                $this->create_thumbnail($target, $target100, 150, 150);
                $sql = 'update user set image=? WHERE id=?';
                $stmt = self::$conn->prepare($sql);
                $stmt->bindValue(1, $name);
                $stmt->bindValue(2, $id);
                $stmt->execute();
            }
        }
    }

    function editPass($userId, $pass0, $pass1)
    {
        $user = $this->getUser($userId);
        $oldHashPass = $user['pass'];
        if (password_verify($pass0, $oldHashPass)) {
            $newHashPass = password_hash($pass1, PASSWORD_DEFAULT);
            $sql = 'update user set pass=? where id=?';
            $stmt = self::$conn->prepare($sql);
            $stmt->bindValue(1, $newHashPass);
            $stmt->bindValue(2, $userId);
            $stmt->execute();
            $msg = "رمز عبور با موفقیت تغییر یافت :)";
        } else {
            $msg = "رمز عبور قدیم نادرست است :|";
        }
        Model::sessionSet('msg2', $msg);
    }

    function editPer3($userId, $pass1)
    {
        $newHashPass = password_hash($pass1, PASSWORD_DEFAULT);
        $sql = 'update user set pass=? where id=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $newHashPass);
        $stmt->bindValue(2, $userId);
        $stmt->execute();
        $msg = "رمز عبور با موفقیت تغییر یافت :)";
        Model::sessionSet('msg2', $msg);
    }

    function rol($userId, $weight, $height, $num)
    {
        $user = $this->getUser($userId);
        $user = $user['name'] . ' ' . $user['last'];
        $format = 'Y/n/j';
        $time = time();
        $time_d = Model::jaliliDate($format, $time);
        $sql = 'insert into rol (noe,weight,height,tedad,user,time,time_d) VALUES (?,?,?,?,?,?,?)';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, 'بنر');
        $stmt->bindValue(2, $weight);
        $stmt->bindValue(3, $height);
        $stmt->bindValue(4, $num);
        $stmt->bindValue(5, $user);
        $stmt->bindValue(6, $time);
        $stmt->bindValue(7, $time_d);
        $stmt->execute();
        $rol = "ثبت گزارش با موفقیت انجام شد .";
        Model::sessionSet('rol', $rol);
    }

    function getAllOrder()
    {
        // اضافه کردن LIMIT
        $sql = "select * from orders ORDER by id desc limit 100";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    function report2($start, $end)
    {
        if (empty($start) or empty($end)) {
            // بهینه‌سازی با INDEX و LIMIT
            $sql = "select * from orders where mood=? ORDER by id desc LIMIT 500";
            $stmt = self::$conn->prepare($sql);
            $stmt->bindValue(1, 1);
            $stmt->execute();
            $result = $stmt->fetchAll();
        } else {
            $start = Model::jaliliToMiladi($start);
            $start = strtotime($start);
            $end = Model::jaliliToMiladi($end);
            $end = strtotime($end);
            $sql = "select * from orders where start BETWEEN ? and ? and mood=? ORDER by id desc LIMIT 500";
            $stmt = self::$conn->prepare($sql);
            $stmt->bindValue(1, $start);
            $stmt->bindValue(2, $end);
            $stmt->bindValue(3, 1);
            $stmt->execute();
            $result = $stmt->fetchAll();
        }
        return $result;
    }

    function report3($start, $end)
    {
        if (empty($start) or empty($end)) {
            $sql = "select * from orders where mood=? ORDER by id desc LIMIT 500";
            $stmt = self::$conn->prepare($sql);
            $stmt->bindValue(1, 0);
            $stmt->execute();
            $result = $stmt->fetchAll();
        } else {
            $start = Model::jaliliToMiladi($start);
            $start = strtotime($start);
            $end = Model::jaliliToMiladi($end);
            $end = strtotime($end);
            $sql = "select * from orders where start BETWEEN ? and ? and mood=? ORDER by id desc LIMIT 500";
            $stmt = self::$conn->prepare($sql);
            $stmt->bindValue(1, $start);
            $stmt->bindValue(2, $end);
            $stmt->bindValue(3, 0);
            $stmt->execute();
            $result = $stmt->fetchAll();
        }
        return $result;
    }

    function report4($start, $end)
    {
        if (empty($start) or empty($end)) {
            $sql = "select * from orders where mood=? ORDER by id desc LIMIT 500";
            $stmt = self::$conn->prepare($sql);
            $stmt->bindValue(1, 2);
            $stmt->execute();
            $result = $stmt->fetchAll();
        } else {
            $start = Model::jaliliToMiladi($start);
            $start = strtotime($start);
            $end = Model::jaliliToMiladi($end);
            $end = strtotime($end);
            $sql = "select * from orders where start BETWEEN ? and ? and mood=? ORDER by id desc LIMIT 500";
            $stmt = self::$conn->prepare($sql);
            $stmt->bindValue(1, $start);
            $stmt->bindValue(2, $end);
            $stmt->bindValue(3, 2);
            $stmt->execute();
            $result = $stmt->fetchAll();
        }
        return $result;
    }

    function sRespect($id)
    {
        $sql = "select * from orders where id=?";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    function sFactor($id)
    {
        $sql = "select * from orders where factor=?";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    function getPer()
    {
        // استفاده از cache
        return $this->users();
    }

    function getPrint($id)
    {
        $fac = $this->getOrderByFactorId($id);
        $ordersId = [];
        foreach ($fac as $row) {
            $sefaresh = $row[0];
            $ordersId[] = $sefaresh;
        }

        if (empty($ordersId)) {
            return [];
        }

        $x = join(',', array_values($ordersId));
        $sql = 'select * from print where orderid IN (' . $x . ')';
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    function per1()
    {
        // بهینه‌سازی شدید با SQL aggregation
        $now = jdate('n');
        $months = [];
        for ($i = 5; $i >= 0; $i--) {
            $months[] = $now - $i;
        }

        // یک کوئری برای همه آمار
        $sql = "SELECT 
                MONTH(STR_TO_DATE(start_d, '%Y/%m/%d')) as month,
                SUM(CASE WHEN design IS NOT NULL AND design != '' THEN 1 ELSE 0 END) as design_count,
                SUM(CASE WHEN baner IS NOT NULL AND baner != '' THEN 1 ELSE 0 END) as baner_count,
                SUM(CASE WHEN riso IS NOT NULL AND riso != '' THEN 1 ELSE 0 END) as riso_count,
                SUM(CASE WHEN laser IS NOT NULL AND laser != '' THEN 1 ELSE 0 END) as laser_count,
                SUM(CASE WHEN `out` IS NOT NULL AND `out` != '' THEN 1 ELSE 0 END) as out_count,
                COUNT(*) as total
                FROM orders 
                WHERE mood=1 
                AND MONTH(STR_TO_DATE(start_d, '%Y/%m/%d')) IN (" . implode(',', $months) . ")
                GROUP BY MONTH(STR_TO_DATE(start_d, '%Y/%m/%d'))";

        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Initialize arrays
        $allS = array_fill(0, 6, 0);
        $designS = array_fill(0, 6, 0);
        $banerS = array_fill(0, 6, 0);
        $otherS = array_fill(0, 6, 0);
        $laserS = array_fill(0, 6, 0);
        $outS = array_fill(0, 6, 0);

        foreach ($results as $row) {
            $monthIndex = array_search($row['month'], $months);
            if ($monthIndex !== false) {
                $allS[$monthIndex] = $row['total'];
                $designS[$monthIndex] = $row['design_count'];
                $banerS[$monthIndex] = $row['baner_count'];
                $otherS[$monthIndex] = $row['riso_count'];
                $laserS[$monthIndex] = $row['laser_count'];
                $outS[$monthIndex] = $row['out_count'];
            }
        }

        // حفظ ساختار خروجی اصلی
        return [$months, $allS, $designS, $banerS, $otherS, $laserS, $outS];
    }

    function per2()
    {
        // بهینه‌سازی با SQL COUNT
        $sql = "SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN design IS NOT NULL AND design != '' THEN 1 ELSE 0 END) as design_count,
                SUM(CASE WHEN baner IS NOT NULL AND baner != '' THEN 1 ELSE 0 END) as baner_count,
                SUM(CASE WHEN riso IS NOT NULL AND riso != '' THEN 1 ELSE 0 END) as riso_count,
                SUM(CASE WHEN laser IS NOT NULL AND laser != '' THEN 1 ELSE 0 END) as laser_count,
                SUM(CASE WHEN `out` IS NOT NULL AND `out` != '' THEN 1 ELSE 0 END) as out_count
                FROM orders 
                WHERE mood=1";

        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        // حفظ ساختار خروجی اصلی
        return [
            $result['total'],
            $result['design_count'],
            $result['baner_count'],
            $result['riso_count'],
            $result['laser_count'],
            $result['out_count']
        ];
    }

    function showMsg($id)
    {
        $sql = "select * from msg where resive=? ORDER BY id DESC LIMIT 100";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    function insertMsg($admin, $id, $msg)
    {
        $format = 'Y/n/j';
        $time = time();
        $time_d = Model::jaliliDate($format, $time);
        $sql = 'insert into msg (send,resive,msg,seen,date) VALUES (?,?,?,?,?)';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $admin);
        $stmt->bindValue(2, $id);
        $stmt->bindValue(3, $msg);
        $stmt->bindValue(4, '0');
        $stmt->bindValue(5, $time_d);
        $stmt->execute();
    }

    function remember()
    {
        $sql = "select * from remember order by id desc LIMIT 100";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    function insertRem($rem)
    {
        $format = 'Y/n/j';
        $time = time();
        $time_d = Model::jaliliDate($format, $time);
        $sql = 'insert into remember (text,time,time_d,chek) VALUES (?,?,?,?)';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $rem);
        $stmt->bindValue(2, $time);
        $stmt->bindValue(3, $time_d);
        $stmt->bindValue(4, '0');
        $stmt->execute();
    }

    function removeUser($id)
    {
        $sql = 'DELETE FROM `user` WHERE id=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->execute();
        // Clear cache
        unset(self::$userCache[$id]);
    }

    function seenMsg($seen, $id)
    {
        $sql = 'update msg set seen=? WHERE resive=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $seen);
        $stmt->bindValue(2, $id);
        $stmt->execute();
    }

    function getPriceFactors($factors)
    {
        if (empty($factors)) {
            return 0;
        }

        // بهینه‌سازی با SUM در SQL
        $factors = implode(',', $factors);
        $sql = "SELECT SUM(price_manag) as total FROM orders WHERE factor IN (" . $factors . ")";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetch();
        return $result['total'] ?? 0;
    }

    function searchFactor($key, $start, $end)
    {
        $factors = [];
        if (empty($start)) {
            $start = 111111;
        } else {
            $start = Model::jaliliToMiladi($start);
            $start = strtotime($start);
        }
        if (empty($end)) {
            $end = 99999999999;
        } else {
            $end = Model::jaliliToMiladi($end);
            $end = strtotime($end);
        }

        if ($key == "mapnoco.ir") {
            // بهینه‌سازی: LIMIT در خود query
            $sql = "select * from factor_hogh UNION select * from factor_hagh order by start desc limit 15";
            $stmt = self::$conn->prepare($sql);
            $stmt->execute();
            $result = $stmt->fetchAll();
        } else {
            $key = str_replace(' ', '%', $key);
            $sql = "select * from factor_hogh where id like ? or cos like ? and start BETWEEN ? and ?
                    UNION select * from factor_hagh where id like ? or cos like ? and start BETWEEN ? and ?
                    order by start desc limit 15";
            $stmt = self::$conn->prepare($sql);
            $stmt->bindValue(1, "$key%");
            $stmt->bindValue(2, "%$key%");
            $stmt->bindValue(3, $start);
            $stmt->bindValue(4, $end);
            $stmt->bindValue(5, "$key%");
            $stmt->bindValue(6, "%$key%");
            $stmt->bindValue(7, $start);
            $stmt->bindValue(8, $end);
            $stmt->execute();
            $result = $stmt->fetchAll();
        }

        foreach ($result as $row) {
            $factor = $row['id'];
            $factors[] = $factor;
        }
        $price = $this->getPriceFactors($factors);
        $data = [$result, $price];
        return $data;
    }

    function getOrderByFactorId($id)
    {
        $sql = 'select orders.*,orders.id as Id,orders.mood as Mood ,user.* from orders JOIN user on user.id=orders.user where orders.factor=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    function geFactorFromFactor($id)
    {
        $sql = "select * from factor_hogh where id=? UNION select * from factor_hagh where id=? ";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->bindValue(2, $id);
        $stmt->execute();
        $result = $stmt->fetch();
        return $result;
    }

    function noShow($id)
    {
        $bayegani = time();
        $sql = 'update orders set hesab_show=?,bayegani=? WHERE id=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, '1');
        $stmt->bindValue(2, $bayegani);
        $stmt->bindValue(3, $id);
        $stmt->execute();
    }

    function getHesabCost($start, $end)
    {
        $start_time = Model::jaliliToMiladi($start);
        $end_time = Model::jaliliToMiladi($end);
        $start_time = strtotime($start_time);
        $end_time = strtotime($end_time);
        $sql = "select * from orders where start BETWEEN ? and ? and cost=? 
                UNION SELECT * FROM orders where start_d=? and cost=? 
                UNION SELECT * FROM orders where start_d=? and cost=?
                LIMIT 1000";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $start_time);
        $stmt->bindValue(2, $end_time);
        $stmt->bindValue(3, 1);
        $stmt->bindValue(4, $start);
        $stmt->bindValue(5, 1);
        $stmt->bindValue(6, $end);
        $stmt->bindValue(7, 1);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    function getHesabChap($start, $end)
    {
        $start_time = Model::jaliliToMiladi($start);
        $end_time = Model::jaliliToMiladi($end);
        $start_time = strtotime($start_time);
        $end_time = strtotime($end_time);

        // بهینه‌سازی query اول
        $sql = "select * from print where (time BETWEEN ? and ?) OR time_d=? OR time_d=? LIMIT 500";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $start_time);
        $stmt->bindValue(2, $end_time);
        $stmt->bindValue(3, $start);
        $stmt->bindValue(4, $end);
        $stmt->execute();
        $result = $stmt->fetchAll();

        $baner = $flax = $mesh = $venil = $baner1 = $mesh1 = $flax1 = $venil1 = [];
        foreach ($result as $key => $row) {
            $noe = $row['noe'];
            switch ($noe) {
                case 'بنر':
                    $baner[] = $row;
                    break;
                case 'فلکس':
                    $flax[] = $row;
                    break;
                case 'مش':
                    $mesh[] = $row;
                    break;
                case 'وینیل':
                    $venil[] = $row;
                    break;
            }
        }

        $sql = "select * from rol where time_d=? ";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $start);
        $stmt->execute();
        $result = $stmt->fetchAll();

        foreach ($result as $key => $row) {
            $noe = $row['noe'];
            switch ($noe) {
                case 'بنر':
                    $baner1[] = $row;
                    break;
                case 'فلکس':
                    $flax1[] = $row;
                    break;
                case 'مش':
                    $mesh1[] = $row;
                    break;
                case 'وینیل':
                    $venil1[] = $row;
                    break;
            }
        }

        $cost = $this->getHesabCost($start, $end);
        $data = [$baner, $baner1, $flax, $flax1, $venil, $venil1, $mesh, $mesh1, $cost];
        return $data;
    }

    function getSetting()
    {
        // Cache settings in session
        if (Model::sessionGet('settings_cached')) {
            return;
        }

        $sql = "select * from hesab_setting where id=?";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, '1');
        $stmt->execute();
        $setting = $stmt->fetch();
        $mony_baner = $setting['baner'];
        $mony_life = $setting['life'];
        $mony_valed = $setting['valed'];
        $mony_flax = $setting['flax'];
        $mony_venil = $setting['vinil'];
        $mony_mesh = $setting['mesh'];
        Model::sessionSet('baner', $mony_baner);
        Model::sessionSet('life', $mony_life);
        Model::sessionSet('valed', $mony_valed);
        Model::sessionSet('flax', $mony_flax);
        Model::sessionSet('vinil', $mony_venil);
        Model::sessionSet('mesh', $mony_mesh);
        Model::sessionSet('settings_cached', true);
    }

    function getSetting2()
    {
        $sql = "select * from hesab_setting where id=?";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, '1');
        $stmt->execute();
        $setting = $stmt->fetch();
        return $setting;
    }

    function editSetting($baner, $flax, $vinil, $mesh, $valed, $life)
    {
        $sql = 'update hesab_setting set baner=?,flax=?,vinil=?,mesh=?,valed=?,life=? WHERE id=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $baner);
        $stmt->bindValue(2, $flax);
        $stmt->bindValue(3, $vinil);
        $stmt->bindValue(4, $mesh);
        $stmt->bindValue(5, $valed);
        $stmt->bindValue(6, $life);
        $stmt->bindValue(7, '1');
        $stmt->execute();
        // Clear cache
        Model::sessionSet('settings_cached', false);
    }
}