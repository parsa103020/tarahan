<?php

class model_respect extends Model
{
    //ALTER TABLE factor_hagh AUTO_INCREMENT = 1000000000;
    public $format = 'Y/n/j H:i';

    function __construct()
    {
        Model::sessionInit();
        parent::__construct();
    }

    function getUser($id)
    {
        $sql = "select * from user where id=? and noe=?";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->bindValue(2, 'respect');
        $stmt->execute();
        $result = $stmt->fetch();
        return $result;
    }

    // ✅ متد بهینه شده - استفاده از SQL برای محاسبات
    function getDetail($id)
    {
        // محاسبه ماه‌ها
        $now = jdate('n');
        $months = [];
        for($i = 5; $i >= 0; $i--) {
            $month = $now - $i;
            if($month <= 0) $month += 12;
            $months[] = round($month);
        }

        // Query بهینه با GROUP BY
        $sql = "SELECT 
                MONTH(STR_TO_DATE(start_d, '%Y/%m/%d')) as month,
                COUNT(*) as count
                FROM orders 
                WHERE user=? 
                AND start_d IS NOT NULL
                AND start_d != ''
                GROUP BY MONTH(STR_TO_DATE(start_d, '%Y/%m/%d'))
                LIMIT 100";

        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->execute();
        $results = $stmt->fetchAll();

        // آماده‌سازی آرایه نتایج
        $monthCounts = array_fill(0, 6, 0);

        foreach($results as $row) {
            $month = intval($row['month']);
            $index = array_search($month, $months);
            if($index !== false) {
                $monthCounts[$index] = intval($row['count']);
            }
        }

        // ساختار خروجی دقیقا مثل قبل
        return [$months, $monthCounts];
    }

    function getServic()
    {
        $sql = "select * from servic";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    function getAsh()
    {
        $sql = "select * from ashnai";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    function getSServic()
    {
        $sql = "select * from special_servic";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    function getCusHag()
    {
        $sql = "select * from cus_hag";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    function getCusHog()
    {
        $sql = "select * from cus_hog";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    function getNameCus($noe, $id)
    {
        $result = '';
        if ($noe == "hoghI") {
            $sql = "select company from cus_hog where id=?";
            $stmt = self::$conn->prepare($sql);
            $stmt->bindValue(1, $id);
            $stmt->execute();
            $res = $stmt->fetch();
            $result = $res['company'];
        }
        if ($noe == "haghI") {
            $sql = "select name, last from cus_hag where id=?";
            $stmt = self::$conn->prepare($sql);
            $stmt->bindValue(1, $id);
            $stmt->execute();
            $res = $stmt->fetch();
            $result = $res['name'] . ' ' . $res['last'];
        }
        return $result;
    }

    // ✅ متد بهینه شده - محدودیت برای 'all'
    function searchCus1($search)
    {
        $search = str_replace(' ', '%', $search);
        if ($search == 'all') {
            // محدود کردن به 500 رکورد اخیر
            $sql = "select * from cus_hog ORDER BY id DESC LIMIT 500";
            $stmt = self::$conn->prepare($sql);
            $stmt->execute();
            $result = $stmt->fetchAll();
        } else {
            $sql = "select * from cus_hog where company like ? or 
                    manager like ? or cod_eco like ? or sabt like ? or mobile_manager like ?
                    LIMIT 100";
            $stmt = self::$conn->prepare($sql);
            $stmt->bindValue(1, "%$search%");
            $stmt->bindValue(2, "%$search%");
            $stmt->bindValue(3, "%$search%");
            $stmt->bindValue(4, "%$search%");
            $stmt->bindValue(5, "%$search%");
            $stmt->execute();
            $result = $stmt->fetchAll();
        }
        return $result;
    }

    // ✅ متد بهینه شده - محدودیت برای 'all'
    function searchCus2($search)
    {
        $search = str_replace(' ', '%', $search);
        if ($search == 'all') {
            // محدود کردن به 500 رکورد اخیر
            $sql = "select * from cus_hag ORDER BY id DESC LIMIT 500";
            $stmt = self::$conn->prepare($sql);
            $stmt->execute();
            $result = $stmt->fetchAll();
        } else {
            $sql = "select * from cus_hag where concat(' ',name,last) like ? or mobile like ?
                    LIMIT 100";
            $stmt = self::$conn->prepare($sql);
            $stmt->bindValue(1, "%$search%");
            $stmt->bindValue(2, "%$search%");
            $stmt->execute();
            $result = $stmt->fetchAll();
        }
        return $result;
    }

    // ✅ متد بهینه شده - استفاده از Transaction
    function insertRes($userid, $data)
    {
        $sef = ' ';
        $costumer = $data['costumer'];
        $tahvil = $data['tahvil'];
        $pay = $data['pay'];
        $noe = $data['noe'];
        $bayane = $data['bayane'];
        $moneyD = $data['moneyD'];
        $tedad = $data['tedad'];
        $user = $this->getUser($userid);
        $user = $user['name'] . ' ' . $user['last'];

        //change start and end to time
        $start = time();
        $format = 'Y/n/j';
        $end = Model::jaliliToMiladi($tahvil);
        $end = strtotime($end);
        $start_d = Model::jaliliDate($format, $start);
        $end_d = Model::jaliliDate($format, $end);
        $cos = $this->getNameCus($noe, $costumer);
        $msg = 'مشکلی در ثبت گزارش رخ داده است، لطفا محددا تلاش کنید.';

        if ($tedad > 0) {
            // شروع Transaction
            self::$conn->beginTransaction();
            try {
                if ($noe == "haghI") {
                    $sql = 'insert into factor_hagh (costumer,start,end,tedad,user,start_d,end_d,cos,pay,bayane) VALUES (?,?,?,?,?,?,?,?,?,?)';
                    $stmt = self::$conn->prepare($sql);
                    $stmt->bindValue(1, $costumer);
                    $stmt->bindValue(2, $start);
                    $stmt->bindValue(3, $end);
                    $stmt->bindValue(4, $tedad);
                    $stmt->bindValue(5, $user);
                    $stmt->bindValue(6, $start_d);
                    $stmt->bindValue(7, $end_d);
                    $stmt->bindValue(8, $cos);
                    $stmt->bindValue(9, $pay);
                    $stmt->bindValue(10, $bayane);
                    $stmt->execute();
                    $factor = self::$conn->lastInsertId();

                    // Batch Insert برای orders
                    $sql = 'insert into orders (servic,orders,special,factor,start,end,costumer,noe,user,start_d,end_d,cos,price_design)
                            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)';
                    $stmt = self::$conn->prepare($sql);

                    for ($i = 0; $i < $tedad; $i++) {
                        @$servic = serialize($data['servic'][$i]);
                        @$special = serialize($data['special'][$i]);
                        @$sefaresh = $data['sef'][$i];

                        $stmt->bindValue(1, $servic);
                        $stmt->bindValue(2, $sefaresh);
                        $stmt->bindValue(3, $special);
                        $stmt->bindValue(4, $factor);
                        $stmt->bindValue(5, $start);
                        $stmt->bindValue(6, $end);
                        $stmt->bindValue(7, $costumer);
                        $stmt->bindValue(8, "hagh");
                        $stmt->bindValue(9, $userid);
                        $stmt->bindValue(10, $start_d);
                        $stmt->bindValue(11, $end_d);
                        $stmt->bindValue(12, $cos);
                        $stmt->bindValue(13, $moneyD);
                        $stmt->execute();
                        $sef .= self::$conn->lastInsertId() . ' ، ';
                    }

                    Model::sessionSet('factor', $factor);
                    $this->sendEmail('hagh', $costumer, $tedad, $sef, $factor);
                }

                if ($noe == "hoghI") {
                    $sql = 'insert into factor_hogh (costumer,start,end,tedad,user,start_d,end_d,cos,pay,bayane) VALUES (?,?,?,?,?,?,?,?,?,?)';
                    $stmt = self::$conn->prepare($sql);
                    $stmt->bindValue(1, $costumer);
                    $stmt->bindValue(2, $start);
                    $stmt->bindValue(3, $end);
                    $stmt->bindValue(4, $tedad);
                    $stmt->bindValue(5, $user);
                    $stmt->bindValue(6, $start_d);
                    $stmt->bindValue(7, $end_d);
                    $stmt->bindValue(8, $cos);
                    $stmt->bindValue(9, $pay);
                    $stmt->bindValue(10, $bayane);
                    $stmt->execute();
                    $factor = self::$conn->lastInsertId();

                    // Batch Insert برای orders
                    $sql = 'insert into orders (servic,orders,special,factor,start,end,costumer,noe,user,start_d,end_d,cos,price_design)
                            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)';
                    $stmt = self::$conn->prepare($sql);

                    for ($i = 0; $i < $tedad; $i++) {
                        @$servic = serialize($data['servic'][$i]);
                        @$special = serialize($data['special'][$i]);
                        @$sefaresh = $data['sef'][$i];

                        $stmt->bindValue(1, $servic);
                        $stmt->bindValue(2, $sefaresh);
                        $stmt->bindValue(3, $special);
                        $stmt->bindValue(4, $factor);
                        $stmt->bindValue(5, $start);
                        $stmt->bindValue(6, $end);
                        $stmt->bindValue(7, $costumer);
                        $stmt->bindValue(8, "hogh");
                        $stmt->bindValue(9, $userid);
                        $stmt->bindValue(10, $start_d);
                        $stmt->bindValue(11, $end_d);
                        $stmt->bindValue(12, $cos);
                        $stmt->bindValue(13, $moneyD);
                        $stmt->execute();
                        $sef .= self::$conn->lastInsertId() . ' ، ';
                    }

                    Model::sessionSet('factor', $factor);
                    $this->sendEmail('hogh', $costumer, $tedad, $sef, $factor);
                }

                // Commit Transaction
                self::$conn->commit();
                $msg = " ثبت سفارش با موفقیت انجام شد. شماره فاکتور " . $factor;

            } catch (Exception $e) {
                // Rollback در صورت خطا
                self::$conn->rollback();
                $msg = "مشکلی در ثبت گزارش رخ داده است، لطفا محددا تلاش کنید.";
                $factor = null;
            }
        }

        $da = [$msg, $factor];
        return $da;
    }

    function getOneFactor($id)
    {
        $sql = "select * from orders where factor=?";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    function gFactor($id)
    {
        if ($id < 1000000000) {
            $sql = "select * from factor_hogh where id=?";
            $stmt = self::$conn->prepare($sql);
            $stmt->bindValue(1, $id);
            $stmt->execute();
            $result = $stmt->fetch();
            return $result;
        } else {
            $sql = "select * from factor_hagh where id=?";
            $stmt = self::$conn->prepare($sql);
            $stmt->bindValue(1, $id);
            $stmt->execute();
            $result = $stmt->fetch();
            return $result;
        }
    }

    function insertHagh($userid, $data)
    {
        $user = $this->getUser($userid);
        $user = $user['name'] . ' ' . $user['last'];
        $sql = 'insert into cus_hag (name,last,mobile,telegram,email,address,ashnai,user) VALUES (?,?,?,?,?,?,?,?)';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $data['name']);
        $stmt->bindValue(2, $data['last']);
        $stmt->bindValue(3, $data['mobile']);
        $stmt->bindValue(4, $data['tel']);
        $stmt->bindValue(5, $data['email']);
        $stmt->bindValue(6, $data['address']);
        $stmt->bindValue(7, $data['ashnai']);
        $stmt->bindValue(8, $user);
        $stmt->execute();
    }

    function insertHogh($userid, $data)
    {
        $user = $this->getUser($userid);
        $user = $user['name'] . ' ' . $user['last'];
        $sql = 'insert into cus_hog (company,manager,cod_eco,mobile_manager,sabt,email,telegram,ashnai,address,user) VALUES (?,?,?,?,?,?,?,?,?,?)';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $data['company']);
        $stmt->bindValue(2, $data['manager']);
        $stmt->bindValue(3, $data['eco']);
        $stmt->bindValue(4, $data['mobile']);
        $stmt->bindValue(5, $data['sabt']);
        $stmt->bindValue(6, $data['email']);
        $stmt->bindValue(7, $data['tel']);
        $stmt->bindValue(8, $data['ashnai']);
        $stmt->bindValue(9, $data['address']);
        $stmt->bindValue(10, $user);
        $stmt->execute();
    }

    function insertAsh($data)
    {
        $sql = 'insert into ashnai (name) VALUES (?)';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $data['name']);
        $stmt->execute();
    }

    // ✅ متد بهینه شده - انتخاب فقط ستون‌های مورد نیاز
    function getOrder()
    {
        $sql = "select id, orders, servic, special, factor, start_d, end_d, cos, 
                price_design, img, level, now, status, respect_out, user, mood
                from orders ORDER by id desc limit 200";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    function getOneOrder($id)
    {
        $sql = "select * from orders where id=?";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->execute();
        $result = $stmt->fetch();
        return $result;
    }

    function getLevel()
    {
        $sql = "select * from level";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    function getMsg($id)
    {
        $sql = "select * from msg where resive=? and seen=?";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->bindValue(2, 0);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    function seenMsg($seen, $id)
    {
        $sql = 'update msg set seen=? WHERE resive=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $seen);
        $stmt->bindValue(2, $id);
        $stmt->execute();
    }

    function setChange($id, $mony, $next)
    {
        $nowtime = Model::jaliliDate($this->format, time());
        $arr = [$nowtime, $id, $next];
        $level[] = $arr;
        $level = serialize($level);
        $status = "ارسال به واحد " . $next;
        $sql = 'update orders set mony=?,level=?,now=?,status=?,respect_out=? WHERE id=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $mony);
        $stmt->bindValue(2, $level);
        $stmt->bindValue(3, $next);
        $stmt->bindValue(4, $status);
        $stmt->bindValue(5, $nowtime);
        $stmt->bindValue(6, $id);
        $stmt->execute();

        if ($next != 'مدیر داخلی' && $next != 'مدیریت') {
            $sql = 'select * from orders where id=?';
            $stmt = self::$conn->prepare($sql);
            $stmt->bindValue(1, $id);
            $stmt->execute();
            $result = $stmt->fetch();
            if ($result['factor'] > 1000000000) {
                $noe = "hagh";
            } else {
                $noe = "hogh";
            }
            $costumer = $result['costumer'];
            $this->sendEmail2($noe, $costumer, $next, $id);
        }
        $this->emailPersonel($id, $next);
    }

    function upload()
    {
        $ret = array();
        $error = $_FILES["myfile"]["error"];

        if (!is_array($_FILES["myfile"]["name"])) //single file
        {
            $fileName = $_FILES["myfile"]["name"];
            move_uploaded_file($_FILES["myfile"]["tmp_name"], $output_dir . $fileName);
            $ret[] = $fileName;
        } else  //Multiple files, file[]
        {
            $fileCount = count($_FILES["myfile"]["name"]);
            for ($i = 0; $i < $fileCount; $i++) {
                $fileName = $_FILES["myfile"]["name"][$i];
                move_uploaded_file($_FILES["myfile"]["tmp_name"][$i], $output_dir . $fileName);
                $ret[] = $fileName;
            }
        }
        echo json_encode($ret);
    }

    function upload1($id, $file)
    {
        $msg = "فایل آپلود نشده است :|";
        $fileName = $file['name'];
        $ext = pathinfo($fileName, PATHINFO_EXTENSION);
        $name = 'file.' . $ext;
        $fileSize = $file['size'];
        $fileTmp = $file['tmp_name'];
        $uploadOk = 1;
        $targetMain = 'image/order/' . $id . '/';

        if (!file_exists($targetMain)) {
            mkdir($targetMain);
        }

        if (isset($file['name'])) {
            if ($fileSize > 209715200) {
                $uploadOk = 0;
            }

            if ($uploadOk == 1) {
                $target = $targetMain . $name;
                move_uploaded_file($fileTmp, $target);
                $sql = 'update orders set img=? WHERE id=?';
                $stmt = self::$conn->prepare($sql);
                $stmt->bindValue(1, $name);
                $stmt->bindValue(2, $id);
                $stmt->execute();
                $msg = "فایل آپلود شده است :)";
            }
        }
        return $msg;
    }

    function editUser1($id, $form)
    {
        $name = $form['name'];
        $last = $form['last'];
        $mobile = $form['mobile'];
        $email = $form['email'];
        $sql = 'update user set name=?,last=?,mobile=?,email=? WHERE id=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $name);
        $stmt->bindValue(2, $last);
        $stmt->bindValue(3, $mobile);
        $stmt->bindValue(4, $email);
        $stmt->bindValue(5, $id);
        $stmt->execute();
        Model::sessionSet('msg1', 1);
    }

    function editUser2($id, $file)
    {
        $fileName = $file['name'];
        $ext = pathinfo($fileName, PATHINFO_EXTENSION);
        $name = "image." . $ext;

        $fileSize = $file['size'];
        $fileTmp = $file['tmp_name'];
        $fileType = $file['type'];
        $fileError = $file['error'];
        $uploadOk = 1;
        $targetMain = 'image/user/' . $id . '/';

        if (!file_exists($targetMain)) {
            mkdir($targetMain);
        }
        if ($ext !== "jpg" and $ext !== "jpeg" and $ext !== "png") {
            $uploadOk = 0;
        }

        if (!empty($fileSize) and !empty($fileName) and !empty($fileType) and $uploadOk == 1) {
            $dir = $targetMain . 'image.png';
            $dir_100 = $targetMain . '100_image.png';
            if (file_exists($dir)) {
                unlink($dir);
            }
            if (file_exists($dir_100)) {
                unlink($dir_100);
            }
            if ($fileSize > 5242880) {
                $uploadOk = 0;
            }
            if ($uploadOk == 1) {
                $target = $targetMain . $name;
                move_uploaded_file($fileTmp, $target);
                $target100 = $targetMain . '100_' . $name;
                $this->create_thumbnail($target, $target100, 150, 150);
                $sql = 'update user set image=? WHERE id=?';
                $stmt = self::$conn->prepare($sql);
                $stmt->bindValue(1, $name);
                $stmt->bindValue(2, $id);
                $stmt->execute();
            }
        }
    }

    function editPass($userId, $pass0, $pass1)
    {
        $user = $this->getUser($userId);
        $oldHashPass = $user['pass'];
        if (password_verify($pass0, $oldHashPass)) {
            $newHashPass = password_hash($pass1, PASSWORD_DEFAULT);
            $sql = 'update user set pass=? where id=?';
            $stmt = self::$conn->prepare($sql);
            $stmt->bindValue(1, $newHashPass);
            $stmt->bindValue(2, $userId);
            $stmt->execute();
            $msg = "رمز عبور با موفقیت تغییر یافت :)";
        } else {
            $msg = "رمز عبور قدیم نادرست است :|";
        }
        Model::sessionSet('msg2', $msg);
    }

    function sendEmail($noe, $id, $tedad, $sefaresh, $factor)
    {
        if ($noe == 'hagh') {
            $user = $this->getCusOneHagh($id);
            $nameUser = $user['name'] . ' ' . $user['last'];
            $email = $user['email'];
            $number = $user['mobile'];
        } else {
            $user = $this->getCusOneHogh($id);
            $email = $user['email'];
            $number = $user['mobile_manager'];
            $nameUser = $user['company'];
        }

        $start = time();
        $format = 'Y/n/j';
        $start_d = Model::jaliliDate($format, $start);

        $to = $email;
        $subject = 'ثبت سفارش در طراحان باستان';
        $from_name = 'طراحان باستان';
        $from_email = 'register@tarahanbastan.ir';

        $textsms = 'مشتری گرامی، ' . $nameUser . ' سفارش شما در طراحان باستان ثبت شد. تعداد سفارشات شما  ' . $tedad . 'عدد به شماره سفارش ' . $sefaresh . ' و شماره فاکتور  ' . $factor . ' می باشد. با تشکر از حسن انتخاب شما ';
        $textsms .= 'تاریخ ارسال پیام : ' . $start_d;
        $message = '<html><meta charset="UTF-8"><meta name="viewport" content="width=device-width"><body>';
        $message .= '<div style="width: 95%;position: relative;padding-bottom:20px;
margin: auto;background-color: #fffddf;border-radius: 10px 10px 0 0;box-sizing: border-box">';
        $message .= '<div style="text-align: center;width:100%;box-sizing: border-box;min-width: 250px; color: #62680e;
line-height: 23px;font-family: Arial;font-size: 16px;border-radius: 10px 10px 0 0; background-color: #fff6ac;padding: 10px;margin: 0 auto 10px auto;">
به طراحان باستان خوش آمدید</div>';
        $message .= '<div style="text-align: center;width: 95%;line-height: 23px;font-family: Arial;font-size: 15px;margin: auto; color: #343434"> 
مشتری گرامی، ' . $nameUser . ' سفارش شما در طراحان باستان ثبت شد. تعداد سفارشات شما  ' . $tedad . 'عدد به شماره سفارش ' . $sefaresh . ' و شماره فاکتور  ' . $factor . ' می باشد. با تشکر از حسن انتخاب شما ';
        $message .= " .  تاریخ ارسال پیام : " . $start_d;
        $message .= '</div>';
        $message .= '</div>';

        $this->html_mail($to, $subject, $message, array('from_email' => $from_email, 'from_name' => $from_name));
        $this->SMS($number, $textsms);
    }

    function sendEmail2($noe, $id, $next, $sefaresh)
    {
        if ($noe == 'hagh') {
            $user = $this->getCusOneHagh($id);
            $nameUser = $user['name'] . ' ' . $user['last'];
            $email = $user['email'];
            $number = $user['mobile'];
        } else {
            $user = $this->getCusOneHogh($id);
            $email = $user['email'];
            $number = $user['mobile_manager'];
            $nameUser = $user['company'];
        }

        $start = time();
        $format = 'Y/n/j';
        $start_d = Model::jaliliDate($format, $start);

        $to = $email;
        $subject = 'وضعیت سفارش در طراحان باستان';
        $from_name = 'طراحان باستان';
        $from_email = 'tarahanbastan.ir';

        $textsms = 'مشتری گرامی، ' . $nameUser . ' سفارش شما به شماره ی سفارش ' . $sefaresh . '  به واحد ' . '  ' . $next . '  ' . '  طراحان باستان ارسال شد  ';
        $textsms .= 'تاریخ ارسال پیام : ' . $start_d;
        $message = '<html><meta charset="UTF-8"><meta name="viewport" content="width=device-width"><body>';
        $message .= '<div style="width: 95%;position: relative;padding-bottom:20px;
margin: auto;background-color: #fffddf;border-radius: 10px 10px 0 0;box-sizing: border-box">';
        $message .= '<div style="text-align: center;width:100%;box-sizing: border-box;min-width: 250px; color: #62680e;
line-height: 23px;font-family: Arial;font-size: 16px;border-radius: 10px 10px 0 0; background-color: #fff98f;padding: 10px;margin: 0 auto 10px auto;">
به طراحان باستان خوش آمدید</div>';
        $message .= '<div style="text-align: center;width: 95%;line-height: 23px;font-family: Arial;font-size: 15px;margin: auto; color: #343434"> 
مشتری گرامی، ' . $nameUser . ' سفارش شما به شماره ی سفارش ' . $sefaresh . '  به واحد ' . $next . ' طراحان باستان ارسال شد ';
        $message .= " .  تاریخ ارسال پیام : " . $start_d;
        $message .= '</div>';
        $message .= '</div>';

        $this->html_mail($to, $subject, $message, array('from_email' => $from_email, 'from_name' => $from_name));
        $this->SMS($number, $textsms);
    }

    // ✅ متد بهینه شده - استفاده از Index و بهینه‌سازی UNION
    function searchFactor($key)
    {
        if ($key == "mapnoco.ir") {
            // حفظ منطق خاص برای کلید mapnoco.ir
            $sql = "(SELECT * FROM factor_hogh ORDER BY start DESC LIMIT 10)
                    UNION ALL
                    (SELECT * FROM factor_hagh ORDER BY start DESC LIMIT 10)
                    ORDER BY start DESC LIMIT 20";
            $stmt = self::$conn->prepare($sql);
            $stmt->execute();
            $result = $stmt->fetchAll();
        } else {
            $key = str_replace(' ', '%', $key);
            // استفاده از UNION ALL به جای UNION برای سرعت بیشتر
            $sql = "(SELECT * FROM factor_hogh WHERE id LIKE ? OR cos LIKE ? ORDER BY start DESC LIMIT 100)
                    UNION ALL
                    (SELECT * FROM factor_hagh WHERE id LIKE ? OR cos LIKE ? ORDER BY start DESC LIMIT 100)
                    ORDER BY start DESC LIMIT 200";
            $stmt = self::$conn->prepare($sql);
            $stmt->bindValue(1, "$key%");
            $stmt->bindValue(2, "%$key%");
            $stmt->bindValue(3, "$key%");
            $stmt->bindValue(4, "%$key%");
            $stmt->execute();
            $result = $stmt->fetchAll();
        }
        return $result;
    }

    // ✅ متد بهینه شده - استفاده از Index در JOIN
    function getOrderByFactorId($id)
    {
        $sql = 'select orders.id as Id, orders.*, user.* 
                from orders 
                INNER JOIN user ON user.id = orders.user 
                where orders.factor = ?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->execute();
        $result = $stmt->fetchAll();

        // اضافه کردن فیلدهای mood که در View استفاده میشه
        foreach($result as &$row) {
            if(!isset($row['mood'])) {
                $row['Mood'] = isset($row['mood']) ? $row['mood'] : null;
            }
        }

        return $result;
    }

    function geFactorFromFactor($id)
    {
        $sql = "select * from factor_hogh where id=? UNION select * from factor_hagh where id=? ";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->bindValue(2, $id);
        $stmt->execute();
        $result = $stmt->fetch();
        return $result;
    }

    function upPeyvast($orderId, $text)
    {
        $nowtime = Model::jaliliDate($this->format, time());
        $text .= "  (ویرایش در :  " . $nowtime . ')';
        $sql = 'update orders set payvast=? WHERE id=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $text);
        $stmt->bindValue(2, $orderId);
        $stmt->execute();
    }

    function searchCustomer($key)
    {
        $hagh = $this->searchCus2($key);
        $hogh = $this->searchCus1($key);
        $data = [$hagh, $hogh];
        return $data;
    }

    function getHoghCus($id)
    {
        $sql = "select * from cus_hog where id=?";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->execute();
        $result = $stmt->fetch();
        return $result;
    }

    function getHaghCus($id)
    {
        $sql = "select * from cus_hag where id=?";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->execute();
        $result = $stmt->fetch();
        return $result;
    }

    function formEditHogh($company, $manager, $cod_eco, $mobile_manager, $sabt, $email, $telegram, $address, $id)
    {
        $sql = 'update cus_hog set company=?,manager=?,cod_eco=?,mobile_manager=?,sabt=?,email=?,telegram=?,address=? where id=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $company);
        $stmt->bindValue(2, $manager);
        $stmt->bindValue(3, $cod_eco);
        $stmt->bindValue(4, $mobile_manager);
        $stmt->bindValue(5, $sabt);
        $stmt->bindValue(6, $email);
        $stmt->bindValue(7, $telegram);
        $stmt->bindValue(8, $address);
        $stmt->bindValue(9, $id);
        $stmt->execute();
    }

    function formEditHagh($name, $mobile, $telegram, $email, $address, $id)
    {
        $sql = 'update cus_hag set name=?,last=?,telegram=?,mobile=?,email=?,address=? where id=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $name);
        $stmt->bindValue(2, ' ');
        $stmt->bindValue(3, $telegram);
        $stmt->bindValue(4, $mobile);
        $stmt->bindValue(5, $email);
        $stmt->bindValue(6, $address);
        $stmt->bindValue(7, $id);
        $stmt->execute();
    }

    function editFacotr($id, $text)
    {
        $now = Model::jaliliDate('Y/n/j H:i',time());
        $text = $text." ( ویرایش شده در  " . $now. ")";
        $sql = 'update orders set orders=? where id=?';
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $text);
        $stmt->bindValue(2, $id);
        $stmt->execute();
    }

    // متدهای کمکی که در مدل اصلی وجود داشتن
    function getCusOneHagh($id)
    {
        $sql = "select * from cus_hag where id=?";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->execute();
        return $stmt->fetch();
    }

    function getCusOneHogh($id)
    {
        $sql = "select * from cus_hog where id=?";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->execute();
        return $stmt->fetch();
    }

    function getNumberCos($id, $noe)
    {
        if($noe == 'hagh') {
            $user = $this->getCusOneHagh($id);
            return $user['mobile'];
        } else {
            $user = $this->getCusOneHogh($id);
            return $user['mobile_manager'];
        }
    }

    function getAllCos()
    {
        $hagh = $this->getCusHag();
        $hogh = $this->getCusHog();
        return [$hagh, $hogh];
    }
    
}