<?php

class model_coincalendar extends Model
{
    function __construct()
    {
        Model::sessionInit();
        parent::__construct();
    }

    function getCoin()
    {
        $sql = "select * from coin";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    public static function getOneCoin($id)
    {
        $sql = "select * from coin where id=?";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    function getNoe()
    {
        $sql = "select * from cal_noe";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    function getCat()
    {
        $sql = "select * from cal_category";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    function countSql($sql, $start, $end)
    {
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $start);
        $stmt->bindValue(2, $end);
        $stmt->execute();
        $result = $stmt->fetchAll();
        $result = count($result);
        return $result;
    }

    function countSql2($sql, $key, $start, $end)
    {
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $key);
        $stmt->bindValue(2, $key);
        $stmt->bindValue(3, $key);
        $stmt->bindValue(4, $key);
        $stmt->bindValue(5, $start);
        $stmt->bindValue(6, $end);
        $stmt->execute();
        $result = $stmt->fetchAll();
        $result = count($result);
        return $result;
    }

    function search($coin = [], $cat = [], $noe = [], $key, $start, $end, $lang, $page, $event)
    {
        //page
        $lengt = PER;
        $st = ($page - 1) * $lengt;
        $nowTime12 = time();

        //  change to miladi and set difult time
        if (empty($start)) {
            if ($event == 1) {
                $start = time();
            } else {
                $start = 11111111111;
            }
        } else {
            if ($lang == 'fa') {
                $start = Model::jaliliToMiladi($start);
            }
            $start = strtotime($start);
            if ($event == 1) {
                if ($start < $nowTime12) {
                    $start = $nowTime12;
                }
            }
        }
        if (empty($end)) {
            if ($event == 2) {
                $end = time();
            } else {
                $end = 9999999999999;
            }
        } else {
            if ($lang == 'fa') {
                $end = Model::jaliliToMiladi($end);
            }
            $end = strtotime($end);
            if ($event == 2) {
                if ($end > $nowTime12) {
                    $end = $nowTime12;
                }
            }
        }

        // set key
        if (empty($key)) {
        } else {
            $key = '%' . $key . '%';
            $key = str_replace(' ', '%', $key);
        }

        if (!is_array($coin) && !is_array($cat) && !is_array($noe) && $key == '') {
            $sql = "select cal.*,cal.id as idcal,coin.* from cal JOIN coin on cal.coinid=coin.id 
                    where cal.fu_time BETWEEN ? and ?
                    order by cal.id DESC LIMIT $st,$lengt";
            $stmt = self::$conn->prepare($sql);
            $stmt->bindValue(1, $start);
            $stmt->bindValue(2, $end);
            $stmt->execute();
            $result = $stmt->fetchAll();
            $sql2 = "select cal.*,coin.* from cal JOIN coin on cal.coinid=coin.id 
                     where cal.fu_time BETWEEN ? and ? ";
            $count = $this->countSql($sql2, $start, $end);
            $result = [$result, $count, $page];
        } //empty
        else if (is_array($coin) && !is_array($cat) && !is_array($noe) && $key == null) {
            $x = join(',', array_values($coin));
            $sql = "select cal.*,cal.id as idcal,coin.* from cal JOIN coin on cal.coinid=coin.id 
            where cal.coinid in ( $x ) and
            cal.fu_time BETWEEN ? and ?
            order by cal.id DESC LIMIT $st,$lengt ";
            $stmt = self::$conn->prepare($sql);
            $stmt->bindValue(1, $start);
            $stmt->bindValue(2, $end);
            $stmt->execute();
            $result = $stmt->fetchAll();
            $sql2 = "select cal.*,coin.* from cal JOIN coin on cal.coinid=coin.id 
            where cal.coinid in ( $x ) and
            cal.fu_time BETWEEN ? and ?";
            $count = $this->countSql($sql2, $start, $end);
            $result = [$result, $count, $page];
        }// Coin
        else if (!is_array($coin) && is_array($cat) && !is_array($noe) && $key == null) {
            $x = join(',', array_values($cat));
            $sql = "select cal.*,cal.id as idcal,coin.* from cal JOIN coin on cal.coinid=coin.id 
                    where cal.cat1 in ( $x ) or cal.cat2 in ( $x) or cal.cat3 in ( $x ) or cal.cat4 in ( $x ) or cal.cat5 in ( $x ) 
                    and cal.fu_time BETWEEN ? and ?
                    order by cal.id DESC LIMIT $st,$lengt ";
            $stmt = self::$conn->prepare($sql);
            $stmt->bindValue(1, $start);
            $stmt->bindValue(2, $end);
            $stmt->execute();
            $result = $stmt->fetchAll();
            $sql2 = "select cal.*,cal.id as idcal,coin.* from cal JOIN coin on cal.coinid=coin.id 
                                where cal.cat1 in ( $x ) or cal.cat2 in ( $x) or cal.cat3 in ( $x ) or cal.cat4 in ( $x ) or cal.cat5 in ( $x ) 
                                and cal.fu_time BETWEEN ? and ?";
            $count = $this->countSql($sql2, $start, $end);
            $result = [$result, $count, $page];
        }// Cat
        else if (!is_array($coin) && !is_array($cat) && is_array($noe) && $key == null) {
            $x = join(',', array_values($noe));
            $sql = "select cal.*,cal.id as idcal,coin.* from cal JOIN coin on cal.coinid=coin.id 
                    where cal.cal_noe in ( $x ) AND 
                    BETWEEN ? and ? 
                    order by cal.id DESC LIMIT $st,$lengt ";
            $stmt = self::$conn->prepare($sql);
            $stmt->bindValue(1, $start);
            $stmt->bindValue(2, $end);
            $stmt->execute();
            $result = $stmt->fetchAll();
            $sql2 = "select cal.*,cal.id as idcal,coin.* from cal JOIN coin on cal.coinid=coin.id 
                                where cal.cal_noe in ( $x ) AND 
                                BETWEEN ? and ?";
            $count = $this->countSql($sql2, $start, $end);
            $result = [$result, $count, $page];
        }// Noe
        else if (!is_array($coin) && !is_array($cat) && !is_array($noe) && $key != null) {
            $sql = "select cal.*,cal.id as idcal,coin.* from cal JOIN coin on cal.coinid=coin.id where
                    en_titr like ? OR en_text like ? OR fa_text like ? OR fa_titr like ?
                    and cal.fu_time BETWEEN ? and ?
                    order by cal.id DESC LIMIT $st,$lengt ";
            $stmt = self::$conn->prepare($sql);
            $stmt->bindValue(1, $key);
            $stmt->bindValue(2, $key);
            $stmt->bindValue(3, $key);
            $stmt->bindValue(4, $key);
            $stmt->bindValue(5, $start);
            $stmt->bindValue(6, $end);
            $stmt->execute();
            $result = $stmt->fetchAll();
            $sql2 = "select cal.*,cal.id as idcal,coin.* from cal JOIN coin on cal.coinid=coin.id where
                     en_titr like ? OR en_text like ? OR fa_text like ? OR fa_titr like ?
                    and cal.fu_time BETWEEN ? and ?";
            $count = $this->countSql2($sql2, $key, $start, $end);
            $result = [$result, $count, $page];
        } // keyword
        else if (is_array($coin) && is_array($cat) && !is_array($noe) && $key == null) {
            $x = join(',', array_values($cat));
            $y = join(',', array_values($coin));
            $sql = "select cal.*,cal.id as idcal,coin.* from cal JOIN coin on cal.coinid=coin.id 
                    where (cal.cat1 in ( $x ) or cal.cat2 in ( $x )
                    or cal.cat3 in ( $x ) or cal.cat4 in ( $x ) or cal.cat5 in ( $x)) 
                    and cal.coinid in ($y ) and
                    cal.fu_time BETWEEN ? and ?
                    order by cal.id DESC LIMIT $st,$lengt ";
            $stmt = self::$conn->prepare($sql);
            $stmt->bindValue(1, $start);
            $stmt->bindValue(2, $end);
            $stmt->execute();
            $result = $stmt->fetchAll();
            $sql2 = "select cal.*,cal.id as idcal,coin.* from cal JOIN coin on cal.coinid=coin.id 
                                where (cal.cat1 in ( $x ) or cal.cat2 in ( $x )
                                or cal.cat3 in ( $x ) or cal.cat4 in ( $x ) or cal.cat5 in ( $x)) 
                                and cal.coinid in ($y ) and
                                cal.fu_time BETWEEN ? and ?";
            $count = $this->countSql($sql2, $start, $end);
            $result = [$result, $count, $page];
        }// Coin & Cat
        else if (is_array($coin) && !is_array($cat) && is_array($noe) && $key == null) {
            $x = join(',', array_values($noe));
            $y = join(',', array_values($coin));
            $sql = "select cal.*,coin.* from cal JOIN coin on cal.coinid=coin.id 
                            where cal.coinid in ($y ) and
                            cal.cal_noe in ( $x ) and
                            cal.fu_time BETWEEN ? and ?
                            order by cal.id DESC LIMIT $st,$lengt ";
            $stmt = self::$conn->prepare($sql);
            $stmt->bindValue(1, $start);
            $stmt->bindValue(2, $end);
            $stmt->execute();
            $result = $stmt->fetchAll();
            $sql2 = "select cal.*,coin.* from cal JOIN coin on cal.coinid=coin.id 
                                        where cal.coinid in ($y ) and
                                        cal.cal_noe in ( $x ) and
                                        cal.fu_time BETWEEN ? and ?";
            $count = $this->countSql($sql2, $start, $end);
            $result = [$result, $count, $page];
        }// Coin & Noe
        else if (is_array($coin) && !is_array($cat) && !is_array($noe) && $key != null) {
            $y = join(',', array_values($coin));
            $sql = "select cal.*,cal.id as idcal,coin.* from cal JOIN coin on cal.coinid=coin.id 
                            where cal.coinid in ( $y ) and
                            (en_titr like ? OR en_text like ? OR fa_text like ? OR fa_titr like ?) and                            
                            cal.fu_time BETWEEN ? and ?
                            order by cal.id DESC LIMIT $st,$lengt ";
            $stmt = self::$conn->prepare($sql);
            $stmt->bindValue(1, $key);
            $stmt->bindValue(2, $key);
            $stmt->bindValue(3, $key);
            $stmt->bindValue(4, $key);
            $stmt->bindValue(5, $start);
            $stmt->bindValue(6, $end);
            $stmt->execute();
            $result = $stmt->fetchAll();
            $sql2 = "select cal.*,cal.id as idcal,coin.* from cal JOIN coin on cal.coinid=coin.id 
                                        where cal.coinid in ( $y ) and
                                        (en_titr like ? OR en_text like ? OR fa_text like ? OR fa_titr like ?) and                            
                                        cal.fu_time BETWEEN ? and ?";
            $count = $this->countSql2($sql2, $key, $start, $end);
            $result = [$result, $count, $page];
        }// Coin & Keyword
        else if (!is_array($coin) && is_array($cat) && !is_array($noe) && $key != null) {
            $x = join(',', array_values($cat));
            $sql = "select cal.*,cal.id as idcal,coin.* from cal JOIN coin on cal.coinid=coin.id 
                            where (cal.cat1 in ( $x ) or cal.cat2 in ( $x )
                            or cal.cat3 in ( $x ) or cal.cat4 in ( $x ) or cal.cat5 in ( $x ))
                            and (en_titr like ? OR en_text like ? OR fa_text like ? OR fa_titr like ?) and                            
                            cal.fu_time BETWEEN ? and ?
                            order by cal.id DESC LIMIT $st,$lengt ";
            $stmt = self::$conn->prepare($sql);
            $stmt->bindValue(1, $key);
            $stmt->bindValue(2, $key);
            $stmt->bindValue(3, $key);
            $stmt->bindValue(4, $key);
            $stmt->bindValue(5, $start);
            $stmt->bindValue(6, $end);
            $stmt->execute();
            $result = $stmt->fetchAll();
            $sql2 = "select cal.*,cal.id as idcal,coin.* from cal JOIN coin on cal.coinid=coin.id 
                                        where (cal.cat1 in ( $x ) or cal.cat2 in ( $x )
                                        or cal.cat3 in ( $x ) or cal.cat4 in ( $x ) or cal.cat5 in ( $x ))
                                        and (en_titr like ? OR en_text like ? OR fa_text like ? OR fa_titr like ?) and                            
                                        cal.fu_time BETWEEN ? and ?";
            $count = $this->countSql2($sql2, $key, $start, $end);
            $result = [$result, $count, $page];
        }// Cat & Keyword
        // Cat & Noe
        else if (!is_array($coin) && is_array($cat) && is_array($noe) && $key == null) {
            $x = join(',', array_values($cat));
            $sql = "select cal.*,cal.id as idcal,coin.* from cal JOIN coin on cal.coinid=coin.id 
                    where (cal.cat1 in ( $x ) or cal.cat2 in ( $x )
                    or cal.cat3 in ( $x ) or cal.cat4 in ( $x ) or cal.cat5 in ( $x ))
                    and cal.cal_noe in ( $x ) and
                    cal.fu_time BETWEEN ? and ?
                    order by cal.id DESC LIMIT $st,$lengt ";
            $stmt = self::$conn->prepare($sql);
            $stmt->bindValue(1, $start);
            $stmt->bindValue(2, $end);
            $stmt->execute();
            $result = $stmt->fetchAll();
            $sql2 = "select cal.*,cal.id as idcal,coin.* from cal JOIN coin on cal.coinid=coin.id 
                                where (cal.cat1 in ( $x ) or cal.cat2 in ( $x )
                                or cal.cat3 in ( $x ) or cal.cat4 in ( $x ) or cal.cat5 in ( $x ))
                                and cal.cal_noe in ( $x ) and
                                cal.fu_time BETWEEN ? and ?";
            $count = $this->countSql($sql2, $start, $end);
            $result = [$result, $count, $page];
        } // Noe & Keyword
        else if (!is_array($coin) && !is_array($cat) && is_array($noe) && $key != null) {
            $x = join(',', array_values($noe));
            $sql = "select cal.*,cal.id as idcal,coin.* from cal JOIN coin on cal.coinid=coin.id 
                    where (en_titr like ? OR en_text like ? OR fa_text like ? OR fa_titr like ?)
                    and cal.cal_noe in ( $x ) and
                    cal.fu_time BETWEEN ? and ?
                    order by cal.id DESC LIMIT $st,$lengt ";
            $stmt = self::$conn->prepare($sql);
            $stmt->bindValue(1, $key);
            $stmt->bindValue(2, $key);
            $stmt->bindValue(3, $key);
            $stmt->bindValue(4, $key);
            $stmt->bindValue(5, $start);
            $stmt->bindValue(6, $end);
            $stmt->execute();
            $result = $stmt->fetchAll();
            $sql2 = "select cal.*,cal.id as idcal,coin.* from cal JOIN coin on cal.coinid=coin.id 
                                where (en_titr like ? OR en_text like ? OR fa_text like ? OR fa_titr like ?)
                                and cal.cal_noe in ( $x ) and
                                cal.fu_time BETWEEN ? and ?";
            $count = $this->countSql2($sql2, $key, $start, $end);
            $result = [$result, $count, $page];
        } // Noe & Keyword & coin
        else if (is_array($coin) && !is_array($cat) && is_array($noe) && $key != null) {
            $x = join(',', array_values($noe));
            $y = join(',', array_values($coin));
            $sql = "select cal.*,cal.id as idcal,coin.* from cal JOIN coin on cal.coinid=coin.id 
                    where (en_titr like ? OR en_text like ? OR fa_text like ? OR fa_titr like ?)
                    and cal.coinid in ( $y )    
                    and cal.cal_noe in ( $x ) and
                    cal.fu_time BETWEEN ? and ?
                    order by cal.id DESC LIMIT $st,$lengt ";
            $stmt = self::$conn->prepare($sql);
            $stmt->bindValue(1, $key);
            $stmt->bindValue(2, $key);
            $stmt->bindValue(3, $key);
            $stmt->bindValue(4, $key);
            $stmt->bindValue(5, $start);
            $stmt->bindValue(6, $end);
            $stmt->execute();
            $result = $stmt->fetchAll();
            $sql2 = "select cal.*,cal.id as idcal,coin.* from cal JOIN coin on cal.coinid=coin.id 
                                where (en_titr like ? OR en_text like ? OR fa_text like ? OR fa_titr like ?)
                                and cal.coinid in ( $y )    
                                and cal.cal_noe in ( $x ) and
                                cal.fu_time BETWEEN ? and ?";
            $count = $this->countSql2($sql2, $key, $start, $end);
            $result = [$result, $count, $page];
        } // Noe & Keyword & cat
        else if (!is_array($coin) && is_array($cat) && is_array($noe) && $key != null) {
            $x = join(',', array_values($cat));
            $y = join(',', array_values($noe));
            $sql = "select cal.*,cal.id as idcal,coin.* from cal JOIN coin on cal.coinid=coin.id 
                    where (cal.cat1 in ( $x ) or cal.cat2 in ( $x )
                    or cal.cat3 in ( $x ) or cal.cat4 in ( $x ) or cal.cat5 in ( $x ))
                    and (en_titr like $key OR en_text like $key OR fa_text like $key OR fa_titr like $key)
                    and cal.cal_noe in ( $y ) and
                    cal.fu_time BETWEEN ? and ?
                    order by cal.id DESC LIMIT $st,$lengt ";
            $stmt = self::$conn->prepare($sql);
            $stmt->bindValue(1, $key);
            $stmt->bindValue(2, $key);
            $stmt->bindValue(3, $key);
            $stmt->bindValue(4, $key);
            $stmt->bindValue(5, $start);
            $stmt->bindValue(6, $end);
            $stmt->execute();
            $result = $stmt->fetchAll();
            $sql2 = "select cal.*,cal.id as idcal,coin.* from cal JOIN coin on cal.coinid=coin.id 
                                where (cal.cat1 in ( $x ) or cal.cat2 in ( $x )
                                or cal.cat3 in ( $x ) or cal.cat4 in ( $x ) or cal.cat5 in ( $x ))
                                and (en_titr like ? OR en_text like ? OR fa_text like ? OR fa_titr like ?)
                                and cal.cal_noe in ( $y ) and
                                cal.fu_time BETWEEN ? and ?";
            $count = $this->countSql2($sql2, $key, $start, $end);
            $result = [$result, $count, $page];
        } // coin & Keyword & cat
        else if (is_array($coin) && is_array($cat) && !is_array($noe) && $key != null) {
            $x = join(',', array_values($cat));
            $y = join(',', array_values($coin));
            $sql = "select cal.*,cal.id as idcal,coin.* from cal JOIN coin on cal.coinid=coin.id 
                           where (cal.cat1 in ( $x ) or cal.cat2 in ( $x )
                           or cal.cat3 in ( $x ) or cal.cat4 in ( $x ) or cal.cat5 in ( $x ))
                           and (en_titr like ? OR en_text like ? OR fa_text like ? OR fa_titr like ?)
                           and cal.coinid in ( $y )    
                           and cal.fu_time BETWEEN ? and ?
                           order by cal.id DESC LIMIT $st,$lengt ";
            $stmt = self::$conn->prepare($sql);
            $stmt->bindValue(1, $key);
            $stmt->bindValue(2, $key);
            $stmt->bindValue(3, $key);
            $stmt->bindValue(4, $key);
            $stmt->bindValue(5, $start);
            $stmt->bindValue(6, $end);
            $stmt->execute();
            $result = $stmt->fetchAll();
            $sql2 = "select cal.*,cal.id as idcal,coin.* from cal JOIN coin on cal.coinid=coin.id 
                                       where (cal.cat1 in ( $x ) or cal.cat2 in ( $x )
                                       or cal.cat3 in ( $x ) or cal.cat4 in ( $x ) or cal.cat5 in ( $x ))
                                       and (en_titr like ? OR en_text like ? OR fa_text like ? OR fa_titr like ?)
                                       and cal.coinid in ( $y )    
                                       and cal.fu_time BETWEEN ? and ?";
            $count = $this->countSql2($sql2, $key, $start, $end);
            $result = [$result, $count, $page];

        }// coin & noe & cat
        else if (is_array($coin) && is_array($cat) && is_array($noe) && $key == null) {
            $x = join(',', array_values($cat));
            $y = join(',', array_values($coin));
            $z = join(',', array_values($noe));
            $sql = "select cal.*,cal.id as idcal,coin.* from cal JOIN coin on cal.coinid=coin.id 
                    where (cal.cat1 in ( $x ) or cal.cat2 in ( $x )
                    or cal.cat3 in ( $x ) or cal.cat4 in ( $x ) or cal.cat5 in ( $x ))
                    and cal.cal_noe in ( $z )
                    and cal.coinid in ( $y )    
                    and cal.fu_time BETWEEN ? and ?
                    order by cal.id DESC LIMIT $st,$lengt ";
            $stmt = self::$conn->prepare($sql);
            $stmt->bindValue(1, $start);
            $stmt->bindValue(2, $end);
            $stmt->execute();
            $result = $stmt->fetchAll();
            $sql2 = "select cal.*,cal.id as idcal,coin.* from cal JOIN coin on cal.coinid=coin.id 
                                where (cal.cat1 in ( $x ) or cal.cat2 in ( $x )
                                or cal.cat3 in ( $x ) or cal.cat4 in ( $x ) or cal.cat5 in ( $x ))
                                and cal.cal_noe in ( $z )
                                and cal.coinid in ( $y )    
                                and cal.fu_time BETWEEN ? and ?";
            $count = $this->countSql($sql2, $start, $end);
            $result = [$result, $count, $page];

        }// coin & noe & cat & keyword
        else if (is_array($coin) && is_array($cat) && is_array($noe) && $key != null) {
            $x = join(',', array_values($cat));
            $y = join(',', array_values($coin));
            $z = join(',', array_values($noe));
            $sql = "select cal.*,cal.id as idcal,coin.* from cal JOIN coin on cal.coinid=coin.id 
                    where (cal.cat1 in ( $x ) or cal.cat2 in ( $x )
                    or cal.cat3 in ( $x ) or cal.cat4 in ( $x ) or cal.cat5 in ( $x ))
                    and (en_titr like ? OR en_text like ? OR fa_text like ? OR fa_titr like ?)
                    and cal.coinid in ( $y )                        
                    and cal.cal_noe in ( $z )
                    and cal.fu_time BETWEEN ? and ?
                    order by cal.id DESC LIMIT $st,$lengt ";
            $stmt = self::$conn->prepare($sql);
            $stmt->bindValue(1, $key);
            $stmt->bindValue(2, $key);
            $stmt->bindValue(3, $key);
            $stmt->bindValue(4, $key);
            $stmt->bindValue(5, $start);
            $stmt->bindValue(6, $end);
            $stmt->execute();
            $result = $stmt->fetchAll();
            $sql2 = "select cal.*,cal.id as idcal,coin.* from cal JOIN coin on cal.coinid=coin.id 
                                where (cal.cat1 in ( $x ) or cal.cat2 in ( $x )
                                or cal.cat3 in ( $x ) or cal.cat4 in ( $x ) or cal.cat5 in ( $x ))
                                and (en_titr like ? OR en_text like ? OR fa_text like ? OR fa_titr like ?)
                                and cal.coinid in ( $y )                        
                                and cal.cal_noe in ( $z )
                                and cal.fu_time BETWEEN ? and ?";
            $count = $this->countSql2($sql2, $key, $start, $end);
            $result = [$result, $count, $page];
        }

        return $result;
    }

    function chekVote($ip, $id)
    {
        $sql = "select * from cal_vote where ip=? and idcal=?";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $ip);
        $stmt->bindValue(2, $id);
        $stmt->execute();
        $result = $stmt->fetchAll();
        if (count($result) > 0) {
            $res = 1;
        } else {
            $res = 0;
        }
        return $res;
    }

    function sendVote($ip, $id, $val)
    {
        $vote = $this->chekVote($ip, $id);
        $time = time();
        if ($vote == 0) {
            $sql = 'insert into cal_vote (ip,idcal,val,time) VALUES (?,?,?,?)';
            $stmt = self::$conn->prepare($sql);
            $stmt->bindValue(1, $ip);
            $stmt->bindValue(2, $id);
            $stmt->bindValue(3, $val);
            $stmt->bindValue(4, $time);
            $stmt->execute();

            if ($val == 1) {
                $sql = 'update cal set 
                        vote_like= vote_like +1,
                        vote_all=vote_all + 1 
                        WHERE id=?';
                $stmt = self::$conn->prepare($sql);
                $stmt->bindValue(1, $id);
                $stmt->execute();
            } elseif ($val == 0) {
                $sql = 'update cal set 
                        vote_all=vote_all + 1 
                        WHERE id=?';
                $stmt = self::$conn->prepare($sql);
                $stmt->bindValue(1, $id);
                $stmt->execute();
            }
        }
    }

    function resetVote($id)
    {
        $sql = "select * from cal where id=?";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->execute();
        $result = $stmt->fetch();
        $like = $result['vote_like'];
        $all = $result['vote_all'];
        $per = ceil(($like / $all) * 100);
        return $per;
    }

    function searchCoin($search)
    {
        if ($search == 'all') {
            $sql = "select * from coin";
            $stmt = self::$conn->prepare($sql);
            $stmt->execute();
            $result = $stmt->fetchAll();
        } else {
            $sql = "select * from coin where name like ?";
            $stmt = self::$conn->prepare($sql);
            $stmt->bindValue(1, "%$search%");
            $stmt->execute();
            $result = $stmt->fetchAll();
        }
        return $result;
    }

}