<?php

class Model
{
    public static $conn = '';

    function __construct()
    {
        $servername = 'localhost';
        $username = 'tarahanb_db';
        $password = '12345qaz54321zaq';
        $dbname = 'tarahanb_db';
        $attr = array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8');
        self::$conn = new PDO('mysql:host=' . $servername . ';dbname=' . $dbname, $username, $password, $attr);
        //self::$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }

    function create_thumbnail($file, $pathToSave = '', $w, $h = '', $crop = FALSE)
    {

        $new_height = $h;

        list($width, $height) = getimagesize($file);

        $r = $width / $height;

        if ($crop) {
            if ($width > $height) {
                $width = ceil($width - ($width * abs($r - $w / $h)));
            } else {
                $height = ceil($height - ($height * abs($r - $w / $h)));
            }
            $newwidth = $w;
            $newheight = $h;
        } else {
            if ($w / $h > $r) {
                $newwidth = $h * $r;
                $newheight = $h;
            } else {
                $newheight = $w / $r;
                $newwidth = $w;
            }
        }

        $what = getimagesize($file);

        switch (strtolower($what['mime'])) {
            case 'image/png':
                $src = imagecreatefrompng($file);

                break;
            case 'image/jpeg':
                $src = imagecreatefromjpeg($file);
                break;
            case 'image/gif':
                $src = imagecreatefromgif($file);
                break;
            default:
                //die();
        }

        if ($new_height != '') {
            $newheight = $new_height;
        }

        $dst = imagecreatetruecolor($newwidth, $newheight);//the new image
        imagecopyresampled($dst, $src, 0, 0, 0, 0, $newwidth, $newheight, $width, $height);//az function

        imagejpeg($dst, $pathToSave, 95);//pish farz in tabe 75 darsad quality ast

        return $dst;


    }

    public static function sessionInit()
    {

        @session_start();
    }

    public static function sessionSet($name, $value)
    {

        $_SESSION[$name] = $value;
    }

    public static function sessionGet($name)
    {

        if (isset($_SESSION[$name])) {

            return $_SESSION[$name];
        } else {
            return false;
        }
    }

    public static function miladiDate($format = 'Y - m - d')
    {
        $date = date($format);
        return $date;
    }

    public static function jaliliDate($format = 'Y/n/j H:i', $time)
    {
        $date = jdate($format, $time);
        return $date;
    }

    public static function jaliliToMiladi($jalili, $format = '/')
    {

        $jalili = explode('/', $jalili);
        $year = $jalili[0];
        $month = $jalili[1];
        $day = $jalili[2];
        $date = jalali_to_gregorian($year, $month, $day);
        $date = implode($format, $date);
        $date = new DateTime($date);
        $date = $date->format('Y/m/d');

        return $date;
    }

    public static function MiladiTojalili($miladi, $format = '/')
    {

        $miladi = explode('/', $miladi);
        $year = $miladi[0];
        $month = $miladi[1];
        $day = $miladi[2];
        $date = gregorian_to_jalali($year, $month, $day);
        $date = implode($format, $date);
        return $date;
    }


    function updatePass($iduser, $oldPass, $newpass1, $newPass2)
    {
        $msg = '';
        if ($newpass1 === $newPass2) {
            $sql = 'select * from users where Id=:id';
            $stmt = $this->conn->prepare($sql);
            $stmt->bindValue(':id', $iduser);
            $stmt->execute();
            $result = $stmt->fetch();
            $oldPass2 = $result['Password'];
            if ($oldPass2 === $oldPass) {
                $sql = 'update users set Password=:Password WHERE Id=:Id';
                $stmt = $this->conn->prepare($sql);
                $stmt->bindValue(':Password', $newpass1);
                $stmt->bindValue(':Id', $iduser);
                $stmt->execute();
                $msg = "رمز عبور با موفقیت تغییر یافت .";
            } else {
                $msg = "رمز عبور قدیم نادرست است !";
            }

        } else {
            $msg = "رمز عبور جدید به صورت صحیح وارد نشده است !";
        }

        return $msg;
    }


    public static function isLogin()
    {
        $ckeck = '';
        @Model::sessionInit();
        $ckeck = Model::sessionGet('userId');
        if ($ckeck == false) {
            return false;
        } else {
            return true;
        }
    }


    public static function cleanInput($input)
    {
        $search = array(
            '@<script[^>]*?>.*?</script>@si', // Strip out javascript
            '@<[\/\!]*?[^<>]*?>@si', // Strip out HTML tags
            '@<style[^>]*?>.*?</style>@siU', // Strip style tags properly
            '@<![\s\S]*?--[ \t\n\r]*>@' // Strip multi-line comments
        );
        $output = preg_replace($search, '', $input);
        return $output;
    }

//Data sanitizing
    public static function sanitize($input)
    {
        if (is_array($input)) {
            foreach ($input as $var => $val) {
                $output[$var] = Model::sanitize($val);
            }
        } else {
            if (get_magic_quotes_gpc()) {
                $input = stripslashes($input);
            }
            $input = Model::cleanInput($input);
            $output = addslashes($input);
        }
        return $output;
    }

    public static function getRealIpAddr()
    {
        if (!empty($_SERVER['HTTP_CLIENT_IP']))   //check ip from share internet
        {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))   //to check ip is pass from proxy
        {
            $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        } else {
            $ip = $_SERVER['REMOTE_ADDR'];
        }
        Model::sessionSet('ipClient', $ip);
    }

    function html_mail($to, $subject, $message, $options)
    {
        if (isset($options['from_name'])) {
            $headers = "From: " . $options['from_name'] . "<" . $options['from_email'] . ">" . "\r\n";
        }
        $headers = '';
        $headers .= "Reply-To: " . strip_tags(@$_POST['req-email']) . "\r\n";
        $headers .= "CC: info@tarahanbastan.ir\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
        mail($to, $subject, $message, $headers);
    }

    function SMS($number, $text)
    {
        require_once('view/assets/nosoap/nusoap.php');
        //$client = new nusoap_client($s_WSPROTOCOL."://".$s_WSHOSTNAME.$s_WSPORT."/".$s_WSPATHNAME, true);
        $client = new nusoap_client('http://api.payamak-panel.com/post/send.asmx?wsdl', true);
        $client->soap_defencoding = 'UTF-8';
        $client->decode_utf8 = false;
        $err = $client->getError();

        if ($err) {
            echo 'Constructor error' . $err;
        }
        $parameters['username'] = "amveks43";
        $parameters['password'] = "4310870899";
        $parameters['from'] = "300088103081";
        $parameters['to'] = $number;
        $parameters['text'] = $text;
        $parameters['isflash'] = false;
        $result = $client->call('SendSimpleSMS2', $parameters);
    }

    function getCusOneHagh($id)
    {
        $sql = "select * from cus_hag where id=?";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->execute();
        $result = $stmt->fetch();
        return $result;
    }

    function getCusOneHogh($id)
    {
        $sql = "select * from cus_hog where id=?";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $id);
        $stmt->execute();
        $result = $stmt->fetch();
        return $result;
    }
        function emailPersonel($id, $next)
    {
        $user = '';
        if ($next == "طراحی") {
            $user = "design";
        } else if ($next == "چاپ") {
            $user = "baner";
        } else if ($next == "چاپ دیجیتال") {
            $user = "other";
        } else if ($next == "لیزر") {
            $user = "laser";
        } else if ($next == "مدیر داخلی") {
            $user = "out";
        } else if ($next == "حسابداری") {
            $user = "hesab";
        } else if ($next == "مدیریت") {
            $user = "manag";
        }
        $sql = "select * from user where noe=?";
        $stmt = self::$conn->prepare($sql);
        $stmt->bindValue(1, $user);
        $stmt->execute();
        $result = $stmt->fetchAll();
        if (count($result)>0) {
            foreach ($result as $row) {
                $active = $row['emaill'];
                $email = $row['email'];
                $name = $row['name'] . ' ' . $row['last'];
                if ($active == 1) {
                 $this->sendEmailPersonel($email, $next, $name);
                }
            }
        }
    }

      function sendEmailPersonel($email, $next, $name)
    {
        $start = time();
        $format = 'Y/n/j';
        $start_d = Model::jaliliDate($format, $start);

        $to = $email;
        $subject = 'وضعیت سفارش در طراحان باستان';
        $from_name = 'طراحان باستان';
        $from_email = 'tarahanbastan.ir';

        $message = '<html><meta charset="UTF-8"><meta name="viewport" content="width=device-width"><body>';
        $message .= '<div style="width: 95%;position: relative;padding-bottom:20px;
       margin: auto;background-color: #fffddf;border-radius: 10px 10px 0 0;box-sizing: border-box">';
        $message .= '<div style="text-align: center;width:100%;box-sizing: border-box;min-width: 250px; color: #62680e;
       line-height: 23px;font-family: Arial;font-size: 16px;border-radius: 10px 10px 0 0; background-color: #fff98f;padding: 10px;margin: 0 auto 10px auto;">
       سفارش جدید</div>';
        $message .= '<div style="text-align: center;width: 95%;line-height: 23px;font-family: Arial;font-size: 15px;margin: auto; color: #343434">
همکار محترم ،  ' . $name . '،  سفارش جدیدی به واحد  ' . $next . ' ارسال شده است. لطفا به پنل کاربری خود مراجعه بفرمایید ';
        $message .= " .  تاریخ ارسال پیام : " . $start_d;
        $message .= '</div>';
        $message .= '</div>';
        //echo $message;
        $this->html_mail($to, $subject, $message, array('from_email' => $from_email, 'from_name' => $from_name));
    }

    function getNumberCos($id, $noe)
    {
        if ($noe == 'hagh') {
            $user = $this->getCusOneHagh($id);
            $number = $user['mobile'];
        } else {
            $user = $this->getCusOneHogh($id);
            $number = $user['mobile_manager'];
        }
        return $number;
    }


    function getNumberAllCos()
    {
        $numbers = array();
        $sql = "select * from cus_hag";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        foreach ($result as $row) {
            $numbers[] = $row['mobile'];
        }
        $sql = "select * from cus_hog";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $result2 = $stmt->fetchAll();
        foreach ($result2 as $row2){
            $numbers[]=$row['mobile_manager'];
        }
        return $numbers;
    }
    function sms3($rcpt_nm, $text)
       {
           $url = "37.130.202.188/services.jspd";
           //$rcpt_nm = array('9167592080', '09027490090');
           $param = array
           (
               'uname' => 'avatar72',
               'pass' => '1234567890',
               'from' => '100020400',
               'message' => $text,
               'to' => json_encode($rcpt_nm),
               'op' => 'send'
           );
           $handler = curl_init($url);
           curl_setopt($handler, CURLOPT_CUSTOMREQUEST, "POST");
           curl_setopt($handler, CURLOPT_POSTFIELDS, $param);
           curl_setopt($handler, CURLOPT_RETURNTRANSFER, true);
           $response2 = curl_exec($handler);
           $response2 = json_decode($response2);
           $res_code = $response2[0];
           $res_data = $response2[1];
       }


}

