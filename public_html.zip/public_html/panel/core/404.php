<?php

echo "Your Server is Down! Wait for fixing!!!";