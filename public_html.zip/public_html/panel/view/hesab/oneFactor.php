<?php
$fac = $data[2];
?>
<div class="option">
    <style>
        .option {
            width: 100%;
            min-width: 1300px !important;
            margin: 10px auto;
        }

        .option * {
            text-align: right;
            direction: rtl;
        }

        .mainOption {
            width: 95%;
            min-width: 1000px;
            margin: 10px auto;
            border: 1px solid #53a3c6;
        }
        .hed{
            background: #53a3c6;
            padding: 14px;
            color: white;
            text-align: center;
        }

    </style>
    <style>
        .page {
            position: relative;
        }

        #order {
            width: 694px;
            margin: 10px auto;
            min-width: 400px;
            height: 86px;
            font-size: 13px;
            font-family: mapnoS;
            border: 1px solid #c0e6e3;
            box-sizing: border-box;
            padding: 8px 10px;
            border-radius: 4px;
            resize: none;
        }

        .laborder {
            display: block;
            margin-bottom: 5px;
        }

        .attr {
            width: 300px;
            height: 60px;
            margin-top: 24px;
            display: inline-block;
            margin-left: 25px;
        }

        .label {
            display: block;
            margin-right: 5px;
        }

        .input {
            display: block;
            margin-top: 15px;
            width: 300px;
            height: 35px;
            box-sizing: border-box;
            border: 1px solid #c0e6e3;
            border-radius: 5px;
            padding: 4px 10px;
        }

        .attr1 {
            width: 220px;
            height: 60px;
            margin-top: 24px;
            display: inline-block;
            position: relative;
            margin-left: 6px;
            margin-right: 15px;
        }

        .label1 {
            margin-left: 10px;
            position: absolute;
            right: 0;
            top: 8px;
        }

        .input1 {
            width: 132px;
            height: 35px;
            box-sizing: border-box;
            border: 1px solid #c0e6e3;
            border-radius: 5px;
            padding: 4px 10px;
            position: absolute;
            left: 0;
            top: -4px;
            text-align: center;
            direction: ltr;
        }

        input, select {
            background: white;
        }

        .file {
            position: absolute;
            width: 74px;
            left: 8px;
            top: 3px;
        }

        .line {
            width: 689px;
            border-bottom: 1px dashed #19b5fe;
            position: absolute;
            bottom: 0;
        }

        .line2 {
            width: 689px;
            border-bottom: 1px dashed #19b5fe;
            bottom: 0;
        }

        .in {
            width: 100%;
            position: relative;
            border-bottom: 1px dashed #19b5fe;
        }

        .sub {
            border: 1px solid #1d3b3e;
            position: absolute;
            bottom: 35px;
            left: 37px;
            padding-top: 0 !important;
        }

        .img {
            position: absolute;
            left: 30px;
            top: 37px;
            z-index: 33;
            border: 1px solid #8198af;
            border-radius: 4px;
            overflow: hidden;
            height: 317px;
            width: 300px;
        }

        .img img {
            width: 100%;
            height: 100%;
            position: absolute;
            top: 0;
            left: 0;
        }

        .img:hover {
            left: 150px;
            transform: scale(1.8);
            box-shadow: 0 0 10px 1px #1e4561;
            z-index: 99;
            transition: 0.8s;
        }

        .men {
            display: inline-block;
            margin-right: 27px;
            margin-top: 2px;
        }

        .men a {
            color: #f4f8ff !important;
        }

        .men a:hover {
            color: #28e1ff !important;
        }

        .span {
            position: relative;
            width: 44px;
            display: inline-block;
        }

        .span img {
            position: absolute;
            top: -12px;
            right: 10px;
        }

        .don {
            position: absolute;
            right: -3px;
            bottom: 30px;
            width: 200px;
        }

        .don2 {
            position: absolute;
            right: 220px;
            bottom: 30px;
            width: 200px;
        }

        #dis {
            width: 366px;
            height: 35px;
            border: 1px solid #C0E6E3;
            resize: none;
            border-radius: 4px;
            padding: 7px 20px;
            box-sizing: border-box;
            font-size: 13px;
            font-family: mapnoS;
            margin-bottom: 36px;
        }

        .lab {
            font-family: mapno;
            margin: 13px 2px 8px 0;
        }

        .subDis {
            padding-top: 0 !important;
            position: absolute;
            bottom: 30px;
            right: 588px;
        }

        .line2 {
            width: 689px;
            border-bottom: 1px dashed #19b5fe;
            position: absolute;
            bottom: 95px;
        }

        .baner {
            display: inline-block;
            width: 158px;
            text-align: center;
            border: 1px solid #c0e6e3;
            border-radius: 3px;
            height: 30px;
            box-sizing: border-box;
            margin: 20px 0 0 15px;
        }

        .subBaner {
            padding-bottom: 10px;
            position: absolute;
            bottom: 23px;
            left: 26px;
        }

        .at {
            width: 366px;
            height: 52px;
            position: relative;
            margin: 10px 2px 24px 0;
        }

        .input2 {
            position: absolute;
            left: 0;
            top: 0;
        }

        .lab2 {
            top: 15px;
            position: absolute;
        }

        .table {
            width: 100%;
            position: relative;
            min-width: 700px;
            background-color: #f7feff;
            border: 1px solid #3da6ff;
            box-sizing: border-box;
            margin: 20px auto -2px auto;
        }

        .table tr:first-child td {
            background-color: #53a3c6;
            padding: 13px 8px;
            text-align: center;
            font-size: 12px;
            min-width: 80px;
            display: table-cell;
            color: white;
            font-family: mapno !important;
        }

        .table tr:nth-child(even) {
            background-color: white;
        }

        .table tr td {
            padding: 13px 8px;
            text-align: center;
            font-size: 12px;
            min-width: 52px;
            color: #030375;
            line-height: 18px;
            font-family: mapnoS;

        }

        .one {
            padding: 15px 10px;
            color: #00007f;
            font-family: mapnoS;
        }

        .price {
            display: inline-block;
            width: 260px;
            background: #f6fcff;
            padding: 15px 10px;
            border: 1px solid #3da6ff;
            text-align: left;
            margin-bottom: 23px;
            border-top: none;
            z-index: 999;
        }
    </style>
    <div class="mainOption">
        <div class="hed">نمایش فاکتور
        </div>
        <div class="page">

            <div class="attr1">
                <label for="factor" class="label1">شماره فاکتور : </label>
                <input type="text" class="input1" value="<?= @$fac['id'] ?>" disabled>
            </div>

            <div class="attr1">
                <label for="start" class="label1">تاریخ سفارش : </label>
                <input type="text" class="input1" name="start" value="<?= @$fac['start_d'] ?>" disabled>
            </div>

            <div class="attr1" style="block !important;">
                <label for="factor" class="label1">تاریخ تحویل : </label>
                <input type="text" class="input1" value="<?= @$fac['end_d'] ?>" disabled>
            </div>
            <div class="attr1" style="width: 350px;">
                <label for="cos" class="label1">مشتری : </label>
                <input type="text" class="input1" value="<?= @$fac['cos'] ?>" name="special" disabled style="width: 260px;">
            </div>
            <?php
            $allOrders = $data[0];
            $level = $data[1];
            if(count($allOrders)>0) {
                foreach ($allOrders as $key => $row) {
                    $orders = $allOrders[$key];
                    //print_r($orders);
                    $order = $orders['orders'];

                    $lev = unserialize($orders['level']);
                    $nameLev = $orders['now'];

                    $servic = unserialize($orders['servic']);
                    if (is_array($servic)) {
                        $servicValus = array_values($servic);
                        $servic = implode(' ،  ', $servicValus);
                    }

                    $special = unserialize($orders['special']);
                    if (is_array($special)) {
                        $specialValus = array_values($special);
                        $special = implode(' ،  ', $specialValus);
                    }
                    @$mony_out = $orders['price_out'];
                    if (!empty($mony_out) && is_numeric($mony_out)) {
                        $mony_out = number_format($mony_out);
                    }
                    @$mony_design = $orders['price_design'];
                    if (!empty($mony_design) && is_numeric($mony_design)) {
                        $mony_design = number_format($mony_design);
                    }
                    $mony_respect = $orders['mony'];
                    if (!empty($mony_respect) && is_numeric($mony_respect)) {
                        $mony_respect = number_format($mony_respect);
                    }

                    $ok = 0;
                    $dis = unserialize($orders['dis']);
                    ?>

                    <div class="in">
                        <table class="table">
                            <tr>
                                <td>ردیف</td>
                                <td>مرحله</td>
                                <td>جزئیات</td>
                                <td>تاریخ دریافت</td>
                                <td>تاریخ ارسال</td>
                                <td>کاربر</td>
                                <td>هزینه</td>
                            </tr>
                            <tr>
                                <td>1</td>
                                <td>پذیرش</td>
                                <td><?= $order ?></td>
                                <td> <?= $orders['start_d'] ?> </td>
                                <td><?= $orders['respect_out'] ?></td>
                                <td> <?= $orders['name'] . ' ' . $orders['last'] ?> </td>
                                <td>0</td>
                            </tr>
                            <?php
                            $allMony = 0;
                            if(is_array($dis) && count($dis)>0) {
                                foreach ($dis as $key2 => $row2) {
                                    $i = $key2 + 2;
                                    $mony = $row2[3];
                                    $allMony += $mony;
                                    if (!empty($mony) && is_numeric($mony)) {
                                        $mony = number_format($mony);
                                    }
                                    //$arr = [$nowtime, $id, $next];
                                    $start = $lev[$key2][0];
                                    $send = $lev[$key2 + 1][0];
                                    ?>
                                    <tr>
                                        <td><?= $i ?></td>
                                        <td><?= $row2[0] ?></td>
                                        <td><?= $row2[4] ?></td>
                                        <td> <?= $start ?> </td>
                                        <td><?= $send ?></td>
                                        <td><?= $row2[2] ?></td>
                                        <td><?= $mony ?></td>
                                    </tr>
                                <?php }
                            }?>
                        </table>
                    </div>
                <?php }
            }?>
            <!--
            <?php if (!empty($orders['img'])) { ?>
                <div class="img"><img src="image/order/<?= $orders['id'] ?>/<?= $orders['img'] ?>" width="300"
                                      height="317"></div>
            <?php } ?>
            -->

        </div>
    </div>

</div>


