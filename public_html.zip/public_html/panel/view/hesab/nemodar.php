<script src="<?= U ?>view/assets/highcharts/highcharts.js"></script>
<script src="<?= U ?>view/assets/highcharts/variable-pie.js"></script>


<?php

$data = $data[1];
$moon = $data[0];
$ejra = $data[1];
$finish = $data[2];
$laghv = $data[3];
$all = $data[4];
$values_moon = array_values($moon);
$values_moon = implode(',', $values_moon);
$values_ejra = array_values($ejra);
$values_ejra = implode(',', $values_ejra);
$values_finish = array_values($finish);
$values_finish = implode(',', $values_finish);
$values_laghv = array_values($laghv);
$values_laghv = implode(',', $values_laghv);
$values_all = array_values($all);
$values_all = implode(',', $values_all);
?>


<script type="text/javascript">
    $(function () {
        $('#container').highcharts({
            title: {
                text: 'نمودار سفارشات در شش ماه اخیر',
                x: 0 //center
            },
            subtitle: {
                text: 'مپنو',
                x: 0
            },
            xAxis: {
                categories: [<?= $values_moon ?>]
            },
            yAxis: {
                title: {
                    text: 'تعداد سفارش'
                },
                plotLines: [{
                    value: 0,
                    width: 1,
                    color: '#f00'
                }]
            },
            tooltip: {
                valueSuffix: '',
                enabled: true,
                useHTML: true,
                padding: 20
            },

            legend: {
                layout: 'vertical',
                align: 'right',
                verticalAlign: 'middle',
                borderWidth: 0
            },

            series: [{
                name: 'سفارش در حال اجرا',
                data: [<?= $values_ejra ?>]
            }, {
                name: 'سفارش انجام شده',
                data: [<?= $values_finish ?>]
            }, {
                name: 'سفارش لغو شده',
                data: [<?= $values_laghv ?>]
            }, {
                name: 'همه سفارشات',
                data: [<?= $values_all ?>]
            }
            ]
        });

    });

</script>
<div id="container" style="min-width: 600px;width: 100%; height: 400px; margin: 0 auto"></div>


<style>
    #container * {
        direction: ltr !important;
        text-align: left !important;
        font-family: mapnoS;
    }


</style>


