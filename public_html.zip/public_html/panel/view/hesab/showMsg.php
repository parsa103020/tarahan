<?php
$msg = $data[0];
?>

<?php foreach ($msg as $row) {
    ?>
    <div class="div02">
        <span class="send2"><?= $row['msg'] ?>
            <span class="time2"><?= $row['date'] ?></span>
            <?php if($row['seen']==1){ ?>
            <img src="view/assets/image/check-mark.png" class="mark">
            <?php } ?>
        </span>
    </div>

<?php } ?>

<style>
    .mark{
        width: 12px;
        height: 12px;
        position: absolute;
        bottom: 7px;
        left: 15px;
    }

    .time2 {
        position: absolute;
        font-size: 10px;
        width: 78px;
        bottom: 1px;
        left: 6px;
        color: #313e50;
        font-family: mapnoS;
    }

    .send2 {
        position: relative;
        display: inline-block;
        padding: 9px 10px 16px 60px;
        background-color: white;
        margin: 5px 7px;
        border-radius: 15px 15px 15px 0;
        font-size: 14px;
        font-family: mapnoS;
        max-width: 400px;
        min-width: 18px;
        line-height: 23px;
    }

    .div01 {
        text-align: right !important;
    }

    .div02 {
        text-align: left !important;
    }
</style>













