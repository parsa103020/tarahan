<?php
//$filter = $data[0];
?>
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.css"/>
    <link rel="stylesheet" href="public/c_jalili/style/kamadatepicker.css"/>
    <link rel="stylesheet" href="public/c_jalili/style/kamadatepicker.min.css"/>
    <script src="public/c_jalili/src/kamadatepicker.js"></script>
    <script src="public/c_jalili/src/kamadatepicker.min.js"></script>
</head>
<br/>
<style>
    .container {
        position: relative;
        top: 0px;
        font-family: mapno;
    }

    .container input {
        font-family: mapnos;
        border: 1px solid #6cdbc7 !important;
    }

    .container .col-md-2 {
        position: absolute;
        right: -10%;
    }

    .container .cm2 {
        position: absolute;
        right: 5%;
    }
    .col-md-8 {
        width: 16.667% !important;
        float: right;
        margin-right: 21%;
    }
</style>
<form action="hesab/filterFactor" method="post">
    <div class="container">
        <div class="col-md-2">
            <input type="text" name="From" id="test-date-id" class="form-control" placeholder="از تاریخ"/>
        </div>
        <div class="col-md-2 cm2">
            <input type="text" name="to" id="test-date-id2" class="form-control" placeholder="تا تاریخ"/>
        </div>
        <div class="col-md-8">
            <input type="button" onclick="search(1)" name="range" id="range" value="فیلتر" class="btn btn-success"/>
        </div>
        <!--<script>
        $(document).ready(function(){
        	$.datepicker.setDefaults({
        		dateFormat: 'yy-mm-dd'
        	});
        	$(function(){
        		$("#From").datepicker();
        		$("#to").datepicker();
        	});
        	$('#range').click(function(){
        		var From = $('#From').val();
        		var to = $('#to').val();
        		if(From != '' && to != '')
        		{
        			$.ajax({
        				url:"hesab/filterFactor",
        				method:"POST",
        				data:{From:From, to:to},
        				success:function(data)
        				{
        					$('#purchase_order').html(data);
        				}
        			});
        		}
        		else
        		{
        			alert("Please Select the Date");
        		}
        	});
        });
        </script>-->
        <script>
            kamaDatepicker('test-date-id');
            kamaDatepicker('test-date-id2');
            /*
            kamaDatepicker('test-date-id', { buttonsColor: "red", forceFarsiDigits: true });*/

            function search(key) {
                var url = 'hesab/filterFactor';
                var data = {key: key};
                $.post(url, data, function (msg) {
                    $('.manag').html(msg);
                });
            }
        </script>
        <div class="clearfix"></div>
        <br/>
    </div>
</form>
<!-- Script -->
<!--<script>
    $(document).ready(function () {
        $.datepicker.setDefaults({
            dateFormat: 'yy-mm-dd'
        });
        $(function () {
            $("#From").datepicker();
            $("#to").datepicker();
        });
        $('#range').click(function () {
            var From = $('#From').val();
            var to = $('#to').val();
            if (From != '' && to != '') {
                $.ajax({
                    url: "range.php",
                    method: "POST",
                    data: {From: From, to: to},
                    success: function (data) {
                        $('#purchase_order').html(data);
                    }
                });
            } else {
                alert("Please Select the Date");
            }
        });
    });
</script>-->