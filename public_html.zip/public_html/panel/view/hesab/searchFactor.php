<?php
$factors = $data[0][0];
$price = $data[0][1];

?>
<div class="price">
    <?php
    if(is_numeric($price)){
       echo number_format($price);
    }
    ?>
</div>

<table class="table">
    <tr class="heding">
        <td>شماره فاکتور</td>
        <td>مشتری</td>
        <td>تعداد سفارش</td>
        <td>تاریخ سفارش</td>
        <td>تاریخ تحویل</td>
        <td>نحوه تسویه</td>
        <td>بیعانه</td>
        <td>پرینت</td>
        <td>سند</td>
        <td>نمایش</td>
    </tr>
    <?php foreach ($factors as $key => $row) {
        ?>
        <tr>
            <td><?= $row['id'] ?></td>
            <td><?= $row['cos'] ?></td>
            <td><?= $row['tedad'] ?></td>
            <td><?= $row['start_d'] ?></td>
            <td><?= $row['end_d'] ?></td>
            <td><?= $row['pay'] ?></td>
            <td><?= $row['bayane'] ?></td>
            <td>
                <a target="_blank" <?php if (empty($nowLev)) { ?> href="hesab/print/<?= $row['id'] ?>" <?php } ?>><img
                            src="view/assets/image/printer.png"
                            style="cursor: pointer"></a>
            </td>
            <td>
                <a target="_blank" <?php if (empty($nowLev)) { ?> href="hesab/document/<?= $row['id'] ?>" <?php } ?>><img
                            src="view/assets/image/printer.png"
                            style="cursor: pointer"></a>
            </td>
            <td>
                <a target="_blank" <?php if (empty($nowLev)) { ?> href="hesab/oneFactor/<?= $row['id'] ?>" <?php } ?>><img
                            src="view/assets/image/show.png"
                            style="cursor: pointer"></a>
            </td>
        </tr>
    <?php } ?>
</table>

