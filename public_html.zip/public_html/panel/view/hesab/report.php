
<?php
$user = $data[0];
?>
<div class="option">
    <style>
        .option {
            width: 100%;
            min-width: 1300px !important;
            margin: 10px auto;
        }

        .option * {
            text-align: right;
            direction: rtl;
        }

        .mainOption {
            width: 80%;
            min-width: 1000px;
            float: left;
            margin-left: 10px;
            margin-top: 10px;
        }

        .tim {
            position: absolute;
            left: 6px;
            bottom: 0;
            font-size: 12px;
            color: #494972;
            font-family: mapnoS;
        }

        .hed div {
            margin-right: 30px;
            display: inline-block;

        }

        .hed div a {
            font-size: 13px;
            color: #fb721d;
            margin-right: 46px;
        }

        .hed div a:hover {
            color: #fb002e;
        }

        .detail {
            margin: 20px 16px;
            line-height: 33px;
            font-family: tahoma;
            font-size: 13px;
        }

        .tab {
            min-width: 1000px;
            float: right;
            background-color: #0093ff;
            width: 100%;
            font-size: 0;
        }

        .tab li {
            float: right;
            padding: 15px;
            font-size: 13px;
            border-left: 1px solid #0078bf;
            cursor: pointer;
            color: #fff;
            font-family: mapno;
        }
        .tab li:hover{
            box-shadow: 0 0 1px 1px #0064ca;
            transition: 0.7s;
            background-color: #00a8ff;
        }
        .activ {
            background: #fdfffd !important;
            border-top: 1px solid #0093ff;
            color: #020c67 !important;
            box-shadow: 0 0 0 0 #fff !important;
        }

        .tabchilds {
            min-width: 1000px;
            width: 100%;
            float: right;
            background: #fff;
            position: relative;
        }

        .tabchilds div {
            box-sizing: border-box;
            font-size: 12pt;
            padding: 20px 5px;
            width: 100%;
            min-width: 900px;
        }

        ul {
            list-style: none;
        }

        .divs1 {
            display: none;
        }

        .divNew {

        }
    </style>

    <?php require('optionList.php'); ?>
    <div class="mainOption">
        <div class="hed">گزارشات
        </div>

        <ul class="tab">
            <li data-tab="1" class="activ">کل سفارشات</li>
            <li data-tab="2"> انجام شده</li>
            <li data-tab="3"> در حال اجر</li>
            <li data-tab="4">لغو شده</li>
            <li data-tab="6">جست و جو سفارش</li>
        </ul>
        <div class="tabchilds">
            <div data-tab="1" class="divss  ">
                <?php
               require('report1.php');
                ?>
            </div>
            <div data-tab="2" class="divss divs1"></div>
            <div data-tab="3" class="divss divs1"></div>
            <div data-tab="4" class="divss divs1"></div>
            <div data-tab="5" class="divss divs1"></div>
            <div data-tab="6" class="divss divs1"></div>
        </div>

    </div>

</div>
<div class="clear"></div>


<script>

    $('.tab li').click(function () {
        var idTab = $(this).attr('data-tab');
        $('.divss').hide(0);
        var showTab = $('.tabchilds>div[data-tab = ' + idTab + ']');
        var url = "<?= U;?>hesab/rep";
        var data = {'id': idTab};
        $.post(url, data, function (msq) {
            showTab.html(msq);
        });
        showTab.fadeIn(300);
        $('.tab li').removeClass('activ');
        $(this).addClass('activ');
    });


    $('#rep').addClass('liActiv');
    $('#rep a').addClass('aActiv');
</script>