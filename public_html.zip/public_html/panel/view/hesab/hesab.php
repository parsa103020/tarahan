<script src="view/assets/calendar/js-persian-cal.min.js"></script>
<div class="option">
    <style>
        .option {
            width: 100%;
            min-width: 1300px !important;
            margin: 10px auto;
        }

        .option * {
            text-align: right;
            direction: rtl;
        }

        .mainOption {
            width: 80%;
            min-width: 1000px;
            float: left;
            margin-left: 10px;
            margin-top: 10px;
        }

        .tim {
            position: absolute;
            left: 6px;
            bottom: 0;
            font-size: 12px;
            color: #494972;
            font-family: mapnoS;
        }

        .hed div {
            margin-right: 30px;
            display: inline-block;

        }

        .hed div a {
            font-size: 13px;
            color: #fb721d;
            margin-right: 46px;
        }

        .hed div a:hover {
            color: #fb002e;
        }

        .detail {
            margin: 20px 16px;
            line-height: 33px;
            font-family: tahoma;
            font-size: 13px;
        }

        .tab {
            min-width: 1000px;
            float: right;
            background-color: #0093ff;
            width: 100%;
            font-size: 0;
        }

        .tab li {
            float: right;
            padding: 15px;
            font-size: 13px;
            border-left: 1px solid #0078bf;
            cursor: pointer;
            color: #fff;
            font-family: mapno;
        }

        .tab li:hover {
            box-shadow: 0 0 1px 1px #0064ca;
            transition: 0.7s;
            background-color: #00a8ff;
        }

        .activ {
            background: #fdfffd !important;
            border-top: 1px solid #0093ff;
            color: #020c67 !important;
            box-shadow: 0 0 0 0 #fff !important;
        }

        .tabchilds {
            min-width: 1000px;
            width: 100%;
            float: right;
            background: #fff;
            position: relative;
        }

        .tabchilds div {
            box-sizing: border-box;
            font-size: 12pt;
            padding: 20px 5px;
            width: 100%;
            min-width: 900px;
        }

        ul {
            list-style: none;
        }

        .divs1 {
            display: none;
        }

        .divNew {

        }
    </style>
    <style>


        input.valid {
            background-color: #f8f8f8 !important;
        }

        .pcalBtn {
            top: 40px !important;
            right: 9px !important;
        }

        .search2:hover {
            background-color: #d9f3f8 !important;
            border: 1px solid #00a4dc !important;
        }

        .s1 {
            position: relative;
            width: 155px;
            height: 33px;
            border: 1px solid #51bcdc;
            box-sizing: border-box;
            padding: 9px 17px;
            border-radius: 30px;
            display: inline-block;
            color: #022670;
            cursor: pointer;
            margin-left: 10px !important;
            text-align: center;
        }

        .pcalBtn2 {
            top: 40px !important;
            right: 177px !important;
        }

        div.picker {
            top: 180px !important;
        }

        .s2 img {
            position: absolute;
            top: 9px;
            left: 8px;
        }

        .s2 {
            cursor: pointer;
            display: inline-block;
            width: 33px !important;
            height: 33px;
            border: 1px solid #a49898;
            border-radius: 100% !important;
            position: absolute;
            background-color: #101820;
        }

        .contSearch {
            width: 100%;
            min-height: 240px;
        }
    </style>
    <?php require('optionList.php'); ?>
    <div class="mainOption">
        <div class="hed">دستمزد روزانه
        </div>
        <!--
        <ul class="tab">
            <li data-tab="1" class="activ">واحد چاپ</li>
        </ul>
        -->
        <div class="tabchilds">
            <div data-tab="1" class="divss  ">

                <div class="sea">
                    <input type="text" id="fcal1" class="pdate s1" style="overflow: hidden" placeholder="شروع تاریخ ">
                    <input type="hidden" name="extra" id="extra">
                    <span class="two">
                        <input type="text" id="fcal2" class="pdate2 s1"
                               style="overflow: hidden;text-align: center !important;"
                               placeholder="پایان تاریخ ">
                        <input type="hidden" name="extra2" id="extra2">
                    </span>
                    <span onclick="search()" class="s2">
                        <img id="ss" src="view/assets/image/search.png" width="16" height="16" alt="search"></span>
                </div>

                <div class="contSearch">

                </div>
            </div>
        </div>

    </div>

</div>
<div class="clear"></div>

<script>
    function search() {
        var start = $('#fcal1').val();
        var end = $('#fcal2').val();
        var url = "hesab/heasbChap";
        var data = {start: start,end:end};
       $.post(url, data, function (msq) {
            // console.log(msq);
            $('.contSearch').html(msq);
        });
    }

    // active calendar
    var objCal1 = new AMIB.persianCalendar('fcal1',
        {extraInputID: "extra", extraInputFormat: "YYYYMMDD"}
    );
    var objCal2 = new AMIB.persianCalendar('fcal2',
        {extraInputID: "extra2", extraInputFormat: "YYYYMMDD"}
    );
    var span = $('.two');
    span.find('.pcalBtn').addClass('pcalBtn2');


    // hover search btn
    $('.s2').hover(function () {
        $('#ss').animate({width: "17px", height: "17px"}, 70);

    }, function () {
        $('#ss').animate({width: "16px", height: "16px"}, 70);
    });

</script>

<script>
    $('#hesab').addClass('liActiv');
    $('#hesab a').addClass('aActiv');
</script>