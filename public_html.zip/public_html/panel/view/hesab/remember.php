<?php
$rem = $data[0];
?>
<div class="option">
    <style>
        .option {
            width: 100%;
            min-width: 1300px !important;
            margin: 10px auto;
        }

        .option * {
            text-align: right;
            direction: rtl;
        }

        .mainOption {
            width: 80%;
            min-width: 1000px;
            float: left;
            margin-left: 10px;
            margin-top: 10px;
        }

        .tim {
            position: absolute;
            left: 6px;
            bottom: 0;
            font-size: 12px;
            color: #494972;
            font-family: mapnoS;
        }
    </style>
    <style>
        .table {
            width: 100%;
            position: relative;
            min-width: 700px;
            background-color: #f7feff;
            border: 1px solid #3da6ff;
            box-sizing: border-box;
        }

        .table tr:first-child td {
            background-color: #53a3c6;
            padding: 13px 8px;
            text-align: center;
            font-size: 12px;
            min-width: 80px;
            display: table-cell;
            color: white;
            font-family: mapno !important;
        }

        .table tr:nth-child(even) {
            background-color: white;
        }

        .table tr td {
            padding: 13px 8px;
            text-align: center;
            font-size: 12px;
            min-width: 52px;
            color: #030375;
            line-height: 18px;
            font-family: mapnoS;

        }

        .manag {
            height: 500px;
            overflow-y: auto;
        }

    </style>
    <style>

        .add {
            display: inline-block;
            position: absolute;
            left: 30px;
        }

        .add0 {
            display: inline-block;
            margin-right: 13px;
            cursor: pointer;
            font-size: 12px;
            font-family: mapno;
        }

        .add0:hover {
            color: #00bbff;
        }

        .flip-box, .flip-box2, .flip-box3 {
            background: #066568;
            width: 100%;
            margin: 3px auto 8px auto;
            height: 135px;
            border: 1px solid #d5e6f1;
            perspective: 1000px;
            margin: auto;
            display: none;
            position: relative;
        }

        .flip-box-inner, .flip-box-inner2, .flip-box-inner3 {
            position: relative;
            width: 100%;
            height: 100%;
            text-align: center;
            transition: transform 1s;
            transform-style: preserve-3d;
            transform: rotate3d(1, 0, 0, -90deg);

        }

        .tozih {
            font-family: mapno;
            font-size: 13px !important;
        }

        .flip-box-hover, .flip-box-hover2, .flip-box-hover3 {
            transform: rotate3d(1, -1, 1, 0deg);
        }

        .flip-box-front, .flip-box-front2, .flip-box-front3 {
            position: absolute;
            width: 100%;
            height: 100%;
            backface-visibility: hidden;
            background-color: black;

        }

        .flip-box-front, .flip-box-front2, .flip-box-front3 {
            background-color: #dff9f3;
            color: black;

        }

        .lable11 {
            font-family: mapno;
            right: 0;
            position: absolute;
            top: 10px;
        }

        .input11 {
            box-sizing: border-box;
            border: 1px solid #eee;
            width: 800px;
            height: 35px;
            border-radius: 5px;
            padding: 3px 10px;
            position: absolute;
            right: 0;
            bottom: 0;
            margin-left: -113px;
            font-family: mapnoS;
        }

        .attr11 {
            min-width: 800px;
            height: 40px;
            position: relative;
            display: inline-block;
            margin: 10px 1% 0 1%;
        }

        .sub2 {
            padding-top: 0 !important;
            font-family: mapno;
            font-size: 12px;
            border: 1px solid #eee;
            position: absolute;
            top: 14px;
            left: 23px;
        }
    </style>

    <?php require('optionList.php'); ?>
    <div class="mainOption">
        <div class="hed">یادآوری
            <div class="add">
                <span class="add0 add1">افزودن یادآوری</span>
            </div>
        </div>
        <div>
        <div class="flip-box3">
            <div class="flip-box-inner3">
                <div class="flip-box-front3">
                    <form action="manag/insertRem" method="post">
                        <div class="attr11">
                            <input type="text" name="rem" class="input11" placeholder="اینجا بنویسید" required>
                        </div>
                        <input type="submit" class="submit sub2" value="ثبت اطلاعات">
                    </form>
                </div>
            </div>
    </div>
        </div>
        <div class="manag">
            <table class="table">
                <tr class="heding">
                    <td>ردیف</td>
                    <td>یادآوری</td>
                    <td>تاریخ</td>
                    <td>وضعیت</td>
                </tr>
                <?php foreach ($rem as $key => $row) {
                    $check = $row['chek'];
                    if ($check == 0) {
                        $ch = 'انجام نشده';
                    } else {
                        $ch = 'انجام شده';
                    }
                    ?>
                    <tr>
                        <td><?= $key+1 ?></td>
                        <td><?= $row['text'] ?></td>
                        <td><?= $row['time_d'] ?></td>
                        <td><?= $ch ?></td>
                    </tr>
                <?php } ?>
            </table>
        </div>
    </div>

</div>
<div class="clear"></div>
<script>
    var flipBox3 = $('.flip-box3');
    $('.add0').click(function () {
        flipBox3.fadeToggle(800);
        flipBox3.toggleClass('flip-box-hover');
        $('.flip-box-inner3').toggleClass('flip-box-hover');
    });



    $('#remember').addClass('liActiv');
    $('#remember a').addClass('aActiv');
</script>