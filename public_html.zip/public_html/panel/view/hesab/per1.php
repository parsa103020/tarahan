<?php
$per = $data[0];
?>
<style>
    .table {
        position: relative;
        min-width: 230px;
        box-sizing: border-box;
    }

    .table tr {
        height: 76px;
        position: relative;
    }

    .table tr td {
        padding: 13px 8px;
        text-align: right;
        font-size: 13px;
        padding-right: 30px;
        min-width: 52px;
        color: #030375;
        line-height: 18px;
        font-family: mapnoS;
        padding-top: 27px;
    }

    .manag {
        background-color: #f7feff;
        min-width: 250px !important;
        margin-top: 0 !important;
    }

    .right {
        display: inline-block;
        width: 25% !important;
        height: 400px;
        margin-top: 10px;
        min-width: 250px !important;
    }

    .imgUser {
        width: 70px;
        height: 70px;
        border-radius: 100%;
        overflow: hidden;
        position: absolute;
        right: 3px;
        top: 3px;
        border: 1px solid white;
    }

    tr td span {
        display: block;
        text-align: center !important;
        margin-top: 3px;
        color: #030375;
        font-size: 12px !important;
    }

    .online {
        position: absolute;
        width: 10px;
        height: 10px;
        background-color: #00f600;
        border-radius: 100%;
        z-index: 9;
        bottom: 14px;
        left: 27px;
    }

    .ofline {
        position: absolute;
        width: 10px;
        height: 10px;
        background-color: #e6e6e6;
        border-radius: 100%;
        z-index: 9;
        bottom: 14px;
        left: 27px;
    }

    .noee {
        color: #030375;
        text-align: right !important;
        padding-right: 2px;
        box-sizing: border-box;
        font-size: 12px !important;
        font-family: mapnoS;
    }

    .left {
        display: inline-block;
        width: 72% !important;
        margin-top: 10px;
        min-width: 250px !important;
        margin-right: 1%;
        position: absolute;
    }

</style>
<div class="right">
    <div class="manag">
        <table class="table">
            <?php foreach ($per as $key => $row) {
                $onlin = $row['onlin'];
                $noe = $row['noe'];
                if ($noe != 'manag' && $noe != 'hesab') {
                    if ($noe == 'respect') {
                        $mod = "پذیرش";
                    } elseif ($noe == 'design') {
                        $mod = "طراحی";
                    } elseif ($noe == 'baner') {
                        $mod = "بنر";
                    } elseif ($noe == 'aser') {
                        $mod = "لیزر";
                    } elseif ($noe == 'other') {
                        $mod = "متفرقه";
                    } elseif ($noe == 'out') {
                        $mod = "بیرون";
                    } elseif ($noe == 'laser') {
                        $mod = "لیزر";
                    }
                    ?>
                    <tr>
                        <td style="position: relative">
                            <span <?php if ($onlin == 0) { ?> class="ofline" <?php } else { ?> class="online" <?php } ?>></span>
                            <img src="image/user/<?= $row['id'] ?>/100_<?= $row['image'] ?>" class="imgUser"></td>
                        <td><?= $row['name'] . ' ' . $row['last'] ?> <span class="noee"><?= $mod ?></span></td>
                    </tr>
                <?php }
            } ?>
        </table>
    </div>
</div>
<div class="left">
    <?php require 'per11.php' ?>
</div>
