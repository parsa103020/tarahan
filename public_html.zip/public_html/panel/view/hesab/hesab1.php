<?php
Model::sessionInit();
$data = $data[0];
$mony_baner = Model::sessionGet('baner');
$mony_life = Model::sessionGet('life');
$mony_valed = Model::sessionGet('valed');
$mony_flax = Model::sessionGet('flax');
$mony_venil = Model::sessionGet('vinil');
$mony_mesh = Model::sessionGet('mesh');
?>
<style>
    .hederr {
        text-align: center;
        padding: 12px 0 !important;
        position: relative;
    }

    .hederr span {
        width: 100px;
        text-align: center;
        display: block;
        background: #53a3c6;
        font-family: mapno;
        color: white;
        border-radius: 100% 100% 100% 100%;
        position: absolute;
        bottom: -58px;
        height: 100px;
        font-size: 15px;
        box-sizing: border-box;
        padding-top: 17px;
        left: 50%;
        margin-left: -50px;

    }

    .table {
        width: 100%;
        position: relative;
        min-width: 700px;
        background-color: #f7feff;
        border: 1px solid #3da6ff;
        box-sizing: border-box;
        margin-bottom: 30px;
        border-top: none !important;
    }

    .table tr:first-child td {
        background-color: #53a3c6;
        padding: 13px 8px;
        text-align: center;
        font-size: 12px;
        min-width: 80px;
        display: table-cell;
        color: white;
        font-family: mapno !important;
    }

    .table tr:nth-child(even) {
        background-color: white;
    }

    .table tr td {
        padding: 13px 8px;
        text-align: center;
        font-size: 12px;
        min-width: 52px;
        color: #030375;
        line-height: 18px;
        font-family: mapnoS;

    }

    .manag {
        min-height: 360px;
    }

    .not11 {
        width: 300px !important;
        height: 300px;
        margin: auto;
        position: absolute;
        display: inline-block;
        min-width: 300px !important;
        padding: 0 !important;
        left: 50%;
        margin-left: -150px;
        border-radius: 0 0 54% 35%;
        overflow: hidden;
        display: none;

    }

    .not11 img {
        width: 300px;
        height: 300px;
    }

    .not11 span {
        display: block;
        width: 161px;
        position: absolute;
        top: 128px;
        right: 53px;
        background: #f0f0f0;
        height: 93px;
        border-radius: 26%;
        box-sizing: border-box;
        text-align: center;
        padding-top: 27px;
        font-family: mapnoS;
        font-size: 16px;
        line-height: 23px;
    }
</style>
<div class="manag">
    <a href="hesab/hesab2" target="_blank" class="print submit">چاپ</a>
    <?php
    if (count($data[0]) > 0) { ?>
        <div class="hederr"><span>بنر</span></div>
        <table class="table">
            <tr class="heding">
                <td>ردیف</td>
                <td>سفیدی</td>
                <td>پرتی</td>
                <td>منگنه</td>
                <td>لیفه</td>
                <td>ولد</td>
                <td>طول</td>
                <td>عرض</td>
                <td>تعداد</td>
                <td>متراژ</td>
                <td>تاریخ</td>
            </tr>
            <?php
            $sefidi = $p_es = $p_de = $p_op = $mangene = $life = $valed = $metr = 0;
            foreach ($data[0] as $key => $row) {
                $sefidi += $row['sefidi'];
                $p_de += round(($row['perti_device'] / 10000), 2);
                $mangene += $row['mangene'];
                $life += $row['life'];
                $valed += $row['valed'];
                $metr += round(($row['metr'] / 10000), 2);
                ?>
                <tr>
                    <td><?= $key + 1 ?></td>
                    <td><?= $row['sefidi'] ?></td>
                    <td><?= round(($row['perti_device'] / 10000), 2) ?></td>
                    <td><?= $row['mangene'] ?></td>
                    <td><?= $row['life'] ?></td>
                    <td><?= $row['valed'] ?></td>
                    <td><?= $row['tool_b'] ?></td>
                    <td><?= $row['arz_b'] ?></td>
                    <td><?= $row['tedad'] ?></td>
                    <td><?= round(($row['metr'] / 10000), 2) ?></td>
                    <td><?= $row['time_d'] ?></td>
                </tr>
            <?php } ?>
            <tr>
                <td>مجموع</td>
                <td><?= $sefidi ?></td>
                <td><?= $p_de ?></td>
                <td><?= $mangene ?></td>
                <td><?= $life ?></td>
                <td><?= $valed ?></td>
                <td></td>
                <td></td>
                <td></td>
                <td><?= $metr ?></td>
                <td></td>
            </tr>
            <tr>
                <td>دستمزد</td>
                <td></td>
                <td></td>
                <td></td>
                <td><?= number_format($life * $mony_life) ?></td>
                <td><?= number_format($valed * $mony_valed) ?></td>
                <td></td>
                <td></td>
                <td></td>
                <td><?= number_format($metr * $mony_baner) ?></td>
                <td></td>
            </tr>
        </table>
    <?php } ?>
    <?php
    if (count($data[2]) > 0) { ?>
        <div class="hederr"><span>فلکس</span></div>
        <table class="table">
            <tr class="heding">
                <td>ردیف</td>
                <td>سفیدی</td>
                <td>پرتی</td>
                <td>منگنه</td>
                <td>لیفه</td>
                <td>ولد</td>
                <td>طول</td>
                <td>عرض</td>
                <td>تعداد</td>
                <td>متراژ</td>
                <td>ثبت کننده</td>
            </tr>
            <?php
            $sefidi = $p_es = $p_de = $p_op = $mangene = $life = $valed = $metr = 0;
            foreach ($data[2] as $key => $row) {
                $sefidi += $row['sefidi'];
                $p_es += $row['perti_es'];
                $p_de += round(($row['perti_device'] / 10000), 2);
                $p_op += $row['perti_operator'];
                $mangene += $row['mangene'];
                $life += $row['life'];
                $valed += $row['valed'];
                $metr += round(($row['metr'] / 10000), 2);
                ?>
                <tr>
                    <td><?= $key + 1 ?></td>
                    <td><?= $row['sefidi'] ?></td>
                    <td><?= round(($row['perti_device'] / 10000), 2) ?></td>
                    <td><?= $row['mangene'] ?></td>
                    <td><?= $row['life'] ?></td>
                    <td><?= $row['valed'] ?></td>
                    <td><?= $row['tool_b'] ?></td>
                    <td><?= $row['arz_b'] ?></td>
                    <td><?= $row['tedad'] ?></td>
                    <td><?= round(($row['metr'] / 10000), 2) ?></td>
                    <td><?= $row['user'] ?></td>
                </tr>
            <?php } ?>
            <tr>
                <td>مجموع</td>
                <td><?= $sefidi ?></td>
                <td><?= $p_de ?></td>
                <td><?= $mangene ?></td>
                <td><?= $life ?></td>
                <td><?= $valed ?></td>
                <td></td>
                <td></td>
                <td></td>
                <td><?= $metr ?></td>
                <td></td>
            </tr>
            <tr>
                <td>دستمزد</td>
                <td></td>
                <td></td>
                <td></td>
                <td><?= number_format($life * $mony_life) ?></td>
                <td><?= number_format($valed * $mony_valed) ?></td>
                <td></td>
                <td></td>
                <td></td>
                <td><?= number_format($metr * $mony_baner) ?></td>
                <td></td>
            </tr>
        </table>
        <?php
    } ?>
    <?php
    if (count($data[4]) > 0) { ?>
        <div class="hederr"><span>ونیل</span></div>
        <table class="table">
            <tr class="heding">
                <td>ردیف</td>
                <td>سفیدی</td>
                <td>پرتی</td>
                <td>منگنه</td>
                <td>لیفه</td>
                <td>ولد</td>
                <td>طول</td>
                <td>عرض</td>
                <td>تعداد</td>
                <td>متراژ</td>
                <td>ثبت کننده</td>
            </tr>
            <?php
            $sefidi = $p_es = $p_de = $p_op = $mangene = $life = $valed = $metr = 0;
            foreach ($data[4] as $key => $row) {
                $sefidi += $row['sefidi'];
                $p_es += $row['perti_es'];
                $p_de += round(($row['perti_device'] / 10000), 2);
                $p_op += $row['perti_operator'];
                $mangene += $row['mangene'];
                $life += $row['life'];
                $valed += $row['valed'];
                $metr += round(($row['metr'] / 10000), 2);
                ?>
                <tr>
                    <td><?= $key + 1 ?></td>
                    <td><?= $row['sefidi'] ?></td>
                    <td><?= round(($row['perti_device'] / 10000), 2) ?></td>
                    <td><?= $row['mangene'] ?></td>
                    <td><?= $row['life'] ?></td>
                    <td><?= $row['valed'] ?></td>
                    <td><?= $row['tool_b'] ?></td>
                    <td><?= $row['arz_b'] ?></td>
                    <td><?= $row['tedad'] ?></td>
                    <td><?= round(($row['metr'] / 10000), 2) ?></td>
                    <td><?= $row['user'] ?></td>
                </tr>
            <?php } ?>
            <tr>
                <td>مجموع</td>
                <td><?= $sefidi ?></td>
                <td><?= $p_de ?></td>
                <td><?= $mangene ?></td>
                <td><?= $life ?></td>
                <td><?= $valed ?></td>
                <td></td>
                <td></td>
                <td></td>
                <td><?= $metr ?></td>
                <td></td>
            </tr>
            <tr>
                <td>دستمزد</td>
                <td></td>
                <td></td>
                <td></td>
                <td><?= number_format($life * $mony_life) ?></td>
                <td><?= number_format($valed * $mony_valed) ?></td>
                <td></td>
                <td></td>
                <td></td>
                <td><?= number_format($metr * $mony_baner) ?></td>
                <td></td>
            </tr>
        </table>
    <?php } ?>
    <?php
    if (count($data[6]) > 0) { ?>
        <div class="hederr"><span>مش</span></div>
        <table class="table">
            <tr class="heding">
                <td>ردیف</td>
                <td>سفیدی</td>
                <td>پرتی</td>
                <td>منگنه</td>
                <td>لیفه</td>
                <td>ولد</td>
                <td>طول</td>
                <td>عرض</td>
                <td>تعداد</td>
                <td>متراژ</td>
                <td>ثبت کننده</td>
            </tr>
            <?php
            $sefidi = $p_es = $p_de = $p_op = $mangene = $life = $valed = $metr = 0;
            foreach ($data[6] as $key => $row) {
                $sefidi += $row['sefidi'];
                $p_es += $row['perti_es'];
                $p_de += round(($row['perti_device'] / 10000), 2);
                $p_op += $row['perti_operator'];
                $mangene += $row['mangene'];
                $life += $row['life'];
                $valed += $row['valed'];
                $metr += round(($row['metr'] / 10000), 2);
                ?>
                <tr>
                    <td><?= $key + 1 ?></td>
                    <td><?= $row['sefidi'] ?></td>
                    <td><?= round(($row['perti_device'] / 10000), 2) ?></td>
                    <td><?= $row['mangene'] ?></td>
                    <td><?= $row['life'] ?></td>
                    <td><?= $row['valed'] ?></td>
                    <td><?= $row['tool_b'] ?></td>
                    <td><?= $row['arz_b'] ?></td>
                    <td><?= $row['tedad'] ?></td>
                    <td><?= round(($row['metr'] / 10000), 2) ?></td>
                    <td><?= $row['user'] ?></td>
                </tr>
            <?php } ?>
            <tr>
                <td>مجموع</td>
                <td><?= $sefidi ?></td>
                <td><?= $p_de ?></td>
                <td><?= $mangene ?></td>
                <td><?= $life ?></td>
                <td><?= $valed ?></td>
                <td></td>
                <td></td>
                <td></td>
                <td><?= $metr ?></td>
                <td></td>
            </tr>
            <tr>
                <td>دستمزد</td>
                <td></td>
                <td></td>
                <td></td>
                <td><?= number_format($life * $mony_life) ?></td>
                <td><?= number_format($valed * $mony_valed) ?></td>
                <td></td>
                <td></td>
                <td></td>
                <td><?= number_format($metr * $mony_baner) ?></td>
                <td></td>
            </tr>
        </table>
        <?php
    } ?>
    <?php
    if (count($data[8]) > 0) { ?>
        <div class="hederr"><span> متفرقه</span></div>
        <table class="table">
            <tr class="heding">
                <td>ردیف</td>
                <td>سفارش</td>
                <td>مشتری</td>
                <td>قیمت</td>
                <td>مالیات</td>
                <td>سود</td>
                <td>درصد</td>
                <td>سود*درصد</td>
                <td>تاریخ</td>
            </tr>
            <?php
            $allDastmozd = 0;
            foreach ($data[8] as $key => $row) {
                $order = $row['orders'];
                $noe = $row['noe'];
                if ($noe = "hogh") {
                    $maliat = round($row['price_manag'] * 0.09, 0);
                } else {
                    $maliat = 0;
                }
                $manag_price = $row['price_manag'];
                $sood = $row['sood'];
                $dastmozd = $row['sood'] * $row['percent'] * 0.01;
                $allDastmozd += $dastmozd;
                if (is_numeric($dastmozd)) {
                    $dastmozd = number_format($dastmozd);
                }
                if (is_numeric($allDastmozd)) {
                    $allDastmozd = number_format($allDastmozd);
                }
                if (is_numeric($manag_price)) {
                    $manag_price = number_format($manag_price);
                }

                if (is_numeric($maliat)) {
                    $maliat = number_format($maliat);
                }
                if (is_numeric($sood)) {
                    $sood = number_format($sood);
                }

                ?>
                <tr>
                    <td><?= $key + 1 ?></td>
                    <td><?= $order ?></td>
                    <td><?= $row['cos'] ?></td>
                    <td><?= $manag_price ?></td>
                    <td><?= $maliat ?></td>
                    <td><?= $sood ?></td>
                    <td><?= $row['percent'] ?></td>
                    <td><?= $dastmozd ?></td>
                    <td><?= $row['start_d'] ?></td>
                </tr>
            <?php } ?>
            <tr>
                <td>مجموع</td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td><?= $allDastmozd ?></td>
                <td></td>
            </tr>
        </table>
    <?php } ?>
</div>

