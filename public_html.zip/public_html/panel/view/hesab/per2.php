<script src="view/assets/highcharts/highcharts.js"></script>
<script src="view/assets/highcharts/variable-pie.js"></script>

<style>
    #khabgah {
        min-width: 300px;
        width: 100%;
        height: 500px;
        margin: 1em auto;
    }
    #khabgah *{
        font-family: mapnoS !important;
    }
    .err{
        text-align: center;
        margin-top: 30px;
        font-family: mapnoS;
        font-size: 15px;
    }
</style>
<?php
$data = $data[0];
$tedadAll = $data[0];
$design = $data[1];
$baner = $data[2];
$other = $data[3];
$laser = $data[4];
$out = $data[5];

if($tedadAll != 0){
@$designP = ceil(($design / $tedadAll) * 100);
@$banerP = ceil(($baner / $tedadAll) * 100);
@$otherP = ceil(($other / $tedadAll) * 100);
@$laserP = ceil(($laser / $tedadAll) * 100);
@$outP = ceil(($out / $tedadAll) * 100);

?>

<div id="khabgah"></div>
<script type="text/javascript">
    Highcharts.chart('khabgah', {
        chart: {
            type: 'variablepie'
        },
        title: {
            text: 'مقایسه کل سفارشات انجام شده شرکت در واحدها',
            enabled: true,
            useHTML: true,
            color: '#101138'
        },
        tooltip: {
            headerFormat: '',
            enabled: true,
            useHTML: true,
            padding: 20,
            pointFormat: '<span style="color:{point.color}">واحد </span> <b> {point.name}</b><br/>' +
            'تعداد : <b>{point.y}</b><br/>' +
            'سهم از کل(درصد) : <b>{point.z}</b><br/>'
        },

        plotOptions: {
            series: {
                dataLabels: {
                    enabled: true,
                    useHTML: true,
                    color: '#101138'
                }
            }
        },

        series: [{
            minPointSize: 10,
            innerSize: '20%',
            zMin: 0,
            name: 'countries',
            data: [
                {
                    name: 'طراحی',
                    y: <?= $design;  ?>,
                    z: <?= $designP; ?>
                },
                {
                    name: 'بنر',
                    y: <?= $baner;  ?>,
                    z: <?= $banerP; ?>
                }, {
                    name: 'متفرقه',
                    y: <?= $other;  ?>,
                    z: <?= $otherP; ?>
                }, {
                    name: 'لیزر',
                    y: <?= $laser;  ?>,
                    z: <?= $laserP; ?>
                }, {
                    name: 'بیرون',
                    y: <?= $out;  ?>,
                    z: <?= $outP; ?>
                }
            ]
        }]
    });
</script>
<?php }else{ ?>
<div class="err">هیچ سفارشی ثبت نشده است !</div>
<?php } ?>

