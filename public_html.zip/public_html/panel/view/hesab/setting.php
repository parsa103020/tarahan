<?php
$setting = $data[0];
?>
<div class="option">
    <style>
        .option {
            width: 100%;
            min-width: 1300px !important;
            margin: 10px auto;
        }

        .option * {
            text-align: right;
            direction: rtl;
        }

        .mainOption {
            width: 80%;
            min-width: 1000px;
            float: left;
            margin-left: 10px;
            margin-top: 10px;
        }

        .tim {
            position: absolute;
            left: 40px;
            bottom: 0;
            font-size: 12px;
            color: #494972;
        }
    </style>
    <style>
        .in {
            width: 97%;
            height: 100px;
            box-sizing: border-box;
            padding: 10px 0;
            position: relative;
            margin: auto;
        }

        .heder {
            font-family: mapno;
        }

        .attr {
            width: 150px;
            position: relative;
            margin: 20px 0 0 30px;
            display: inline-block;
            height: 35px;
        }

        .input {
            width: 100px;
            position: absolute;
            left: 0;
            top: 0;
            height: 30px;
            box-sizing: border-box;
            border: 1px solid #b7d6ea;
            border-radius: 4px;
            text-align: center;
        }

        .label {
            position: absolute;
            top: 9px;
            right: 0;
            font-family: mapnoS;
        }

        .sub1 {
            display: inline-block;
            padding-top: 0;
            position: absolute;
            height: 32px;
            margin-right: 31px;
        }

        .err {
            display: inline-block;
            position: absolute;
            margin: 74px 35px 0 0;
            color: #346fa2;
            font-family: mapno;
        }
    </style>
    <?php require('optionList.php'); ?>
    <div class="mainOption">
        <div class="hed">تنظیمات
        </div>
        <div class="cont">
            <form action="hesab/editSetting" method="post">
                <div class="in">
                    <div class="heder">ویرایش قیمت های واحد :</div>
                    <div class="attr">
                        <label for="height" class="label">بنر : </label>
                        <input type="number" name="baner" class="input" value="<?= $setting['baner'] ?>" required>
                    </div>
                    <div class="attr">
                        <label for="weight" class="label">فلکس : </label>
                        <input type="number" name="flax" class="input" value="<?= $setting['flax'] ?>" required>
                    </div>
                    <div class="attr">
                        <label for="num" class="label">ونیل : </label>
                        <input type="number" name="vinil" class="input" value="<?= $setting['vinil'] ?>" required>
                    </div>
                    <div class="attr">
                        <label for="num" class="label">مش : </label>
                        <input type="number" name="mesh" class="input" value="<?= $setting['mesh'] ?>" required>
                    </div>
                    <div class="attr">
                        <label for="num" class="label">لیفه : </label>
                        <input type="number" name="life" class="input" value="<?= $setting['life'] ?>" required>
                    </div>
                    <div class="attr">
                        <label for="num" class="label">ولد : </label>
                        <input type="number" name="valed" class="input" value="<?= $setting['valed'] ?>" required>
                    </div>

                <div class="attr">
                    <input type="submit" value="اعمال تغییرات" class="submit sub1">
                </div>
                </div>

        </div>
        </form>
    </div>
</div>
<div class="clear"></div>
<script>
    $('#anbar').addClass('liActiv');
    $('#anbar a').addClass('aActiv');
</script>