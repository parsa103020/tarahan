<script src="view/assets/calendar/js-persian-cal.min.js"></script>

<div class="option">
    <style>
        .price {
            position: absolute;
            top: 137px;
            left: 43px;
            font-family: tahoma;
            font-weight: inherit;
            font-size: 16px;
        }

        .option {
            width: 100%;
            min-width: 1300px !important;
            margin: 10px auto;
        }

        .option * {
            text-align: right;
            direction: rtl;
        }

        .mainOption {
            width: 80%;
            min-width: 1000px;
            float: left;
            margin-left: 10px;
            margin-top: 10px;
        }

    </style>
    <style>
        .table {
            width: 100%;
            position: relative;
            min-width: 700px;
            background-color: #f7feff;
            border: 1px solid #3da6ff;
            box-sizing: border-box;
        }

        .table tr:first-child td {
            background-color: #53a3c6;
            padding: 13px 8px;
            text-align: center;
            font-size: 12px;
            min-width: 65px;
            display: table-cell;
            color: white;
            font-family: mapno !important;
        }

        .table tr:nth-child(even) {
            background-color: white;
        }

        .table tr td {
            padding: 13px 8px;
            text-align: center;
            font-size: 12px;
            min-width: 52px;
            color: #030375;
            line-height: 18px;
            font-family: mapnoS;

        }

        .manag {
            height: 500px;
            overflow-y: auto;
        }

        .search {
            width: 405px;
            height: 40px;
            box-sizing: border-box;
            border: 1px solid #6cdbc7;
            padding: 2px 14px;
            margin: 15px 1px 6px 10px;
            border-radius: 6px;
            font-family: mapnoS;
            font-size: 13px;
            color: #00006d;
        }

        div.picker {
            top: 213px !important;
        }

        #pcal12_pDatePicker {
            top: 270px !important;
        }
    </style>
    <?php require('optionList.php'); ?>
    <div class="mainOption">
        <div class="hed">مدیریت فاکتورها</div>
        <style>
            .into {
                position: absolute;
                left: -183px;
                top: -95px;
            }

            .into .row2 {
                margin: 5px 0px;
            }

            .into .btn_green {
                float: left;
                position: absolute;
                left: -120px;
                top: 35px;
                background: #53a3c6;
                padding: 7px;
                color: white;
                font-size: 11px;
                font-family: mapno;
                border-radius: 3px;
                line-height: 10px;
                cursor: pointer;
            }
        </style>

        <div style="width: 35%;">
            <input type="text" class="search" placeholder="شماره فاکتور یا نام مشتری را وارد کنید ... ">

            <div class="sea">
                <input type="text" id="fcal1" class="pdate s1" style="overflow: hidden" placeholder="شروع تاریخ ">
                <input type="hidden" name="extra" id="extra">
                <span class="two">
                         <input type="text" id="fcal2" class="pdate2 s1"
                                style="overflow: hidden;text-align: center !important;"
                                placeholder="پایان تاریخ ">
                         <input type="hidden" name="extra2" id="extra2">
                     </span>
                <span onclick="search()" class="s2">
                         <img id="ss" src="view/assets/image/search.png" width="16" height="16" alt="search"
                              class="imgSearch">
                </span>
            </div>

        </div>
        <script>
            // active calendar
            var objCal1 = new AMIB.persianCalendar('fcal1',
                {extraInputID: "extra", extraInputFormat: "YYYYMMDD"}
            );
            var objCal2 = new AMIB.persianCalendar('fcal2',
                {extraInputID: "extra2", extraInputFormat: "YYYYMMDD"}
            );
            var span = $('.two');
            span.find('.pcalBtn').addClass('pcalBtn2');

            function submitForm(formId) {
                $('#' + formId).submit();
            }
        </script>
        <script>

            function submitForm(formId) {
                $('#' + formId).submit();
            }
        </script>
        <div class="manag">
        </div>
    </div>

</div>
<style>

    .imgSearch {
        position: absolute;
        width: 20px;
        height: 20px;
        top: 9px;
        right: 9px;
    }

    .s2 {
        width: 38px;
        height: 38px;
        background: #092039;
        display: inline-table;
        border: 1px solid #092039;
        border-radius: 100%;
        position: absolute;
        right: 418px;
        bottom: 7px;
        cursor: pointer;
    }

    .sea {
        position: relative;
        width: 550px;
    }

    a.pcalBtn {
        vertical-align: bottom;
        display: inline-block;
        margin: 0 1px;
        position: absolute;
        top: 9px !important;
        left: 347px;
        background: none;
        width: 200px;
        height: 37px;
        box-sizing: border-box;
        border-radius: 30px;
        text-align: center;
    }

    input.pdate {
        width: 198px;
        height: 35px;
        border-radius: 5px;
        border: 1px solid #6cdbc7;
        margin: 8px 0;
    }

    input.pdate2 {
        width: 198px;
        height: 35px;
        border-radius: 5px;
        border: 1px solid #6cdbc7;
        margin: 8px 0;
    }

    .pcalBtn2 {
        left: 144px !important;
    }
</style>
<div class="clear"></div>

<script>
    function search() {
        var key = $('.search').val();
        if (key == "") {
            key = "mapnoco.ir";
        }
        var start = $('.pdate').val();
        var end = $('.pdate2').val();
        var url = 'hesab/searchFactor';
        var data = {key: key, start: start, end: end};
        $.post(url, data, function (msg) {
            $('.manag').html(msg);
        });
    }

    $('.search').keydown(function () {
        search();
    });

    $('.pdate').keyup(function () {
        search();
    });
    
    $('#factor').addClass('liActiv');
    $('#factor a').addClass('aActiv');
</script>
