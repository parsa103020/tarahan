<script src="<?= U ?>view/assets/highcharts/highcharts.js"></script>
<script src="<?= U ?>view/assets/highcharts/variable-pie.js"></script>


<?php

$data = $data[1];
$moon = $data[0];
$all = $data[1];
$design = $data[2];
$baner = $data[3];
$other = $data[4];
$laser = $data[5];
$out = $data[6];
$values_moon = array_values($moon);
$values_moon = implode(',', $values_moon);
$values_all = array_values($all);
$values_all = implode(',', $values_all);
$values_design = array_values($design);
$values_design = implode(',', $values_design);
$values_baner = array_values($baner);
$values_baner = implode(',', $values_baner);
$values_other = array_values($other);
$values_other = implode(',', $values_other);
$values_laser = array_values($laser);
$values_laser = implode(',', $values_laser);
$values_out = array_values($out);
$values_out = implode(',', $values_out);
?>


<script type="text/javascript">
    $(function () {
        $('#container').highcharts({
            title: {
                text: 'نمودار سفارشات در شش ماه اخیر',
                x: 0 //center
            },
            subtitle: {
                text: 'مپنو',
                x: 0
            },
            xAxis: {
                categories: [<?= $values_moon ?>]
            },
            yAxis: {
                title: {
                    text: 'تعداد سفارش'
                },
                plotLines: [{
                    value: 0,
                    width: 1,
                    color: '#f00'
                }]
            },
            tooltip: {
                valueSuffix: '',
                enabled: true,
                useHTML: true,
                padding: 20
            },

            legend: {
                layout: 'vertical',
                align: 'right',
                verticalAlign: 'middle',
                borderWidth: 0
            },

            series: [{
                name: 'همه سفارشات',
                data: [<?= $values_all ?>]
            }, {
                name: 'طراحی',
                data: [<?= $values_design ?>]
            }, {
                name: 'چاپ بنر',
                data: [<?= $values_baner ?>]
            }, {
                name: 'چاپ متفرقه',
                data: [<?= $values_other ?>]
            }, {
                name: 'لیزر',
                data: [<?= $values_laser ?>]
            }, {
                name: 'بیرون',
                data: [<?= $values_out ?>]
            }
            ]
        });

    });

</script>
<div id="container" style="min-width: 600px;width: 100%; height: 400px; margin: 0 auto"></div>


<style>
    #container * {
        direction: ltr !important;
        text-align: left !important;
        font-family: mapnoS;
    }


</style>


