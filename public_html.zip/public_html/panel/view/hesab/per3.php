<?php
$user = $data[0];
?>
<style>
    .del {
        width: 16px;
        height: 16px;
        margin: 0;
        background: url("view/assets/image/delete.png");
        text-align: center;
        margin: auto;
    }

    .edite {
        width: 16px;
        height: 16px;
        margin: 0;
        background: url("view/assets/image/edit.png");
        text-align: center;
        margin: auto;
    }

    .table1 {
        width: 100%;
        position: relative;
        min-width: 700px;
        background-color: #f7feff;
        border: 1px solid #3da6ff;
        box-sizing: border-box;
    }

    .table1 tr:first-child td {
        background-color: #63bdff;
        padding: 13px 8px;
        text-align: center;
        font-size: 12px;
        min-width: 80px;
        display: table-cell;
        color: white;
        font-family: mapno !important;
    }

    .table1 tr:nth-child(even) {
        background-color: white;
    }

    .table1 tr td {
        padding: 13px 8px;
        text-align: center;
        font-size: 12px;
        min-width: 52px;
        color: #030375;
        line-height: 18px;
        font-family: mapnoS;

    }

    .manag1 {
        overflow-y: auto;
        height: 534px;
    }

    .not11 {
        width: 300px !important;
        height: 300px;
        margin: auto;
        position: absolute;
        display: inline-block;
        min-width: 300px !important;
        padding: 0 !important;
        left: 50%;
        margin-left: -150px;
        border-radius: 0 0 54% 35%;
        overflow: hidden;
        display: none;

    }

    .not11 img {
        width: 300px;
        height: 300px;
    }

    .not11 span {
        display: block;
        width: 161px;
        position: absolute;
        top: 128px;
        right: 53px;
        background: #f0f0f0;
        height: 93px;
        border-radius: 26%;
        box-sizing: border-box;
        text-align: center;
        padding-top: 27px;
        font-family: mapnoS;
        font-size: 16px;
        line-height: 23px;
    }

    .tr {
        height: 44px !important;
    }
</style>
<div class="manag1">
    <?php
    if (count($user) > 0) { ?>
        <table class="table1">
            <tr class="tr">
                <td>ردیف</td>
                <td>نام</td>
                <td>واحد</td>
                <td>کاربری</td>
                <td>ویرایش</td>
                <td>حذف</td>
            </tr>
            <?php foreach ($user as $key => $row) {
                $noe = $row['noe'];
                if ($noe != 'manag') {
                    $noe = $row['noe'];
                    if ($noe == "respect") {
                        $noo = 'پذیرش';
                    }
                    if ($noe == "design") {
                        $noo = 'طراحی';
                    }
                    if ($noe == "baner") {
                        $noo = 'چاپ';
                    }
                    if ($noe == "other") {
                        $noo = 'چاپ دیجیتال';
                    }
                    if ($noe == "out") {
                        $noo = 'مدیر داخلی';
                    }
                    if ($noe == "laser") {
                        $noo = 'لیزر';
                    }
                    if ($noe == "hesab") {
                        $noo = 'حسابداری';
                    }
                    ?>
                    <tr class="tr">
                        <td><?= $key + 1 ?></td>
                        <td><?= $row['name'] . ' ' . $row['last'] ?></td>
                        <td><?= $noo ?></td>
                        <td><?= $row['user'] ?></td>
                        <td><a target="_blank" href="hesab/editPersonel/<?= $row['id']; ?>"><span
                                        class="edite"></span></a></td>
                        <td><a onclick="del(<?= $row['id'] ?>)"><span class="del"></span></a></td>
                    </tr>
                <?php }
            } ?>
        </table>
        <?php
    } ?>
</div>

