<script src="view/assets/calendar/js-persian-cal.min.js"></script>

<style>


    input.valid {
        background-color: #f8f8f8 !important;
    }

    .pcalBtn {
        top: 40px !important;
        right: 9px !important;
    }

    .search2:hover {
        background-color: #d9f3f8 !important;
        border: 1px solid #00a4dc !important;
    }

    .s1 {
        position: relative;
        width: 155px;
        height: 33px;
        border: 1px solid #51bcdc;
        box-sizing: border-box;
        padding: 9px 17px;
        border-radius: 30px;
        display: inline-block;
        color: #022670;
        cursor: pointer;
        margin-left: 10px !important;
        text-align: center;
    }

    .pcalBtn2 {
        top: 40px !important;
        right: 177px !important;
    }

    div.picker {
        top: 225px !important;
    }

    .s2 img {
        position: absolute;
        top: 9px;
        left: 8px;
    }

    .s2 {
        cursor: pointer;
        display: inline-block;
        width: 33px !important;
        height: 33px;
        border: 1px solid #a49898;
        border-radius: 100% !important;
        position: absolute;
        background-color: #101820;
    }

    .contSearch {
        width: 100%;
    }
</style>
<div class="sea">
    <input type="text" id="mcal1" class="pdate s1" style="overflow: hidden" placeholder="شروع تاریخ ">
    <input type="hidden" name="extra" id="extra">
    <span class="two">
        <input type="text" id="mcal2" class="pdate2 s1" style="overflow: hidden;text-align: center !important;"
               placeholder="پایان تاریخ ">
        <input type="hidden" name="extra2" id="extra2">
    </span>
    <span onclick="search()" class="s2">
        <img id="ss" src="view/assets/image/search.png" width="16" height="16" alt="search"></span>
</div>
<div class="contSearch">

</div>
<script>
    function search() {
        var start = $('#mcal1').val();
        var end = $('#mcal2').val();
        var url = "hesab/report3";
        var data = {start: start, end: end};
        $.post(url, data, function (msq) {
            $('.contSearch').html(msq);
        });
    }
    search();

    // active calendar
    var objCal1 = new AMIB.persianCalendar('mcal1',
        {extraInputID: "extra", extraInputFormat: "YYYYMMDD"}
    );
    var objCal2 = new AMIB.persianCalendar('mcal2',
        {extraInputID: "extra2", extraInputFormat: "YYYYMMDD"}
    );
    var span = $('.two');
    span.find('.pcalBtn').addClass('pcalBtn2');

    // hover search btn
    $('.s2').hover(function () {
        $('#ss').animate({width: "17px", height: "17px"}, 70);

    }, function () {
        $('#ss').animate({width: "16px", height: "16px"}, 70);
    });

</script>












