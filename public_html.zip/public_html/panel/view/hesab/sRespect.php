<script src="view/assets/calendar/js-persian-cal.min.js"></script>

<style>


    input.valid {
        background-color: #f8f8f8 !important;
    }

    .sRes {
        position: relative;
        width: 265px;
        height: 39px;
        border: 1px solid #51bcdc;
        box-sizing: border-box;
        padding: 9px 17px;
        border-radius: 3px;
        display: inline-block;
        color: #022670;
        margin-left: 10px !important;
        text-align: right !important;
    }

    .sRes2 img {
        position: absolute;
        top: 9px;
        left: 10px;
    }

    .sRes2 {
        cursor: pointer;
        display: inline-block;
        width: 39px !important;
        height: 35px;
        border: 1px solid #a49898;
        border-radius: 3px 0 0 3px !important;
        position: absolute;
        background-color: #092039;
        right: 233px;
        margin-top: 1px;
    }

    .contSearch {
        width: 100%;
    }
</style>
<div class="sea">
    <input type="text" id="respect" class="sRes" placeholder="شماره سفارش را وارد کنید + اینتر">
    <input type="hidden" name="extra" id="extra">

</div>
<div class="contSearch">

</div>
<script>


    $('#respect').keypress(function (e) {
            if (e.keyCode == 13 && !e.shiftKey) {
                searchRes();
            }
        }
    );

    function searchRes() {
        var id = $('#respect').val();
        var url = "hesab/sRespect";
        var data = {id: id};
        $.post(url, data, function (msq) {
            $('.contSearch').html(msq);
        });
    }


</script>












