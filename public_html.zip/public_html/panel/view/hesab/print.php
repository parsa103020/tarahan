<?php
$print = $data[0];
$factor = $data[1];
$prints = $data[2];
$bayane = $factor['bayane'];
if (is_numeric($factor['bayane'])) {
    $bayane = number_format($bayane);
}
$priceAll = $maliat = $alls = 0;
?>
<style>
    .ax {
        display: inline-block;
        margin: 10px 3px;
        width: 45%;
        position: relative;
    }

    .ax img {
        width: 300px;
    }

    body {
        box-sizing: border-box;
        min-width: 180mm;
        width: 180mm !important;
        max-width: 180mm;
        margin: auto;
        min-height: 200mm;
        background-color: white;
        text-align: center;
        padding-bottom: 50px;
    }

    .cont {
        margin: 0;
        position: relative;
    }

    .hed {
        text-align: center;
        padding: 25px 0 0 0;
        color: black;
        font-family: mapnos;
        box-sizing: border-box;
        cursor: pointer;
    }

    .cus {
        width: 100%;
        margin: 45px 0 15px 0;
        box-sizing: border-box;
        padding: 10px 15px;
    }

    .tex {
        display: inline-block;
        width: 303px;
        height: 28px;
        box-sizing: border-box;
        padding: 5px 10px;
        color: black;
    }

    html {
        background: #e4e4e4;
    }

    .table {
        position: relative;
        width: 100%;
        padding: 1px 2px;
        box-sizing: border-box;
        margin-bottom: 22px;
    }

    .table tr:first-child td {
        background-color: #fff;
        padding: 13px 8px;
        text-align: center;
        font-size: 12px;
        width: 50px;
        display: table-cell;
        color: black;
        font-family: mapno !important;
    }

    .table tr td {
        padding: 13px 8px;
        text-align: center;
        font-size: 12px;
        width: 50px;
        color: black;
        line-height: 18px;
        font-family: mapno;
        border: 1px solid #1a1a1a;
    }

    .fac {
        display: inline-block;
        position: absolute;
        left: 52px;
        top: 44px;
        font-size: 11px;
        font-family: mapno;
    }

    .abc {
        border: 1px solid #2d2d2d;
        width: 226px;
        float: left;
        padding: 10px 0;
    }

    .one {
        text-align: right;
        padding: 10px 14px;
        direction: rtl;
        font-size: 13px;
        font-family: mapno;
        color: black;
        position: relative;
    }

    .del {
        position: absolute;
        right: 5px;
        top: 4px;
        font-family: Arial;
        font-weight: bold;
        font-size: 12px;
        color: red;
        cursor: pointer;
    }

    .none {
        display: none;
    }

    .abc * {
        font-family: mapno !important;
    }

    .rem {
        position: absolute;
        color: red;
        font-family: Arial;
        top: 11px;
        right: 2px;
        font-weight: bold;
        cursor: pointer;
    }

    .heedd {
        display: block;
        font-family: mapno;
        text-align: center;
        margin: 128px auto 13px auto;
    }
    .fac2{
        position: absolute;
        left: 0;
        top: 65px;
    }
    .fac2 input{
        width: 64px;
        border: 1px solid #fffefe;
        margin-left: 2px;
        font-size: 11px;
        font-family: mapno;
    }
</style>
<div class="cont">
    <div class="hed">چاپ و تبلیغات طراحان باستان</div>
    <div class="fac"> شماره فاکتور : <?= $print[0]['factor'] ?></div>
    <div class="fac2"> شماره سند : <input type="text"></div>
    <div class="cus">
        <div class="tex">مشتری : <?= $print[0]['cos'] ?></div>
        <div class="tex">تاریخ دریافت : <?= $print[0]['start_d'] ?></div>
        <div class="tex">تاریخ تحویل : <?= $print[0]['end_d'] ?></div>
        <div class="tex">تعداد سفارش : <?= count($print) ?></div>
        <div class="tex">نحوه تسویه : <?= $factor['pay'] ?></div>
        <div class="tex">بیعانه : <?= $bayane ?> ریال</div>
    </div>
    <?php foreach ($print as $key => $row) {
        $dis = $row['dis'];
        $dis = unserialize($dis);
        $servic = unserialize($row['servic']);
        if (is_array($servic)) {
            $servicValus = array_values($servic);
            $servic = implode(' ،  ', $servicValus);
        }

        if (empty($servic)) {
            $servic = "ندارد";
        }

        $special = unserialize($row['special']);
        if (is_array($special)) {
            $soecialValus = array_values($special);
            $special = implode(' ،  ', $soecialValus);
        }
        if (empty($special)) {
            $special = "ندارد";
        }
        $mony0 = $row['price_manag'];
        if (is_numeric($mony0)) {
            $priceAll += $mony0;
            $mony = number_format($mony0);
        }
        @$mood = $row['mood'];
        if ($mood == 0) {
            $mod = "در حال اجرا";
        } elseif ($mood == 1) {
            $mod = "انجام شده";
        } elseif ($mood == 2) {
            $mod = "لغو شده";
        }
        ?>
        <table class="table table2" id="<?= $key ?>">
            <input type="hidden" class="monyboss" value="<?= $row['price_manag'] ?>">
            <tr>
                <td>کد سفارش</td>
                <td>وضعیت</td>
                <td>مرحله</td>
                <td style="min-width: 250px">جزئیات</td>
                <td>قیمت</td>
            </tr>
            <tr class="row act" >
                <td style="position: relative" data-ids="<?= $row['Id'] ?>" class="ids"><?= $row['Id'] ?><span class="del">X</span></td>
                <td><?= $mod ?></td>
                <td>پذیرش</td>
                <td><?= $row['orders'] . " </br> خدمات : " . $servic . '  </br> خدمات ویژه : ' . $special ?></td>
                <td>0</td>
            </tr>
            <?php foreach ($dis as $row2) { ?>
                <tr class="row act" id="<?= $key ?>">
                    <td style="border: none !important;"></td>
                    <td style="border: none !important;"></td>
                    <td><?= $row2[0] ?></td>
                    <td><?= $row2[4] ?></td>
                    <td><?= $row2[3] ?></td>
                </tr>
            <?php } ?>
        </table>
    <?php } ?>
    <?php
    if (is_numeric($priceAll) && $priceAll != 0) {
        $maliat = (9 * $priceAll) / 100;
        $alls = $maliat + $priceAll;
        $alls = number_format($alls);
        $maliat = number_format($maliat);
        $priceAll = number_format($priceAll);
        ?>
        <div class="abc">
            <div class="one "> مجموع هزینه ها : <span class="all"><?= $priceAll ?></span> ریال</div>
            <?php if ($print[0]['factor'] < 1000000000) { ?>
                <div class="one to"><span class="rem">X</span> مالیات بر ارزش افزوده :<span
                            class="mal"><?= $maliat ?></span> ریال
                </div>
                <div class="one to"> قیمت نهایی : <span class="gole"><?= $alls ?></span> ریال</div>
            <?php } ?>
        </div>
    <?php } ?>

    <?php if (count($prints) > 0) { ?>
        <div class="heedd">جزئیات واحد چاپ</div>
        <table class="table chap">
            <tr>
                <td>سفارش</td>
                <td>متراژ (متر)</td>
                <td>پرتی (متر)</td>
                <td>منگنه</td>
                <td>سفیدی (متر)</td>
                <td>لیفه (متر)</td>
                <td>ولد (متر)</td>
                <td>طراحی</td>
            </tr>
            <?php foreach ($prints as $row) { ?>
                <tr class="<?= $row['orderid'] ?>">
                    <td><?= $row['orderid'] ?></td>
                    <td><?= $row['metr'] / 10000 ?></td>
                    <td><?= $row['perti_device'] ?></td>
                    <td><?= $row['mangene'] ?></td>
                    <td><?= $row['sefidi'] ?></td>
                    <td><?= $row['life'] ?></td>
                    <td><?= $row['valed'] ?></td>
                    <td></td>
                </tr>
                <tr class="<?= $row['orderid'] ?>">
                    <td>فی -></td>
                    <td><?= $row['fee_metr'] ?></td>
                    <td><?= $row['fee_perti'] ?></td>
                    <td><?= $row['fee_man'] ?></td>
                    <td><?= $row['fee_sefidi'] ?></td>
                    <td><?= $row['fee_life'] ?></td>
                    <td><?= $row['fee_valed'] ?></td>
                    <td><?= $row['fee_design'] ?></td>
                </tr>
            <?php } ?>
        </table>
    <?php } else { ?>
        <div style="margin-top: 130px"></div>
    <?php } ?>
    <div class="axs" style="margin-top: 30px;text-align: center !important;">
        <?php foreach ($print as $row) {
            if (!empty($row['img'])) {
                ?>
                <div class="ax"><img src="image/order/<?= $row['Id'] ?>/<?= $row['img'] ?>">
                </div>
            <?php }
            if (!empty($row['file_design'])) { ?>
                <div class="ax"><img src="image/order/<?= $row['Id'] ?>/<?= $row['file_design'] ?>">
                </div>
            <?php }
        } ?>

    </div>
</div>
<script>
    var item;
    var fee;
    var length = ($('.cont').find('.table2').length) + 1;
    var maliat;
    var gole;

    function price() {
        var allFee = 0;
        for (var k = 0; k < length; k++) {
            item = $('#' + k);
            if (item !== undefined && item.length === 1) {
                fee = parseInt(item.find('.monyboss').val(), 10);
                allFee += fee;
            }
        }
        maliat = (9 * allFee) / 100;
        gole = parseInt(allFee, 10) + parseInt(maliat, 10);
        maliat = maliat.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1.");
        gole = gole.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1.");
        allFee = allFee.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1.");
        if (allFee == 'NaN') {
            allFee = 0;
        }
        $('.all').text(allFee);
        $('.mal').text(maliat);
        $('.gole').text(gole);
    }

    $('.del').click(function () {
        var orderid = $(this).parents('.ids').attr('data-ids');
        $(this).parents('.table').removeClass('.act').remove();
        $('.chap').find('.'+orderid).remove();
        price();
    });
    $('.hed').click(function () {
        $('.del').fadeToggle(100);
        $('.rem').fadeToggle(100);
    });
    $('.rem').click(function () {
        $('.to').fadeOut(100);
    })
</script>





















