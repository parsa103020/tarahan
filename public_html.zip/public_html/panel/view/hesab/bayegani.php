<?php
$order = $data[0];
?>
<div class="option">
    <style>
        .option {
            width: 100%;
            min-width: 1300px !important;
            margin: 10px auto;
        }

        .option * {
            text-align: right;
            direction: rtl;
        }

        .mainOption {
            width: 80%;
            min-width: 1000px;
            float: left;
            margin-left: 10px;
            margin-top: 10px;
        }

    </style>
    <style>
        .table {
            width: 100%;
            position: relative;
            min-width: 700px;
            background-color: #f7feff;
            border: 1px solid #3da6ff;
            box-sizing: border-box;
        }

        .table tr:first-child td {
            background-color: #53a3c6;
            padding: 13px 8px;
            text-align: center;
            font-size: 12px;
            min-width: 80px;
            display: table-cell;
            color: white;
            font-family: mapno !important;
        }

        .table tr:nth-child(even) {
            background-color: white;
        }

        .table tr td {
            padding: 13px 8px;
            text-align: center;
            font-size: 12px;
            min-width: 52px;
            color: #030375;
            line-height: 18px;
            font-family: mapnoS;

        }

        .manag {
            height: 500px;
            overflow-y: auto;
        }

    </style>
    <?php require('optionList.php'); ?>
    <div class="mainOption">
        <div class="hed">بایگانی</div>
        <div class="manag">
            <table class="table">
                <tr class="heding">
                    <td>شماره فاکتور</td>
                    <td style="min-width: 200px">سفارش</td>
                    <td>مشتری</td>
                    <td>جزییات</td>
                    <td>فاکتور</td>
                </tr>
                <?php foreach ($order as $key => $row) {
                    $order = $row['orders'];
                    $level = unserialize($row['level']);
                    $arr=[];
                    if(is_array($arr)){
                        $arr = implode(' => ',$arr);
                    }
                    ?>
                    <tr>
                        <td><?= $row['factor'] ?></td>
                        <td><?= $order ?></td>
                        <td><?= $row['cos'] ?></td>
                        <td><a target="_blank" href="hesab/oneRespect/<?= $row['id'] ?>"><img src="view/assets/image/review.png"
                                                                         style="cursor: pointer"></a></td>
                        <td><a target="_blank" href="hesab/print/<?= $row['factor'] ?>"><img src="view/assets/image/review.png"
                                                                         style="cursor: pointer"></a></td>
                    </tr>
                <?php } ?>
            </table>
        </div>
    </div>

</div>
<div class="clear"></div>

<script>
    $('#bayegani').addClass('liActiv');
    $('#bayegani a').addClass('aActiv');
</script>