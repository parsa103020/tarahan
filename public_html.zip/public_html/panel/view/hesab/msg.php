<?php
@$msg = $data[0];
?>
<?php
if (count($msg) > 0) {
    foreach ($msg as $row) { ?>
        <div class="textmsg"><?= $row['text'] ?><span class="tim"><?= $row['time_d'] ?></span> <a onclick="check(<?= $row['id'] ?>)" class="del" title="حذف">X</a></div>
    <?php }
} else { ?>
    <div class="textno errNo">شما هیچ یادآوری جدیدی ندارید :)</div>
<?php } ?>
