<?php
$orders = $data[0];
$level = $data[1];
$order = $orders['orders'];

$lev = unserialize($orders['level']);
$nameLev = $orders['now'];

$servic = unserialize($orders['servic']);
if (is_array($servic)) {
    $servicValus = array_values($servic);
    $servic = implode(' ،  ', $servicValus);
}

$special = unserialize($orders['special']);
if (is_array($special)) {
    $specialValus = array_values($special);
    $special = implode(' ،  ', $specialValus);
}
$mony = $orders['price_design'];
if (!empty($mony) && is_numeric($mony)) {
    $mony = number_format($mony);
}
@$mony_out = $orders['price_out'];
if (!empty($mony_out) && is_numeric($mony_out)) {
    $mony_out = number_format($mony_out);
}
@$mony_design = $orders['price_design'];
if (!empty($mony_design) && is_numeric($mony_design)) {
    $mony_design = number_format($mony_design);
}
$mony_respect = $orders['mony'];
if (!empty($mony_respect) && is_numeric($mony_respect)) {
    $mony_respect = number_format($mony_respect);
}


$dis = unserialize($orders['dis']);
if (is_array($dis)) {
    foreach ($dis as $key => $row) {
        if ($row[0] == 'لیزر') {
            $description = $row[4];
            $monyy = $row[3];
            if (!empty($monyy) && is_numeric($monyy)) {
                $monyy = number_format($monyy);
            }
        }
    }
}
@$plaxi = $data[2];
@$laser = $data[3];
@$rang = $data[4];
@$jens = $data[5];
@$setting = $data[6];
$ok22 = $ok = 0;
if (is_array($laser)) {
    $ok22 = $ok = 1;
    $tool = $laser['tool'];
    $weigh = $laser['weight'];
    $height = $laser['height'];
    $tedad = $laser['tedad'];
    $time = $laser['time'];
    $price = $laser['price'];
    $price2 = $laser['price2'];
    $color = $laser['color'];
    $jens = $laser['jens'];
    $date_laser = $laser['date_d'];
}
?>
<div class="option">
    <style>

        .payvast {
            background: #fff7f7;
            padding: 20px 20px;
            color: red;
        }

        .option {
            width: 100%;
            min-width: 1300px !important;
            margin: 10px auto;
        }

        .option * {
            text-align: right;
            direction: rtl;
        }

        .mainOption {
            width: 80%;
            min-width: 1000px;
            float: left;
            margin-left: 10px;
            margin-top: 10px;
        }

    </style>
    <style>
        .page {
            padding: 20px 10px;
            position: relative;
        }

        #order {
            width: 694px;
            margin: 10px auto;
            min-width: 400px;
            height: 86px;
            font-size: 13px;
            font-family: mapnoS;
            border: 1px solid #c0e6e3;
            box-sizing: border-box;
            padding: 8px 10px;
            border-radius: 4px;
            resize: none;
        }

        .laborder {
            display: block;
            margin-bottom: 5px;
        }

        .attr {
            width: 300px;
            height: 60px;
            margin-top: 24px;
            display: inline-block;
            margin-left: 25px;
        }

        .label {
            display: block;
            margin-right: 5px;
        }

        .input {
            display: block;
            margin-top: 15px;
            width: 300px;
            height: 35px;
            box-sizing: border-box;
            border: 1px solid #c0e6e3;
            border-radius: 5px;
            padding: 4px 10px;
        }

        .attr1 {
            width: 220px;
            height: 60px;
            margin-top: 24px;
            display: inline-block;
            position: relative;
            margin-left: 13px;
        }

        .label1 {
            margin-left: 10px;
            position: absolute;
            right: 0;
            top: 8px;
        }

        .input1 {
            width: 132px;
            height: 35px;
            box-sizing: border-box;
            border: 1px solid #c0e6e3;
            border-radius: 5px;
            padding: 4px 10px;
            position: absolute;
            left: 0;
            top: -4px;
            text-align: center;
            direction: ltr;
        }

        input, select {
            background: white;
        }

        .file {
            position: absolute;
            width: 74px;
            left: 8px;
            top: 3px;
        }

        .line {
            width: 689px;
            border-bottom: 1px dashed #19b5fe;
            position: absolute;
            bottom: 0;
        }

        .line2 {
            width: 689px;
            border-bottom: 1px dashed #19b5fe;
            bottom: 0;
        }

        .in {
            width: 715px;
            position: relative;
            height: 180px;
        }

        .sub {
            border: 1px solid #1d3b3e;
            position: absolute;
            bottom: 125px;
            left: 366px;
            padding-top: 0 !important;
        }

        .img {
            position: absolute;
            left: 30px;
            top: 37px;
            z-index: 33;
            border: 1px solid #8198af;
            border-radius: 4px;
            overflow: hidden;
            height: 317px;
            width: 300px;
        }

        .img img {
            width: 100%;
            height: 100%;
            position: absolute;
            top: 0;
            left: 0;
        }

        .img:hover {
            left: 150px;
            transform: scale(1.8);
            box-shadow: 0 0 10px 1px #1e4561;
            z-index: 99;
            transition: 0.8s;
        }

        .men {
            display: inline-block;
            margin-right: 27px;
            margin-top: 2px;
        }

        .men a {
            color: #f4f8ff !important;
        }

        .men a:hover {
            color: #28e1ff !important;
        }

        .span {
            position: relative;
            width: 44px;
            display: inline-block;
        }

        .span img {
            position: absolute;
            top: -12px;
            right: 10px;
        }

        .don {
            position: absolute;
            right: -3px;
            bottom: 30px;
            width: 200px;
        }

        .don2 {
            position: absolute;
            right: 220px;
            bottom: 30px;
            width: 200px;
        }

        #dis {
            width: 690px;
            height: 88px;
            border: 1px solid #EEE;
            resize: none;
            border-radius: 4px;
            padding: 10px 20px;
            box-sizing: border-box;
            font-size: 13px;
            font-family: mapno;
        }

        .lab {
            font-family: mapno;
            margin: 13px 2px 8px 0;
        }

        .subDis {
            padding-top: 0 !important;
            position: absolute;
            bottom: 30px;
            right: 588px;
        }

        .line2 {
            width: 689px;
            border-bottom: 1px dashed #19b5fe;
            position: absolute;
            bottom: 95px;
        }

        .baner {
            display: inline-block;
            width: 158px;
            text-align: center;
            border: 1px solid #c0e6e3;
            border-radius: 3px;
            height: 30px;
            box-sizing: border-box;
            margin: 20px 0 0 15px;
        }

        .subBaner {
            padding-bottom: 10px;
            position: absolute;
            bottom: 23px;
            left: 26px;
        }
    </style>
    <?php require('optionList.php'); ?>
    <div class="mainOption">
        <div class="hed">مدیریت سفارشات
            <div class="men">
                <a href="laser/manag">سفارشات</a>
                <span class="span"><img src="view/assets/image/double-arrow.png" width="20" height="20"></span>
                <a>سفارش <?= @$orders['cos'] ?></a>
            </div>
        </div>

        <?php if (!empty($orders['payvast'])) { ?>
            <div class="payvast">
                <?= $orders['payvast'] ?>
            </div>
        <?php } ?>

        <div class="page">
            <div class="in">
                <form action="laser/setChange/<?= $orders['id'] ?>" method="post" enctype="multipart/form-data">
                    <div class="attr1">
                        <label for="factor" class="label1">مرحله ی بعد : </label>
                        <select name="next" id="next" name="next" class="input1" required>
                            <option value=""></option>
                            <?php foreach ($level as $row) { ?>
                                <?php if ($row['name'] != 'لیزر') { ?>
                                    <option value="<?= $row['name'] ?>" <?php if (isset($nameLev) && $nameLev == $row['name']) {
                                        echo "selected";
                                    } ?>><?= $row['name'] ?></option>
                                <?php }
                            } ?>
                        </select>
                    </div>
                    <div class="line2"></div>
                    <?php if (!empty($orders['img'])) { ?>
                        <a class="submit don" href="image/order/<?= @$orders['id'] ?>/<?= @$orders['img'] ?>"
                           rel="nofollow"
                           download target="_blank">دانلود پیوست پذریش</a>
                    <?php } ?>
                    <?php if (!empty($orders['file_design'])) { ?>
                        <a class="submit don2" href="image/order/<?= @$orders['id'] ?>/<?= @$orders['file_design'] ?>"
                           rel="nofollow"
                           download target="_blank">دانلود پیوست طراحی</a>
                    <?php } ?>
                    <?php if ($ok == 1) { ?>
                        <input type="submit" value="اعمال تغییرات" class="submit sub">
                    <?php } ?>
                </form>
                <div class="line"></div>
            </div>
            <style>
                .attr2 {
                    width: 180px;
                    height: 40px;
                    position: relative;
                    display: inline-block;
                    margin: 10px 11px 0 44px;
                }

                .input2 {
                    position: absolute;
                    left: 0;
                    width: 120px;
                    height: 36px;
                    border: 1px solid #d7f1ff;
                    box-sizing: border-box;
                    border-radius: 3px;
                    text-align: center;
                    padding: 3px 5px;
                    font-family: mapnoS;
                }

                .label2 {
                    position: absolute;
                    right: 0;
                    top: 11px;
                    font-size: 13px;
                    font-family: mapnoS;
                }
            </style>
            <input type="hidden" value="<?= $setting['one_minet'] ?>" class="minet">
            <input type="hidden" value="<?= $setting['zarib'] ?>" class="zarib">
            <div class="in" style="height: 470px !important;">
                <form method="post" action="laser/des/<?= $orders['id'] ?>">
                    <div class="attr2">
                        <label for="" class="label2">طول : </label>
                        <input type="number" class="input2 tool" id="tool" name="tool" placeholder="cm"
                               required <?php if ($ok22 == 1) {
                            echo "value=$tool";
                        } ?>>
                    </div>
                    <div class="attr2">
                        <label for="" class="label2">عرض : </label>
                        <input type="number" class="input2 weight" name="weight" placeholder="cm"
                               required <?php if ($ok22 == 1) {
                            echo "value=$weigh";
                        } ?>>
                    </div>
                    <div class="attr2">
                        <label for="" class="label2">ضخامت : </label>
                        <select name="heghit" id="heghit" class="input2 height" required>
                            <option value="">انتخاب کنید</option>
                            <?php foreach ($plaxi as $row) { ?>
                                <option value="<?= $row['name'] . '|' . $row['price'] ?>" <?php if (@$height == $row['name']) {
                                    echo 'selected';
                                } ?>><?= $row['name'] ?></option>
                            <?php } ?>
                        </select>

                    </div>
                    <div class="attr2">
                        <label for="" class="label2">رنگ : </label>
                        <select name="color" id="heghit" class="input2 color" required>
                            <option value="">انتخاب کنید</option>
                            <?php foreach ($rang as $row) { ?>
                                <option value="<?= @$row['name'] ?>" <?php if (@$color == $row['name']) {
                                    echo 'selected';
                                } ?>><?= $row['name'] ?></option>
                            <?php } ?>
                        </select>

                    </div>
                    <div class="attr2">
                        <label for="" class="label2">جنس : </label>
                        <select name="jens" id="heghit" class="input2 jens" required>
                            <option value="">انتخاب کنید</option>
                            <?php foreach ($jens as $row) { ?>
                                <option value="<?= @$row['name'] ?>" <?php if (@$jens == $row['name']) {
                                    echo 'selected';
                                } ?>><?= $row['name'] ?></option>
                            <?php } ?>
                        </select>

                    </div>
                    <div class="attr2">
                        <label for="" class="label2">تعداد : </label>
                        <input type="number" class="input2 tedad" name="tedad" placeholder="به عدد بنویسید"
                               required <?php if ($ok22 == 1) {
                            echo "value=$tedad";
                        } ?>>
                    </div>
                    <div class="attr2">
                        <label for="" class="label2">زمان برش : </label>
                        <input step="0.01" type="number" class="input2 time" name="time" placeholder="به دقیقه بنویسید"
                               required <?php if ($ok22 == 1) {
                            echo "value=$time";
                        } ?>>
                    </div>
                    <div></div>
                    <div class="attr2" style="width: 300px !important;">
                        <label for="" class="label2">قیمت تمام شده با 10% پرت: </label>
                        <input style="background: #f6fcff !important; border: none !important;width: 120px !important;"
                               type="text"
                               class="input2 price" name="price" <?php if ($ok22 == 1) {
                            echo "value=$price";
                        } ?>>
                    </div>
                    <div></div>
                    <div class="attr2" style="width: 300px !important;">
                        <label for="" class="label2">قیمت با احتساب بالاسری : </label>
                        <input style="background: #f6fcff !important; border: none !important;" type="text"
                               class="input2 price2" name="price2" <?php if ($ok22 == 1) {
                            echo "value=$price2";
                        } ?>>
                    </div>

                    <div class="lab">توضیحات :</div>
                    <textarea name="des" id="dis" cols="30" rows="10"><?= @$description ?></textarea>
                    <div class="attr1">
                        <?php if ($ok == 0) { ?>
                            <input type="submit" class="submit subDis" value="اعمال تغییرات">
                        <?php } ?>
                    </div>
                </form>
                <div class="line"></div>
            </div>
            <div class="line2"></div>
            <div class="attr1">
                <label for="factor" class="label1">شماره فاکتور : </label>
                <input type="text" class="input1" value="<?= @$orders['factor'] ?>" disabled>
            </div>

            <div class="attr1">
                <label for="start" class="label1">تاریخ سفارش : </label>
                <input type="text" class="input1" name="start" value="<?= @$orders['start_d'] ?>" disabled>
            </div>

            <div class="attr1">
                <label for="factor" class="label1">تاریخ تحویل : </label>
                <input type="text" class="input1" value="<?= @$orders['end_d'] ?>" disabled>
            </div>

            <div>
                <style>

                    .table {
                        width: 100%;
                        position: relative;
                        min-width: 700px;
                        background-color: #f7feff;
                        border: 1px solid #3da6ff;
                        box-sizing: border-box;
                        margin: 20px auto -2px auto;
                    }

                    .table tr:first-child td {
                        background-color: #53a3c6;
                        padding: 13px 8px;
                        text-align: center;
                        font-size: 12px;
                        min-width: 80px;
                        display: table-cell;
                        color: white;
                        font-family: mapno !important;
                    }

                    .table tr:nth-child(even) {
                        background-color: white;
                    }

                    .table tr td {
                        padding: 13px 8px;
                        text-align: center;
                        font-size: 12px;
                        min-width: 52px;
                        color: #030375;
                        line-height: 18px;
                        font-family: mapnoS;

                    }

                    .one {
                        padding: 15px 10px;
                        color: #00007f;
                        font-family: mapnoS;
                    }

                    .price {
                        display: inline-block;
                        width: 260px;
                        background: #f6fcff;
                        padding: 15px 10px;
                        border: 1px solid #3da6ff;
                        text-align: left;
                        margin-bottom: 23px;
                        border-top: none;
                        z-index: 999;
                    }

                    .show {
                        display: inline-block;
                        color: white;
                        position: absolute;
                        left: 40px;
                        margin-top: 1px;
                    }

                    .show2 {
                        display: inline-block;
                        color: white;
                        position: absolute;
                        left: 110px;
                        margin-top: 1px;
                    }

                    .show:hover, .show2:hover {
                        color: #25f5ff;
                        transition: 0.4s;
                    }
                </style>
                <table class="table">
                    <tr>
                        <td>ردیف</td>
                        <td>مرحله</td>
                        <td>جزئیات</td>
                        <td>تاریخ دریافت</td>
                        <td>تاریخ ارسال</td>
                        <td>کاربر</td>
                        <td>هزینه</td>
                    </tr>
                    <tr>
                        <td>1</td>
                        <td>پذیرش</td>
                        <td><?= $order ?></td>
                        <td> <?= $orders['start_d'] ?> </td>
                        <td><?= $orders['respect_out'] ?></td>
                        <td> واحد پذیرش</td>
                        <td>0</td>
                    </tr>
                    <?php
                    $allMony = 0;
                    if (is_array($dis)) {
                        foreach ($dis as $key => $row) {
                            $i = $key + 2;
                            $mony = $row[3];
                            $allMony += $mony;
                            if (!empty($mony) && is_numeric($mony)) {
                                $mony = number_format($mony);
                            }
                            //$arr = [$nowtime, $id, $next];
                            $start = $lev[$key][0];
                            $send = @$lev[$key + 1][0];
                            ?>
                            <tr>
                                <td><?= $i ?></td>
                                <td><?= $row[0] ?></td>
                                <td><?= $row[4] ?></td>
                                <td> <?= $start ?> </td>
                                <td><?= $send ?></td>
                                <td><?= $row[2] ?></td>
                                <td><?= $mony ?></td>
                            </tr>
                        <?php }
                    }
                    ?>
                </table>
            </div>
            <div class="attr">
                <label for="cos" class="label">مشتری : </label>
                <input type="text" class="input" value="<?= @$orders['cos'] ?>" name="special" disabled>
            </div>
            <div class="attr">
                <label for="servic" class="label">خدمات : </label>
                <input type="text" class="input" value="<?= @$servic ?>" name="servic" disabled>
            </div>
            <div class="attr">
                <label for="special" class="label">خدمات ویژه : </label>
                <input type="text" class="input" value="<?= @$special ?>" name="special" disabled>
            </div>

        </div>
    </div>

</div>
<div class="clear"></div>

<script>
    $('#manag').addClass('liActiv');
    $('#manag a').addClass('aActiv');

</script>
<script>


    var price;
    var price2;
    var minet = $('.minet').val();
    var zarib_bala = $('.zarib').val();
    var zarib = 0;

    $('.input2').keyup(function () {
        cal();

    });

    function cal() {
        var tool = $('.tool').val();
        var weight = $('.weight').val();
        var val = $('.height').val();
        var tax = val.split('|');
        var height = tax[0];
        var price_zekhamat = tax[1];
        var tedad = $('.tedad').val();
        var time = $('.time').val();
        var color = $('.color').val();
        var jens = $('.jens').val();

        if (tool.length > 0 && weight.length > 0 && height.length > 0 && tedad.length > 0 && time.length > 0 && color.length > 0 && jens.length > 0) {
            zarib = (price_zekhamat / ((tool * weight) / height)) * 1.1;
            price = ((time * minet) + (tool * weight * height * tedad * zarib)).toFixed(0);
            price1 = price.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1.");
            price2 = (price * zarib_bala).toFixed(0).toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1.");
            $('.price').val(price1);
            $('.price2').val(price2);

        }
    }

</script>

