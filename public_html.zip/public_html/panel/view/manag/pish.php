<div class="option">
    <style>
        .option {
            width: 100%;
            min-width: 1300px !important;
            margin: 10px auto;
        }

        .option * {
            text-align: right;
            direction: rtl;
        }

        .mainOption {
            width: 80%;
            min-width: 1000px;
            float: left;
            margin-left: 10px;
            margin-top: 10px;
        }

        #day {
            display: inline-block;
            width: 190px;
            height: 35px;
            border: 1px solid #90dde0;
            border-radius: 4px;
            margin: 10px 4px 10px 20px;
            color: #0000a9;
        }

        .err{
            display: inline-block;
            margin: 4px 24px;
            font-family: mapnoS;
            display: none;
        }
    </style>
    <?php require('optionList.php'); ?>
    <div class="mainOption">
        <div class="hed">پیشرفته</div>
        <div class="manag">
            <div style="margin-top: 10px;">
                <select name="day" id="day" class="sel">
                    <option value="">انتخاب کنید</option>
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                    <option value="5">5</option>
                    <option value="6">6</option>
                    <option value="7">7</option>
                    <option value="8">8</option>
                    <option value="9">9</option>
                    <option value="10">10</option>
                </select>
                <a class="submit sub">مشاهده</a>
                <span class="err"> لطفا عددی را انتخاب کنید </span>
            </div>

            <div class="cont"></div>

        </div>
    </div>

</div>
<div class="clear"></div>

<script>
    $('.sub').click(function () {
        var day = $('#day').val();
        if (day.length > 0) {
            var data={day:day};
            var url="manag/pish2";
            $.post(url,data,function (msg) {
                $('.cont').html(msg);
            })
        } else {
            $('.err').fadeIn(200).delay(2000).fadeOut(500);
        }
    });

    $('#pish').addClass('liActiv');
    $('#pish a').addClass('aActiv');
</script>