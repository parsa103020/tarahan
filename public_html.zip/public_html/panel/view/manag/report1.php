<?php
$order = $data[0];
?>
<style>
    .table {
        width: 100%;
        position: relative;
        min-width: 700px;
        background-color: #f7feff;
        border: 1px solid #3da6ff;
        box-sizing: border-box;
    }

    .table tr:first-child td {
        background-color: #53a3c6;
        padding: 13px 8px;
        text-align: center;
        font-size: 12px;
        min-width: 80px;
        display: table-cell;
        color: white;
        font-family: mapno !important;
    }

    .table tr:nth-child(even) {
        background-color: white;
    }

    .table tr td {
        padding: 13px 8px;
        text-align: center;
        font-size: 12px;
        min-width: 52px;
        color: #030375;
        line-height: 18px;
        font-family: mapnoS;

    }

    .manag {
        overflow-y: auto;
        height: 333px;
    }

    .not11 {
        width: 300px !important;
        height: 300px;
        margin: auto;
        position: absolute;
        display: inline-block;
        min-width: 300px !important;
        padding: 0 !important;
        left: 50%;
        margin-left: -150px;
        border-radius: 0 0 54% 35%;
        overflow: hidden;
        display: none;

    }

    .not11 img {
        width: 300px;
        height: 300px;
    }
    .not11 span{
        display: block;
        width: 161px;
        position: absolute;
        top: 128px;
        right: 53px;
        background: #f0f0f0;
        height: 93px;
        border-radius: 26%;
        box-sizing: border-box;
        text-align: center;
        padding-top: 27px;
        font-family: mapnoS;
        font-size: 16px;
        line-height: 23px;
    }
</style>
<div class="manag">
    <?php
    if (count($order) > 0) { ?>
        <table class="table">
            <tr class="heding">
                <td>کد سفارش</td>
                <td style="min-width: 200px">سفارش</td>
                <td>شماره فاکتور</td>
                <td>مشتری</td>
                <td>مراحل</td>
                <td>وضعیت</td>
                <td>جزئیات</td>
            </tr>
            <?php foreach ($order as $key => $row) {
                $order = $row['orders'];
                $level = unserialize($row['level']);
                $arr = [];
                if (is_array($level)) {
                    foreach ($level as $index => $lev) {
                        if ($lev[2] == 'مدیریت') {
                            $send = $lev[0];
                        }
                        $arr[] = $lev[2] . ' (' . $lev[0] . ') ';
                    }
                }
                if (is_array($arr)) {
                    $arr = implode(' => ', $arr);
                }
                $mood = $row['mood'];
                if ($mood == 0) {
                    $mod = "در حال اجرا";
                } elseif ($mood == 1) {
                    $mod = "انجام شده";
                } elseif ($mood == 2) {
                    $mod = "لغو شده";
                }
                ?>
                <tr>
                    <td><?= $row['id'] ?></td>
                    <td><?= $order ?></td>
                    <td><?= $row['factor'] ?></td>
                    <td><?= $row['cos'] ?></td>
                    <td>پذیرش(<?= $row['start_d'] ?>) => <?= $arr ?></td>
                    <td> <?= $mod ?> </td>
                    <td><a target="_blank" href="manag/oneRespect/<?= $row['id'] ?>"><img
                                    src="view/assets/image/review.png"
                                    style="cursor: pointer"></a></td>
                </tr>
            <?php } ?>
        </table>
        <?php
    } else { ?>
        <div>
            <div class="not11">
                <span>متسفانه سفارشی یافت نشد :| </span>
                <img src="view/assets/image/not2.jpg">
            </div>
        </div>
        <script>
            $('.not11').fadeIn(900).delay(2000).fadeOut(1000);
        </script>
    <?php } ?>
</div>

