<?php
Model::sessionInit();
$err = '';
if (isset($_SESSION['suc']))
{
    $err=$_SESSION['suc'];
}
unset($_SESSION['suc']);

?>

<div class="option">
    <style>
        .image {
            position: absolute;
            display: inline-block;
            top: 26px;
            left: 46px;
            border-radius: 100%;
            overflow: hidden;
        }

        .end {
            display: inline-block;
            position: absolute;
            top: 147px;
            left: 35px;
            font-size: 14px;
        }

        .start {
            display: inline-block;
            position: absolute;
            top: 117px;
            left: 35px;
            font-size: 14px;
        }

        .sheme {
            display: inline-block;
            position: absolute;
            top: 87px;
            left: 35px;
            font-size: 14px;
        }

        .country {
            display: inline-block;
            position: absolute;
            top: 57px;
            right: 27px;
            font-size: 13px;
            font-family: Byekan;
        }

        .charj {
            display: inline-block;
            position: absolute;
            top: 88px;
            right: 27px;
            font-size: 13px;
            font-family: Byekan;
        }

        .name {
            display: inline-block;
            position: absolute;
            font-size: 13px;
            color: #213148;
            top: 40px;
            right: 33px;
            font-family: mapno;
            font-weight: 500;
        }

        .last {
            display: inline-block;
            position: absolute;
            font-size: 13px;
            color: #213148;
            top: 68px;
            right: 33px;
            font-family: mapno;
        }

        .personel {
            display: inline-block;
            position: absolute;
            font-size: 13px;
            color: #213148;
            top: 97px;
            right: 33px;
            font-family: mapno;
        }

        .msg {
            display: block;
            position: absolute;
            top: 181px;
            width: 334px;
            right: 33px;
            background: rgba(234, 242, 255, 0.8);
            height: 218px;
            box-sizing: border-box;
            padding: 16px 10px;
            border-radius: 14px;
            line-height: 20px;
        }

        .contmsg{
            overflow: auto;
            height: 158px;
        }
        .headmsg {
            text-align: center !important;
            display: block;
            padding-bottom: 6px;
            color: #063958;
        }


        .textmsg {
            overflow: auto;
            padding: 13px 28px 22px 13px;
            color: #063958;
            position: relative;
            font-size: 13px;
            font-family: mapnoS;
            background: #f6fcff;
            margin: 10px 0;
            border-radius: 4px;

        }
        .del{
            position: absolute;
            right: 10px;
            top: 13px;
            font-family: tahoma;
            font-weight: bold;
            font-size: 13px;
            color: #b0c7e6;
        }
        .del:hover{
            color: #f80405;
            transition: 0.7s;
        }

        .textno {
            max-height: 125px;
            padding: 13px 13px 22px 13px;
            color: #063958;
            position: relative;
            text-align: center !important;
        }

        .daletmsg {
            position: absolute;
            top: 21px;
            right: 17px;
            font-family: Tahoma;
            color: white;
            cursor: pointer;
            font-weight: bold;
            font-size: 14px;
        }

        .daletmsg:hover {
            color: #3385a4;
        }

    </style>
    <style>
        .option {
            width: 100%;
            min-width: 1300px !important;
            margin: 10px auto;
        }

        .option * {
            text-align: right;
            direction: rtl;
        }

        .mainOption {
            width: 80%;
            min-width: 1000px;
            float: left;
            margin-left: 10px;
            margin-top: 10px;
        }

        .tim {
            position: absolute;
            left: 6px;
            bottom: 0;
            font-size: 12px;
            color: #494972;
            font-family: mapnoS;
        }
    </style>
    <style>
        .text{
            display: block;
            width: 80%;
            min-width: 700px;
            box-sizing: border-box;
            font-family: mapnoS;
            font-size: 15px;
            padding: 20px;
            border: 1px solid #94d4d1;
            border-radius: 5px;
            height: 200px;
            margin: 15px auto 20px auto;
            resize: none;
        }
        .submit{
            padding-top: 0 !important;
            font-size: 15px;
            display: block;
            margin: auto;
            width: 150px;
            font-family: mapno !important;
        }
        .suc{
            text-align: center;
            margin: 19px auto;
            font-size: 16px;
            font-family: mapnoS;
            color: green;
        }
    </style>
    <?php require('optionList.php'); ?>
    <div class="mainOption">
        <div class="hed">ارسال پیام انبوه
        </div>
        <div class="box">
            <form action="manag/sendMsgs" method="post">
                <textarea name="text" id="text" class="text" placeholder="متن پیام را اینجا بنویسید" required></textarea>
                <input type="submit" value="ارسال" class="submit">
                <div class="suc"><?= $err ?></div>
            </form>
        </div>
    </div>

</div>
<div class="clear"></div>
<script>
    $('#msgs').addClass('liActiv');
    $('#msgs a').addClass('aActiv');
</script>