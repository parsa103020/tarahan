<script src="view/assets/calendar/js-persian-cal.min.js"></script>

<?php
$user = $data[0];
?>
<div class="option">
    <style>
        .option {
            width: 100%;
            min-width: 1300px !important;
            margin: 10px auto;
        }

        .option * {
            text-align: right;
            direction: rtl;
        }

        .mainOption {
            width: 80%;
            min-width: 1000px;
            float: left;
            margin-left: 10px;
            margin-top: 10px;
        }

        .tim {
            position: absolute;
            left: 6px;
            bottom: 0;
            font-size: 12px;
            color: #494972;
            font-family: mapnoS;
        }

        .hed div {
            margin-right: 30px;
            display: inline-block;

        }

        .hed div a {
            font-size: 13px;
            color: #fb721d;
            margin-right: 46px;
        }

        .hed div a:hover {
            color: #fb002e;
        }

        .detail {
            margin: 20px 16px;
            line-height: 33px;
            font-family: tahoma;
            font-size: 13px;
        }

        .tab {
            min-width: 1000px;
            float: right;
            background-color: #0093ff;
            width: 100%;
            font-size: 0;
        }

        .tab li {
            float: right;
            padding: 15px;
            font-size: 13px;
            border-left: 1px solid #0078bf;
            cursor: pointer;
            color: #fff;
            font-family: mapno;
        }

        .tab li:hover {
            box-shadow: 0 0 1px 1px #0064ca;
            transition: 0.7s;
            background-color: #00a8ff;
        }

        .activ {
            background: #fdfffd !important;
            border-top: 1px solid #0093ff;
            color: #020c67 !important;
            box-shadow: 0 0 0 0 #fff !important;
        }

        .tabchilds {
            min-width: 1000px;
            width: 100%;
            float: right;
            background: #fff;
            position: relative;
        }

        .tabchilds div {
            box-sizing: border-box;
            font-size: 12pt;
            padding: 20px 5px;
            width: 100%;
            min-width: 900px;
        }

        ul {
            list-style: none;
        }

        .divs1 {
            display: none;
        }

        .divNew {

        }
    </style>

    <style>


        input.valid {
            background-color: #f8f8f8 !important;
        }

        .pcalBtn {
            top: 40px !important;
            right: 9px !important;
        }

        .search2:hover {
            background-color: #d9f3f8 !important;
            border: 1px solid #00a4dc !important;
        }

        .s1 {
            position: relative;
            width: 155px;
            height: 33px;
            border: 1px solid #51bcdc;
            box-sizing: border-box;
            padding: 9px 17px;
            border-radius: 30px;
            display: inline-block;
            color: #022670;
            cursor: pointer;
            margin-left: 10px !important;
            text-align: center;
        }

        .pcalBtn2 {
            top: 40px !important;
            right: 177px !important;
        }

        div.picker {
            top: 225px !important;
        }

        .s2 img {
            position: absolute;
            top: 9px;
            left: 8px;
        }

        .s2 {
            cursor: pointer;
            display: inline-block;
            width: 33px !important;
            height: 33px;
            border: 1px solid #a49898;
            border-radius: 100% !important;
            position: absolute;
            background-color: #101820;
        }

        .contSearch {
            width: 100%;
            min-height: 240px;
        }
    </style>
    <?php require('optionList.php'); ?>
    <div class="mainOption">
        <div class="hed">گزارشات
        </div>

        <ul class="tab">
            <li data-tab="1" class="activ">سفارشات امروز</li>
            <li data-tab="2"> انجام شده</li>
            <li data-tab="3"> در حال اجر</li>
            <li data-tab="4">لغو شده</li>
            <li data-tab="5">جست و جو فاکتور</li>
            <li data-tab="6">جست و جو سفارش</li>
        </ul>
        <div class="tabchilds">
            <div data-tab="1" class="divss  ">

                <div class="contC">
                    <?php
                    require('report0.php');
                    ?>
                </div>

            </div>
            <div data-tab="2" class="divss divs1"></div>
            <div data-tab="3" class="divss divs1"></div>
            <div data-tab="4" class="divss divs1"></div>
            <div data-tab="5" class="divss divs1"></div>
            <div data-tab="6" class="divss divs1"></div>
        </div>

    </div>

</div>
<div class="clear"></div>


<script>

    $('.tab li').click(function () {
        var idTab = $(this).attr('data-tab');
        $('.divss').hide(0);
        var showTab = $('.tabchilds>div[data-tab = ' + idTab + ']');
        var url = "<?= U;?>manag/rep";
        var data = {'id': idTab};
        $.post(url, data, function (msq) {
            showTab.html(msq);
        });
        showTab.fadeIn(300);
        $('.tab li').removeClass('activ');
        $(this).addClass('activ');
    });

    $('#choose').click(function () {
        var cal = $('#Ccal1').val();
        var url = "<?= U ?>manag/rep0";
        var data = {'day': cal};
        $.post(url, data, function (msq) {
            $('.contC').html(msq);
        });
    });

    $('#rep').addClass('liActiv');
    $('#rep a').addClass('aActiv');
</script>