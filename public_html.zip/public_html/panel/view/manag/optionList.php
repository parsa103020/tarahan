<?php
Model::sessionInit();
$new_notif = Model::sessionGet('new');
?>
<style>
    header {
        display: none;
    }

    .notif {
        width: 25px;
        height: 25px;
        background-color: red;
        display: inline-block;
        position: absolute;
        border-radius: 100%;
        text-align: center;
        box-sizing: border-box;
        color: white;
        font-size: 14px;
        font-family: Arial;
        padding-top: 5px;
        left: 10px;
        top: 10px;
    }
</style>
<div id="toptwo" class="slidertwo">
    <div class="rightslider">
        <div class="menurele">
            <div class="insid">
                <img class="menuimg" src="view/assets/image/project-management.png">
            </div>
        </div>
        <img class="iconSaradtwo" src="view/assets/image/hed.png" width="180" height="25">
    </div>

</div>
<style>
    /* slider  */
    .slider {
        display: none !important;
    }

    .menurele {
        display: inline-block;
        margin: 0;
        width: 55px;
        height: 50px;
        border-left: 1px solid #c5c5c5;
    }

    .insid {
        display: inline-block;
        margin: 0;
        width: 55px;
        height: 49px;
    }

    .menuimg {
        display: table;
        margin: 17px auto;
        width: 24px;
        height: 24px;
        position: absolute;
        top: -4px;
        right: 14px;
    }

    .next {
        display: inline-block;
        position: absolute;
        top: 19px;
        right: 34px;
        width: 6px;
        height: 9px;
        transform: rotate(-180deg);
    }

    .slidertwo {
        width: 100%;
        height: 49px;
        min-height: 50px;
        background-color: #fff;
        box-sizing: border-box;
        -webkit-background-size: cover;
        -moz-background-size: cover;
        -o-background-size: cover;
        background-size: cover;
        border-bottom: 1px solid #c5c5c5;

    }

    .iconSaradtwo {
        display: inline-block;
        position: absolute;
        top: 14px;
        right: 56px;
    }

    .rightslider {
        width: 17%;
        min-width: 230px;
        height: 49px;
        background-color: #fff;
        display: inline-block;
        position: relative;
    }

    #main nav {
        display: none;
    }

    .option {
        width: 100%;
        min-width: 1300px;
        margin: 0 auto;
        min-height: 450px;
    }

    .listKhabgah {
        width: 100%;
        font-size: 13px;
        border: 1px solid #efefef;

    }

    .listKhabgah tr {

    }

    .listKhabgah tr td {
        height: 40px;
        box-sizing: border-box;
        padding: 9px 15px;
        border: 1px solid #efefef;
    }

    .listKhabgah tr:first-child {
        background-color: #9da2a2 !important;
    }

    .listKhabgah tr:nth-child(even) {
        background-color: #e7fff3;
    }

    .hed {
        background-color: #092039;
        width: 100%;
        height: 40px;
        box-sizing: border-box;
        min-width: 500px;
        padding: 12px 15px;
        margin-bottom: 5px;
        border-radius: 5px;
        font-size: 13px;
        color: white;
        font-family: BYekan;
    }

    .itemSelect {
        background: url("view/assets/image/square-list.png");
        width: 10px;
        height: 10px;
        display: inline-block;
        cursor: pointer;
    }

    .itemeye {
        background: url("view/assets/image/eye.png");
        width: 16px;
        height: 16px;
        display: inline-block;
        margin-right: 3px;
        box-sizing: border-box;
        cursor: pointer;
    }

    .btnAdd {
        float: left;
        color: white;
        cursor: pointer;
        padding-left: 5px;
        font-size: 13px !important;
        color: white !important;
    }

    .addKhabgah {
        width: 100%;
        display: none;
        background-color: #fb721d;
        margin: 15px auto;
        padding: 10px 0;
        border-radius: 5px;
        position: relative;
        height: 103px;
        color: white !important;
    }

    .addKhabgah:after {
        content: "";
        display: block;
    }

    .addKhabgah form input {
        width: 172px;
        margin: 4px 21px;
        height: 28px;
        box-sizing: border-box;
        padding-right: 8px;
        direction: ltr;
        border-radius: 2px;
        border: none;
        background-color: #e7fff3;
    }

    .addKhabgah form select {
        margin: 4px 21px;
    }

    .addKhabgah form option {
        width: 151px;
        height: 28px;
        box-sizing: border-box;
        padding-right: 8px;
        direction: ltr;
        border-radius: 2px;
        border: none;
        background-color: #e7fff3;
    }

    #addressKhabgah {
        width: 393px !important;
        margin-right: 21px !important;
    }

    #submitForm {
        box-sizing: border-box;
        width: 92px;
        height: 27px;
        text-align: center;
        background-color: #092039;
        display: inline-block;
        color: white;
        cursor: pointer;
        position: absolute;
        padding-top: 5px;
        border-radius: 3px;
        bottom: 7px;
        left: 84px;
    }

    #submitForm:hover {
        color: #fb721d;
    }

    .btnDelete {
        float: left !important;
        color: white !important;
        cursor: pointer;
        padding-left: 5px;
        font-size: 13px !important;
        margin-left: 20px;
    }

    .btnAdd:hover, .btnDelete:hover {
        color: #fb721d !important;
    }

    .editIcon {
        background: url("<?= U ?>view/assets/image/review.png");
        width: 16px;
        height: 16px;
        display: inline-block;
        margin-right: 3px;
        box-sizing: border-box;
        cursor: pointer;
    }

    .divmessage {
        display: none;
    }

    /* menu2  */
    #menu2 {
        background-color: #092039;
        color: white;
        width: 150px;
        height: 100%;
        max-height: 600px;
        min-height: 400px;
        position: absolute;
        display: inline-block;
        left: -150px;
        z-index: 33;
        top: 0;
    }

    #menu2 ul {
        position: absolute;
        width: 100%;
        height: 100%;
        margin-top: 14px;
        border-radius: 3px;
        list-style: none;
        text-align: right;
        direction: ltr;
    }

    #menu2 ul li {
        box-sizing: border-box;
        margin-top: 10px;
        width: 140px;
        height: 30px;
    }

    #menu2 ul li a {
        box-sizing: border-box;
        font-size: 13px;
        display: block;
        width: 140px;
        height: 30px;
        padding: 8px 10px;
        color: white;
    }

    #menu2 ul li a:hover {
        color: red;
    }

    .img_menu {
        background-image: url("<?= U ?>view/assets/image/menu.png");
        width: 16px;
        height: 16px;
        position: absolute;
        display: inline-block;
        right: -16px;
        top: 2px;
        cursor: pointer;
        z-index: 33;
    }

    .rot90 {
        transform: rotate(+180deg);
        transition: 0.4s;
    }

    .rot0 {
        transform: rotate(0deg);
        transition: 0.4s;
    }

    .slider2 {
        width: 100%;
        height: 60px;
        background-color: #fff;
        box-sizing: border-box;
        display: inline-block;
    }

    .iconSarad2 {
        background: url("<?= U ?>view/assets/image/iconSarad.png");
        display: block;
        position: relative;
        margin-top: 12px;
        margin-right: 40px;
    }
</style>
<style>
    .nash {
        position: absolute;
        display: inline-block;
        width: 231px;
        height: 50px;
        top: -2px;
        right: 25px;
        z-index: 9;
    }

    .textf {
        position: absolute;
        left: -40px;
        top: 13px;
        font-family: Byekan;
        font-size: 13px;
        display: inline-block;
        width: 60px;
        cursor: text;
    }

    .textf:hover {
        color: black !important;
    }

    .finger {
        background: url("view/assets/image/finger.png");
        display: inline-block;
        position: absolute;
        top: 10px;
        left: 15px;
        width: 32px;
        height: 32px;
        cursor: text;
    }

    .telegram-icon1 {
        background: url("view/assets/image/telegram-logo.png");
        display: inline-block;
        position: absolute;
        top: 10px;
        left: 65px;
        width: 32px;
        height: 32px;
    }

    .google-icon1 {
        background: url("view/assets/image/google-plus-hover.png");
        display: inline-block;
        position: absolute;
        top: 10px;
        left: 111px;
        width: 32px;
        height: 32px;
    }

    .instagram-icon1 {
        background: url("view/assets/image/instagram-hover.png");
        display: inline-block;
        position: absolute;
        top: 10px;
        left: 154px;
        width: 32px;
        height: 32px;
    }

    .twitter-icon1 {
        background: url("view/assets/image/twitter-hover.png");
        display: inline-block;
        position: absolute;
        top: 10px;
        left: 196px;
        width: 32px;
        height: 32px;
    }

</style>
<!-- sidebar right -->
<style>

    .option {
        direction: ltr !important;
        text-align: right !important;
    }

    /* sidebar right  */
    .sright {
        min-width: 230px;
        background-color: #fff;
        display: inline-block;
        border-left: 1px solid #c5c5c5;
        border-bottom: 1px solid #c5c5c5;
        min-height: 557px;
        z-index: 999 !important;

    }

    ..sright:after {
        content: "";
        display: block;
        clear: both;
    }

    .ul11 {
        list-style: none;
        overflow: hidden;
    }

    .ul11 li {
        margin: 0;
        border-bottom: 1px solid #c5c5c5;
        position: relative;
        width: 100%;
        height: 46px;
    }

    .ul11 li:hover {
        background-color: #fcfcfc;
    }

    .ul11 li a {
        display: block;
        font-size: 13px;
        padding: 17px 49px 10px 49px;
        position: relative;
        width: 100%;
        height: 100%;
        box-sizing: border-box;
        color: #413f59;
    }

    .ul11 li a:hover {
        color: black !important;
    }

    .liActiv {
    }

    .aActiv {
        color: black !important;
        background-color: #f1f9f6;
    }

    .One-icon {
        background: url("view/assets/image/reservation.png") no-repeat;
        display: inline-block;
        position: absolute;
        width: 24px;
        height: 24px;
        top: 14px;
        right: 12px;
    }

    .payment-icon {
        background: url("view/assets/image/credit-card.png") no-repeat;
        display: inline-block;
        position: absolute;
        width: 24px;
        height: 24px;
        top: 14px;
        right: 12px;

    }

    .transfer-icon {
        background: url("view/assets/image/transfer.png") no-repeat;
        display: inline-block;
        position: absolute;
        width: 24px;
        height: 24px;
        top: 14px;
        right: 12px;
    }

    .warning-icon {
        background: url("view/assets/image/warning.png") no-repeat;
        display: inline-block;
        position: absolute;
        width: 24px;
        height: 24px;
        top: 14px;
        right: 12px;
    }

    .edit-icon {
        background: url("view/assets/image/edit.png") no-repeat;
        display: inline-block;
        position: absolute;
        width: 24px;
        height: 24px;
        top: 14px;
        right: 12px;
    }

    .logOut-icon {
        background: url("view/assets/image/logout.png") no-repeat;
        display: inline-block;
        position: absolute;
        width: 24px;
        height: 24px;
        top: 14px;
        right: 12px;
    }

    .nash {
        display: none;
    }

    /*  contant  */

    .contant {
        float: right;
        width: 48%;
        margin-right: 16px;
        margin-top: 10px;
        border-radius: 15px;
    }

    #titr {
        width: 500px;
        border-radius: 20px;
        margin: auto;
        background-color: #092039;
        margin-top: 15px;

    }

    #titr p {
        font-family: BYekan;
        font-size: 13px;
        padding: 10px;
        text-align: center;
        color: white;
    }

    #etelaat {
        width: 500px;
        margin: auto 13px;
        float: right;
    }

    #etelaat_shakhsi ul {
        list-style: url(view/assets/image/image2.png);
        padding-right: 30px;
        float: right;
        margin-right: 70px;
        min-width: 250px;
    }

    #etelaat_shakhsi ul li p {
        font-family: BYekan;
        font-size: 13px;
        margin: 23px;
        padding: -5px;

    }

    .ax {
        width: 100px;
        height: 120px;
        float: left;
        margin-top: 18px;
        margin-left: -45px;
        border-radius: 100%;
        overflow: hidden;
    }

    .dashbord-icon {
        background: url("view/assets/image/dashboard.png") no-repeat;
        display: inline-block;
        position: absolute;
        width: 24px;
        height: 24px;
        top: 15px;
        right: 11px;
    }

    .manag-icon {
        background: url("view/assets/image/manage.png") no-repeat;
        display: inline-block;
        position: absolute;
        width: 24px;
        height: 24px;
        top: 15px;
        right: 11px;
    }

    .report-icon {
        background: url("view/assets/image/report.png") no-repeat;
        display: inline-block;
        position: absolute;
        width: 24px;
        height: 24px;
        top: 15px;
        right: 11px;
    }

    .taradod-icon {
        background: url("view/assets/image/taradod.png") no-repeat;
        display: inline-block;
        position: absolute;
        width: 24px;
        height: 24px;
        top: 15px;
        right: 11px;
    }

    .news-icon {
        background: url("view/assets/image/news.png") no-repeat;
        display: inline-block;
        position: absolute;
        width: 24px;
        height: 24px;
        top: 15px;
        right: 11px;
    }

    .serach-icon {
        background: url("view/assets/image/list.png") no-repeat;
        display: inline-block;
        position: absolute;
        width: 24px;
        height: 24px;
        top: 14px;
        right: 12px;

    }

    .reserv-icon {
        background: url("view/assets/image/booking.png") no-repeat;
        display: inline-block;
        position: absolute;
        width: 24px;
        height: 24px;
        top: 14px;
        right: 12px;
    }

    .pishsabt-icon {
        background: url("view/assets/image/list.png") no-repeat;
        display: inline-block;
        position: absolute;
        width: 24px;
        height: 24px;
        top: 14px;
        right: 12px;
    }

    .logos {
        display: inline-block;
        position: relative;
        width: 230px;
        height: 215px;
        border-radius: 100%;
        overflow: hidden;
    }

    .logos img {
        display: inline-block;
        position: relative;
        width: 230px;
        height: 118px;
        margin: 0;
    }
</style>
<!-- sidebar right -->
<div class="sright">
    <ul class="ul11">
        <li id="dashbord"><a href="manag/index"><span class="One-icon"></span> داشبورد
                </a></li>
        <li id="manag"><a href="manag/manag"><span class="reserv-icon"></span> سفارشات
                <?php if ($new_notif > 0) { ?> <span class="notif"><?= $new_notif ?></span><?php } ?></a></li>
        <li id="peygiri"><a href="manag/peygiri"><span class="pishsabt-icon"></span> پیگیری سفارشات</a></li>
                <li id="rep"><a href="manag/report"><span class="pishsabt-icon"></span> گزارشات</a></li>
        <li id="pish"><a href="manag/pish"><span class="dashbord-icon"></span> پیشرفته</a></li>
        <li id="per"><a href="manag/per"><span class="news-icon"></span> پرسنل</a></li>
        <li id="msg"><a href="manag/msg"><span class="manag-icon"></span>پیام ها</a></li>
        <li id="msgs"><a href="manag/msgs"><span class="manag-icon"></span>پیام انبوه</a></li>
        <li id="remember"><a href="manag/remember"><span class="report-icon"></span> یاداوری ها</a></li>
        <li id="setting"><a href="manag/setting"><span class="edit-icon"></span> تنظیمات </a></li>
        <!--
        <li id="costumer"><a href="manag/costumer"><span class="reserv-icon"></span> مشتری ها</a></li>
        -->
        <li id="edit"><a href="<?= U ?>manag/edit/0"><span class="edit-icon"></span>ویرایش اطلاعات</a></li>
        <li><a href="<?= U ?>manag/logout"><span class="logOut-icon"></span> خروج </a></li>
    </ul>
    <span class="logos"><img src="view/assets/image/images.jpeg"></span>
</div>




