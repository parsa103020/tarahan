<?php
$user = $data[0];
$err = ' ';
$plaxi = $data[1];
$setting = $data[2];
$digital = $data[3];
?>
<div class="option">
    <style>
        .option {
            width: 100%;
            min-width: 1300px !important;
            margin: 10px auto;
        }

        .option * {
            text-align: right;
            direction: rtl;
        }

        .mainOption {
            width: 80%;
            min-width: 1000px;
            float: left;
            margin-left: 10px;
            margin-top: 10px;
        }

        .tim {
            position: absolute;
            left: 40px;
            bottom: 0;
            font-size: 12px;
            color: #494972;
        }
    </style>
    <style>
        .in {
            width: 97%;
            height: 100px;
            box-sizing: border-box;
            padding: 10px 0;
            position: relative;
            margin: auto;
        }

        .heder {
            font-family: mapno;
        }

        .attr {
            width: 150px;
            position: relative;
            margin: 41px 0 0 30px;
            display: inline-block;
        }

        .input {
            width: 100px;
            position: absolute;
            left: 0;
            top: 0;
            height: 30px;
            box-sizing: border-box;
            border: 1px solid #b7d6ea;
            border-radius: 4px;
            text-align: center;
        }

        .label {
            position: absolute;
            top: 9px;
            right: 0;
            font-family: mapnoS;
        }

        .sub1 {
            display: inline-block;
            padding-top: 0;
            position: absolute;
            margin-top: 40px;
            height: 30px;
            margin-right: 31px;
        }

        .err {
            display: inline-block;
            position: absolute;
            margin: 30px 160px;
            color: #346fa2;
            font-family: mapno;
        }

        .cont {
            border-bottom: 1px dashed #3437ee;
        }

        .table {
            position: relative;
            width: 96%;
            background-color: #f7feff;
            border: 1px solid #3da6ff;
            box-sizing: border-box;
            margin-bottom: 20px;
        }

        .table tr:first-child td {
            background-color: #53a3c6;
            padding: 13px 8px;
            text-align: center;
            font-size: 12px;
            min-width: 80px;
            display: table-cell;
            color: white;
            font-family: mapno !important;
        }

        .table tr:nth-child(even) {
            background-color: white;
        }

        .table tr td {
            padding: 13px 8px;
            text-align: center;
            font-size: 12px;
            min-width: 52px;
            color: #030375;
            line-height: 18px;
            font-family: mapnoS;
        }

        .del {
            width: 16px;
            height: 16px;
            margin: 0;
            background: url("view/assets/image/delete.png");
            text-align: center;
            margin: auto;
            display: block;
        }

        .sub2 {
            display: inline-block;
            padding-top: 0;
            position: absolute;
            margin-top: 42px;
            height: 29px;
            margin-right: -7px;
        }
        .edit2{
            background: azure;
            width: 845px;
            text-align: center;
            padding: 10px 20px;
            height: 120px;
            position: fixed;
            top: 140px;
            box-shadow: 0 0 5px 5px #a6b3cf;
            display: none;
            z-index: 999;
        }
        .hid{
            position: absolute;
            right: 14px;
            top: 10px;
            font-size: 13px;
            font-family: tahoma;
            font-weight: bold;
            color: red;
            cursor: pointer;
        }
    </style>
    <?php require('optionList.php'); ?>
    <div class="mainOption">
        <div class="hed">تنظیمات
        </div>
        <div class="cont" style="min-height: 170px;">
            <form action="manag/editPlaxi" method="post">
                <div class="in">
                    <div class="heder"> قیمت هر شیت پلکسی :</div>
                    <?php foreach ($plaxi as $row) { ?>
                        <div class="attr">
                            <label for="" class="label"><?= $row['name'] ?> میل : </label>
                            <input type="number" name="<?= $row['name'] ?>" class="input" step="1"
                                   value="<?= $row['price'] ?>" required>
                        </div>
                    <?php } ?>
                    <input type="submit" value="اعمال تغییرات" class="submit sub1">
                    <span class="err"><?= @$err ?></span>
                </div>
            </form>
        </div>
        <div class="cont" style="min-height: 160px !important;">
            <div class="heder" style="margin: 20px 0"> سایر تنظیمات :</div>
            <form action="manag/editSetting" method="post">
                <div class="attr" style="margin-top: 0 !important; width: 320px !important;">
                    <label for="" class="label"> قیمت هر دقیقه برش : </label>
                    <input type="number" style="width: 200px !important;" name="minet" class="input"
                           value="<?= $setting['one_minet'] ?>" required>
                </div>
                <div class="attr" style="margin-top: 0 !important; width: 300px !important;">
                    <label for="" class="label"> ضریب بالاسری : </label>
                    <input type="number" style="width: 200px !important;" name="zarib" step="0.01" class="input"
                           value="<?= $setting['zarib'] ?>" required>
                </div>
                <input type="submit" value="اعمال تغییرات" class="submit sub2" style="margin-top: 10px !important;">

            </form>
        </div>
        <div class="cont" style="min-height: 262px;padding-bottom: 50px;">
            <div class="heder" style="margin: 20px 0">تعرفه های واحد چاپ دیجیتال و ویرایش :</div>
            <table class="table">
                <tr>
                    <td>ردیف</td>
                    <td>تعرفه</td>
                    <td>قیمت</td>
                    <td>کاغذ</td>
                    <td>ویرایش</td>
                    <td>حذف</td>
                </tr>
                <?php foreach ($digital as $key => $row) {
                    $mony = $row['price'];
                    ?>
                    <tr class="ro">
                        <input type="hidden" value="<?= $row['id'] ?>" class="ids">
                        <td><?= $key + 1 ?></td>
                        <td class="name"><?= $row['name'] ?></td>
                        <td class="price"><?= $mony ?></td>
                        <td class="paper"><?= $row['paper'] ?></td>
                        <td ><img class="ed" src="view/assets/image/review.png" style="cursor: pointer"></td>
                        <td><a href="manag/deletDig/<?= $row['id'] ?>"><span class="del"></span></a></td>
                    </tr>
                <?php } ?>
            </table>
            <form action="manag/addDigital" method="post" style="height: 75px;">
                <div class="attr" style="margin-top: 0 !important; width: 287px !important;">
                    <label for="" class="label"> نام تعرفه : </label>
                    <input type="text" style="width: 200px !important;" name="name" class="input" required>
                </div>

                <div class="attr">
                    <label for="" class="label"> قیمت : </label>
                    <input type="number" name="price" class="input" required>
                </div>
                <div class="attr">
                    <label class="label"> کاغذ : </label>
                    <select name="paper" id="paper" class="input" required>
                        <option value="">انتخاب کنید</option>
                        <option value="A1">A1</option>
                        <option value="A2">A2</option>
                        <option value="A3">A3</option>
                        <option value="A4">A4</option>
                        <option value="A4">A5</option>
                    </select>
                </div>

                <input type="submit" value="افزودن" class="submit sub2">

            </form>
        </div>

        <div class="edit2">
            <span class="hid">X</span>
            <form action="manag/editDig" method="post">
                <input type="hidden" name="id" class="id">
                <div class="attr" style="margin-top: 0 !important; width: 287px !important;">
                    <label for="" class="label"> نام تعرفه : </label>
                    <input type="text" style="width: 200px !important;" name="name" class="input name" required>
                </div>

                <div class="attr">
                    <label for="" class="label"> قیمت : </label>
                    <input type="number" name="price" class="input price" required>
                </div>
                <div class="attr">
                    <label class="label"> کاغذ : </label>
                    <input type="text" name="paper" style="font-family: Arial" class="input paper" required>
                </div>

                <input type="submit" value="اعمال تغییرات" class="submit sub2">

            </form>
        </div>

    </div>
    <div class="clear"></div>
    <script>

        $(".ed").click(function () {
            $('.edit2').fadeIn(100);
            var parent = $(this).parents('.ro');
            var name = parent.find('.name').text();
            var price = parent.find('.price').text();
            var paper = parent.find('.paper').text();
            var id = parent.find('.ids').val();
            $('.edit2 .name').val(name);
            $('.edit2 .price').val(price);
            $('.edit2 .paper').val(paper);
            $('.edit2 .id').val(id);
        });
        $('.hid').click(function () {
           $('.edit2').fadeOut(0);
        });

        $('#setting').addClass('liActiv');
        $('#setting a').addClass('aActiv');
    </script>