<?php
$data = $data[0];
$respect = $data[0];
$design = $data[1];
$baner = $data[2];
$other = $data[3];
$laser = $data[4];
$out = $data[5];
$tedadRes = count($respect);
$tedadDes = count($design);
$tedadBan = count($baner);
$tedadOth = count($other);
$tedadLas = count($laser);
$tedadOut = count($out);
?>
<div class="row">
    <ul class="tab">
        <li data-id="1" class="activ"><span class="ala"><?= $tedadRes ?></span> پذیرش</li>
        <li data-id="2">طراحی <span class="ala"><?= $tedadDes ?></span></li>
        <li data-id="3">چاپ <span class="ala"><?= $tedadBan ?></span></li>
        <li data-id="4">چاپ دیجیتال <span class="ala"><?= $tedadOth ?></span></li>
        <li data-id="5">لیزر <span class="ala"><?= $tedadLas ?></span></li>
        <li data-id="6">مدیر داخلی <span class="ala"><?= $tedadOut ?></span></li>
    </ul>
    <div class="tabchilds">
        <div data-id="1" class="one">
            <table class="table">
                <tr class="heding">
                    <td>کد سفارش</td>
                    <td style="min-width: 200px">سفارش</td>
                    <td>شماره فاکتور</td>
                    <td>مشتری</td>
                    <td>مراحل</td>
                    <td>وضعیت</td>
                    <td>پیشرفته</td>
                </tr>
                <?php foreach ($respect as $key => $row) {
                    $order = $row['orders'];
                    $level = unserialize($row['level']);
                    $arr = [];
                    if (is_array($level)) {
                        foreach ($level as $index => $lev) {
                            if ($lev[2] == 'مدیریت') {
                                $send = $lev[0];
                            }
                            $arr[] = $lev[2] . ' (' . $lev[0] . ') ';
                        }
                    }
                    if (is_array($arr)) {
                        $arr = implode(' => ', $arr);
                    }
                    $mood = $row['mood'];
                    if ($mood == 0) {
                        $mod = "در حال اجرا";
                    } elseif ($mood == 1) {
                        $mod = "انجام شده";
                    } elseif ($mood == 2) {
                        $mod = "لغو شده";
                    }
                    ?>
                    <tr>
                        <td><?= $row['id'] ?></td>
                        <td><?= $order ?></td>
                        <td><?= $row['factor'] ?></td>
                        <td><?= $row['cos'] ?></td>
                        <td>پذیرش(<?= $row['start_d'] ?>) => <?= $arr ?></td>
                        <td> <?= $mod ?> </td>
                        <td><a target="_blank" href="manag/oneRespect/<?= $row['id'] ?>"><img
                                        src="view/assets/image/review.png"
                                        style="cursor: pointer"></a></td>
                    </tr>
                <?php } ?>
            </table>
        </div>
        <div data-id="2" class="none one">
            <table class="table">
                <tr class="heding">
                    <td>کد سفارش</td>
                    <td style="min-width: 200px">سفارش</td>
                    <td>شماره فاکتور</td>
                    <td>مشتری</td>
                    <td>مراحل</td>
                    <td>وضعیت</td>
                    <td>پیشرفته</td>
                </tr>
                <?php foreach ($design as $key => $row) {
                    $order = $row['orders'];
                    $level = unserialize($row['level']);
                    $arr = [];
                    if (is_array($level)) {
                        foreach ($level as $index => $lev) {
                            if ($lev[2] == 'مدیریت') {
                                $send = $lev[0];
                            }
                            $arr[] = $lev[2] . ' (' . $lev[0] . ') ';
                        }
                    }
                    if (is_array($arr)) {
                        $arr = implode(' => ', $arr);
                    }

                    $status = $row['status'];
                    if ($status == "منتظر تایید مشتری") {
                        $mod = 1;
                    } elseif ($status == "ارسال به واحد طراحی") {
                        $mod = 0;
                    } else {
                        $mod = 2;
                    }

                    ?>
                    <tr <?php if ($mod == 1) { ?> style="background-color: #fffe82" <?php } elseif ($mod == 2) { ?> style="background-color: #7eff6b" <?php } ?>>
                        <td><?= $row['id'] ?></td>
                        <td><?= $order ?></td>
                        <td><?= $row['factor'] ?></td>
                        <td><?= $row['cos'] ?></td>
                        <td>پذیرش(<?= $row['start_d'] ?>) => <?= $arr ?></td>
                        <td> <?= $status ?> </td>
                        <td><a target="_blank" href="manag/oneRespect/<?= $row['id'] ?>"><img
                                        src="view/assets/image/review.png"
                                        style="cursor: pointer"></a></td>
                    </tr>
                <?php } ?>
            </table>
        </div>
        <div data-id="3" class="none one">
            <table class="table">
                <tr class="heding">
                    <td>کد سفارش</td>
                    <td style="min-width: 200px">سفارش</td>
                    <td>شماره فاکتور</td>
                    <td>مشتری</td>
                    <td>مراحل</td>
                    <td>وضعیت</td>
                    <td>پیشرفته</td>
                </tr>
                <?php foreach ($baner as $key => $row) {
                    $order = $row['orders'];
                    $level = unserialize($row['level']);
                    $arr = [];
                    if (is_array($level)) {
                        foreach ($level as $index => $lev) {
                            if ($lev[2] == 'مدیریت') {
                                $send = $lev[0];
                            }
                            $arr[] = $lev[2] . ' (' . $lev[0] . ') ';
                        }
                    }
                    if (is_array($arr)) {
                        $arr = implode(' => ', $arr);
                    }
                    $status = $row['status'];
                    if ($status == "در مرحله چاپ") {
                        $mod = 1;
                    } else {
                        $mod = 0;
                    }
                    ?>
                    <tr <?php if ($mod == 1) { ?> style="background-color: #7eff6b" <?php } ?>>
                        <td><?= $row['id'] ?></td>
                        <td><?= $order ?></td>
                        <td><?= $row['factor'] ?></td>
                        <td><?= $row['cos'] ?></td>
                        <td>پذیرش(<?= $row['start_d'] ?>) => <?= $arr ?></td>
                        <td> <?= $status ?> </td>
                        <td><a target="_blank" href="manag/oneRespect/<?= $row['id'] ?>"><img
                                        src="view/assets/image/review.png"
                                        style="cursor: pointer"></a></td>
                    </tr>
                <?php } ?>
            </table>
        </div>
        <div data-id="4" class="none one">
            <table class="table">
                <tr class="heding">
                    <td>کد سفارش</td>
                    <td style="min-width: 200px">سفارش</td>
                    <td>شماره فاکتور</td>
                    <td>مشتری</td>
                    <td>مراحل</td>
                    <td>وضعیت</td>
                    <td>پیشرفته</td>
                </tr>
                <?php foreach ($other as $key => $row) {
                    $order = $row['orders'];
                    $level = unserialize($row['level']);
                    $arr = [];
                    if (is_array($level)) {
                        foreach ($level as $index => $lev) {
                            if ($lev[2] == 'مدیریت') {
                                $send = $lev[0];
                            }
                            $arr[] = $lev[2] . ' (' . $lev[0] . ') ';
                        }
                    }
                    if (is_array($arr)) {
                        $arr = implode(' => ', $arr);
                    }
                    $status = $row['status'];
                    if ($status == "در مرحله چاپ دیجیتال") {
                        $mod = 1;
                    } else {
                        $mod = 0;
                    }
                    ?>
                    <tr <?php if ($mod == 1) { ?> style="background-color: #7eff6b" <?php } ?>>
                        <td><?= $row['id'] ?></td>
                        <td><?= $order ?></td>
                        <td><?= $row['factor'] ?></td>
                        <td><?= $row['cos'] ?></td>
                        <td>پذیرش(<?= $row['start_d'] ?>) => <?= $arr ?></td>
                        <td> <?= $mod ?> </td>
                        <td><a target="_blank" href="manag/oneRespect/<?= $row['id'] ?>"><img
                                        src="view/assets/image/review.png"
                                        style="cursor: pointer"></a></td>
                    </tr>
                <?php } ?>
            </table>
        </div>
        <div data-id="5" class="none one">
            <table class="table">
                <tr class="heding">
                    <td>کد سفارش</td>
                    <td style="min-width: 200px">سفارش</td>
                    <td>شماره فاکتور</td>
                    <td>مشتری</td>
                    <td>مراحل</td>
                    <td>وضعیت</td>
                    <td>پیشرفته</td>
                </tr>
                <?php foreach ($laser as $key => $row) {
                    $order = $row['orders'];
                    $level = unserialize($row['level']);
                    $arr = [];
                    if (is_array($level)) {
                        foreach ($level as $index => $lev) {
                            if ($lev[2] == 'مدیریت') {
                                $send = $lev[0];
                            }
                            $arr[] = $lev[2] . ' (' . $lev[0] . ') ';
                        }
                    }
                    if (is_array($arr)) {
                        $arr = implode(' => ', $arr);
                    }
                    $status = $row['status'];
                    if ($status == "در مرحله چاپ دیجیتال") {
                        $mod = 1;
                    } else {
                        $mod = 0;
                    }
                    ?>
                    <tr <?php if ($mod == 1) { ?> style="background-color: #7eff6b" <?php } ?>>
                        <td><?= $row['id'] ?></td>
                        <td><?= $order ?></td>
                        <td><?= $row['factor'] ?></td>
                        <td><?= $row['cos'] ?></td>
                        <td>پذیرش(<?= $row['start_d'] ?>) => <?= $arr ?></td>
                        <td> <?= $status ?> </td>
                        <td><a target="_blank" href="manag/oneRespect/<?= $row['id'] ?>"><img
                                        src="view/assets/image/review.png"
                                        style="cursor: pointer"></a></td>
                    </tr>
                <?php } ?>
            </table>
        </div>
        <div data-id="6" class="none one">
            <table class="table">
                <tr class="heding">
                    <td>کد سفارش</td>
                    <td style="min-width: 200px">سفارش</td>
                    <td>شماره فاکتور</td>
                    <td>مشتری</td>
                    <td>مراحل</td>
                    <td>وضعیت</td>
                    <td>پیشرفته</td>
                </tr>
                <?php foreach ($out as $key => $row) {
                    $order = $row['orders'];
                    $level = unserialize($row['level']);
                    $arr = [];
                    if (is_array($level)) {
                        foreach ($level as $index => $lev) {
                            if ($lev[2] == 'مدیریت') {
                                $send = $lev[0];
                            }
                            $arr[] = $lev[2] . ' (' . $lev[0] . ') ';
                        }
                    }
                    if (is_array($arr)) {
                        $arr = implode(' => ', $arr);
                    }
                    $status = $row['status'];
                    if ($status == "ارسال به واحد مدیر داخلی") {
                        $mod = 0;
                    } else {
                        $mod = 1;
                    }
                    ?>
                    <tr <?php if ($mod == 1) { ?> style="background-color: #7eff6b" <?php } ?>>
                        <td><?= $row['id'] ?></td>
                        <td><?= $order ?></td>
                        <td><?= $row['factor'] ?></td>
                        <td><?= $row['cos'] ?></td>
                        <td>پذیرش(<?= $row['start_d'] ?>) => <?= $arr ?></td>
                        <td> <?= $status ?> </td>
                        <td><a target="_blank" href="manag/oneRespect/<?= $row['id'] ?>"><img
                                        src="view/assets/image/review.png"
                                        style="cursor: pointer"></a></td>
                    </tr>
                <?php } ?>
            </table>
        </div>
    </div>
</div>

<script>

    $('.tab li').click(function () {
        var idTab = $(this).attr('data-id');
        $('.one').hide(0);
        var showTab = $('.tabchilds>div[data-id = ' + idTab + ']');
        showTab.fadeIn(300);
        $('.tab li').removeClass('activ');
        $(this).addClass('activ');
    });
</script>
<style>

    .ala {
        position: absolute;
        right: 2px;
        top: 3px;
        display: inline-block;
        width: 20px;
        height: 20px;
        background: white;
        color: blue;
        text-align: center;
        border-radius: 100%;
        box-sizing: border-box;
        padding-top: 2px;
    }

    .tabchilds * {
        font-family: mapnoS;
        font-size: 13px;
    }

    .tabchilds {
        min-width: 1000px;
        width: 100%;
        position: relative;
        background: #fff;
        top: -4px;
    }

    .tabchilds div {
        box-sizing: border-box;
        font-size: 12pt;
        padding: 20px 5px;
        width: 100%;
        min-width: 900px;
        height: 490px;
    }

    .none {
        display: none;
    }

    .row {
        margin: 35px 0;
    }

    .tab {
        background-color: #0093ff;
        font-size: 0;
        display: inline-block;
    }

    .tab li {
        float: right;
        padding: 15px 30px;
        font-size: 13px;
        border-left: 1px solid #0078bf;
        cursor: pointer;
        color: #fff;
        font-family: mapno;
        position: relative;
    }

    .tab li:hover {
        box-shadow: 0 0 1px 1px #0064ca;
        transition: 0.7s;
        background-color: #00a8ff;
    }

    .activ {
        background: #fdfffd !important;
        border-top: 1px solid #0093ff;
        color: #020c67 !important;
        box-shadow: 0 0 0 0 #fff !important;
    }

</style>
<style>
    .table {
        width: 100%;
        position: relative;
        min-width: 700px;
        background-color: #f7feff;
        border: 1px solid #3da6ff;
        box-sizing: border-box;
    }

    .table tr:first-child td {
        background-color: #53a3c6;
        padding: 13px 8px;
        text-align: center;
        font-size: 12px;
        min-width: 80px;
        display: table-cell;
        color: white;
        font-family: mapno !important;
    }
    

    .table tr td {
        padding: 13px 8px;
        text-align: center;
        font-size: 12px;
        min-width: 52px;
        color: #030375;
        line-height: 18px;
        font-family: mapnoS;

    }

    .manag {
        min-height: 500px;
    }

</style>
