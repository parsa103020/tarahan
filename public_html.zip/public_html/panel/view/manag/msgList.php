<?php
$user = $data[0];
$adminId = $data[1];
?>
<input type="hidden" class="userss">
<?php
if (is_array($user)) {
    foreach ($user as $row) {
        $userId = $row['id'];
        $name = $row['last'];
        $text = $row['id'] . '|' . $name = $row['last'];
        $noe = $row['noe'];
        if ($noe == 'respect') {
            $mod = "پذیرش";
        } elseif ($noe == 'design') {
            $mod = "طراحی";
        } elseif ($noe == 'baner') {
            $mod = "بنر";
        } elseif ($noe == 'aser') {
            $mod = "لیزر";
        } elseif ($noe == 'other') {
            $mod = "متفرقه";
        } elseif ($noe == 'out') {
            $mod = "بیرون";
        } elseif ($noe == 'laser') {
            $mod = "لیزر";
        }
        if ($userId != $adminId) {
            ?>
            <li onclick="selectItem('<?= $text ?>')">
                <input type="hidden" name="id" class="id" value="<?= $row['id'] ?>">
                <span class="user" style="overflow: hidden"><?= $name ?> <span class="noee"><?= $mod ?></span></span>
                <span class="imguser">
                                    <?php if (file_exists('image/user/' . $row['id'] . '/100_' . $row['image'])) { ?>
                                        <img src="image/user/<?= $row['id'] ?>/100_<?= $row['image'] ?>" width="64"
                                             height="64">
                                    <?php } else { ?>
                                        <img src="view/assets/image/user.png" width="64" height="64">
                                    <?php } ?>
                        </span>
            </li>
            <?php
        }
    }

} ?>

<style>
    .noee{
        display: block;
        font-size: 11px;
        font-family: mapnoS;
    }
    .warn {
        display: inline-block;
        position: absolute;
        width: 16px;
        height: 16px;
        bottom: 3px;
        right: 3px;
    }
</style>

<script>

    function selectItem(doc) {
        var text = doc.split("|");
        var user = text[0];
        var name = text[1];
        $('.headText').text(name);
        $('.userss').val(user);
        var li = $('.member ul li');
        var textInsert = $('.type');
        var textBox = $('#type');
        var submit = $('.sub');
        var sendId = $('.sendId');

        var data = {id: user};
        var url = 'manag/showMsg';
        $.post(url, data, function (msg) {
            $('#cont').html(msg);
        });
        //fade eext box
        textInsert.fadeIn(0);
        submit.fadeIn(0);
        sendId.val(user);
        scrollDoun();
    }

</script>



