<?php
$user = $data[0];
?>
<div class="option">
    <style>
        .option {
            width: 100%;
            min-width: 1300px !important;
            margin: 10px auto;
        }

        .option * {
            text-align: right;
            direction: rtl;
        }

        .mainOption {
            width: 80%;
            min-width: 1000px;
            float: left;
            margin-left: 10px;
            margin-top: 10px;
        }

        .tim {
            position: absolute;
            left: 6px;
            bottom: 0;
            font-size: 12px;
            color: #494972;
            font-family: mapnoS;
        }
    </style>
    <style>

        .all {
            display: block;
            position: relative;
            width: 900px;
            height: 502px;
            overflow: hidden;
            border: 1px solid #5dd6df;

        }

        .member {
            width: 199px;
            display: inline-block;
            position: absolute;
            top: 0;
            right: 0;
            background: #f9ffff;
            height: 502px;
            border-right: 1px solid #5dd6df;
        }

        .member ul {
            margin-top: 30px;
            overflow: auto;
            height: 488px;
        }

        .member ul li {
            position: relative;
            width: 100%;
            height: 70px;
            background-color: #effcf9;
            cursor: pointer;
        }

        .user {
            position: absolute;
            right: 89px;
            top: 21px;
            font-size: 14px;
            color: #2f494d;
            width: 102px;
            display: inline-block;
            text-align: right;
            font-family: mapnoS;
            line-height: 18px;
        }

        .imguser {
            width: 64px;
            height: 64px;
            display: inline-block;
            position: absolute;
            border-radius: 100%;
            overflow: hidden;
            right: 4px;
            top: 3px;
        }

        .member ul li:hover {
            background-color: #d7f7f5;
        }

        .heduser {
            width: 100%;
            position: absolute;
            display: inline-block;
            height: 30px;
            text-align: center;
            box-sizing: border-box;
            padding-top: 6px;
            font-size: 16px;
            background-color: #02a6ff;
            color: white;
            font-family: mapno;
        }

        .activeli {
            background-color: #489ca5 !important;
        }

        .activeuser {
            color: white !important;
        }

        .msg * {
            direction: rtl !important;
            text-align: right !important;
        }

        .msg {
            height: 472px;
            display: inline-block;
            width: 700px;
            position: absolute;
            top: 30px;
            left: 0;
            text-align: left;
            direction: ltr;
            box-sizing: border-box;
            background-color: #f6fcf7;
        }

        .cont {
            position: absolute;
            width: 100%;
            height: 78%;
            background-color: #f6fcf7;
            top: 0;
            overflow: auto;
            scroll-snap-margin-block-end: 0;
        }

        .type {
            position: absolute;
            width: 100%;
            height: 20%;
            bottom: 0;
            background: white;
            display: none;
        }

        #type {
            position: absolute;
            width: 100%;
            height: 99%;
            border: none;
            box-sizing: border-box;
            padding: 10px 10px 10px 50px;
            text-align: right !important;
            font-size: 13px;
            font-family: mapnoS;
            line-height: 25px;
            overflow: hidden;
            resize: none;
            left: 3px;
        }

        .sub {
            position: absolute;
            display: none;
            bottom: 5px;
            left: 5px;
            font-size: 15px;
            color: green;
            cursor: pointer;
            width: 30px;
            height: 30px;
            border-radius: 100%;
            border: 1px solid #cdfbf2;
            transform: rotate(180deg);
        }

        .sub:hover {
            color: #00f61d !important;
            font-size: 16px !important;
        }

        .resive {
            display: inline-block;
            padding: 12px 30px 17px 75px;
            margin: 10px;
            font-size: 14px;
            font-family: Arial;
            background-color: white;
            border-radius: 43px 10px 16px 2px;
            line-height: 20px;
            max-width: 65%;
            position: relative;
        }

        .sender {
            display: inline-block;
            padding: 12px 75px 17px 30px;
            margin: 10px;
            font-size: 14px;
            font-family: Arial;
            background-color: white;
            border-radius: 17px 52px 4px 17px;
            float: right;
            right: 11px;
            line-height: 20px;
            max-width: 65%;
            position: relative;
        }

        .clear {
            float: none;
            clear: both;
        }

        .color {
            height: 10px;
            position: absolute;
            width: 100%;
            top: -10px;
            background-color: #0f74a8;
            border: 1px solid #0f74a8;
            left: -1px;
            border-radius: 8px 8px 0px 0px;
        }

        .img {
            width: 23px;
            height: 24px;
            position: absolute;
            top: 3px;
            left: 6px;
        }

        .headText {
            position: absolute;
            width: 100%;
            top: -31px;
            height: 30px;
            text-align: center !important;
            font-family: mapno;
            font-size: 16px;
            background-color: #02a6ff;
            color: white;
            padding-top: 7px;
            border: 0.5px solid #5dd6df;
            left: -1px;
            border-left: 1px solid #459ba4;
        }
    </style>
    <?php require('optionList.php'); ?>
    <div class="mainOption">
        <div class="hed">داشبورد
        </div>
        <div class="all">
            <div class="member">
                <span class="heduser">پرسنل</span>
                <ul class="listUs">
                    <?php require "msgList.php" ?>
                </ul>
            </div>
            <div class="msg">
                <div class="headText">ارتباط با پرسنل</div>
                <div class="cont" id="cont" style="padding: 4px 1px"></div>
                <div class="type">
                    <input type="hidden" class="sendId" value="0">
                    <textarea name="type" id="type" autofocus required></textarea>
                </div>
                <span class="sub" onclick="sendMsg()"><img class="img" src="view/assets/image/sendmsg.png"
                                                           alt="Send"></span>
            </div>
        </div>
    </div>

</div>
<div class="clear"></div>

<script>
    var li = $('.member ul li');
    var textInsert = $('.type');
    var textBox = $('#type');
    var sendId = $('.sendId');

    function sendMsg() {
        var newMsg = textBox.val();
        var user = sendId.val();
        if (newMsg.length > 1) {
            var url = "manag/insertNewMsg";
            var data = {msg: newMsg, user: user};
            $.post(url, data, function (msq) {
                textBox.val(" ");
                reset();
                scrollDoun();
            });

        }
    }

    function reset() {
        var user = sendId.val();
        var data2 = {id: user};
        var url2 = 'manag/showMsg';
        $.post(url2, data2, function (msg) {
            $('#cont').html(msg);
        });
    }

    function resetScroll() {
        scrollDoun();
    }

    function scrollDoun() {
        $('#cont').stop().animate({
            scrollTop: $('#cont')[0].scrollHeight
        }, 100);
    }

    textInsert.keypress(function (e) {
            if (e.keyCode == 13 && !e.shiftKey) {
                sendMsg();
            }
        }
    );


</script>
<script>
    $('#msg').addClass('liActiv');
    $('#msg a').addClass('aActiv');
</script>