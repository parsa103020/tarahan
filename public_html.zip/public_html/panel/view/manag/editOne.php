<?php
$orders = $data[0];
$level = $data[1];
$print = $data[2];
$costumer = $data[3];
$order = $orders['orders'];

$chap = 0;

$lev = unserialize($orders['level']);
$nameLev = $orders['now'];

$servic = unserialize($orders['servic']);
if (is_array($servic)) {
    $servicValus = array_values($servic);
    $servic = implode(' ،  ', $servicValus);
}

$special = unserialize($orders['special']);
if (is_array($special)) {
    $specialValus = array_values($special);
    $special = implode(' ،  ', $specialValus);
}
@$mony_out = $orders['price_out'];
if (!empty($mony_out) && is_numeric($mony_out)) {
    $mony_out = number_format($mony_out);
}
@$mony_design = $orders['price_design'];
if (!empty($mony_design) && is_numeric($mony_design)) {
    $mony_design = number_format($mony_design);
}
$mony_respect = $orders['mony'];
if (!empty($mony_respect) && is_numeric($mony_respect)) {
    $mony_respect = number_format($mony_respect);
}


$ok = 0;
$dis = unserialize($orders['dis']);
?>
<div class="option">
    <style>
        .payvast {
            background: #fff7f7;
            padding: 20px 20px;
            color: red;
        }

        .option {
            width: 100%;
            min-width: 1300px !important;
            margin: 10px auto;
        }

        .option * {
            text-align: right;
            direction: rtl;
        }

        .mainOption {
            width: 80%;
            min-width: 1000px;
            float: left;
            margin-left: 10px;
            margin-top: 10px;
        }

    </style>
    <style>
        .page {
            padding: 20px 10px;
            position: relative;
        }

        #order {
            width: 694px;
            margin: 10px auto;
            min-width: 400px;
            height: 86px;
            font-size: 14px;
            font-family: mapnoS;
            border: 1px solid #c0e6e3;
            box-sizing: border-box;
            padding: 8px 10px;
            border-radius: 4px;
            resize: none;
        }

        .laborder {
            display: block;
            margin-bottom: 5px;
        }

        .attr {
            width: 300px;
            height: 60px;
            margin-top: 24px;
            display: inline-block;
            margin-left: 25px;
        }

        .label {
            display: block;
            margin-right: 5px;
        }

        .input {
            display: block;
            margin-top: 15px;
            width: 300px;
            height: 35px;
            box-sizing: border-box;
            border: 1px solid #c0e6e3;
            border-radius: 5px;
            padding: 4px 10px;
        }

        .attr1 {
            width: 220px;
            height: 60px;
            margin-top: 24px;
            display: inline-block;
            position: relative;
            margin-left: 14px;
        }

        .label1 {
            margin-left: 10px;
            position: absolute;
            right: 0;
            top: 8px;
        }

        .input1 {
            width: 132px;
            height: 35px;
            box-sizing: border-box;
            border: 1px solid #c0e6e3;
            border-radius: 5px;
            padding: 4px 10px;
            position: absolute;
            left: 0;
            top: -4px;
            text-align: center;
            direction: ltr;
        }

        input, select {
            background: white;
        }

        .file {
            position: absolute;
            width: 74px;
            left: 8px;
            top: 3px;
        }

        .line {
            width: 689px;
            border-bottom: 1px dashed #19b5fe;
            position: absolute;
            bottom: 0;
        }

        .line2 {
            width: 689px;
            border-bottom: 1px dashed #19b5fe;
            bottom: 0;
        }

        .in {
            width: 100%;
            position: relative;
            border-bottom: 1px dashed #19b5fe;
        }

        .sub {
            border: 1px solid #1d3b3e;
            position: absolute;
            bottom: 36px;
            left: -3px;
            padding-top: 0 !important;
        }

        .img {
            position: absolute;
            left: 30px;
            top: 37px;
            z-index: 33;
            border: 1px solid #8198af;
            border-radius: 4px;
            overflow: hidden;
            height: 317px;
            width: 300px;
        }

        .img img {
            width: 100%;
            height: 100%;
            position: absolute;
            top: 0;
            left: 0;
        }

        .img:hover {
            left: 150px;
            transform: scale(1.8);
            box-shadow: 0 0 10px 1px #1e4561;
            z-index: 99;
            transition: 0.8s;
        }

        .men {
            display: inline-block;
            margin-right: 27px;
            margin-top: 2px;
        }

        .men a {
            color: #f4f8ff !important;
        }

        .men a:hover {
            color: #28e1ff !important;
        }

        .span {
            position: relative;
            width: 44px;
            display: inline-block;
        }

        .span img {
            position: absolute;
            top: -12px;
            right: 10px;
        }

        .don {
            position: absolute;
            right: -3px;
            bottom: 30px;
            width: 200px;
        }

        .don2 {
            position: absolute;
            right: 220px;
            bottom: 30px;
            width: 200px;
        }

        #dis {
            width: 231px;
            height: 35px;
            border: 1px solid #C0E6E3;
            resize: none;
            border-radius: 4px;
            padding: 7px 20px;
            box-sizing: border-box;
            font-size: 14px;
            font-family: mapnoS;
            margin-bottom: 36px;
        }

        .lab {
            font-family: mapno;
            margin: 14px 2px 8px 0;
        }

        .subDis {
            padding-top: 0 !important;
            position: absolute;
            bottom: 30px;
            right: 588px;
        }

        .line2 {
            width: 689px;
            border-bottom: 1px dashed #19b5fe;
            position: absolute;
            bottom: 95px;
        }

        .baner {
            display: inline-block;
            width: 158px;
            text-align: center;
            border: 1px solid #c0e6e3;
            border-radius: 3px;
            height: 30px;
            box-sizing: border-box;
            margin: 20px 0 0 15px;
        }

        .subBaner {
            padding-bottom: 10px;
            position: absolute;
            bottom: 23px;
            left: 26px;
        }

        .at {
            width: 366px;
            height: 52px;
            position: relative;
            margin: 10px 2px 24px 0;
        }

        .input2 {
            position: absolute;
            left: 0;
            top: 0;
        }

        .lab2 {
            top: 15px;
            position: absolute;
        }

        .table {
            width: 100%;
            position: relative;
            min-width: 700px;
            background-color: #f7feff;
            border: 1px solid #3da6ff;
            box-sizing: border-box;
            margin: 20px auto -2px auto;
        }

        .table tr:first-child td {
            background-color: #53a3c6;
            padding: 13px 8px;
            text-align: center;
            font-size: 14px;
            min-width: 80px;
            display: table-cell;
            color: white;
            font-family: mapno !important;
        }

        .table tr:nth-child(even) {
            background-color: white;
        }

        .table tr td {
            padding: 14px 8px;
            text-align: center;
            font-size: 14px;
            min-width: 52px;
            color: #030375;
            line-height: 18px;
            font-family: mapnoS;

        }

        .one {
            padding: 15px 10px;
            color: #00007f;
            font-family: mapnoS;
        }

        .price {
            display: inline-block;
            width: 260px;
            background: #f6fcff;
            padding: 15px 10px;
            border: 1px solid #3da6ff;
            text-align: left;
            margin-bottom: 23px;
            border-top: none;
            z-index: 999;
        }
    </style>
    <style>
        .esh {
            position: absolute;
            left: 40px;
            font-size: 13px;
            cursor: pointer;
        }

        .esh:hover {
            color: #84eeff;
        }

        .dele {
            position: absolute;
            right: 10px;
            top: 10px;
            font-family: tahoma;
            font-weight: bold;
            color: red;
            cursor: pointer;
        }

        .input {
            border: none;
            width: 100px;
            text-align: center;
            background-color: white;
            border-radius: 4px;
            display: inline-block;
            margin-right: 10px;
        }

        .one2, .two2, .thery2, .for2, .five2, .six2, .seven2, .eight2, .nin2, .ten2 {
            display: inline-block;
            width: 81px;
            height: 35px;
            padding-top: 19px;
            font-family: mapnos;
        }

        .one, .two, .thery, .for, .five, .six, .seven, .eight, .nin, .ten {
            height: 46px;
            padding: 0;
        }

        .allFee {
            position: absolute;
            bottom: -2px;
            right: 424px;
            border-bottom: 1px solid red;
            padding-bottom: 5px;
            font-size: 15px;
            font-family: mapnoS;
        }

        .edit2 {
            position: fixed;
            top: 300px;
            right: 50%;
            margin-right: -350px;
            background: azure;
            width: 700px;
            height: 100px;
            padding: 15px 30px;
            z-index: 999;
            box-shadow: 0 0 5px 5px #ced6ef;
            display: none;
        }

        .di1 {
            position: absolute;
            left: 124px;
            margin-top: 2px;
        }

        .di2 {
            position: absolute;
            left: 300px;
            margin-top: 2px;
        }
    </style>
    <?php require('optionList.php'); ?>
    <div class="mainOption">
        <div class="hed">مدیریت سفارشات
            <span class="di1"> نحوه آشنایی : <?= $costumer[1] ?></span>
            <span class="di2"> تلفن : <?= $costumer[0] ?></span>
            <span class="esh">مرجوع </span>
            <div class="men">
                <a href="manag/manag">سفارشات</a>
                <span class="span"><img src="view/assets/image/double-arrow.png" width="20" height="20"></span>
                <a>سفارش <?= @$orders['cos'] ?></a>
            </div>
        </div>

        <?php if (!empty($orders['payvast'])) { ?>
            <div class="payvast">
                <?= $orders['payvast'] ?>
            </div>
        <?php } ?>

        <div class="page">
            <form action="manag/setChange/<?= $orders['Id'] ?>" method="post" enctype="multipart/form-data">
                <div class="in">
                    <div class="attr1">
                        <label for="factor" class="label1">قیمت نهایی : </label>
                        <input type="text" class="input1 feeGole" name="mony" value=""
                               placeholder="به ریال بنویسید" required>
                    </div>
                    <div class="attr1">
                        <label for="factor" class="label1">مرحله ی بعد : </label>
                        <select name="next" id="next" class="input1" required>
                            <option value="حسابداری" selected>حسابداری</option>
                            <option value="لغو">لغو</option>
                        </select>
                    </div>
                    <div class="attr1">
                        <label for="maliat" class="label1">ارزش افزوده : </label>
                        <select name="maliat" id="maliat" class="input1" required>
                            <option value=""></option>
                            <option value="1">دارد</option>
                            <option value="0">ندارد</option>
                        </select>
                    </div>
                    <div class="attr1">
                        <label for="maliat" class="label1">سود (ریال) : </label>
                        <input type="number" name="sood" class="input1" value="0">
                    </div>
                    <div class="attr1">
                        <label for="maliat" class="label1">درصد : </label>
                        <input type="number" name="percent" class="input1" value="40">
                    </div>
                    <textarea name="dis" id="dis" cols="30" rows="10"
                              placeholder="توضیحات خود را اینجا بنویسید"></textarea>


                    <input type="submit" value="اعمال تغییرات" class="submit sub">

                </div>
                <div class="in">
                    <table class="table">
                        <tr>
                            <td>ردیف</td>
                            <td>مرحله</td>
                            <td>جزئیات</td>
                            <td>تاریخ دریافت</td>
                            <td>تاریخ ارسال</td>
                            <td>کاربر</td>
                            <td>هزینه</td>
                        </tr>
                        <tr>
                            <td>1</td>
                            <td>پذیرش</td>
                            <td><?= $order ?></td>
                            <td> <?= $orders['start_d'] ?> </td>
                            <td><?= $orders['respect_out'] ?></td>
                            <td> <?= $orders['name'] . ' ' . $orders['last'] ?> </td>
                            <td>0</td>
                        </tr>
                        <?php
                        $allMony = 0;
                        foreach ($dis as $key => $row) {
                            if ($row[0] == "چاپ") {
                                $chap = 1;
                            }
                            $i = $key + 2;
                            $mony = $row[3];
                            $allMony += $mony;
                            if (!empty($mony) && is_numeric($mony)) {
                                $mony = number_format($mony);
                            }
                            //$arr = [$nowtime, $id, $next];
                            $start = $lev[$key][0];
                            $send = $lev[$key + 1][0];
                            ?>
                            <tr>
                                <td><?= $i ?></td>
                                <td><?= $row[0] ?></td>
                                <td><?= $row[4] ?></td>
                                <td> <?= $start ?> </td>
                                <td><?= $send ?></td>
                                <td><?= $row[2] ?></td>
                                <td><?= $mony ?></td>
                            </tr>
                        <?php } ?>
                    </table>
                    <div style="text-align: left !important;">
                        <div class="price">
                            <?php if (!empty($mony_respect)) { ?>
                                <div class="one">استعلام قیمت در پذیرش : <?= $mony_respect ?></div>
                            <?php } ?>
                            <?php if (!empty($mony_design)) { ?>
                                <div class="one">قیمت پیشنهادی طراحی : <?= $mony_design ?></div>
                            <?php } ?>
                            <?php if (!empty($mony_out)) { ?>
                                <div class="one">قیمت پیشنهادی واحد بیرون : <?= $mony_out ?></div>
                            <?php }
                            if (!empty($allMony) && is_numeric($allMony)) {
                                $allMony = number_format($allMony);
                            }
                            ?>
                            <div class="one">مجموع هزینه های انجام شده : <?= $allMony ?></div>
                        </div>
                    </div>
                    <div style="margin-bottom: 55px;position: relative;">
                        <?php if (is_array($print)) { ?>
                            <div class="one">
                            <span class="one2">متراژ : <span
                                        class="one3"><?= round(($print['metr'] / 10000), 2) ?></span></span>
                                <input type="text" name="fee_metr" class=" input one4" placeholder="فی به ریال">
                                <input type="text" class="input one5" placeholder="قیمت نهایی">
                            </div>
                            <div class="two">
                            <span class="two2">پرتی : <span
                                        class="two3"><?= abs(round(($print['perti_device'] / 10000), 2)) ?></span></span>
                                <input type="text" name="fee_perti" class=" input two4" placeholder="فی به ریال">
                                <input type="text" class="input two5" placeholder="قیمت نهایی">
                            </div>
                            <div class="thery">
                            <span class="thery2">سفیدی : <span
                                        class="thery3"><?= $print['sefidi'] ?></span></span>
                                <input type="text" name="fee_sefidi" class=" input thery4" placeholder="فی به ریال">
                                <input type="text" class="input thery5" placeholder="قیمت نهایی">
                            </div>
                            <div class="for">
                            <span class="for2">ولد : <span
                                        class="for3"><?= round(($print['valed'] / 10000), 2) ?></span></span>
                                <input type="text" name="fee_valed" class=" input for4" placeholder="فی به ریال">
                                <input type="text" class="input for5" placeholder="قیمت نهایی">
                            </div>
                            <div class="five">
                            <span class="five2">منگنه : <span
                                        class="five3"><?= $print['mangene'] ?></span></span>
                                <input type="text" name="fee_man" class=" input five4" placeholder="فی به ریال">
                                <input type="text" class="input five5" placeholder="قیمت نهایی">
                            </div>
                            <div class="six">
                            <span class="six2">لیفه : <span
                                        class="six3"><?= $print['life'] ?></span></span>
                                <input type="text" name="fee_life" class=" input six4" placeholder="فی به ریال">
                                <input type="text" class="input six5" placeholder="قیمت نهایی">
                            </div>
                            <div class="eight">
                            <span class="eight2">داربست : <span
                                        class="eight3"><?= $print['darbast'] ?></span></span>
                                <input type="text" name="fee_darbast" class=" input eight4" placeholder="فی به ریال">
                                <input type="text" class="input eight5" placeholder="قیمت نهایی">
                            </div>
                            <div class="nin">
                            <span class="nin2">اسپیس : <span
                                        class="nin3"><?= $print['space'] ?></span></span>
                                <input type="text" name="fee_space" class=" input nin4" placeholder="فی به ریال">
                                <input type="text" class="input nin5" placeholder="قیمت نهایی">
                            </div>
                            <div class="ten">
                            <span class="ten2">نصب : <span
                                        class="ten3"><?= $print['nasb'] ?></span></span>
                                <input type="text" name="fee_nasb" class=" input ten4" placeholder="فی به ریال">
                                <input type="text" class="input ten5" placeholder="قیمت نهایی">
                            </div>
                            <div class="seven">
                            <span class="seven2">هزینه طراحی :  <span
                                        class="seven3"></span></span>
                                <input type="text" name="fee_design" class=" input seven4" value="0"
                                       placeholder="فی به ریال">
                            </div>
                            <span class="allFee"> مجموع :  <span class="allfee2"></span></span>
                        <?php } ?>
                    </div>
                </div>
            </form>
            <div class="edit2">
                <span class="dele">X</span>
                <form action="manag/laghv" method="post">
                    <input type="hidden" name="id" class="id" value="<?= $orders['Id'] ?>">
                    <div class="attr1">
                        <label for="factor" class="label1">ارسال به واحد : </label>
                        <select name="next" id="next" class="input1" required>
                            <option value=""></option>
                            <?php foreach ($level as $row) { ?>
                                <option value="<?= $row['name'] ?>"><?= $row['name'] ?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <textarea name="dis" id="dis" cols="30" rows="10"
                              placeholder="توضیحات خود را اینجا بنویسید"></textarea>
                    <input type="submit" value="اعمال تغییرات" class="submit sub"
                           style="left: 50px !important;top: 34px !important;">
                </form>
            </div>
            <script>
                $('.input').keyup(function () {
                    var metr0 = parseFloat($('.one3').text(), 10);
                    var metr = parseInt($('.one4').val(), 10);
                    var allMetr = $('.one5');
                    var perti0 = parseFloat($('.two3').text(), 10);
                    var perti = $('.two4').val();
                    var allPerti = $('.two5');
                    var sefidi0 = parseFloat($('.thery3').text(), 10);
                    var sefidi = $('.thery4').val();
                    var allSefidi = $('.thery5');
                    var valed0 = parseFloat($('.for3').text(), 10);
                    var valed = $('.for4').val();
                    var allValed = $('.for5');
                    var mangene0 = parseFloat($('.five3').text(), 10);
                    var mangene = $('.five4').val();
                    var allMangene = $('.five5');
                    var life0 = parseFloat($('.six3').text(), 10);
                    var life = $('.six4').val();
                    var allLife = $('.six5');
                    var darbast0 = parseFloat($('.eight3').text(), 10);
                    var darbast = $('.eight4').val();
                    var allDarbast = $('.eight5');
                    var space0 = parseFloat($('.nin3').text(), 10);
                    var space = $('.nin4').val();
                    var allSpace = $('.nin5');
                    var nasb0 = parseFloat($('.ten3').text(), 10);
                    var nasb = $('.ten4').val();
                    var allNasb = $('.ten5');
                    var design = parseInt($('.seven4').val(), 10);


                    var feeMetr = parseInt(metr0 * metr, 10);
                    allMetr.val(feeMetr);

                    var feePerti = parseInt(perti * perti0, 10);
                    allPerti.val(feePerti);

                    var feeSefidi = parseInt(sefidi0 * sefidi, 10);
                    allSefidi.val(feeSefidi);

                    var feeValed = parseInt(valed * valed0, 10);
                    allValed.val(feeValed);

                    var feeMan = parseInt(mangene * mangene0, 10);
                    allMangene.val(feeMan);

                    var feeLife = parseInt(life * life0, 10);
                    allLife.val(feeLife);

                    var feeDarbast = parseInt(darbast * darbast0, 10);
                    allLife.val(feeDarbast);

                    var feeSpace = parseInt(space * space0, 10);
                    allSpace.val(feeSpace);
                    var feeNasb = parseInt(nasb * nasb0, 10);
                    allNasb.val(feeNasb);

                    var feeDesign = parseInt(design, 10);

                    var All = (feeMetr + feePerti + feeSefidi + feeValed + feeMan + feeLife + feeDesign + feeDarbast + feeSpace + feeNasb);
                    $('.feeGole').val(All);
                    var All2 = All.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1.");
                    $('.allfee2').text(All2);
                })
            </script>

            <!--
            <?php if (!empty($orders['img'])) { ?>
                <div class="img"><img src="image/order/<?= $orders['id'] ?>/<?= $orders['img'] ?>" width="300"
                                      height="317"></div>
            <?php } ?>
            -->
            <div class="attr1">
                <label for="factor" class="label1">شماره فاکتور : </label>
                <input type="text" class="input1" value="<?= @$orders['factor'] ?>" disabled>
            </div>

            <div class="attr1">
                <label for="start" class="label1">تاریخ سفارش : </label>
                <input type="text" class="input1" name="start" value="<?= @$orders['start_d'] ?>" disabled>
            </div>

            <div class="attr1" style="block !important;">
                <label for="factor" class="label1">تاریخ تحویل : </label>
                <input type="text" class="input1" value="<?= @$orders['end_d'] ?>" disabled>
            </div>
            <div></div>
            <div class="attr">
                <label for="cos" class="label">مشتری : </label>
                <input type="text" class="input" value="<?= @$orders['cos'] ?>" name="special" disabled>
            </div>
            <div class="attr">
                <label for="servic" class="label">خدمات : </label>
                <input type="text" class="input" value="<?= @$servic ?>" name="servic" disabled>
            </div>
            <div class="attr">
                <label for="special" class="label">خدمات ویژه : </label>
                <input type="text" class="input" value="<?= @$special ?>" name="special" disabled>
            </div>

        </div>
    </div>

</div>
<div class="clear"></div>

<script>
    $('.esh').click(function () {
        $('.edit2').fadeToggle(100)
    });

    $('.dele').click(function () {
        $('.edit2').fadeOut(0)
    });

    $('#manag').addClass('liActiv');
    $('#manag a').addClass('aActiv');

</script>

<div class="thi">
    <?php if (!empty($orders['img'])) { ?>
        <div class="axxx">
            <span class="hedere">پیوست واحد پذیرش : </span>
            <img src="image/order/<?= $orders['Id'] ?>/<?= $orders['img'] ?>">
        </div>
    <?php } ?>
    <?php if (!empty($orders['file_design'])) { ?>
        <div class="axxx">
            <span class="hedere">پیوست واحد طراحی : </span>
            <img src="image/order/<?= $orders['Id'] ?>/<?= $orders['file_design'] ?>">
        </div>
    <?php } ?>
</div>

<style>
    .thi {
        display: block;
        margin-top: 34px;
        text-align: center;
        position: relative;
    }

    .axxx {
        position: relative;
        width: 40%;
        display: inline-block;
    }

    .axxx img {
        display: block;
        text-align: center;
        margin: 20px 0;
        font-family: mapnoS;
        font-size: 15px;
        position: absolute;
        width: 100%;
    }
</style>
