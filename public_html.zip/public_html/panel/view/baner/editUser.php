<?php
Model::sessionInit();
$err=Model::sessionGet('msg1');
$err1=Model::sessionGet('msg2');
unset($_SESSION['msg1']);
unset($_SESSION['msg2']);
$user = $data[0];

?>
<div class="option">
    <style>
        .option {
            width: 100%;
            min-width: 1300px !important;
            margin: 10px auto;
        }

        .option * {
            text-align: right;
            direction: rtl;
        }

        .mainOption {
            width: 80%;
            min-width: 1000px;
            float: left;
            margin-left: 10px;
            margin-top: 10px;
        }

    </style>
    <style>
        .page {
            width: 100%;
            box-sizing: border-box;
            margin: 10px auto;
            padding: 10px 12px;
            position: relative;
        }
    </style>
    <?php require('optionList.php'); ?>
    <div class="mainOption">
        <div class="hed">مدیریت سفارشات

        </div>
        <div class="page">
            <div class="talent">
                <div class="right">
                    <form action="baner/editUser1" method="post" class="frm">
                        <div class="attr">
                            <label class="label" for="name">نام : </label>
                            <input type="text" class="inputRelative" id="name" name="name"
                                   value="<?= $user['name'] ?>" required>
                        </div>
                        <div class="attr">
                            <label class="label" for="lastname">نام خانوادگی : </label>
                            <input type="text" class="inputRelative" id="last" name="last"
                                   value="<?= $user['last'] ?>" required>
                        </div>

                        <div class="attr">
                            <label class="label" for="country">تلفن : </label>
                            <input type="text" class="inputRelative" id="mobile"
                                   name="mobile"
                                   value="<?= $user['mobile'] ?>">
                        </div>
                        <div class="attr">
                            <label class="label" for="name">ایمیل : </label>
                            <input type="email" class="inputRelative" id="email" name="email"
                                   value="<?= $user['email'] ?>" required>
                        </div>

                        <div class="attr">
                            <input type="submit" class="submit" value="اعمال تغییرات">
                        </div>
                    </form>
                </div>

                <style>
                    .right {
                        display: inline-block;
                        width: 45%;
                        border-left: 1px dashed #c5c5c5;
                        position: relative;
                    }

                    .left {
                        display: inline-block;
                        width: 49%;
                        position: absolute;
                    }

                    .img1 {
                        display: inline-block;
                        position: absolute;
                        right: 97px;
                        bottom: 0;
                        width: 174px;
                        height: 270px;
                        border-radius: 2px;
                        border: 1px solid #ced1d0;
                        background-color: #f8f8f8;
                        overflow: hidden;
                    }

                    .imgeUser {
                        display: inline-block;
                        position: absolute;
                        right: 299px;
                        top: 18px;
                        width: 150px;
                        height: 150px;
                        border-radius: 100%;
                        border: 1px solid #ced1d0;
                        overflow: hidden;
                        z-index: 333;
                    }

                    .image1 {
                        display: inline-block;
                        position: absolute;
                        top: 0;
                        left: 0;
                        width: 150px;
                        height: 150px;
                    }

                    .formImage {
                        display: inline-block;
                        position: relative;
                        bottom: 35px;
                        margin-bottom: 0 !important;
                        width: 500px;
                        height: 282px;
                    }

                    .textL {
                        display: block;
                        width: 130px;
                        position: absolute;
                        top: 10px;
                        right: 65px;
                        font-size: 14px;
                        color: #383c50;
                        padding-left: 22px;
                    }

                    .file {
                        position: absolute;
                        display: inline-block;
                        top: 145px;
                        right: 40px;
                    }

                    .submit2 {
                        display: inline-block;
                        position: absolute;
                        top: 189px;
                        right: 41px;
                        width: 100px;
                        text-align: center;
                        box-sizing: border-box;
                        background-color: #162a53;
                        height: 33px;
                        color: white;
                        font-size: 12px;
                        padding-top: 9px;
                        border: 1px solid grey;
                        border-radius: 3px;
                    }

                    .line {
                        width: 86%;
                        position: absolute;
                        border: 1px dashed #c5c5c5;
                        top: 247px;
                        left: 40px;
                    }

                    /* pass */
                    .submit3 {
                        display: inline-block;
                        position: absolute;
                        top: 483px;
                        left: 48px;
                        width: 100px;
                        text-align: center;
                        box-sizing: border-box;
                        background-color: #162a53;
                        height: 33px;
                        color: white;
                        font-size: 12px;
                        padding-top: 9px;
                        border: 1px solid grey;
                        border-radius: 3px;
                    }

                    .textP {
                        display: block;
                        width: 150px;
                        position: absolute;
                        top: 280px;
                        right: 67px;
                        font-size: 14px;
                        color: #383c50;
                        padding-left: 20px;
                    }

                    .textP img {
                        position: absolute;
                        display: inline-block;
                        width: 16px;
                        height: 16px;
                        top: -1px;
                        right: -20px;
                    }

                    .formpass {
                        position: absolute;
                        display: inline-block;
                        top: 319px;
                    }

                    .attrPass1 {
                        position: absolute;
                        display: inline-block;
                        width: 436px;
                        height: 50px;
                        top: 335px;
                        left: 8px;
                    }

                    .attrPass2 {
                        position: absolute;
                        display: inline-block;
                        width: 436px;
                        height: 50px;
                        top: 385px;
                        left: 8px;
                    }

                    .attrPass3 {
                        position: absolute;
                        display: inline-block;
                        width: 436px;
                        height: 50px;
                        top: 434px;
                        left: 8px;
                    }

                    .inputRelative33 {
                        width: 303px;
                        height: 44px;
                        box-sizing: border-box;
                        text-align: left;
                        padding: 0 5px 5px 11px;
                        background-color: white;
                        border: 1px solid #6c7196;
                        position: absolute;
                        border-radius: 3px;
                        right: 0;
                    }

                    .oldpass {
                        display: inline-block;
                        position: absolute;
                        right: 0;
                        top: 17px;
                        font-size: 14px;
                        font-family: Arial;
                        color: #757575;
                    }

                    .err {
                        position: absolute;
                        display: inline-block;
                        top: 496px;
                        left: 179px;
                        color: #0078ff;
                    }

                    .textL img {
                        width: 18px;
                        height: 18px;
                        position: absolute;
                        top: -4px;
                        right: -24px;
                    }

                </style>

                <div class="left">
                    <div class="textL"><img src="view/assets/image/uploadImg.png">آپلود تصویر پرسنلی </div>
                    <div class="imgeUser">
                        <img class="image1"
                            <?php if (isset($user['image'])) { ?>
                                src="image/user/<?= $user['id'] ?>/100_<?= $user['image'] ?>"
                            <?php } else { ?>
                                src="<?= U ?>view/assets/image/profile.png"
                            <?php } ?>
                        >
                    </div>
                    <form action="baner/editUser2" class="formImage" method="post" enctype="multipart/form-data">
                        <input type="file" class="file" name="file" required>
                        <a class="submit2"> اعمال تغییرات </a>
                    </form>
                    <div class="line"></div>
                    <div class="pass">
                        <div class="textP"><img src="view/assets/image/key.png">تغییر رمز ورود</div>
                        <form action="baner/editUser3" method="post" class="formPass">
                            <div class="attrPass1">
                                <span class="oldpass">رمز فعلی : </span>
                                <input type="password" class="pass0 inputRelative" name="pass0">
                            </div>
                            <div class="attrPass2">
                                <span class="oldpass">رمز جدید : </span>
                                <input type="password" class="pass1 inputRelative" name="pass1">
                            </div>
                            <div class="attrPass3">
                                <span class="oldpass">تکرار رمز جدید : </span>
                                <input type="password" class="pass2 inputRelative" name="pass2">
                            </div>
                        </form>
                        <span class="err"><?= @$err1; ?></span>
                        <a class="submit3"> اعمال تغییرات </a>
                    </div>
                </div>
                <script>
                    $('.submit2').click(function () {
                        $('.formImage').submit();
                    });

                    $('.submit').click(function () {
                        $('.frm').submit();
                    });

                    $('.submit3').click(function () {
                        var err = "";
                        var pass0 = $('.pass0').val();
                        var pass1 = $('.pass1').val();
                        var pass2 = $('.pass2').val();
                        if (pass1 == pass2) {
                            if (pass1.length < 5) {
                                err = "پسورد جدید کوتاه است";
                                $('.err').text(err);
                            } else {
                                if (pass0.length < 5) {
                                    err = "پسورد قدیم کوتاه است";
                                    $('.err').text(err);
                                } else {
                                    $('.formPass').submit();
                                    $('.err').text(err);
                                }
                            }
                        } else {
                            err = "تکرار پسورد اشتباه است";
                            $('.err').text(err);
                        }
                    });
                </script>

            </div>
            <style>
                .label {
                    font-size: 13px;
                    position: absolute;
                    color: #6d6d6d;
                    font-family: BYekan;
                    right: 0px;
                    top: 15px;
                }
                .talent *{
                    font-family: mapno !important;
                }

                .attr {
                    position: relative;
                    display: inline-block;
                    width: 424px;
                    height: 45px;
                    margin: 1px 5px;
                }

                .inputRelative {
                    width: 303px;
                    height: 36px;
                    box-sizing: border-box;
                    padding: 0 5px 0 11px;
                    background-color: white;
                    border: 1px solid #6c7196;
                    position: absolute;
                    border-radius: 3px;
                    left: 40px;
                }

                .submit {
                    display: inline-block;
                    position: absolute;
                    top: 0;
                    left: 40px;
                    width: 100px;
                    font-size: 12px;
                    height: 32px;
                    box-sizing: border-box;
                    border-radius: 3px;
                    background-color: #162a53;
                    color: white;
                    text-align: center;
                    padding-top: 2px;
                    cursor: pointer;
                    border: 1px solid #162a53;
                }

                .submit:hover {
                    color
                }

                .frm {
                    position: relative;
                    text-align: left !important;
                    direction: ltr;
                }

                .label {
                    position: absolute;
                    left: 27px;
                    top: 8px;
                    font-size: 14px;
                }

                .input2 {
                    width: 444px;
                    height: 30px;
                    box-sizing: border-box;
                    padding: 5px;
                    border: 1px solid #6c7196;
                    border-radius: 2px;
                    position: absolute;
                    right: 0;
                }


                .talent {
                    display: inline-block;
                    margin: 1px;
                    width: 76%;
                    position: absolute;
                    box-sizing: border-box;
                    direction: rtl;
                    text-align: right;
                    min-height: 594px;
                    padding: 20px 0;
                    min-width: 1010px;
                }

                .talent form {
                    direction: rtl;
                    text-align: right;
                    margin-bottom: 60px;
                }

                .input {
                    display: inline-block;
                    width: 125px;
                    height: 30px;
                    box-sizing: border-box;
                    border: 1px solid #6c7196;
                    padding-left: 10px;
                    position: absolute;
                    right: 0;
                }

                .label {
                    position: absolute;
                    display: inline-block;
                    font-size: 13px;
                    font-family: Arial;
                    top: 21px;

                }

                .items {
                    width: 250px;
                    height: 30px;
                    position: relative;
                    display: inline-block;
                    margin: 30px 20px;
                }

                #main {
                    background-color: inherit !important;
                }

                .sub {
                    display: inline-block;
                    position: absolute;
                    bottom: 30px;
                    left: 20px;
                    width: 60px;
                    height: 34px;
                    box-sizing: border-box;
                    background-color: #092039;
                    color: white;
                    text-align: center;
                    padding-top: 13px;
                    border-radius: 3px;
                    cursor: pointer;
                }

                .msg {
                    display: inline-block;
                    font-family: Arial;
                    position: absolute;
                    width: 200px;
                    height: 40px;
                    overflow: auto;
                    left: 102px;
                    bottom: 14px;
                    direction: ltr;
                    text-align: left;
                    color: red;
                }


            </style>
        </div>
    </div>

</div>
<div class="clear"></div>

<script>
    $('#edit').addClass('liActiv');
    $('#edit a').addClass('aActiv');
</script>