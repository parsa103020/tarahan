<?php
$print = $data[0];
$factor = $data[1];
?>
<style>
    #main, body {
        width: 210mm !important;
        max-width: 210mm;
        margin: auto;
        border: 1px solid #eee;
        background-color: white;
    }

    .cont {
        width: 210mm;
        margin: auto;
        position: relative;
        border: 1px solid #f4f7fe;
        height:420mm;
    }

    .hed {
        text-align: center;
        padding: 25px 0 0 0;
        color: #175a5a;
        font-family: mapnos;
    }

    .cus {
        width: 100%;
        margin: 45px auto 15px auto;
        box-sizing: border-box;
        padding: 10px 15px;
    }

    .tex {
        display: inline-block;
        width: 303px;
        height: 28px;
        box-sizing: border-box;
        padding: 5px 10px;
        color: #40406c;
    }

    html{
        background: #e4e4e4;
    }
    .table {
        width: 100%;
        position: relative;
        min-width: 210mm;
        box-sizing: border-box;
    }

    .table tr:first-child td {
        background-color: #fff;
        padding: 13px 8px;
        text-align: center;
        font-size: 12px;
        min-width: 65px;
        display: table-cell;
        color: #434377;
        font-family: mapno !important;
    }


    .table tr td {
        padding: 13px 8px;
        text-align: center;
        font-size: 12px;
        min-width: 52px;
        color: #030375;
        line-height: 18px;
        font-family: mapnoS;
        border: 1px solid #eee;
    }

    .fac{
        display: inline-block;
        position: absolute;
        left: 23px;
        top: 44px;
        font-size: 11px;
        font-family: mapnoS;
    }

</style>
<div class="cont">
    <div class="hed">چاپ و تبلیغات طراحان باستان</div>
    <div class="fac"> شماره  : <?= $print[0]['factor'] ?></div>
    <div class="cus">
        <div class="tex" >مشتری : <?= $print[0]['cos'] ?></div>
        <div class="tex">تاریخ دریافت : <?= $print[0]['start_d'] ?></div>
        <div class="tex">تاریخ تحویل : <?= $print[0]['end_d'] ?></div>
        <div class="tex">تعداد سفارش : <?= count($print) ?></div>
        <div class="tex">نحوه تسویه : <?= $factor['pay'] ?></div>
        <div class="tex">بیعانه : <?= $factor['bayane'] ?></div>
    </div>
    <table class="table">
        <tr>
            <td>کد سفارش</td>
            <td style="min-width: 400px">سفارش</td>
            <td>خدمات</td>
            <td>خدمات ویژه</td>
            <td>قیمت</td>
        </tr>
        <?php foreach ($print as $row) {
            $servic = unserialize($row['servic']);
            if (is_array($servic)) {
                $servicValus = array_values($servic);
                $servic = implode(' ،  ', $servicValus);
            }
            $special = unserialize($row['special']);
            if (is_array($special)) {
                $soecialValus = array_values($special);
                $special = implode(' ،  ', $soecialValus);
            }
            ?>
            <tr>
                <td><?= $row['id'] ?></td>
                <td><?= $row['orders'] ?></td>
                <td><?= $servic ?></td>
                <td><?= $special ?></td>
                <td><?= $row['mony'] ?></td>
            </tr>
        <?php } ?>
    </table>

</div>






















