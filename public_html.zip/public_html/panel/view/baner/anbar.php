<?php
$user = $data[0];
$err = $err2 = $eer3 = ' ';
if (isset($_SESSION['rol'])) {
    $err = $_SESSION['rol'];
    unset($_SESSION['rol']);
}
if (isset($_SESSION['rol2'])) {
    $err2 = $_SESSION['rol2'];
    unset($_SESSION['rol2']);
}
if (isset($_SESSION['rol3'])) {
    $err3 = $_SESSION['rol3'];
    unset($_SESSION['rol3']);
}
?>
<div class="option">
    <style>
        .option {
            width: 100%;
            min-width: 1300px !important;
            margin: 10px auto;
        }

        .option * {
            text-align: right;
            direction: rtl;
        }

        .mainOption {
            width: 80%;
            min-width: 1000px;
            float: left;
            margin-left: 10px;
            margin-top: 10px;
        }

        .tim {
            position: absolute;
            left: 40px;
            bottom: 0;
            font-size: 12px;
            color: #494972;
        }
    </style>
    <style>
        .in {
            width: 97%;
            height: 100px;
            box-sizing: border-box;
            padding: 10px 0;
            position: relative;
            margin: auto;
        }

        .in2 {
            margin-top: 10px;
            border-top: 1px dashed #00ebeb;
            padding-top: 20px !important;
        }

        .heder {
            font-family: mapno;
        }

        .attr {
            width: 150px;
            position: relative;
            margin: 20px 0 0 30px;
            display: inline-block;
        }

        .input {
            width: 100px;
            position: absolute;
            left: 0;
            top: 0;
            height: 30px;
            box-sizing: border-box;
            border: 1px solid #b7d6ea;
            border-radius: 4px;
            text-align: center;
        }

        .label {
            position: absolute;
            top: 9px;
            right: 0;
            font-family: mapnoS;
        }

        .sub1 {
            display: inline-block;
            padding-top: 0;
            position: absolute;
            margin-top: 19px;
            height: 32px;
            margin-right: 31px;
            font-family: mapno;
        }

        .err {
            display: inline-block;
            position: absolute;
            margin: 28px 145px 0 0;
            color: #346fa2;
            font-family: mapno;
        }

    </style>
    <?php require('optionList.php'); ?>
    <div class="mainOption">
        <div class="hed">انبار
        </div>
        <div class="cont">
            <form action="baner/rol" method="post">
                <div class="in">
                    <div class="heder">وارد کردن ته رول :</div>
                    <div class="attr">
                        <label for="height" class="label">ارتفاع : </label>
                        <input type="number" name="height" class="input" step="0.01" placeholder="به متر" required>
                    </div>
                    <div class="attr">
                        <label for="weight" class="label">عرض : </label>
                        <input type="number" name="weight" class="input" step="0.01" placeholder="به متر" required>
                    </div>
                    <div class="attr">
                        <label for="num" class="label">تعداد : </label>
                        <input type="number" name="num" class="input" step="1" required>
                    </div>
                    <div class="attr">
                        <select name="noe" id="noe" class="input" style="right: 0 !important;" required>
                            <option value="">نوع</option>
                            <option value="بنر">بنر</option>
                            <option value="فلکس">فلکس</option>
                            <option value="وینیل">وینیل</option>
                            <option value="مش">مش</option>
                        </select>
                    </div>
                    <input type="submit" value="ثبت اطلاعات" class="submit sub1">
                    <span class="err"><?= @$err ?></span>
                </div>
            </form>
            <form action="baner/new" method="post">
                <div class="in in2">
                    <div class="heder">وارد کردن ورودی انبار :</div>
                    <div class="attr">
                        <label for="height" class="label">عرض : </label>
                        <input type="number" name="weight" class="input" step="0.01" placeholder="به متر"
                               required>
                    </div>
                    <div class="attr">
                        <label for="weight" class="label">طول : </label>
                        <input type="number" name="height" class="input" step="0.01" placeholder="به متر "
                               value="50" required>
                    </div>
                    <div class="attr">
                        <select name="noe" id="noe" class="input" style="right: 0 !important;" required>
                            <option value="">نوع</option>
                            <option value="بنر">بنر</option>
                            <option value="فلکس">فلکس</option>
                            <option value="وینیل">وینیل</option>
                            <option value="مش">مش</option>
                        </select>
                    </div>
                    <input type="submit" value="ثبت اطلاعات" class="submit sub1">
                    <span class="err"><?= @$err2 ?></span>
                </div>
            </form>
            <form action="baner/newPlaxi" method="post">
                <div class="in in2">
                    <div class="heder">وارد کردن ورودی پلکسی :</div>
                    <div class="attr">
                        <label for="zekh" class="label">ضخامت : </label>
                        <select name="zekh" id="zekh" class="input" required>
                            <option value="">انتخاب کنید</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                            <option value="6">6</option>
                            <option value="7">7</option>
                            <option value="8">8</option>
                            <option value="9">9</option>
                            <option value="10">10</option>
                        </select>
                    </div>
                    <div class="attr">
                        <label for="weight" class="label">عرض : </label>
                        <input type="number" name="weight" class="input" step="0.01" placeholder="به میلی متر"
                               value="120" required>
                    </div>
                    <div class="attr">
                        <label for="height" class="label">طول : </label>
                        <input type="number" name="height" class="input" step="0.01" placeholder="به متر وارد شود"
                               value="180" required>
                    </div>
                    <div class="attr">
                        <label for="color" class="label"> رنگ : </label>
                        <input type="text" name="color" class="input" required>
                    </div>
                    <input type="submit" value="ثبت اطلاعات" class="submit sub1">
                    <span class="err"><?= @$err3 ?></span>
                </div>
            </form>
        </div>
    </div>
    <div class="clear"></div>
    <script>
        $('#anbar').addClass('liActiv');
        $('#anbar a').addClass('aActiv');
    </script>