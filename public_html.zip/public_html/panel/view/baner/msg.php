<?php
@$msg = $data[0];


