<script src="<?= U ?>view/assets/uploadfile/jquery.uploadfile.min.js"></script>
<?php
$orders = $data[0];
$level = $data[1];
$weights = $data[3];
$order = $orders['orders'];

$lev = unserialize($orders['level']);
$nameLev = $orders['now'];

$servic = unserialize($orders['servic']);
if (is_array($servic)) {
    $servicValus = array_values($servic);
    $servic = implode(' ،  ', $servicValus);
}

$special = unserialize($orders['special']);
if (is_array($special)) {
    $specialValus = array_values($special);
    $special = implode(' ،  ', $specialValus);
}
$mony = $orders['price_design'];
if (!empty($mony) && is_numeric($mony)) {
    $mony = number_format($mony);
}
@$mony_out = $orders['price_out'];
if (!empty($mony_out) && is_numeric($mony_out)) {
    $mony_out = number_format($mony_out);
}
@$mony_design = $orders['price_design'];
if (!empty($mony_design) && is_numeric($mony_design)) {
    $mony_design = number_format($mony_design);
}
$mony_respect = $orders['mony'];
if (!empty($mony_respect) && is_numeric($mony_respect)) {
    $mony_respect = number_format($mony_respect);
}


$dis = unserialize($orders['dis']);
if (is_array($dis)) {
    foreach ($dis as $key => $row) {
        if ($row[0] == 'چاپ') {
            $description = $row[4];
            $monyy = $row[3];
            if (!empty($monyy) && is_numeric($monyy)) {
                $monyy = number_format($monyy);
            }
        }
    }
}
@$print = $data[2];
$ok = 0;
if (is_array($print)) {
    $ok = 1;
    $meter = round(($print['metr'] / 10000), 2);
    $tool = $print['tool_b'];
    $arz = $print['arz_b'];
    $arz0 = $print['arz_d'];
    $tool0 = $print['tool_d'];
    $sefidi = $print['sefidi'];
    $perti = $print['perti_device'];
    $mangene = $print['mangene'];
    @$life = $print['life'];
    @$darbast = $print['darbast'];
    @$space = $print['space'];
    @$nasb = $print['nasb'];
    @$life2 = $print['life2'];
    $valed = $print['valed'];
    $noe = $print['noe'];
    $tedad = $print['tedad'];
}
?>
<div class="option">
    <style>
        .payvast {
            background: #fff7f7;
            padding: 20px 20px;
            color: red;
        }

        .option {
            width: 100%;
            min-width: 1300px !important;
            margin: 10px auto;
        }

        .option * {
            text-align: right;
            direction: rtl;
        }

        .mainOption {
            width: 80%;
            min-width: 1000px;
            float: left;
            margin-left: 10px;
            margin-top: 10px;
        }

    </style>
    <style>
        .one {
            position: absolute;
            top: 10px;
            right: 35px;
            font-family: mapnoS;
        }

        .page {
            padding: 20px 10px;
            position: relative;
        }

        #order {
            width: 694px;
            margin: 10px auto;
            min-width: 400px;
            height: 86px;
            font-size: 13px;
            font-family: mapnoS;
            border: 1px solid #c0e6e3;
            box-sizing: border-box;
            padding: 8px 10px;
            border-radius: 4px;
            resize: none;
        }

        .laborder {
            display: block;
            margin-bottom: 5px;
        }

        .attr {
            width: 300px;
            height: 60px;
            margin-top: 24px;
            display: inline-block;
            margin-left: 25px;
        }

        .label {
            display: block;
            margin-right: 5px;
        }

        .input {
            display: block;
            margin-top: 15px;
            width: 300px;
            height: 35px;
            box-sizing: border-box;
            border: 1px solid #c0e6e3;
            border-radius: 5px;
            padding: 4px 10px;
        }

        .attr1 {
            width: 220px;
            height: 60px;
            margin-top: 24px;
            display: inline-block;
            position: relative;
            margin-left: 13px;
        }

        .label1 {
            margin-left: 10px;
            position: absolute;
            right: 0;
            top: 8px;
        }

        .input1 {
            width: 132px;
            height: 35px;
            box-sizing: border-box;
            border: 1px solid #c0e6e3;
            border-radius: 5px;
            padding: 4px 10px;
            position: absolute;
            left: 0;
            top: -4px;
            text-align: center;
            direction: ltr;
        }

        input, select {
            background: white;
        }

        .file {
            position: absolute;
            width: 74px;
            left: 8px;
            top: 3px;
        }

        .line {
            width: 689px;
            border-bottom: 1px dashed #19b5fe;
            position: absolute;
            bottom: 0;
        }

        .line2 {
            width: 689px;
            border-bottom: 1px dashed #19b5fe;
            bottom: 0;
        }

        .in {
            width: 715px;
            position: relative;
            height: 180px;
        }

        .sub {
            border: 1px solid #1d3b3e;
            position: absolute;
            bottom: 125px;
            left: 366px;
            padding-top: 0 !important;
        }

        .img {
            position: absolute;
            left: 30px;
            top: 37px;
            z-index: 33;
            border: 1px solid #8198af;
            border-radius: 4px;
            overflow: hidden;
            height: 317px;
            width: 300px;
        }

        .img img {
            width: 100%;
            height: 100%;
            position: absolute;
            top: 0;
            left: 0;
        }

        .img:hover {
            left: 150px;
            transform: scale(1.8);
            box-shadow: 0 0 10px 1px #1e4561;
            z-index: 99;
            transition: 0.8s;
        }

        .men {
            display: inline-block;
            margin-right: 27px;
            margin-top: 2px;
        }

        .men a {
            color: #f4f8ff !important;
        }

        .men a:hover {
            color: #28e1ff !important;
        }

        .span {
            position: relative;
            width: 44px;
            display: inline-block;
        }

        .span img {
            position: absolute;
            top: -12px;
            right: 10px;
        }

        .don {
            width: 200px;
            margin: 25px 0 10px 10px;
        }

        .don2 {
            width: 200px;
            margin: 25px 0 10px 10px;
        }

        #dis {
            width: 690px;
            height: 88px;
            border: 1px solid #EEE;
            resize: none;
            border-radius: 4px;
            padding: 10px 20px;
            box-sizing: border-box;
            font-size: 13px;
            font-family: mapno;
        }

        .lab {
            font-family: mapno;
            margin: 13px 2px 8px 0;
        }

        .subDis {
            padding-top: 0 !important;
            position: absolute;
            bottom: 30px;
            right: 588px;
        }

        .line2 {
            width: 689px;
            border-bottom: 1px dashed #19b5fe;
            position: absolute;
            bottom: 95px;
        }

        .baner {
            display: inline-block;
            width: 108px;
            text-align: center;
            border: 1px solid #c0e6e3;
            border-radius: 3px;
            height: 30px;
            box-sizing: border-box;
            margin: 20px 0 0px 6px;
        }

        .subBaner {
            padding-bottom: 10px;
            position: absolute;
            bottom: 23px;
            left: 26px;
        }

        .table {
            width: 100%;
            position: relative;
            min-width: 700px;
            background-color: #f7feff;
            border: 1px solid #3da6ff;
            box-sizing: border-box;
            margin: 20px auto -2px auto;
        }

        .table tr:first-child td {
            background-color: #53a3c6;
            padding: 13px 8px;
            text-align: center;
            font-size: 12px;
            min-width: 80px;
            display: table-cell;
            color: white;
            font-family: mapno !important;
        }

        .table tr:nth-child(even) {
            background-color: white;
        }

        .table tr td {
            padding: 13px 8px;
            text-align: center;
            font-size: 12px;
            min-width: 52px;
            color: #030375;
            line-height: 18px;
            font-family: mapnoS;

        }

        .one {
            padding: 15px 10px;
            color: #00007f;
            font-family: mapnoS;
        }

        .price {
            display: inline-block;
            width: 260px;
            background: #f6fcff;
            padding: 15px 10px;
            border: 1px solid #3da6ff;
            text-align: left;
            margin-bottom: 23px;
            border-top: none;
            z-index: 999;
        }

        .show {
            display: inline-block;
            color: white;
            position: absolute;
            left: 40px;
            margin-top: 1px;
        }

        .show2 {
            display: inline-block;
            color: white;
            position: absolute;
            left: 110px;
            margin-top: 1px;
        }

        .show:hover, .show2:hover {
            color: #25f5ff;
            transition: 0.4s;
        }
    </style>
    <?php require('optionList.php'); ?>
    <div class="mainOption">
        <div class="hed">مدیریت سفارشات
            <div class="men">
                <a href="baner/manag">سفارشات</a>
                <span class="span"><img src="view/assets/image/double-arrow.png" width="20" height="20"></span>
                <a>سفارش <?= @$orders['cos'] ?></a>
            </div>
        </div>

        <?php if (!empty($orders['payvast'])) { ?>
            <div class="payvast">
                <?= $orders['payvast'] ?>
            </div>
        <?php } ?>

        <div class="page">
            <div class="in">
                <form action="baner/setChange/<?= $orders['id'] ?>" method="post" enctype="multipart/form-data">
                    <div class="attr1">
                        <label for="factor" class="label1">مرحله ی بعد : </label>
                        <select name="next" id="next" name="next" class="input1" required>
                            <option value=""></option>
                            <?php foreach ($level as $row) { ?>
                                <?php if ($row['name'] != 'چاپ') { ?>
                                    <option value="<?= $row['name'] ?>" <?php if (isset($nameLev) && $nameLev == $row['name']) {
                                        echo "selected";
                                    } ?>><?= $row['name'] ?></option>
                                <?php }
                            } ?>
                        </select>
                    </div>
                    <div class="line2"></div>
                    <div></div>
                    <?php if (!empty($orders['img'])) { ?>
                        <a class="submit don" href="image/order/<?= @$orders['id'] ?>/<?= @$orders['img'] ?>"
                           rel="nofollow"
                           download target="_blank">دانلود پیوست پذریش</a>
                    <?php } ?>
                    <?php if (!empty($orders['file_design'])) { ?>
                        <a class="submit don2" href="image/order/<?= @$orders['id'] ?>/<?= @$orders['file_design'] ?>"
                           rel="nofollow"
                           download target="_blank">دانلود پیوست طراحی</a>
                    <?php } ?>
                        <input type="submit" value="اعمال تغییرات" class="submit sub">
                </form>
                <div class="line"></div>
            </div>
            <div class="in" style="height: 333px !important;">
                <form method="post" action="baner/des/<?= $orders['id'] ?>">
                    <select name="noe" id="noe" class="baner" required style="display: block !important;">
                        <option value="">نوع</option>
                        <option value="بنر" <?php if (@$noe == 'بنر') {
                            echo 'selected';
                        } ?>>بنر
                        </option>
                        <option value="فلکس" <?php if (@$noe == 'فلکس') {
                            echo 'selected';
                        } ?>>فلکس
                        </option>
                        <option value="وینیل" <?php if (@$noe == 'وینیل') {
                            echo 'selected';
                        } ?>>وینیل
                        </option>
                        <option value="مش" <?php if (@$noe == 'مش') {
                            echo 'selected';
                        } ?>>مش
                        </option>
                    </select>
                    <input type="number" class="baner" name="tool" placeholder="طول چاپ(cm)" step="0.01"
                           required <?php if ($ok == 1) {
                        echo "value=$tool";
                    } ?>>
                    <input type="number" class="baner" name="arz" placeholder="عرض چاپ(cm)" step="0.01"
                           required <?php if ($ok == 1) {
                        echo "value=$arz";
                    } ?>>
                    <input type="number" class="baner" name="tedad" placeholder="تعداد " step="1"
                           required <?php if ($ok == 1) {
                        echo "value=$tedad";
                    } ?>>
                    <input type="number" class="baner" name="tool0" placeholder="پرتی(متر)" step="0.01"
                           required <?php if ($ok == 1) {
                        echo "value=$perti";
                    } ?>>
                    <div></div>

                    <input type="number" class="baner sefidi" name="sefidi" placeholder="سفیدی(متر)" step="0.01"
                           required <?php if ($ok == 1) {
                        echo "value=$sefidi";
                    } ?>>
                    <input type="number" class="baner mangene" name="mangene" placeholder="منگنه" step="0.01"
                           required <?php if ($ok == 1) {
                        echo "value=$mangene";
                    } ?>>

                    <input type="number" class="baner life" name="life" placeholder="لیفه(متر)" step="0.01"
                           required <?php if ($ok == 1) {
                        echo "value=$life";
                    } ?>>

                    <input type="number" class="baner valed" name="valed" placeholder="ولد(متر)" step="0.01"
                           required <?php if ($ok == 1) {
                        echo "value=$valed";
                    } ?>>
                    <input type="number" class="baner darbast" name="darbast" placeholder="داربست(متر)" step="0.01"
                           required <?php if ($ok == 1) {
                        echo "value=$darbast";
                    } ?>>
                    <input type="number" class="baner space" name="space" placeholder="اسپیس(متر)" step="0.01"
                           required <?php if ($ok == 1) {
                        echo "value=$space";
                    } ?>>
                    <input type="number" class="baner nasb" name="nasb" placeholder="نصب(متر)" step="0.01"
                           required <?php if ($ok == 1) {
                        echo "value=$nasb";
                    } ?>>


                    <script>
                        var select = $('#noe');

                        select.change(function () {
                            var option = $(this).find('option:selected');
                            var value = option.val();
                            if (value == "فلکس" || value == "بنر") {
                                $('.life').show(0).val('');
                                $('.valed').show(0).val('');
                                $('.sefidi').show(0).val('');
                            }
                            if (value == "وینیل") {
                                $('.life').hide(0).val('0');
                                $('.valed').hide(0).val('0');
                                $('.sefidi').hide(0).val('0');
                            }
                            if (value == "مش") {
                                $('.life').hide(0).val('0');
                                $('.valed').hide(0).val('0');
                                $('.sefidi').hide(0).val('0');
                            }
                        });
                    </script>
                    <div class="lab">توضیحات :</div>
                    <textarea name="des" id="dis" cols="30" rows="10"><?= @$description ?></textarea>
                    <div class="attr1">
                        <input type="hidden" name="mony" class="input1" placeholder="به ریال بنویسید"
                               value="0">

                        <?php if ($ok == 0) { ?>
                            <input type="submit" class="submit subDis" value="اعمال تغییرات">
                        <?php } ?>
                    </div>
                    <?php if ($ok == 1) { ?>
                    <div class="attr1">
                        <span class="one">متراژ: <?= $meter ?> , پرتی : <?= $perti ?>  </span>
                        <?php } ?>
                    </div>
                </form>
                <div class="line"></div>
            </div>
            <!--
            <?php if (!empty($orders['img'])) { ?>
                <div class="img"><img src="image/order/<?= $orders['id'] ?>/<?= $orders['img'] ?>" width="300"
                                      height="317"></div>
            <?php } ?>
            -->
            <div class="attr1">
                <label for="factor" class="label1">شماره فاکتور : </label>
                <input type="text" class="input1" value="<?= @$orders['factor'] ?>" disabled>
            </div>

            <div class="attr1">
                <label for="start" class="label1">تاریخ سفارش : </label>
                <input type="text" class="input1" name="start" value="<?= @$orders['start_d'] ?>" disabled>
            </div>

            <div class="attr1">
                <label for="factor" class="label1">تاریخ تحویل : </label>
                <input type="text" class="input1" value="<?= @$orders['end_d'] ?>" disabled>
            </div>

            <div>
                <table class="table">
                    <tr>
                        <td>ردیف</td>
                        <td>مرحله</td>
                        <td>جزئیات</td>
                        <td>تاریخ دریافت</td>
                        <td>تاریخ ارسال</td>
                        <td>کاربر</td>
                        <td>هزینه</td>
                    </tr>
                    <tr>
                        <td>1</td>
                        <td>پذیرش</td>
                        <td><?= $order ?></td>
                        <td> <?= $orders['start_d'] ?> </td>
                        <td><?= $orders['respect_out'] ?></td>
                        <td> واحد پذیرش</td>
                        <td>0</td>
                    </tr>
                    <?php
                    $allMony = 0;
                    if (is_array($dis)) {
                        foreach ($dis as $key => $row) {
                            $i = $key + 2;
                            $mony = $row[3];
                            $allMony += $mony;
                            if (!empty($mony) && is_numeric($mony)) {
                                $mony = number_format($mony);
                            }
                            //$arr = [$nowtime, $id, $next];
                            $start = $lev[$key][0];
                            $send = @$lev[$key + 1][0];
                            ?>
                            <tr>
                                <td><?= $i ?></td>
                                <td><?= $row[0] ?></td>
                                <td><?= $row[4] ?></td>
                                <td> <?= $start ?> </td>
                                <td><?= $send ?></td>
                                <td><?= $row[2] ?></td>
                                <td><?= $mony ?></td>
                            </tr>
                        <?php }
                    }
                    ?>
                </table>

            </div>
            <div class="attr">
                <label for="cos" class="label">مشتری : </label>
                <input type="text" class="input" value="<?= @$orders['cos'] ?>" name="special" disabled>
            </div>
            <div class="attr">
                <label for="servic" class="label">خدمات : </label>
                <input type="text" class="input" value="<?= @$servic ?>" name="servic" disabled>
            </div>
            <div class="attr">
                <label for="special" class="label">خدمات ویژه : </label>
                <input type="text" class="input" value="<?= @$special ?>" name="special" disabled>
            </div>

        </div>
    </div>

</div>
<div class="clear"></div>

<script>
    $('#manag').addClass('liActiv');
    $('#manag a').addClass('aActiv');

</script>

