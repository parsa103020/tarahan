<?php
$user = $data[0];
$err = ' ';
$weight = $data[1];


?>
<div class="option">
    <style>
        .option {
            width: 100%;
            min-width: 1300px !important;
            margin: 10px auto;
        }

        .option * {
            text-align: right;
            direction: rtl;
        }

        .mainOption {
            width: 80%;
            min-width: 1000px;
            float: left;
            margin-left: 10px;
            margin-top: 10px;
        }

        .tim {
            position: absolute;
            left: 40px;
            bottom: 0;
            font-size: 12px;
            color: #494972;
        }
    </style>
    <style>
        .in {
            width: 97%;
            height: 100px;
            box-sizing: border-box;
            padding: 10px 0;
            position: relative;
            margin: auto;
        }

        .heder {
            font-family: mapno;
        }

        .attr {
            width: 150px;
            position: relative;
            margin: 41px 0 0 30px;
            display: inline-block;
        }

        .input {
            width: 100px;
            position: absolute;
            left: 0;
            top: 0;
            height: 30px;
            box-sizing: border-box;
            border: 1px solid #b7d6ea;
            border-radius: 4px;
            text-align: center;
        }

        .label {
            position: absolute;
            top: 9px;
            right: 0;
            font-family: mapnoS;
        }

        .sub1 {
            display: inline-block;
            padding-top: 0;
            position: absolute;
            margin-top: 40px;
            height: 30px;
            margin-right: 31px;
        }

        .err {
            display: inline-block;
            position: absolute;
            margin: 30px 160px;
            color: #346fa2;
            font-family: mapno;
        }

        .cont {
            border-bottom: 1px dashed #3437ee;
        }

        .table {
            position: relative;
            width: 400px;
            background-color: #f7feff;
            border: 1px solid #3da6ff;
            box-sizing: border-box;
            margin-bottom: 20px;
        }

        .table tr:first-child td {
            background-color: #53a3c6;
            padding: 13px 8px;
            text-align: center;
            font-size: 12px;
            min-width: 80px;
            display: table-cell;
            color: white;
            font-family: mapno !important;
        }

        .table tr:nth-child(even) {
            background-color: white;
        }

        .table tr td {
            padding: 13px 8px;
            text-align: center;
            font-size: 12px;
            min-width: 52px;
            color: #030375;
            line-height: 18px;
            font-family: mapnoS;
        }

        .del {
            width: 16px;
            height: 16px;
            margin: 0;
            background: url("view/assets/image/delete.png");
            text-align: center;
            margin: auto;
            display: block;
        }

        .sub2 {
            display: inline-block;
            padding-top: 0;
            position: absolute;
            margin-top: 10px;
            height: 29px;
            margin-right: -7px;
            width: 90px;
        }
    </style>
    <?php require('optionList.php'); ?>
    <div class="mainOption">
        <div class="hed">تنظیمات
        </div>
        <div class="cont" style="min-height: 262px;">
            <div class="heder" style="margin: 20px 0"> عرض رول ها و ویرایش :</div>
            <table class="table">
                <tr>
                    <td>ردیف</td>
                    <td>عرض</td>
                    <td>حذف</td>
                </tr>
                <?php foreach ($weight as $key => $row) { ?>
                    <tr>
                        <td><?= $key + 1 ?></td>
                        <td><?= $row['name'] ?></td>
                        <td><a href="baner/deletArz/<?= $row['id'] ?>"><span class="del"></span></a></td>
                    </tr>
                <?php } ?>
            </table>
            <form action="baner/addArz" method="post" style="height: 75px;">
                <div class="attr" style="margin-top: 0 !important; width: 287px !important;">
                    <label for="" class="label"> عرض رول : </label>
                    <input type="number" step="0.1" style="width: 200px !important;" name="name" class="input" placeholder="cm" required>
                </div>
                <input type="submit" value="افزودن" class="submit sub2">
                <span class="err"><?= @$err ?></span>

            </form>
        </div>


    </div>
    <div class="clear"></div>
    <script>
        $('#setting').addClass('liActiv');
        $('#setting a').addClass('aActiv');
    </script>