<div class="option">
    <style>
        .option {
            width: 100%;
            min-width: 1300px !important;
            margin: 10px auto;
        }

        .option * {
            text-align: right;
            direction: rtl;
        }

        .mainOption {
            width: 80%;
            min-width: 1000px;
            float: left;
            margin-left: 10px;
            margin-top: 10px;
        }

    </style>
    <style>
        .table {
            width: 100%;
            position: relative;
            min-width: 700px;
            background-color: #f7feff;
            border: 1px solid #3da6ff;
            box-sizing: border-box;
        }

        .table tr:first-child td {
            background-color: #53a3c6;
            padding: 13px 8px;
            text-align: center;
            font-size: 12px;
            min-width: 65px;
            display: table-cell;
            color: white;
            font-family: mapno !important;
        }

        .table tr:nth-child(even) {
            background-color: white;
        }

        .table tr td {
            padding: 13px 8px;
            text-align: center;
            font-size: 12px;
            min-width: 52px;
            color: #030375;
            line-height: 18px;
            font-family: mapnoS;

        }

        .manag {
            height: 500px;
            overflow-y: auto;
        }

        .search {
            width: 373px;
            height: 40px;
            box-sizing: border-box;
            border: 1px solid #6cdbc7;
            padding: 2px 14px;
            margin: 15px 1px 50px 10px;
            border-radius: 6px;
            font-family: mapnoS;
            font-size: 13px;
            color: #00006d;
        }
        .boxSearch{
            position: absolute;
            width: 500px;
            height: 220px;
            background: white;
            top: 55px;
            margin-right: 3px;
            display: none;
            overflow: auto;
            z-index: 99;
        }
        .right, .left{
            display: inline-table;
            width: 49%;
            height: 100%;
        }
        .right span, .left span{
            text-align: center;
            display: block;
            padding: 11px 0;
            font-family: mapno;

        }
        .right ul li , .left ul li{
            display: inline-block;
            font-size: 14px;
            padding: 10px 19px;
            font-family: mapnoS;
            cursor: pointer;
            width: 100%;
            box-sizing: border-box;
            overflow: hidden;
        }
        .right ul li:hover , .left ul li:hover{
            background: #f2fcff;
        }

        .right ul{
            overflow: auto;
            border-left: 2px dashed #e4f8ff;
        }
        .left ul{
            overflow: auto;
        }
        .attr{
            display: inline-block;
            width: 350px;
            height: 40px;
            position: relative;
        }
        .lable{
            font-size: 14px;
            font-family: mapnoS;
            position: absolute;
            right: 7px;
            top: 13px;
        }
        .input{
            position: absolute;
            left: 8px;
            height: 35px;
            box-sizing: border-box;
            padding: 2px 13px;
            width: 230px;
            border: 1px solid #79cec8;
            border-radius: 5px;
            font-size: 14px;
            font-family: mapnoS;
            color: #051387;
        }
        .sub3{
            position: absolute;
            left: 8px;
            padding: 0;
        }

    </style>
    <?php require('optionList.php'); ?>
    <div class="mainOption">
        <div class="hed">پیگیری سفارشات</div>
        <div  class="boxbox" style="position: relative;">
            <input type="text" class="search" placeholder="نام مشتری را بنویسید ... ">
            <div class="boxSearch">
            </div>
        </div>
        <div class="manag">
        </div>
    </div>
</div>
<div class="clear"></div>
<script>



    function search(key) {
        $(".boxSearch").fadeIn(10);
        var url = 'respect/searchCustomer';
        var data = {key: key};
        $.post(url, data, function (msg) {
            $('.boxSearch').html(msg);
        });
    }
    $('.search').keyup(function () {
       var key = $('.search').val();
       search(key);
    });
    $(".boxbox").mouseleave(function () {
        $(".boxSearch").fadeOut(200);
    });

    $('#cus').addClass('liActiv');
    $('#cus a').addClass('aActiv');
</script>