<?php
$data = $data[0];
$hagh = $data[0];
$hogh = $data[1];
?>
<div class="right">
    <span>مشتری های حقیقی </span>
    <ul>
        <?php foreach ($hagh as $row) { ?>
            <li data-id="<?= $row['id'] ?>"><?= $row['name'] . ' ' . $row['last'] ?></li>
        <?php } ?>
    </ul>
</div>
<div class="left">
    <span>مشتری های حقوقی </span>
    <ul>
        <?php foreach ($hogh as $row) { ?>
            <li data-id="<?= $row['id'] ?>"><?= $row['company'] ?></li>
        <?php } ?>
    </ul>
</div>
<script>
    $(".left ul li").click(function () {
        $(".boxSearch").fadeOut(100);
        var id = $(this).attr("data-id");
        var data = {id: id};
        var url = "respect/getHoghCus";
        $.post(url, data, function (msg) {
            $(".manag").html(msg);
        });
    });
    $(".right ul li").click(function () {
        $(".boxSearch").fadeOut(100);
        var id = $(this).attr("data-id");
        var data = {id: id};
        var url = "respect/getHaghCus";
        $.post(url, data, function (msg) {
            $(".manag").html(msg);
        });
    });


</script>




