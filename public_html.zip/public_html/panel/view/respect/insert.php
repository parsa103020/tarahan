<script src="view/assets/calendar/js-persian-cal.min.js"></script>

<?php
Model::sessionInit();
$servic = $data[0];
$hag = $data[1];
$hog = $data[2];
$special = $data[3];
$ash = $data[4];
@$factor = Model::sessionGet('factor');

?>
<div class="option">
    <style>
        .option {
            width: 100%;
            min-width: 1300px !important;
            margin: 10px auto;
        }

        .option * {
            text-align: right;
            direction: rtl;
        }

        .mainOption {
            width: 80%;
            min-width: 1000px;
            float: left;
            margin-left: 10px;
            margin-top: 10px;
        }
    </style>
    <style>
        .contain {
            width: 100%;
            min-height: 500px;
            display: block;
            position: relative;
        }

        .tab {
            background-color: white;
        }

        .tab ul {
            display: inline-block;
            height: 36px;
            border: 1px solid #eee;
        }

        .tab ul li {
            display: inline-block;
            width: 191px;
            position: relative;
            height: 100%;
            text-align: center;
            box-sizing: border-box;
            padding-top: 12px;
            cursor: pointer;
            font-family: mapno;
            font-size: 12px;
            color: #0a214b;
        }

        .tab ul li:hover {
            color: #00bbff;
        }

        .activTab {
            background-color: #0e84a4;
            color: white !important;
            box-shadow: 0 0 2px 0 #001550;
            border-radius: 2px;
        }

        .add {
            display: inline-block;
            position: absolute;
            left: 30px;
        }

        .add0 {
            display: inline-block;
            margin-right: 13px;
            cursor: pointer;
            font-size: 12px;
            font-family: mapno;
        }

        .add0:hover {
            color: #00bbff;
        }

        .tab1 {
            background-color: #fcfffe;
            padding: 35px 11px;
            min-height: 466px;
            box-sizing: border-box;
        }

        .attr {
            width: 374px;
            height: 40px;
            display: block;
            position: relative;
        }

        .label1 {
            position: absolute;
            font-family: mapno;
            font-size: 12px;
            right: 2px;
            top: 10px;
        }

        .s1 {
            width: 160px;
            border: 1px solid #e4e4e4;
            border-radius: 20px;
            height: 35px;
            box-sizing: border-box;
            padding: 10px 23px;
            color: #4d516f;
            position: relative;
            cursor: pointer;
            display: inline-block;
        }

        .s1:hover {
            border: 1px solid #6bd2de;
        }

        .hovers {
            color: #08b3d1;
        }

        .click {
            color: #08b3d1;
        }

        .arrow {
            display: inline-block;
            position: absolute;
            left: 18px;
            top: 14px;
        }

        .s2 {
            width: 328px;
            height: 200px;
            background-color: white;
            position: absolute;
            top: 109px;
            right: 9px;
            border: 1px solid #eee;
            border-radius: 2px;
            box-shadow: 0 0 3px 1px #befffa;
            display: none;
        }

        .searchCos {
            border: 1px solid #dadada;
            width: 94%;
            margin: 12px auto;
            display: block;
            border-radius: 20px;
            height: 34px;
            box-sizing: border-box;
            padding: 2px 22px;
            color: #16444e;
            outline: none;
        }

        .s2 ul {
            display: block;
            width: 100%;
            position: relative;
            box-sizing: border-box;
            padding: 5px 0;
            overflow: auto;
            max-height: 141px;
        }

        .s2 ul li {
            font-size: 12px;
            font-family: mapno;
            padding: 6px 19px;
            display: inline-block;
            width: 100%;
            position: relative;
            box-sizing: border-box;
            cursor: pointer;
        }

        .s2 ul li:hover {
            color: #08b3d1;
            background-color: #faffff;
        }

        .s11 {
            width: 160px;
            border: 1px solid #e4e4e4;
            border-radius: 20px;
            height: 35px;
            box-sizing: border-box;
            padding: 10px 23px;
            color: #4d516f;
            position: relative;
            cursor: pointer;
            display: inline-block;
            margin-top: 40px;
        }

        .s11:hover {
            border: 1px solid #6bd2de;
        }

        .s21 {
            width: 153px;
            height: 210px;
            background-color: white;
            position: absolute;
            top: 76px;
            right: 3px;
            border: 1px solid #eee;
            border-radius: 2px;
            box-shadow: 0 0 3px 1px #befffa;
            display: none;
        }

        .s21 ul {
            display: block;
            width: 100%;
            position: relative;
            box-sizing: border-box;
            padding: 5px 0;
            overflow: auto;
            max-height: 210px;
        }

        .s21 ul li {
            font-size: 12px;
            font-family: mapno;
            padding: 6px 19px;
            display: inline-block;
            width: 100%;
            position: relative;
            box-sizing: border-box;
            cursor: pointer;
            border: none !important;
            height: 20px;
        }

        .s21 ul li:hover {
            color: #08b3d1;
            background-color: #faffff;
        }

        .s99 {
            width: 160px;
            border: 1px solid #e4e4e4;
            border-radius: 20px;
            height: 35px;
            box-sizing: border-box;
            padding: 10px 23px;
            color: #4d516f;
            position: relative;
            cursor: pointer;
            display: inline-block;
            margin-top: 40px;
            margin-right: 25px;
        }

        .bayane {
            width: 160px;
            border: 1px solid #e4e4e4;
            border-radius: 20px;
            height: 35px;
            box-sizing: border-box;
            padding: 10px 23px;
            color: #4d516f;
            position: relative;
            display: inline-block;
            margin-right: 25px;
            background-color: #fcfffe;
            text-align: left !important;
        }
        .moneyDD{
            width: 160px;
            border: 1px solid #e4e4e4;
            border-radius: 20px;
            height: 35px;
            box-sizing: border-box;
            padding: 10px 23px;
            color: #4d516f;
            position: relative;
            display: inline-block;
            margin-right: 25px;
            background-color: #fcfffe;
            text-align: left !important; 
        }

        .bayane:hover {
            border: 1px solid #6bd2de;
        }

        .moneyDD:hover {
            border: 1px solid #6bd2de;
        }

        .s99:hover {
            border: 1px solid #6bd2de;
        }

        .s100 {
            width: 153px;
            height: 75px;
            background-color: white;
            position: absolute;
            top: 76px;
            right: 386px;
            border: 1px solid #eee;
            border-radius: 2px;
            box-shadow: 0 0 3px 1px #befffa;
            display: none;
        }

        .s100 ul {
            display: block;
            width: 100%;
            position: relative;
            box-sizing: border-box;
            padding: 5px 0;
            overflow: auto;
            max-height: 210px;
        }

        .s100 ul li {
            font-size: 12px;
            font-family: mapno;
            padding: 6px 19px;
            display: inline-block;
            width: 100%;
            position: relative;
            box-sizing: border-box;
            cursor: pointer;
            border: none !important;
            height: 20px;
        }

        .s100 ul li:hover {
            color: #08b3d1;
            background-color: #faffff;
        }

        .lihover {
            color: #08b3d1;
            background-color: #faffff;
        }

        .chekd {
            background: url("view/assets/image/check-mark.png");
            position: absolute;
            left: 21px;
            top: 2px;
            width: 16px;
            height: 16px;
            display: inline-block;
        }

        .r1 {
            width: 160px;
            border: 1px solid #e4e4e4;
            border-radius: 20px;
            height: 35px;
            box-sizing: border-box;
            padding: 10px 23px;
            color: #4d516f;
            position: relative;
            cursor: pointer;
            display: inline-block;
        }

        .r1:hover {
            border: 1px solid #6bd2de;
        }

        .hoverr {
            color: #08b3d1;
        }

        .r2 {
            width: 220px;
            height: 200px;
            background-color: white;
            position: absolute;
            top: 50px;
            right: 14px;
            border: 1px solid #eee;
            border-radius: 2px;
            box-shadow: 0 0 3px 1px #befffa;
            display: none;
        }

        .r2 ul {
            display: block;
            width: 100%;
            position: relative;
            box-sizing: border-box;
            padding: 5px 0;
            overflow: auto;
            max-height: 198px;
        }

        .r2 ul li {
            font-size: 12px;
            font-family: mapno;
            padding: 6px 19px;
            display: inline-block;
            width: 100%;
            position: relative;
            box-sizing: border-box;
            cursor: pointer;
        }

        .r2 ul li:hover {
            color: #08b3d1;
            background-color: #faffff;
        }

        .p1 {
            width: 160px;
            border: 1px solid #e4e4e4;
            border-radius: 20px;
            height: 35px;
            box-sizing: border-box;
            padding: 10px 23px;
            color: #4d516f;
            position: relative;
            cursor: pointer;
            display: inline-block;
            margin-right: 25px;
        }

        .p1:hover {
            border: 1px solid #6bd2de;
        }

        .hoverp {
            color: #08b3d1;
        }

        .p2 {
            width: 220px;
            height: 200px;
            background-color: white;
            position: absolute;
            top: 50px;
            right: 200px;
            border: 1px solid #eee;
            border-radius: 2px;
            box-shadow: 0 0 3px 1px #befffa;
            display: none;
        }

        .p2 ul {
            display: block;
            width: 100%;
            position: relative;
            box-sizing: border-box;
            padding: 5px 0;
            overflow: auto;
            max-height: 198px;
        }

        .p2 ul li {
            font-size: 12px;
            font-family: mapno;
            padding: 6px 19px;
            display: inline-block;
            width: 100%;
            position: relative;
            box-sizing: border-box;
            cursor: pointer;
        }

        .p2 ul li:hover {
            color: #08b3d1;
            background-color: #faffff;
        }

        .div1 {
            height: 80px;
            position: relative;
        }

        .div2 {
            height: 80px;
        }

        .op {
            z-index: 33;
        }

        .resbox {
            width: 100%;
            margin: 2px auto 10px auto;
            box-sizing: border-box;
            padding: 23px 3px;
            border-radius: 4px;
            position: relative;
        }

        .m1 {
            width: 160px;
            border: 1px solid #e4e4e4;
            border-radius: 20px;
            height: 35px;
            box-sizing: border-box;
            padding: 10px 23px;
            color: #4d516f;
            position: relative;
            cursor: pointer;
            display: inline-block;
            margin-right: 25px;
        }

        .m1:hover {
            border: 1px solid #6bd2de;
        }

        .m2 {
            width: 157px;
            max-height: 166px;
            background-color: white;
            position: absolute;
            top: 50px;
            right: 389px;
            border: 1px solid #eee;
            border-radius: 2px;
            box-shadow: 0 0 3px 1px #befffa;
            display: none;
        }

        .m2 ul {
            display: block;
            width: 100%;
            position: relative;
            box-sizing: border-box;
            padding: 5px 0;
            overflow: auto;
            max-height: 141px;
        }

        .m2 ul li {
            font-size: 12px;
            font-family: mapno;
            padding: 6px 19px;
            display: inline-block;
            width: 100%;
            position: relative;
            box-sizing: border-box;
            cursor: pointer;
        }

        .m2 ul li:hover {
            color: #08b3d1;
            background-color: #faffff;
        }

        .sefaresh {
            width: 100%;
            margin: 10px auto;
            padding: 10px;
        }

        .matnSefaresh {
            width: 902px;
            height: 35px;
            margin-right: 10px;
            border: 1px solid #cbedeb;
            border-radius: 20px;
            box-sizing: border-box;
            padding: 0 20px;
            background: #fdfeff;
        }

        .abad {
            width: 100px;
            height: 35px;
            margin-right: 25px;
            border: 1px solid #efefef;
            border-radius: 20px;
            box-sizing: border-box;
            padding: 0 20px;
            background: #fdfeff;
        }

        .input1 {
            width: 100px;
            height: 35px;
            margin-right: 5px;
            border: 1px solid #cbedeb;
            border-radius: 20px;
            box-sizing: border-box;
            padding: 0 20px;
            background: #fdfeff;
        }

        .label2 {
            margin-right: 15px;
        }

        .boxhead {
            display: inline-block;
        }

        .div3 {
            width: 100%;
            min-height: 173px;
            position: relative;
            border: 1px solid #e2fff5;
            box-sizing: border-box;
            padding: 14px 12px;
            border-radius: 4px;
            background-color: white;
            margin-bottom: 10px;
            position: relative;
            display: none;
        }

        .pcalBtn {
            top: 40px !important;
            right: 180px !important;
            margin-right: 17px !important;
        }

        #pcal1 {
            margin-right: 32px !important;
            background: none !important;
        }

        .pcalBtn:hover {
            border: none !important;
        }

        .sub {
            position: absolute;
            left: 50%;
            margin-left: -50px;
            margin-top: 0;
            font-family: mapno;
        }

        ::placeholder {
            color: #000000;
        }

        .boxmsg {
            width: 300px;
            height: 30px;
            text-align: center;
            margin: 0 auto;
            color: #318ccf;
            font-family: mapno;
            font-size: 12px;
            display: block;
            overflow: auto;
            z-index: 3333333;
            position: absolute;
            bottom: -6px;
            left: 50%;
            margin-left: -150px;
        }
    </style>
    <style>

        .flip-box, .flip-box2, .flip-box3 {
            background: #066568;
            width: 100%;
            margin: 3px auto 8px auto;
            height: 135px;
            border: 1px solid #d5e6f1;
            perspective: 1000px;
            margin: auto;
            display: none;
            position: relative;
        }

        .flip-box-inner, .flip-box-inner2, .flip-box-inner3 {
            position: relative;
            width: 100%;
            height: 100%;
            text-align: center;
            transition: transform 1s;
            transform-style: preserve-3d;
            transform: rotate3d(1, 0, 0, -90deg);

        }

        .tozih{
            font-family: mapno;
            font-size: 13px !important;
        }
        .flip-box-hover, .flip-box-hover2, .flip-box-hover3 {
            transform: rotate3d(1, -1, 1, 0deg);
        }

        .flip-box-front, .flip-box-front2, .flip-box-front3 {
            position: absolute;
            width: 100%;
            height: 100%;
            backface-visibility: hidden;
            background-color: black;

        }

        .flip-box-front, .flip-box-front2, .flip-box-front3 {
            background-color: #dff9f3;
            color: black;

        }

        .lable11 {
            font-family: mapno;
            right: 0;
            position: absolute;
            top: 10px;
        }

        .input11 {
            box-sizing: border-box;
            border: 1px solid #eee;
            width: 197px;
            height: 35px;
            border-radius: 5px;
            padding: 3px 10px;
            position: absolute;
            left: 50%;
            bottom: 0;
            margin-left: -113px;
        }

        .attr11 {
            min-width: 185px;
            height: 40px;
            position: relative;
            display: inline-block;
            margin: 10px 1% 0 1%;
        }

        .sub2 {
            padding-top: 0 !important;
            font-family: mapno;
            font-size: 12px;
            border: 1px solid #eee;
            position: absolute;
            bottom: 0;
            left: -21px;
        }
    </style>
    <style>
        .at {
            display: inline-block;
            width: 230px;
            margin-left: 10px;
            position: relative;
            height: 32px;
            margin-top: 10px;
        }

        .label2 {
            position: absolute;
            right: 0;
            top: 13px;
        }

        .input1 {
            position: absolute;
            left: 0;
            width: 127px !important;
        }

        .at2 {
            position: relative;
            width: 956px;
            height: 100px;
        }

        .at2 label {
            display: inline-block;
            position: absolute;
            right: 15px;
            top: 20px;
        }

        .act1{
            position: absolute;
            width: 31px;
            height: 31px;
            top: 2px;
            left: 2px;
        }

        .at2 textarea {
            width: 820px;
            border: 1px solid #cbedeb;
            border-radius: 4px;
            padding: 10px 15px;
            resize: none;
            position: absolute;
            left: 0;
            height: 85px;
            top: 16px;
            background: #fdfeff;
        }

        .factor {
            position: absolute;
            left: 30px;
            display: inline-block;
            top: 0;
            width: 250px;
            height: 35px;
        }

        .factor span {
            margin: 9px 2px;
            display: inline-block;
            color: #009cff;
        }

        .factor a img {
            display: inline-block;
            margin-right: 22px;
            position: absolute;
            margin-top: 3px;
        }

    </style>
    <?php require('optionList.php'); ?>
    <div class="mainOption">
        <div class="hed">ثبت سفارش
            <div class="add">
                <span class="add0 add1">افزودن مشتری حقوقی</span>
                <span class="add0 add2">افزودن مشتری حقیقی</span>
                <span class="add0 add3">افزودن نحوه آشنایی</span>
            </div>
        </div>
        <div>
            <div class="flip-box">
                <div class="flip-box-inner">
                    <div class="flip-box-front">
                        <form action="<?= U ?>respect/insertHogh" method="post">
                            <div class="attr11"><input name="company" type="text" class="input11" required
                                                       placeholder="نام شرکت / سازمان"></div>
                            <div class="attr11"><input name="manager" type="text" class="input11" required
                                                       placeholder="نام مدیر">
                            </div>
                            <div class="attr11"><input name="eco" type="text" class="input11" placeholder="کد اقتصادی">
                            </div>
                            <div class="attr11"><input name="mobile" type="number" style="direction: ltr !important;" class="input11" required
                                                       placeholder="تلفن مدیر">
                            </div>
                            <div class="attr11"><input name="sabt" type="text" class="input11" required
                                                       placeholder="شماره ثبت">
                            </div>
                            <div class="attr11"><input name="email" type="email" class="input11" placeholder="ایمیل">
                            </div>
                            <div class="attr11"><input name="tel" type="text" class="input11"  style="direction: ltr !important;"
                                                       placeholder="شماره تلگرام"></div>
                            <div class="attr11"><input name="address" type="text" class="input11" placeholder="آدرس">
                            </div>
                            <div class="attr11">
                                <select name="ashnai" id="ashnai" class="input11" required>
                                    <option value="">آشنایی</option>
                                    <?php foreach ($ash as $row) { ?>
                                        <option value="<?= $row['id'] ?>"><?= $row['name'] ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                            <div class="attr11"><input type="submit" class="submit sub2" value="ثبت اطلاعات"></div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="flip-box2">
                <div class="flip-box-inner2">
                    <div class="flip-box-front2">
                        <form action="<?= U ?>respect/insertHagh" method="post">
                            <div class="attr11"><input type="text" name="name" class="input11" placeholder="نام"
                                                       required></div>
                            <div class="attr11"><input type="text" name="last" class="input11"
                                                       placeholder="نام خانوادگی" required>
                            </div>
                            <div class="attr11"><input type="number" name="mobile"  style="direction: ltr !important;" class="input11" placeholder="موبایل"
                                                       required></div>
                            <div class="attr11"><input type="email" name="email" class="input11" placeholder="ایمیل">
                            </div>
                            <div class="attr11"><input type="text" name="tel"  style="direction: ltr !important;" class="input11" placeholder="تلگرام">
                            </div>
                            <div class="attr11"><input type="text" name="address" class="input11" placeholder="آدرس">
                            </div>
                            <div class="attr11">
                                <select name="ashnai" id="ashnai" class="input11" required>
                                    <option value="">آشنایی</option>
                                    <?php foreach ($ash as $row) { ?>
                                        <option value="<?= $row['id'] ?>"><?= $row['name'] ?></option>
                                    <?php } ?>
                                </select></div>
                            <div class="attr11"><input type="submit" class="submit sub2" value="ثبت اطلاعات"></div>
                        </form>
                    </div>
                </div>
            </div>
                <div class="flip-box3">
                    <div class="flip-box-inner3">
                        <div class="flip-box-front3">
                            <form action="<?= U ?>respect/insertAsh" method="post">
                                <div class="attr11">
                                    <input type="text" name="name" class="input11" placeholder="نحوه آشنایی" required></div>
                                <div class="attr11"><input type="submit" class="submit sub2" value="ثبت اطلاعات"></div>
                            </form>
                        </div>
                    </div>
            </div>
            </div>
            <div class="contain">
                <div class="tab">
                    <ul>
                        <li onclick="tab(1)" id="hoghI" class="activTab">مشتری حقوقی</li>
                        <li onclick="tab(2)" id="haghI">مشتری حقیقی</li>
                        <?php if (isset($factor) && !empty($factor)) { ?>
                            <div class="factor"><span> آخرین فاکتور ثبت شده : <?= $factor ?> </span>
                                <a title="پرینت A4" href="respect/print/<?= $factor ?>" target="_blank"><img
                                            src="view/assets/image/printer.png"></a>
                            </div>
                        <?php } ?>
                    </ul>
                </div>
                <div class="tab1">
                    <div class="div00">
                        <div class="s1 s111">
                            <span class="textss1 ss"> انتخاب مشتری حقوقی </span>
                            <img id="img1" src="view/assets/image/angle-arrow-down.png" width="8px" height="8px"
                                 class="arrow img img1">
                        </div>
                        <div class="s2 s222 op">
                            <input type="text" class="searchCos1 searchCos">
                            <ul class="ul1"></ul>
                        </div>
                    </div>
                    <div class="div01 none">
                        <div class="s1 s112">
                            <span class="textss2 ss">انتخاب مشتری حقیقی</span>
                            <img src="view/assets/image/angle-arrow-down.png" width="8px" height="8px"
                                 class="arrow img img1">
                        </div>
                        <div class="s2 s223 op">
                            <input type="text" class="searchCos0 searchCos">
                            <ul class="ul0"></ul>
                        </div>
                    </div>
                    <div class="div1">

                        <div class="s11">
                            <span class="texts1 ss">انتخاب تعداد سفارش</span>
                            <img id="img11" src="view/assets/image/angle-arrow-down.png" width="8px" height="8px"
                                 class="arrow img">
                        </div>
                        <div class="s21 op">
                            <ul class="ul111">
                                <li>1 <span></span></li>
                               <!-- <li>2 <span></span></li>
                                <li>3 <span></span></li>
                                <li>4 <span></span></li>
                                <li>5 <span></span></li>
                                <li>6 <span></span></li>
                                <li>7 <span></span></li>
                                <li>8 <span></span></li>
                                <li>9 <span></span></li>
                                <li>10 <span></span></li>-->
                            </ul>
                        </div>
                        <input type="text" id="pcal1" class="pdate s1" style="overflow: hidden"
                               placeholder="تاریخ تحویل به مشتری ">
                        <input type="hidden" name="extra" id="extra">

                        <div class="s99">
                            <span class="texts99 ss">نحوه تسویه</span>
                            <img id="img99" src="view/assets/image/angle-arrow-down.png" width="8px" height="8px"
                                 class="arrow img">
                        </div>
                        <div class="s100 op">
                            <ul class="ul99">
                                <li data-pay="دفتری">دفتری <span></span></li>
                                <li data-pay="نقدی">نقدی <span></span></li>
                                <li data-pay="نقدی">کارت <span></span></li>
                            </ul>
                        </div>

                        <input type="text" class="bayane" placeholder="مبلغ بیانه را وارد کنید" required>


                        <input type="text" class="moneyDD" placeholder="هزینه طراحی" requir

                    </div>
                    <div class="div2">
                        <div class="resbox">
                            <div class="div3" id="11">
                                <div class="boxhead">
                                    <div class="r1"><span class="textr ss">انتخاب خدمات</span>
                                        <img id="img2" src="view/assets/image/angle-arrow-down.png" width="8px"
                                             height="8px"
                                             class="arrow img"></div>
                                    <div class="r2 op opp">
                                        <ul class="ul2"><?php foreach ($servic as $row) { ?>
                                                <li class="li2" data-ids="<?= $row['id'] ?>"
                                                    data-name="<?= $row['name_servic'] ?>"><?= $row['name_servic'] ?>
                                                <span></span></li><?php } ?></ul>
                                    </div>
                                    <div class="p1 "><span class="textp ss">انتخاب خدمات ویژه</span>
                                        <img id="img3" src="view/assets/image/angle-arrow-down.png" width="8px"
                                             height="8px"
                                             class="arrow img">
                                    </div>
                                    <div class="p2 op opp">
                                        <ul class="ul3"><?php foreach ($special as $row) { ?>
                                                <li class="li3"
                                                    data-sp="<?= $row['name_servic'] ?>"><?= $row['name_servic'] ?>
                                                <span></span></li><?php } ?></ul>
                                    </div>
                                </div>
                                <div class="sefaresh sef2"><label for="sef">سفارش : </label><input type="text"
                                                                                                   class="matnSefaresh">
                                    <div class="at">
                                        <label for="abad" class="label2">ابعاد : </label>
                                        <input type="text" class="input1 abad">
                                    </div>
                                    <div class="at">
                                        <label for="tedad" class="label2">تعداد : </label>
                                        <input type="text" class="input1 tedad">
                                    </div>
                                    <div class="at">
                                        <label for="jens" class="label2">جنس : </label>
                                        <input type="text" class="input1 jens">
                                    </div>
                                    <div class="at">
                                        <label for="metr" class="label2">متراژ : </label>
                                        <input type="text" class="input1 metr">
                                    </div>
                                    <div class="at">
                                        <label for="fi" class="label2">فی : </label>
                                        <input type="text" class="input1 fi">
                                    </div>
                                    <div class="at">
                                        <label for="sefidi" class="label2">سفیدی : </label>
                                        <input type="text" class="input1 sefidi">
                                    </div>
                                    <div class="at">
                                        <label for="pert" class="label2">پرت : </label>
                                        <input type="text" class="input1 pert">
                                    </div>
                                    <div class="at">
                                        <label for="man" class="label2">منگنه : </label>
                                        <input type="text" class="input1 man">
                                    </div>
                                    <div class="at">
                                        <label for="lif" class="label2">لیفه : </label>
                                        <input type="text" class="input1 lif">
                                    </div>
                                    <div class="at">
                                        <label for="valed" class="label2">ولد : </label>
                                        <input type="text" class="input1 valed">
                                    </div>
                                    <div class="at">
                                        <label for="mat" class="label2">نوع کاغذ/متریال : </label>
                                        <input type="text" class="input1 mat">
                                    </div>
                                    <div class="at">
                                        <label for="zekh" class="label2">گرماژ/ضخامت : </label>
                                        <input type="text" class="input1 zekh">
                                    </div>
                                    <div class="at">
                                        <label for="dokht" class="label2">دوخت : </label>
                                        <input type="text" class="input1 dokht">
                                    </div>
                                    <div class="at">
                                        <label for="rang" class="label2">رنگ : </label>
                                        <input type="text" class="input1 rang">
                                    </div>
                                    <div class="at2">
                                        <label for="tozih">توضیحات :</label>
                                        <textarea name="tozih" id="tozih" class="tozih" cols="30" rows="10"></textarea>
                                    </div>
                                </div>
                            </div>
                            <div class="div3" id="12">
                                <div class="boxhead">
                                    <div class="r1"><span class="textr ss">انتخاب خدمات</span>
                                        <img id="img2" src="view/assets/image/angle-arrow-down.png" width="8px"
                                             height="8px"
                                             class="arrow img"></div>
                                    <div class="r2 op opp">
                                        <ul class="ul2"><?php foreach ($servic as $row) { ?>
                                                <li class="li2" data-ids="<?= $row['id'] ?>"
                                                    data-name="<?= $row['name_servic'] ?>"><?= $row['name_servic'] ?>
                                                <span></span></li><?php } ?></ul>
                                    </div>
                                    <div class="p1 "><span class="textp ss">انتخاب خدمات ویژه</span>
                                        <img id="img3" src="view/assets/image/angle-arrow-down.png" width="8px"
                                             height="8px"
                                             class="arrow img">
                                    </div>
                                    <div class="p2 op opp">
                                        <ul class="ul3"><?php foreach ($special as $row) { ?>
                                                <li class="li3"
                                                    data-sp="<?= $row['name_servic'] ?>"><?= $row['name_servic'] ?>
                                                <span></span></li><?php } ?></ul>
                                    </div>
                                </div>
                                <div class="sefaresh sef2"><label for="sef">سفارش : </label><input type="text"
                                                                                                   class="matnSefaresh">
                                    <div class="at">
                                        <label for="abad" class="label2">ابعاد : </label>
                                        <input type="text" class="input1 abad">
                                    </div>
                                    <div class="at">
                                        <label for="tedad" class="label2">تعداد : </label>
                                        <input type="text" class="input1 tedad">
                                    </div>
                                    <div class="at">
                                        <label for="jens" class="label2">جنس : </label>
                                        <input type="text" class="input1 jens">
                                    </div>
                                    <div class="at">
                                        <label for="metr" class="label2">متراژ : </label>
                                        <input type="text" class="input1 metr">
                                    </div>
                                    <div class="at">
                                        <label for="fi" class="label2">فی : </label>
                                        <input type="text" class="input1 fi">
                                    </div>
                                    <div class="at">
                                        <label for="sefidi" class="label2">سفیدی : </label>
                                        <input type="text" class="input1 sefidi">
                                    </div>
                                    <div class="at">
                                        <label for="pert" class="label2">پرت : </label>
                                        <input type="text" class="input1 pert">
                                    </div>
                                    <div class="at">
                                        <label for="man" class="label2">منگنه : </label>
                                        <input type="text" class="input1 man">
                                    </div>
                                    <div class="at">
                                        <label for="lif" class="label2">لیفه : </label>
                                        <input type="text" class="input1 lif">
                                    </div>
                                    <div class="at">
                                        <label for="valed" class="label2">ولد : </label>
                                        <input type="text" class="input1 valed">
                                    </div>
                                    <div class="at">
                                        <label for="mat" class="label2">نوع کاغذ/متریال : </label>
                                        <input type="text" class="input1 mat">
                                    </div>
                                    <div class="at">
                                        <label for="zekh" class="label2">گرماژ/ضخامت : </label>
                                        <input type="text" class="input1 zekh">
                                    </div>
                                    <div class="at">
                                        <label for="dokht" class="label2">دوخت : </label>
                                        <input type="text" class="input1 dokht">
                                    </div>
                                    <div class="at">
                                        <label for="rang" class="label2">رنگ : </label>
                                        <input type="text" class="input1 rang">
                                    </div>
                                    <div class="at2">
                                        <label for="tozih">توضیحات :</label>
                                        <textarea name="tozih" id="tozih" class="tozih" cols="30" rows="10"></textarea>
                                    </div>
                                </div>
                            </div>
                            <div class="div3" id="13">
                                <div class="boxhead">
                                    <div class="r1"><span class="textr ss">انتخاب خدمات</span>
                                        <img id="img2" src="view/assets/image/angle-arrow-down.png" width="8px"
                                             height="8px"
                                             class="arrow img"></div>
                                    <div class="r2 op opp">
                                        <ul class="ul2"><?php foreach ($servic as $row) { ?>
                                                <li class="li2" data-ids="<?= $row['id'] ?>"
                                                    data-name="<?= $row['name_servic'] ?>"><?= $row['name_servic'] ?>
                                                <span></span></li><?php } ?></ul>
                                    </div>
                                    <div class="p1 "><span class="textp ss">انتخاب خدمات ویژه</span>
                                        <img id="img3" src="view/assets/image/angle-arrow-down.png" width="8px"
                                             height="8px"
                                             class="arrow img">
                                    </div>
                                    <div class="p2 op opp">
                                        <ul class="ul3"><?php foreach ($special as $row) { ?>
                                                <li class="li3"
                                                    data-sp="<?= $row['name_servic'] ?>"><?= $row['name_servic'] ?>
                                                <span></span></li><?php } ?></ul>
                                    </div>
                                </div>
                                <div class="sefaresh sef2"><label for="sef">سفارش : </label><input type="text"
                                                                                                   class="matnSefaresh">
                                    <div class="at">
                                        <label for="abad" class="label2">ابعاد : </label>
                                        <input type="text" class="input1 abad">
                                    </div>
                                    <div class="at">
                                        <label for="tedad" class="label2">تعداد : </label>
                                        <input type="text" class="input1 tedad">
                                    </div>
                                    <div class="at">
                                        <label for="jens" class="label2">جنس : </label>
                                        <input type="text" class="input1 jens">
                                    </div>
                                    <div class="at">
                                        <label for="metr" class="label2">متراژ : </label>
                                        <input type="text" class="input1 metr">
                                    </div>
                                    <div class="at">
                                        <label for="fi" class="label2">فی : </label>
                                        <input type="text" class="input1 fi">
                                    </div>
                                    <div class="at">
                                        <label for="sefidi" class="label2">سفیدی : </label>
                                        <input type="text" class="input1 sefidi">
                                    </div>
                                    <div class="at">
                                        <label for="pert" class="label2">پرت : </label>
                                        <input type="text" class="input1 pert">
                                    </div>
                                    <div class="at">
                                        <label for="man" class="label2">منگنه : </label>
                                        <input type="text" class="input1 man">
                                    </div>
                                    <div class="at">
                                        <label for="lif" class="label2">لیفه : </label>
                                        <input type="text" class="input1 lif">
                                    </div>
                                    <div class="at">
                                        <label for="valed" class="label2">ولد : </label>
                                        <input type="text" class="input1 valed">
                                    </div>
                                    <div class="at">
                                        <label for="mat" class="label2">نوع کاغذ/متریال : </label>
                                        <input type="text" class="input1 mat">
                                    </div>
                                    <div class="at">
                                        <label for="zekh" class="label2">گرماژ/ضخامت : </label>
                                        <input type="text" class="input1 zekh">
                                    </div>
                                    <div class="at">
                                        <label for="dokht" class="label2">دوخت : </label>
                                        <input type="text" class="input1 dokht">
                                    </div>
                                    <div class="at">
                                        <label for="rang" class="label2">رنگ : </label>
                                        <input type="text" class="input1 rang">
                                    </div>
                                    <div class="at2">
                                        <label for="tozih">توضیحات :</label>
                                        <textarea name="tozih" id="tozih" class="tozih" cols="30" rows="10"></textarea>
                                    </div>
                                </div>
                            </div>
                            <div class="div3" id="14">
                                <div class="boxhead">
                                    <div class="r1"><span class="textr ss">انتخاب خدمات</span>
                                        <img id="img2" src="view/assets/image/angle-arrow-down.png" width="8px"
                                             height="8px"
                                             class="arrow img"></div>
                                    <div class="r2 op opp">
                                        <ul class="ul2"><?php foreach ($servic as $row) { ?>
                                                <li class="li2" data-ids="<?= $row['id'] ?>"
                                                    data-name="<?= $row['name_servic'] ?>"><?= $row['name_servic'] ?>
                                                <span></span></li><?php } ?></ul>
                                    </div>
                                    <div class="p1 "><span class="textp ss">انتخاب خدمات ویژه</span>
                                        <img id="img3" src="view/assets/image/angle-arrow-down.png" width="8px"
                                             height="8px"
                                             class="arrow img">
                                    </div>
                                    <div class="p2 op opp">
                                        <ul class="ul3"><?php foreach ($special as $row) { ?>
                                                <li class="li3"
                                                    data-sp="<?= $row['name_servic'] ?>"><?= $row['name_servic'] ?>
                                                <span></span></li><?php } ?></ul>
                                    </div>
                                </div>
                                <div class="sefaresh sef2"><label for="sef">سفارش : </label><input type="text"
                                                                                                   class="matnSefaresh">
                                    <div class="at">
                                        <label for="abad" class="label2">ابعاد : </label>
                                        <input type="text" class="input1 abad">
                                    </div>
                                    <div class="at">
                                        <label for="tedad" class="label2">تعداد : </label>
                                        <input type="text" class="input1 tedad">
                                    </div>
                                    <div class="at">
                                        <label for="jens" class="label2">جنس : </label>
                                        <input type="text" class="input1 jens">
                                    </div>
                                    <div class="at">
                                        <label for="metr" class="label2">متراژ : </label>
                                        <input type="text" class="input1 metr">
                                    </div>
                                    <div class="at">
                                        <label for="fi" class="label2">فی : </label>
                                        <input type="text" class="input1 fi">
                                    </div>
                                    <div class="at">
                                        <label for="sefidi" class="label2">سفیدی : </label>
                                        <input type="text" class="input1 sefidi">
                                    </div>
                                    <div class="at">
                                        <label for="pert" class="label2">پرت : </label>
                                        <input type="text" class="input1 pert">
                                    </div>
                                    <div class="at">
                                        <label for="man" class="label2">منگنه : </label>
                                        <input type="text" class="input1 man">
                                    </div>
                                    <div class="at">
                                        <label for="lif" class="label2">لیفه : </label>
                                        <input type="text" class="input1 lif">
                                    </div>
                                    <div class="at">
                                        <label for="valed" class="label2">ولد : </label>
                                        <input type="text" class="input1 valed">
                                    </div>
                                    <div class="at">
                                        <label for="mat" class="label2">نوع کاغذ/متریال : </label>
                                        <input type="text" class="input1 mat">
                                    </div>
                                    <div class="at">
                                        <label for="zekh" class="label2">گرماژ/ضخامت : </label>
                                        <input type="text" class="input1 zekh">
                                    </div>
                                    <div class="at">
                                        <label for="dokht" class="label2">دوخت : </label>
                                        <input type="text" class="input1 dokht">
                                    </div>
                                    <div class="at">
                                        <label for="rang" class="label2">رنگ : </label>
                                        <input type="text" class="input1 rang">
                                    </div>
                                    <div class="at2">
                                        <label for="tozih">توضیحات :</label>
                                        <textarea name="tozih" id="tozih" class="tozih" cols="30" rows="10"></textarea>
                                    </div>
                                </div>
                            </div>
                            <div class="div3" id="15">
                                <div class="boxhead">
                                    <div class="r1"><span class="textr ss">انتخاب خدمات</span>
                                        <img id="img2" src="view/assets/image/angle-arrow-down.png" width="8px"
                                             height="8px"
                                             class="arrow img"></div>
                                    <div class="r2 op opp">
                                        <ul class="ul2"><?php foreach ($servic as $row) { ?>
                                                <li class="li2" data-ids="<?= $row['id'] ?>"
                                                    data-name="<?= $row['name_servic'] ?>"><?= $row['name_servic'] ?>
                                                <span></span></li><?php } ?></ul>
                                    </div>
                                    <div class="p1 "><span class="textp ss">انتخاب خدمات ویژه</span>
                                        <img id="img3" src="view/assets/image/angle-arrow-down.png" width="8px"
                                             height="8px"
                                             class="arrow img">
                                    </div>
                                    <div class="p2 op opp">
                                        <ul class="ul3"><?php foreach ($special as $row) { ?>
                                                <li class="li3"
                                                    data-sp="<?= $row['name_servic'] ?>"><?= $row['name_servic'] ?>
                                                <span></span></li><?php } ?></ul>
                                    </div>
                                </div>
                                <div class="sefaresh sef2"><label for="sef">سفارش : </label><input type="text"
                                                                                                   class="matnSefaresh">
                                    <div class="at">
                                        <label for="abad" class="label2">ابعاد : </label>
                                        <input type="text" class="input1 abad">
                                    </div>
                                    <div class="at">
                                        <label for="tedad" class="label2">تعداد : </label>
                                        <input type="text" class="input1 tedad">
                                    </div>
                                    <div class="at">
                                        <label for="jens" class="label2">جنس : </label>
                                        <input type="text" class="input1 jens">
                                    </div>
                                    <div class="at">
                                        <label for="metr" class="label2">متراژ : </label>
                                        <input type="text" class="input1 metr">
                                    </div>
                                    <div class="at">
                                        <label for="fi" class="label2">فی : </label>
                                        <input type="text" class="input1 fi">
                                    </div>
                                    <div class="at">
                                        <label for="sefidi" class="label2">سفیدی : </label>
                                        <input type="text" class="input1 sefidi">
                                    </div>
                                    <div class="at">
                                        <label for="pert" class="label2">پرت : </label>
                                        <input type="text" class="input1 pert">
                                    </div>
                                    <div class="at">
                                        <label for="man" class="label2">منگنه : </label>
                                        <input type="text" class="input1 man">
                                    </div>
                                    <div class="at">
                                        <label for="lif" class="label2">لیفه : </label>
                                        <input type="text" class="input1 lif">
                                    </div>
                                    <div class="at">
                                        <label for="valed" class="label2">ولد : </label>
                                        <input type="text" class="input1 valed">
                                    </div>
                                    <div class="at">
                                        <label for="mat" class="label2">نوع کاغذ/متریال : </label>
                                        <input type="text" class="input1 mat">
                                    </div>
                                    <div class="at">
                                        <label for="zekh" class="label2">گرماژ/ضخامت : </label>
                                        <input type="text" class="input1 zekh">
                                    </div>
                                    <div class="at">
                                        <label for="dokht" class="label2">دوخت : </label>
                                        <input type="text" class="input1 dokht">
                                    </div>
                                    <div class="at">
                                        <label for="rang" class="label2">رنگ : </label>
                                        <input type="text" class="input1 rang">
                                    </div>
                                    <div class="at2">
                                        <label for="tozih">توضیحات :</label>
                                        <textarea name="tozih" id="tozih" class="tozih" cols="30" rows="10"></textarea>
                                    </div>
                                </div>
                            </div>
                            <div class="div3" id="16">
                                <div class="boxhead">
                                    <div class="r1"><span class="textr ss">انتخاب خدمات</span>
                                        <img id="img2" src="view/assets/image/angle-arrow-down.png" width="8px"
                                             height="8px"
                                             class="arrow img"></div>
                                    <div class="r2 op opp">
                                        <ul class="ul2"><?php foreach ($servic as $row) { ?>
                                                <li class="li2" data-ids="<?= $row['id'] ?>"
                                                    data-name="<?= $row['name_servic'] ?>"><?= $row['name_servic'] ?>
                                                <span></span></li><?php } ?></ul>
                                    </div>
                                    <div class="p1 "><span class="textp ss">انتخاب خدمات ویژه</span>
                                        <img id="img3" src="view/assets/image/angle-arrow-down.png" width="8px"
                                             height="8px"
                                             class="arrow img">
                                    </div>
                                    <div class="p2 op opp">
                                        <ul class="ul3"><?php foreach ($special as $row) { ?>
                                                <li class="li3"
                                                    data-sp="<?= $row['name_servic'] ?>"><?= $row['name_servic'] ?>
                                                <span></span></li><?php } ?></ul>
                                    </div>
                                </div>
                                <div class="sefaresh sef2"><label for="sef">سفارش : </label><input type="text"
                                                                                                   class="matnSefaresh">
                                    <div class="at">
                                        <label for="abad" class="label2">ابعاد : </label>
                                        <input type="text" class="input1 abad">
                                    </div>
                                    <div class="at">
                                        <label for="tedad" class="label2">تعداد : </label>
                                        <input type="text" class="input1 tedad">
                                    </div>
                                    <div class="at">
                                        <label for="jens" class="label2">جنس : </label>
                                        <input type="text" class="input1 jens">
                                    </div>
                                    <div class="at">
                                        <label for="metr" class="label2">متراژ : </label>
                                        <input type="text" class="input1 metr">
                                    </div>
                                    <div class="at">
                                        <label for="fi" class="label2">فی : </label>
                                        <input type="text" class="input1 fi">
                                    </div>
                                    <div class="at">
                                        <label for="sefidi" class="label2">سفیدی : </label>
                                        <input type="text" class="input1 sefidi">
                                    </div>
                                    <div class="at">
                                        <label for="pert" class="label2">پرت : </label>
                                        <input type="text" class="input1 pert">
                                    </div>
                                    <div class="at">
                                        <label for="man" class="label2">منگنه : </label>
                                        <input type="text" class="input1 man">
                                    </div>
                                    <div class="at">
                                        <label for="lif" class="label2">لیفه : </label>
                                        <input type="text" class="input1 lif">
                                    </div>
                                    <div class="at">
                                        <label for="valed" class="label2">ولد : </label>
                                        <input type="text" class="input1 valed">
                                    </div>
                                    <div class="at">
                                        <label for="mat" class="label2">نوع کاغذ/متریال : </label>
                                        <input type="text" class="input1 mat">
                                    </div>
                                    <div class="at">
                                        <label for="zekh" class="label2">گرماژ/ضخامت : </label>
                                        <input type="text" class="input1 zekh">
                                    </div>
                                    <div class="at">
                                        <label for="dokht" class="label2">دوخت : </label>
                                        <input type="text" class="input1 dokht">
                                    </div>
                                    <div class="at">
                                        <label for="rang" class="label2">رنگ : </label>
                                        <input type="text" class="input1 rang">
                                    </div>
                                    <div class="at2">
                                        <label for="tozih">توضیحات :</label>
                                        <textarea name="tozih" id="tozih" class="tozih" cols="30" rows="10"></textarea>
                                    </div>
                                </div>
                            </div>
                            <div class="div3" id="17">
                                <div class="boxhead">
                                    <div class="r1"><span class="textr ss">انتخاب خدمات</span>
                                        <img id="img2" src="view/assets/image/angle-arrow-down.png" width="8px"
                                             height="8px"
                                             class="arrow img"></div>
                                    <div class="r2 op opp">
                                        <ul class="ul2"><?php foreach ($servic as $row) { ?>
                                                <li class="li2" data-ids="<?= $row['id'] ?>"
                                                    data-name="<?= $row['name_servic'] ?>"><?= $row['name_servic'] ?>
                                                <span></span></li><?php } ?></ul>
                                    </div>
                                    <div class="p1 "><span class="textp ss">انتخاب خدمات ویژه</span>
                                        <img id="img3" src="view/assets/image/angle-arrow-down.png" width="8px"
                                             height="8px"
                                             class="arrow img">
                                    </div>
                                    <div class="p2 op opp">
                                        <ul class="ul3"><?php foreach ($special as $row) { ?>
                                                <li class="li3"
                                                    data-sp="<?= $row['name_servic'] ?>"><?= $row['name_servic'] ?>
                                                <span></span></li><?php } ?></ul>
                                    </div>
                                </div>
                                <div class="sefaresh sef2"><label for="sef">سفارش : </label><input type="text"
                                                                                                   class="matnSefaresh">
                                    <div class="at">
                                        <label for="abad" class="label2">ابعاد : </label>
                                        <input type="text" class="input1 abad">
                                    </div>
                                    <div class="at">
                                        <label for="tedad" class="label2">تعداد : </label>
                                        <input type="text" class="input1 tedad">
                                    </div>
                                    <div class="at">
                                        <label for="jens" class="label2">جنس : </label>
                                        <input type="text" class="input1 jens">
                                    </div>
                                    <div class="at">
                                        <label for="metr" class="label2">متراژ : </label>
                                        <input type="text" class="input1 metr">
                                    </div>
                                    <div class="at">
                                        <label for="fi" class="label2">فی : </label>
                                        <input type="text" class="input1 fi">
                                    </div>
                                    <div class="at">
                                        <label for="sefidi" class="label2">سفیدی : </label>
                                        <input type="text" class="input1 sefidi">
                                    </div>
                                    <div class="at">
                                        <label for="pert" class="label2">پرت : </label>
                                        <input type="text" class="input1 pert">
                                    </div>
                                    <div class="at">
                                        <label for="man" class="label2">منگنه : </label>
                                        <input type="text" class="input1 man">
                                    </div>
                                    <div class="at">
                                        <label for="lif" class="label2">لیفه : </label>
                                        <input type="text" class="input1 lif">
                                    </div>
                                    <div class="at">
                                        <label for="valed" class="label2">ولد : </label>
                                        <input type="text" class="input1 valed">
                                    </div>
                                    <div class="at">
                                        <label for="mat" class="label2">نوع کاغذ/متریال : </label>
                                        <input type="text" class="input1 mat">
                                    </div>
                                    <div class="at">
                                        <label for="zekh" class="label2">گرماژ/ضخامت : </label>
                                        <input type="text" class="input1 zekh">
                                    </div>
                                    <div class="at">
                                        <label for="dokht" class="label2">دوخت : </label>
                                        <input type="text" class="input1 dokht">
                                    </div>
                                    <div class="at">
                                        <label for="rang" class="label2">رنگ : </label>
                                        <input type="text" class="input1 rang">
                                    </div>
                                    <div class="at2">
                                        <label for="tozih">توضیحات :</label>
                                        <textarea name="tozih" id="tozih" class="tozih" cols="30" rows="10"></textarea>
                                    </div>
                                </div>
                            </div>
                            <div class="div3" id="18">
                                <div class="boxhead">
                                    <div class="r1"><span class="textr ss">انتخاب خدمات</span>
                                        <img id="img2" src="view/assets/image/angle-arrow-down.png" width="8px"
                                             height="8px"
                                             class="arrow img"></div>
                                    <div class="r2 op opp">
                                        <ul class="ul2"><?php foreach ($servic as $row) { ?>
                                                <li class="li2" data-ids="<?= $row['id'] ?>"
                                                    data-name="<?= $row['name_servic'] ?>"><?= $row['name_servic'] ?>
                                                <span></span></li><?php } ?></ul>
                                    </div>
                                    <div class="p1 "><span class="textp ss">انتخاب خدمات ویژه</span>
                                        <img id="img3" src="view/assets/image/angle-arrow-down.png" width="8px"
                                             height="8px"
                                             class="arrow img">
                                    </div>
                                    <div class="p2 op opp">
                                        <ul class="ul3"><?php foreach ($special as $row) { ?>
                                                <li class="li3"
                                                    data-sp="<?= $row['name_servic'] ?>"><?= $row['name_servic'] ?>
                                                <span></span></li><?php } ?></ul>
                                    </div>
                                </div>
                                <div class="sefaresh sef2"><label for="sef">سفارش : </label><input type="text"
                                                                                                   class="matnSefaresh">
                                    <div class="at">
                                        <label for="abad" class="label2">ابعاد : </label>
                                        <input type="text" class="input1 abad">
                                    </div>
                                    <div class="at">
                                        <label for="tedad" class="label2">تعداد : </label>
                                        <input type="text" class="input1 tedad">
                                    </div>
                                    <div class="at">
                                        <label for="jens" class="label2">جنس : </label>
                                        <input type="text" class="input1 jens">
                                    </div>
                                    <div class="at">
                                        <label for="metr" class="label2">متراژ : </label>
                                        <input type="text" class="input1 metr">
                                    </div>
                                    <div class="at">
                                        <label for="fi" class="label2">فی : </label>
                                        <input type="text" class="input1 fi">
                                    </div>
                                    <div class="at">
                                        <label for="sefidi" class="label2">سفیدی : </label>
                                        <input type="text" class="input1 sefidi">
                                    </div>
                                    <div class="at">
                                        <label for="pert" class="label2">پرت : </label>
                                        <input type="text" class="input1 pert">
                                    </div>
                                    <div class="at">
                                        <label for="man" class="label2">منگنه : </label>
                                        <input type="text" class="input1 man">
                                    </div>
                                    <div class="at">
                                        <label for="lif" class="label2">لیفه : </label>
                                        <input type="text" class="input1 lif">
                                    </div>
                                    <div class="at">
                                        <label for="valed" class="label2">ولد : </label>
                                        <input type="text" class="input1 valed">
                                    </div>
                                    <div class="at">
                                        <label for="mat" class="label2">نوع کاغذ/متریال : </label>
                                        <input type="text" class="input1 mat">
                                    </div>
                                    <div class="at">
                                        <label for="zekh" class="label2">گرماژ/ضخامت : </label>
                                        <input type="text" class="input1 zekh">
                                    </div>
                                    <div class="at">
                                        <label for="dokht" class="label2">دوخت : </label>
                                        <input type="text" class="input1 dokht">
                                    </div>
                                    <div class="at">
                                        <label for="rang" class="label2">رنگ : </label>
                                        <input type="text" class="input1 rang">
                                    </div>
                                    <div class="at2">
                                        <label for="tozih">توضیحات :</label>
                                        <textarea name="tozih" id="tozih" class="tozih" cols="30" rows="10"></textarea>
                                    </div>
                                </div>
                            </div>
                            <div class="div3" id="19">
                                <div class="boxhead">
                                    <div class="r1"><span class="textr ss">انتخاب خدمات</span>
                                        <img id="img2" src="view/assets/image/angle-arrow-down.png" width="8px"
                                             height="8px"
                                             class="arrow img"></div>
                                    <div class="r2 op opp">
                                        <ul class="ul2"><?php foreach ($servic as $row) { ?>
                                                <li class="li2" data-ids="<?= $row['id'] ?>"
                                                    data-name="<?= $row['name_servic'] ?>"><?= $row['name_servic'] ?>
                                                <span></span></li><?php } ?></ul>
                                    </div>
                                    <div class="p1 "><span class="textp ss">انتخاب خدمات ویژه</span>
                                        <img id="img3" src="view/assets/image/angle-arrow-down.png" width="8px"
                                             height="8px"
                                             class="arrow img">
                                    </div>
                                    <div class="p2 op opp">
                                        <ul class="ul3"><?php foreach ($special as $row) { ?>
                                                <li class="li3"
                                                    data-sp="<?= $row['name_servic'] ?>"><?= $row['name_servic'] ?>
                                                <span></span></li><?php } ?></ul>
                                    </div>
                                </div>
                                <div class="sefaresh sef2"><label for="sef">سفارش : </label><input type="text"
                                                                                                   class="matnSefaresh">
                                    <div class="at">
                                        <label for="abad" class="label2">ابعاد : </label>
                                        <input type="text" class="input1 abad">
                                    </div>
                                    <div class="at">
                                        <label for="tedad" class="label2">تعداد : </label>
                                        <input type="text" class="input1 tedad">
                                    </div>
                                    <div class="at">
                                        <label for="jens" class="label2">جنس : </label>
                                        <input type="text" class="input1 jens">
                                    </div>
                                    <div class="at">
                                        <label for="metr" class="label2">متراژ : </label>
                                        <input type="text" class="input1 metr">
                                    </div>
                                    <div class="at">
                                        <label for="fi" class="label2">فی : </label>
                                        <input type="text" class="input1 fi">
                                    </div>
                                    <div class="at">
                                        <label for="sefidi" class="label2">سفیدی : </label>
                                        <input type="text" class="input1 sefidi">
                                    </div>
                                    <div class="at">
                                        <label for="pert" class="label2">پرت : </label>
                                        <input type="text" class="input1 pert">
                                    </div>
                                    <div class="at">
                                        <label for="man" class="label2">منگنه : </label>
                                        <input type="text" class="input1 man">
                                    </div>
                                    <div class="at">
                                        <label for="lif" class="label2">لیفه : </label>
                                        <input type="text" class="input1 lif">
                                    </div>
                                    <div class="at">
                                        <label for="valed" class="label2">ولد : </label>
                                        <input type="text" class="input1 valed">
                                    </div>
                                    <div class="at">
                                        <label for="mat" class="label2">نوع کاغذ/متریال : </label>
                                        <input type="text" class="input1 mat">
                                    </div>
                                    <div class="at">
                                        <label for="zekh" class="label2">گرماژ/ضخامت : </label>
                                        <input type="text" class="input1 zekh">
                                    </div>
                                    <div class="at">
                                        <label for="dokht" class="label2">دوخت : </label>
                                        <input type="text" class="input1 dokht">
                                    </div>
                                    <div class="at">
                                        <label for="rang" class="label2">رنگ : </label>
                                        <input type="text" class="input1 rang">
                                    </div>
                                    <div class="at2">
                                        <label for="tozih">توضیحات :</label>
                                        <textarea name="tozih" id="tozih" class="tozih" cols="30" rows="10"></textarea>
                                    </div>
                                </div>
                            </div>
                            <div class="div3" id="20">
                                <div class="boxhead">
                                    <div class="r1"><span class="textr ss">انتخاب خدمات</span>
                                        <img id="img2" src="view/assets/image/angle-arrow-down.png" width="8px"
                                             height="8px"
                                             class="arrow img"></div>
                                    <div class="r2 op opp">
                                        <ul class="ul2"><?php foreach ($servic as $row) { ?>
                                                <li class="li2" data-ids="<?= $row['id'] ?>"
                                                    data-name="<?= $row['name_servic'] ?>"><?= $row['name_servic'] ?>
                                                <span></span></li><?php } ?></ul>
                                    </div>
                                    <div class="p1 "><span class="textp ss">انتخاب خدمات ویژه</span>
                                        <img id="img3" src="view/assets/image/angle-arrow-down.png" width="8px"
                                             height="8px"
                                             class="arrow img">
                                    </div>
                                    <div class="p2 op opp">
                                        <ul class="ul3"><?php foreach ($special as $row) { ?>
                                                <li class="li3"
                                                    data-sp="<?= $row['name_servic'] ?>"><?= $row['name_servic'] ?>
                                                <span></span></li><?php } ?></ul>
                                    </div>
                                </div>
                                <div class="sefaresh sef2"><label for="sef">سفارش : </label><input type="text"
                                                                                                   class="matnSefaresh">
                                    <div class="at">
                                        <label for="abad" class="label2">ابعاد : </label>
                                        <input type="text" class="input1 abad">
                                    </div>
                                    <div class="at">
                                        <label for="tedad" class="label2">تعداد : </label>
                                        <input type="text" class="input1 tedad">
                                    </div>
                                    <div class="at">
                                        <label for="jens" class="label2">جنس : </label>
                                        <input type="text" class="input1 jens">
                                    </div>
                                    <div class="at">
                                        <label for="metr" class="label2">متراژ : </label>
                                        <input type="text" class="input1 metr">
                                    </div>
                                    <div class="at">
                                        <label for="fi" class="label2">فی : </label>
                                        <input type="text" class="input1 fi">
                                    </div>
                                    <div class="at">
                                        <label for="sefidi" class="label2">سفیدی : </label>
                                        <input type="text" class="input1 sefidi">
                                    </div>
                                    <div class="at">
                                        <label for="pert" class="label2">پرت : </label>
                                        <input type="text" class="input1 pert">
                                    </div>
                                    <div class="at">
                                        <label for="man" class="label2">منگنه : </label>
                                        <input type="text" class="input1 man">
                                    </div>
                                    <div class="at">
                                        <label for="lif" class="label2">لیفه : </label>
                                        <input type="text" class="input1 lif">
                                    </div>
                                    <div class="at">
                                        <label for="valed" class="label2">ولد : </label>
                                        <input type="text" class="input1 valed">
                                    </div>
                                    <div class="at">
                                        <label for="mat" class="label2">نوع کاغذ/متریال : </label>
                                        <input type="text" class="input1 mat">
                                    </div>
                                    <div class="at">
                                        <label for="zekh" class="label2">گرماژ/ضخامت : </label>
                                        <input type="text" class="input1 zekh">
                                    </div>
                                    <div class="at">
                                        <label for="dokht" class="label2">دوخت : </label>
                                        <input type="text" class="input1 dokht">
                                    </div>
                                    <div class="at">
                                        <label for="rang" class="label2">رنگ : </label>
                                        <input type="text" class="input1 rang">
                                    </div>
                                    <div class="at2">
                                        <label for="tozih">توضیحات :</label>
                                        <textarea name="tozih" id="tozih" class="tozih" cols="30" rows="10"></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="boxmsg"></div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="clear"></div>
<script>
    var flipBox = $('.flip-box');
    var flipBox2 = $('.flip-box2');
    var flipBox3 = $('.flip-box3');
    $('.add1').click(function () {
        flipBox2.fadeOut(10);
        flipBox3.fadeOut(10);
        flipBox2.removeClass('flip-box-hover');
        flipBox3.removeClass('flip-box-hover');
        $('.flip-box-inner2').removeClass('flip-box-hover');
        $('.flip-box-inner3').removeClass('flip-box-hover');
        flipBox.fadeToggle(800);
        flipBox.toggleClass('flip-box-hover');
        $('.flip-box-inner').toggleClass('flip-box-hover');
    });

    $('.add2').click(function () {
        flipBox.fadeOut(10);
        flipBox3.fadeOut(10);
        flipBox.removeClass('flip-box-hover');
        flipBox3.removeClass('flip-box-hover');
        $('.flip-box-inner').removeClass('flip-box-hover');
        $('.flip-box-inner3').removeClass('flip-box-hover');
        flipBox2.fadeToggle(800);
        flipBox2.toggleClass('flip-box-hover');
        $('.flip-box-inner2').toggleClass('flip-box-hover');
    });

    $('.add3').click(function () {
        flipBox.fadeOut(10);
        flipBox2.fadeOut(10);
        flipBox.removeClass('flip-box-hover');
        flipBox2.removeClass('flip-box-hover');
        $('.flip-box-inner').removeClass('flip-box-hover');
        $('.flip-box-inner2').removeClass('flip-box-hover');
        flipBox3.fadeToggle(800);
        flipBox3.toggleClass('flip-box-hover');
        $('.flip-box-inner3').toggleClass('flip-box-hover');
    })

</script>
<script>

    // for calendar
    var objCal1 = new AMIB.persianCalendar('pcal1',
        {extraInputID: "extra", extraInputFormat: "YYYYMMDD"}
    );


    //for tab
    function tab(i) {
        $('.tab ul li').removeClass('activTab');
        if (i == 1) {
            $('#hoghI').addClass('activTab');
            $('.div00').fadeIn(0);
            $('.div01').fadeOut(0);
        } else {
            $('#haghI').addClass('activTab');
            $('.div01').fadeIn(0);
            $('.div00').fadeOut(0);
        }
    }

    // for noe
    $('.m1').click(function () {
        var parentid = $(this).parents('.div3').attr('id');
        parent = $('#' + parentid);
        var dis = $('.m2').css('display');
        if (dis == "none") {
            $('.op').slideUp(100);
            $('.img').attr("src", "view/assets/image/angle-arrow-down.png");
            $('.ss').removeClass('hovers');
            parent.find('#imgm').attr("src", "view/assets/image/hover-arrow.png");
            parent.find('.textm').addClass('hovers');
            parent.find('.m2').slideDown(100);
        } else {
            parent.find('#imgm').attr("src", "view/assets/image/angle-arrow-down.png");
            parent.find('.textm').removeClass('hovers');
            parent.find('.m2').slideUp(100);
        }
    });

    $('.ulm li').click(function () {
        var parentid = $(this).parents('.div3').attr('id');
        parent = $('#' + parentid);
        parent.find('.ulm li').removeClass('lihover');
        parent.find('.ulm li span').removeClass('chekd');
        $(this).addClass('lihover');
        $(this).find('span').addClass('chekd');
        var act = parent.find('.ulm .lihover').length;
        var name = $(this).text();
        parent.find('.textm').text(name);
        var noe = $(this).attr('data-noe');
        parent.find('.sefaresh').fadeOut(10);
        if (noe == 1) {
            parent.find('.sef1').slideDown(100);
        } else {
            parent.find('.sef2').slideDown(100);
        }
        parent.find('#imgm').attr("src", "view/assets/image/angle-arrow-down.png");
        parent.find('.textm').removeClass('hovers');
        parent.find('.m2').slideUp(100);

    });

    // for pay
    var s99 = $('.s99');
    var texts99 = $('.texts99');
    var s100 = $('.s100');

    s99.click(function () {
        var dis = $('.s100').css('display');
        if (dis == "none") {
            $('.op').slideUp(100);
            $('.img').attr("src", "view/assets/image/angle-arrow-down.png");
            $('.ss').removeClass('hovers');
            $('#img99').attr("src", "view/assets/image/hover-arrow.png");
            texts99.addClass('hovers');
            s100.slideDown(200);
        } else {
            $('#img99').attr("src", "view/assets/image/angle-arrow-down.png");
            texts99.removeClass('hovers');
            s100.slideUp(200);
        }
    });

    $('.ul99 li').click(function () {
        $('.ul99 li').removeClass('lihover');
        $('.ul99 li').find('span').removeClass('chekd');
        $(this).addClass('lihover');
        $(this).find('span').addClass('chekd');
        var name = $('.ul99').find('.lihover').text();
        texts99.text(name);
        $('#img99').attr("src", "view/assets/image/angle-arrow-down.png");
        texts99.removeClass('hovers');
        s100.slideUp(100);
    });


    // for tedad
    var s11 = $('.s11');
    var texts1 = $('.texts1');
    var s21 = $('.s21');

    s11.click(function () {
        var dis = $('.s21').css('display');
        if (dis == "none") {
            $('.op').slideUp(100);
            $('.img').attr("src", "view/assets/image/angle-arrow-down.png");
            $('.ss').removeClass('hovers');
            $('#img11').attr("src", "view/assets/image/hover-arrow.png");
            texts1.addClass('hovers');
            s21.slideDown(100);
        } else {
            $('#img11').attr("src", "view/assets/image/angle-arrow-down.png");
            texts1.removeClass('hovers');
            s21.slideUp(100);
        }
    });

    $('.ul111 li').click(function () {
        $('.ul111 li').removeClass('lihover');
        $('.ul111 li').find('span').removeClass('chekd');
        $(this).addClass('lihover');
        $(this).find('span').addClass('chekd');
        var act = $('.ul111').find('.lihover').length;
        var name = $('.ul111').find('.lihover').text();
        texts1.text(name);
        $('#img11').attr("src", "view/assets/image/angle-arrow-down.png");
        texts1.removeClass('hovers');
        s21.slideUp(100);
        var div2 = $('.resbox');
        $('.div3').fadeOut(0);
        var heightEl = name * 450;
        var height = 160 + 100 + heightEl;
        $('.tab1').css({"height": height});
        if (name == 1) {
            $('#11').fadeIn(0);
        }
        if (name == 2) {
            $('#11').fadeIn(0);
            $('#12').fadeIn(0);
        }
        if (name == 3) {
            $('#11').fadeIn(0);
            $('#12').fadeIn(0);
            $('#13').fadeIn(0);
        }
        if (name == 4) {
            $('#11').fadeIn(0);
            $('#12').fadeIn(0);
            $('#13').fadeIn(0);
            $('#14').fadeIn(0);
        }
        if (name == 5) {
            $('#11').fadeIn(0);
            $('#12').fadeIn(0);
            $('#13').fadeIn(0);
            $('#14').fadeIn(0);
            $('#15').fadeIn(0);
        }
        if (name == 6) {
            $('#11').fadeIn(0);
            $('#12').fadeIn(0);
            $('#13').fadeIn(0);
            $('#14').fadeIn(0);
            $('#15').fadeIn(0);
            $('#16').fadeIn(0);
        }
        if (name == 7) {
            $('#11').fadeIn(0);
            $('#12').fadeIn(0);
            $('#13').fadeIn(0);
            $('#14').fadeIn(0);
            $('#15').fadeIn(0);
            $('#16').fadeIn(0);
            $('#17').fadeIn(0);
        }
        if (name == 8) {
            $('#11').fadeIn(0);
            $('#12').fadeIn(0);
            $('#13').fadeIn(0);
            $('#14').fadeIn(0);
            $('#15').fadeIn(0);
            $('#16').fadeIn(0);
            $('#17').fadeIn(0);
            $('#18').fadeIn(0);
        }
        if (name == 9) {
            $('#11').fadeIn(0);
            $('#12').fadeIn(0);
            $('#13').fadeIn(0);
            $('#14').fadeIn(0);
            $('#15').fadeIn(0);
            $('#16').fadeIn(0);
            $('#17').fadeIn(0);
            $('#18').fadeIn(0);
            $('#19').fadeIn(0);
        }
        if (name == 10) {
            $('#11').fadeIn(0);
            $('#12').fadeIn(0);
            $('#13').fadeIn(0);
            $('#14').fadeIn(0);
            $('#15').fadeIn(0);
            $('#16').fadeIn(0);
            $('#17').fadeIn(0);
            $('#18').fadeIn(0);
            $('#19').fadeIn(0);
            $('#20').fadeIn(0);
        }

        var sub = '<div onclick="submit()" class="sub submit"><span class="act"></span> ثبت سفارش</div>';
        $('.div2').append(sub);

    });

    //for special servic
    var p1 = $('.p1');
    var textp = $('.textp');
    var p2 = $('.p2');

    p1.click(function () {
        var parentid = $(this).parents('.div3').attr('id');
        parent = $('#' + parentid);
        var dis = parent.find('.p2').css('display');
        if (dis == "none") {
            $('.op').slideUp(0);
            $('.img').attr("src", "view/assets/image/angle-arrow-down.png");
            $('.ss').removeClass('hovers');
            parent.find('#img3').attr("src", "view/assets/image/hover-arrow.png");
            parent.find('.textp').addClass('hovers');
            parent.find('.p2').slideDown(100);
        } else {
            parent.find('#img3').attr("src", "view/assets/image/angle-arrow-down.png");
            parent.find('.textp').removeClass('hovers');
            parent.find('.p2').slideUp(100);
        }
    });

    $('.li3').click(function () {
        var parentid = $(this).parents('.div3').attr('id');
        parent = $('#' + parentid);
        $(this).toggleClass('lihover');
        $(this).find('span').toggleClass('chekd');
        var act = parent.find('.p2 ul .lihover').length;
        if (act == 1) {
            var name = parent.find('.p2 ul .lihover').text();
            parent.find('.textp').text(name);
        } else if (act > 1) {
            parent.find('.textp').text(act + " مورد انتخاب شده ");
        } else {
            parent.find('.textp').text(" انتخاب خدمات ویژه");
        }
    });

    //for servic
    var r1 = $('.r1');
    r1.click(function () {
        var parent = $(this).parents('.div3').attr('id');
        var dis = $('#' + parent).find('.r2').css('display');
        if (dis == "none") {
            $('.op').slideUp(0);
            $('.img').attr("src", "view/assets/image/angle-arrow-down.png");
            $('.ss').removeClass('hovers');

            $('#' + parent).find('.textr').addClass('hovers');
            $('#' + parent).find('#img2').attr("src", "view/assets/image/hover-arrow.png");
            $('#' + parent).find('.r2').slideDown(100);
        } else {
            $('#' + parent).find('#img2').attr("src", "view/assets/image/angle-arrow-down.png");
            $('#' + parent).find('.textr').removeClass('hovers');
            $('#' + parent).find('.r2').slideUp(100);
        }
    });
    $('.li2').click(function () {
        var parent = $(this).parents('.div3').attr('id');
        $(this).toggleClass('lihover');
        $(this).find('span').toggleClass('chekd');
        var act = $('#' + parent).find('.r2 .lihover').length;
        if (act == 1) {
            var name = $('#' + parent).find('.r2 ul .lihover').text();
            $('#' + parent).find('.textr').text(name);
        } else if (act > 1) {
            $('#' + parent).find('.textr').text(act + " مورد انتخاب شده ");
        } else {
            $('#' + parent).find('.textr').text(" انتخاب خدمات ");
        }
    });


    // for company
    var s1 = $('.s111');
    var texts = $('.textss1');
    var s2 = $('.s222');
    s1.click(function () {
        var dis = $('.s2').css('display');
        if (dis == "none") {
            $('.op').slideUp(100);
            $('.img').attr("src", "view/assets/image/angle-arrow-down.png");
            $('.ss').removeClass('hovers');
            $('.img1').attr("src", "view/assets/image/hover-arrow.png");
            texts.addClass('hovers');
            s2.slideDown(100);
        } else {
            $('.img1').attr("src", "view/assets/image/angle-arrow-down.png");
            texts.removeClass('hovers');
            s2.slideUp(100);
        }
    });

    // for customer
    $('.s112').click(function () {
        var dis = $('.s223').css('display');
        if (dis == "none") {
            $('.op').slideUp(100);
            $('.img').attr("src", "view/assets/image/angle-arrow-down.png");
            $('.ss').removeClass('hovers');
            $('.img1').attr("src", "view/assets/image/hover-arrow.png");
            $('.textss2').addClass('hovers');
            $('.s223').slideDown(100);
        } else {
            $('.img1').attr("src", "view/assets/image/angle-arrow-down.png");
            $('.textss2').removeClass('hovers');
            $('.s223').slideUp(100);
        }
    });


    // serach in customer
    var boxSearch = $('.searchCos1');
    var boxAll = $('.ul1');
    boxSearch.keyup(function () {
        searchCoin();
    });

    function searchCoin() {
        var search = boxSearch.val();
        var url = "<?= U ?>respect/searchCus1";
        var data = {search: search};
        if (search.length > 0) {
            $.post(url, data, function (msg) {
                boxAll.html(msg);
            })
        } else {
            data = {search: 'all'};
            $.post(url, data, function (msg) {
                boxAll.html(msg);
            })
        }
    }

    searchCoin();


    // serach in customer2
    var boxSearch0 = $('.searchCos0');
    var boxAll0 = $('.ul0');
    boxSearch0.keyup(function () {
        searchCoin0();
    });

    function searchCoin0() {
        var search = boxSearch0.val();
        var url = "<?= U ?>respect/searchCus2";
        var data = {search: search};
        if (search.length > 0) {
            $.post(url, data, function (msg) {
                boxAll0.html(msg);
            })
        } else {
            data = {search: 'all'};
            $.post(url, data, function (msg) {
                boxAll0.html(msg);
            })
        }
    }

    searchCoin0();
</script>
<script>
    $('.op').mouseleave(function () {
        $('.op').slideUp(150);
        $('.img').attr("src", "view/assets/image/angle-arrow-down.png");
        $('.ss').removeClass('hovers');
    });

    $('#insert').addClass('liActiv');
    $('#insert a').addClass('aActiv');
</script>
<script>
    function submit() {
        var noe = $('.tab ul').find('.activTab').attr('id');
        var costumer;
        if (noe == 'haghI') {
            costumer = $('.ul0').find('.lihover').attr('data-h');
        }
        if (noe == "hoghI") {
            costumer = $('.ul1').find('.lihover').attr('data-h');
        }
        var tedad = $('.ul111').find('.lihover').text();
        var tahvil = $('#pcal1').val();

        //get servic
        var k;
        var l;
        var item;
        var name;
        var servic = [];
        var lengthItem;
        var active;
        for (var id = 11; id < 21; id++) {
            var items = [];
            var itemss = [];
            lengthItem = $('#' + id).find('.ul2 li').length;
            for (k = 0; k < lengthItem; k++) {
                active = $('#' + id).find('.ul2 .lihover');
                item = active.attr('data-ids');
                name = active.attr('data-name');
                if (item !== undefined) {
                    $('#' + id).find("[data-ids = '" + item + "']").removeClass('lihover');
                    itemss.push(item);
                    items.push(name);
                }
            }
            for (var kk = 0; kk < itemss.length; kk++) {
                $('#' + id).find("[data-ids = '" + itemss[kk] + "']").addClass('lihover');
            }
            servic.push(items);
        }

        //get special
        var m;
        var it;
        var lengthIt;
        var activeIt;
        var special = [];
        for (var idt = 11; idt < 21; idt++) {
            its = [];
            lengthIt = $('#' + idt).find('.ul3 li').length;
            for (m = 0; m < lengthIt; m++) {
                activeIt = $('#' + idt).find('.ul3 .lihover');
                it = activeIt.attr('data-sp');
                if (it != undefined) {
                    $('#' + idt).find("[data-sp = '" + it + "']").removeClass('lihover');
                    its.push(it);
                }
            }
            for (var mm = 0; mm < its.length; mm++) {
                $('#' + idt).find("[data-sp = '" + its[mm] + "']").addClass('lihover');
            }
            special.push(its);
        }

        //get pay sefaresh
        var pay = $('.ul99').find('.lihover').attr('data-pay');
        var bayane = $('.bayane').val();
        var moneyD = $('.moneyDD').val();

        // get sefaresh
        var allsef = [];

        for (var b = 11; b < 21; b++) {
            //sefaresh
            var sef = ' ';
            var text = $('#' + b).find('.matnSefaresh').val();
            var onvan;
            if (text != undefined && text.length > 0) {
                onvan = 'سفارش : ' + text + ' ,  ';
                sef += onvan;
            }
            var abad = $('#' + b).find('.abad').val();
            if (abad != undefined && abad.length > 0) {
                sef += 'ابعاد : ' + abad + ' ,  ';
            }
            var ted = $('#' + b).find('.tedad').val();
            if (ted != undefined && ted.length > 0) {
                sef += 'تعداد : ' + ted + ' ,  ';
            }
            var jens = $('#' + b).find('.jens').val();
            if (jens != undefined && jens.length > 0) {
                sef += 'جنس : ' + jens + ' ,  ';
            }
            var metr = $('#' + b).find('.metr').val();
            if (metr != undefined && metr.length > 0) {
                sef += 'متراژ : ' + metr + ' ,  ';
            }
            var fi = $('#' + b).find('.fi').val();
            if (fi != undefined && fi.length > 0) {
                sef += 'فی : ' + fi + ' ,  ';
            }

            var sefid = $('#' + b).find('.sefidi').val();
            if (sefid != undefined && sefid.length > 0) {
                sef += 'سفیدی : ' + sefid + ' ,  ';
            }
            var pert = $('#' + b).find('.pert').val();
            if (pert != undefined && pert.length > 0) {
                sef += 'پرت : ' + pert + ' ,  ';
            }
            var man = $('#' + b).find('.man').val();
            if (man != undefined && man.length > 0) {
                sef += 'منگنه : ' + man + ' ,  ';
            }
            var lif = $('#' + b).find('.lif').val();
            if (lif != undefined && lif.length > 0) {
                sef += 'لیفه : ' + lif + ' ,  ';
            }
            var valed = $('#' + b).find('.valed').val();
            if (valed != undefined && valed.length > 0) {
                sef += 'ولد : ' + valed + ' ,  ';
            }

            var mat = $('#' + b).find('.mat').val();
            if (mat != undefined && mat.length > 0) {
                sef += 'متریال : ' + mat + ' ,  ';
            }
            var zekh = $('#' + b).find('.zekh').val();
            if (zekh != undefined && zekh.length > 0) {
                sef += 'گرماژ/ضخامت : ' + zekh + ' ,  ';
            }
            var dokht = $('#' + b).find('.dokht').val();
            if (dokht != undefined && dokht.length > 0) {
                sef += 'دوخت : ' + dokht + ' ,  ';
            }
            var rang = $('#' + b).find('.rang').val();
            if (rang != undefined && rang.length > 0) {
                sef += 'رنگ : ' + rang + ' ,  ';
            }
            var tozih = $('#' + b).find('.tozih').val();
            if (tozih != undefined && tozih.length > 0) {
                sef += 'توضیحات : ' + tozih;
            }
            allsef.push(sef);
        }

        var data = {
            pay: pay,
            noe: noe,
            bayane: bayane,
            costumer: costumer,
            tedad: tedad,
            tahvil: tahvil,
            servic: servic,
            special: special,
            sef: allsef,
            moneyD : moneyD
        };
        
        var url = "<?= U ?>respect/insertRes";
        var ok = 1;
        var err;
        if (costumer == undefined) {
            ok = 0;
            err = 'مشتری وارد نشده است !';
        }
        if (tahvil.length == 0) {
            ok = 0;
            err = 'تاریخ تحویل وارد نشده است !';
        }
        if (pay === undefined || pay.length == 0) {
            ok = 0;
            err = 'نحوه تسویه حساب وارد نشده است !';
        }
        if (bayane.length == 0) {
            ok = 0;
            err = 'مبلغ بیانه وارد نشده است !';
        }
        var subm = $('.sub');
        var span ='<img src="view/assets/image/ajax-loader.gif" class="act1">';
        if (ok == 0) {
            $('.boxmsg').fadeIn(0).text(err);
        } else if (ok == 1) {
            subm.text(' ').animate({"width":"35px","border-radius":"100%","margin-left":"18px","cursor":"text"},400);
            subm.append(span);

            $.post(url, data, function (msg) {
                $('.boxmsg').fadeIn(0).text(msg);
            });
            setTimeout(function () {
                location.reload(true);
            }, 7000)

        }

    }
</script>