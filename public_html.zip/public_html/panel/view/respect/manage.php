<?php
$order = $data[0];
?>
<div class="option">
    <style>
        .option {
            width: 100%;
            min-width: 1300px !important;
            margin: 10px auto;
        }

        .option * {
            text-align: right;
            direction: rtl;
        }

        .mainOption {
            width: 80%;
            min-width: 1000px;
            float: left;
            margin-left: 10px;
            margin-top: 10px;
        }

    </style>
    <style>
        .table {
            width: 100%;
            position: relative;
            min-width: 700px;
            background-color: #f7feff;
            border: 1px solid #3da6ff;
            box-sizing: border-box;
        }

        .table tr:first-child td {
            background-color: #53a3c6;
            padding: 13px 8px;
            text-align: center;
            font-size: 12px;
            min-width: 65px;
            display: table-cell;
            color: white;
            font-family: mapno !important;
        }

        .table tr:nth-child(even) {
            background-color: white;
        }

        .table tr td {
            padding: 13px 8px;
            text-align: center;
            font-size: 12px;
            min-width: 52px;
            color: #030375;
            line-height: 18px;
            font-family: mapnoS;

        }

        .manag {
            height: 500px;
            overflow-y: auto;
        }

    </style>
    <?php require('optionList.php'); ?>
    <div class="mainOption">
        <div class="hed">مدیریت سفارشات</div>
        <div class="manag">
            <table class="table">
                <tr class="heding">
                    <td>کد سفارش</td>
                    <td style="min-width: 100px">سفارش</td>
                    <td>خدمات</td>
                    <td>خدمات ویژه</td>
                    <td>شماره فاکتور</td>
                    <td>تاریخ سفارش</td>
                    <td>تاریخ تحویل</td>
                    <td>مشتری</td>
                    <td>هزینه طراحی</td>
                    <td>پیوست</td>
                    <td>وضعیت</td>
                    <td>پیشرفته</td>
                    <td>ویرایش</td>
                </tr>
                <?php foreach ($order as $key => $row) {
                    $order = $row['orders'];

                    $servic = unserialize($row['servic']);
                    if (is_array($servic)) {
                        $servicValus = array_values($servic);
                        $servic = implode(' ،  ', $servicValus);
                    }
                    $special = unserialize($row['special']);
                    if (is_array($special)) {
                        $soecialValus = array_values($special);
                        $special = implode(' ،  ', $soecialValus);
                    }
                    $level = unserialize($row['level']);
                    $arr = [];
                    $marhale = '';
                    if (is_array($level)) {
                        foreach ($level as $index => $lev) {
                            if ($lev[2] == 'مدیریت') {
                                $send = $lev[0];
                            }
                            $arr[] = $lev[2];
                        }
                        if (is_array($arr)) {
                            $marhale = implode(' => ', $arr);
                        }
                    }
                    $nowLev = $row['now'];
                    ?>
                    <tr id="<?= $row['id'] ?>" class="tr">
                        <td><?= $row['id'] ?></td>
                        <td class="order"><?= $order ?></td>
                        <td><?= $servic ?></td>
                        <td><?= $special ?></td>
                        <td><?= $row['factor'] ?></td>
                        <td class="start"><?= $row['start_d'] ?></td>
                        <td class="end"><?= $row['end_d'] ?></td>
                        <td><?= $row['cos'] ?></td>
                        <td><?= $row['price_design'] ?></td>
                        <td><?php if (!empty($row['img'])) {
                                echo $row['img'];
                            } else {
                                echo "ندارد";
                            } ?></td>
                        <td>پذیرش => <?= $marhale ?></td>
                        <td>
                            <?php if ($nowLev == "پذیرش" || empty($marhale)) { ?>
                                <a href="respect/editone/<?= $row['id'] ?>"><img
                                            src="view/assets/image/review.png"
                                            style="cursor: pointer"></a>
                            <?php } ?>
                        </td>
                        <td>
                            <?php if ($nowLev == "پذیرش" || empty($marhale)) { ?>
                                <img onclick="edit(<?= $row['id'] ?>)"
                                     src="view/assets/image/review.png"
                                     style="cursor: pointer">
                            <?php } ?>
                        </td>
                    </tr>
                <?php } ?>
            </table>
        </div>
    </div>

</div>

<div class="edit">
    <img class="del" src="view/assets/image/delete.png">
    <form action="respect/editFacotr" method="post">
        <span class="tit1">متن سفارش : </span>
        <input name="id" type="hidden" class="idFactor">
        <textarea name="text" id="text" cols="30" rows="10"></textarea>
        <input type="submit" class="submit" value="اعمال تغییرات">
    </form>
</div>
<div class="bgblack"></div>
<div class="clear"></div>
<script>

    var box = $('.edit');
    var black = $('.bgblack');

    function edit(id) {
        var text = $('#' + id).find('.order').text();
        box.fadeIn(100);
        black.fadeIn(100);
        $('#text').val(text);
        $('.idFactor').val(id);
    }

    $(".bgblack").click(function () {
        box.fadeOut(100);
        black.fadeOut(100);
    });
    $(".del").click(function () {
        box.fadeOut(100);
        black.fadeOut(100);
    })

</script>
<script>
    $('#manag').addClass('liActiv');
    $('#manag a').addClass('aActiv');
</script>
<style>

    .del {
        cursor: pointer;
        width: 28px;
        border-radius: 100%;
        overflow: hidden;
        position: absolute;
        top: -16px;
        right: -13px;
    }

    .submit {
        margin: 20px auto;
        display: block;
        padding-top: 0;
    }

    #text {
        width: 96%;
        display: block;
        resize: none;
        margin: auto;
        border: 1px solid #a2aab1;
        border-radius: 8px;
        padding: 20px;
        box-sizing: border-box;
        color: #07051d;
        font-family: mapnoS;
        font-size: 14px;
    }

    .tit1 {
        display: block;
        padding: 22px 12px 10px 45px;
        font-family: mapnoS;
        font-size: 15px;
    }

    .edit {
        display: none;
        width: 800px;
        height: 430px;
        position: fixed;
        background: #fff;
        z-index: 99;
        top: 50%;
        margin-top: -215px;
        left: 50%;
        margin-left: -400px;
        border-radius: 5px;
    }

    .bgblack {
        cursor: pointer;
        display: none;
        width: 100%;
        height: 100%;
        position: fixed;
        top: 0;
        left: 0;
        opacity: 0.5;
        background: #0a2b1d;
        z-index: 9;
    }
</style>