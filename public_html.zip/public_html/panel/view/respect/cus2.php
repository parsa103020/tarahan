<?php
$result = $data[0];
?>
<?php foreach ($result as $row) { ?>
    <li data-h="<?= $row['id'] ?>" class="li22"><?= $row['name'] . ' ' . $row['last'] ?><span></span></li>
<?php } ?>
<script>
    var li2 = $('.li22');
    li2.click(function () {
        li2.removeClass('lihover');
        li2.find('span').removeClass('chekd');
        $(this).addClass('lihover');
        $(this).find('span').addClass('chekd');
        $('.textss2').text("1 مورد انتخاب شده");
        $('.img1').attr("src", "view/assets/image/angle-arrow-down.png");
        $('.s223').slideUp(100);
        $('.textss2').removeClass('hovers');
        // in cus1
        $('.textss1').text("انتخاب مشتری حقوقی");
        $('.li1').removeClass('lihover');
        $('.li1').find('span').removeClass('chekd');
    });
</script>






