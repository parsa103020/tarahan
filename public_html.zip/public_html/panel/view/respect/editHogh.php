<?php
$cus = $data[0];
?>
<form action="respect/formEditHogh" method="post">
    <input type="hidden" value="<?= $cus['id'] ?>" name="id">
    <div class="attr">
        <label for="" class="lable"> مشتری حقوقی :</label>
        <input type="text" name="company" class="input" value="<?= $cus['company'] ?>">
    </div>
    <div class="attr">
        <label for="" class="lable"> مدیر :</label>
        <input type="text" name="manager" class="input" value="<?= $cus['manager'] ?>">
    </div>
    <div class="attr">
        <label for="" class="lable"> کد اقتصادی :</label>
        <input type="text" name="cod_eco" class="input" value="<?= $cus['cod_eco'] ?>">
    </div>
    <div class="attr">
        <label for="" class="lable"> تلفن مدیر :</label>
        <input type="text" class="input" name="mobile_manager" value="<?= $cus['mobile_manager'] ?>"
               style="direction: ltr !important;text-align:left:">
    </div>
    <div class="attr">
        <label for="" class="lable">شماره ثبت :</label>
        <input type="text" class="input" name="sabt" value="<?= $cus['sabt'] ?>" style="direction: ltr !important;text-align:left:">
    </div>
    <div class="attr">
        <label for="" class="lable"> ایمیل :</label>
        <input type="text" class="input" name="email" value="<?= $cus['email'] ?>"
               style="direction: ltr !important;text-align:left:">
    </div>
    <div class="attr">
        <label for="" class="lable"> تلگرام :</label>
        <input type="text" class="input" name="telegram" value="<?= $cus['telegram'] ?>"
               style="direction: ltr !important;text-align:left:">
    </div>
    <div class="attr">
        <label for="" class="lable"> آدرس :</label>
        <input type="text" class="input" name="address" value="<?= $cus['address'] ?>">
    </div>

    <div class="attr">
        <input type="submit" class="submit sub3" value="اعمال تغییرات">
    </div>

</form>