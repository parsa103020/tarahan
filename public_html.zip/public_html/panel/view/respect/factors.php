<div class="option">
    <style>
        .option {
            width: 100%;
            min-width: 1300px !important;
            margin: 10px auto;
        }

        .option * {
            text-align: right;
            direction: rtl;
        }

        .mainOption {
            width: 80%;
            min-width: 1000px;
            float: left;
            margin-left: 10px;
            margin-top: 10px;
        }

    </style>
    <style>
        .table {
            width: 100%;
            position: relative;
            min-width: 700px;
            background-color: #f7feff;
            border: 1px solid #3da6ff;
            box-sizing: border-box;
        }

        .table tr:first-child td {
            background-color: #53a3c6;
            padding: 13px 8px;
            text-align: center;
            font-size: 12px;
            min-width: 65px;
            display: table-cell;
            color: white;
            font-family: mapno !important;
        }

        .table tr:nth-child(even) {
            background-color: white;
        }

        .table tr td {
            padding: 13px 8px;
            text-align: center;
            font-size: 12px;
            min-width: 52px;
            color: #030375;
            line-height: 18px;
            font-family: mapnoS;

        }

        .manag {
            height: 500px;
            overflow-y: auto;
        }

        .search {
            width: 373px;
            height: 40px;
            box-sizing: border-box;
            border: 1px solid #6cdbc7;
            padding: 2px 14px;
            margin: 15px 1px 50px 10px;
            border-radius: 6px;
            font-family: mapnoS;
            font-size: 13px;
            color: #00006d;
        }
    </style>
    <?php require('optionList.php'); ?>
    <div class="mainOption">
        <div class="hed">پیگیری سفارشات</div>
        <div>
            <input type="text" class="search" placeholder="شماره فاکتور یا نام مشتری را وارد کنید ... ">
        </div>
        <div class="manag">
        </div>
    </div>

</div>
<div class="clear"></div>

<script>
    function search(key) {
        var url = 'respect/searchFactor';
        var data = {key: key};
        if(key.length>3){
        $.post(url, data, function (msg) {
            $('.manag').html(msg);
        });
        }
    }

    $('.search').keyup(function () {
       var key = $('.search').val();
       search(key);
    });
    search('mapnoco.ir');
    $('#pay').addClass('liActiv');
    $('#pay a').addClass('aActiv');
</script>
