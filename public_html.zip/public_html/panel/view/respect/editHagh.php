<?php
$cus = $data[0];
?>
<form action="respect/formEditHagh" method="post">
    <input type="hidden" name="id" value="<?= $cus['id'] ?>">
    <div class="attr">
        <label for="" class="lable"> مشتری :</label>
        <input type="text" name="name" class="input" value="<?= $cus['name'] . ' ' . $cus['last'] ?>">
    </div>
    <div class="attr">
        <label for="" class="lable"> تلفن :</label>
        <input type="text" class="input" name="mobile" value="<?= $cus['mobile'] ?>" style="direction: ltr !important;">
    </div>
    <div class="attr">
        <label for="" class="lable"> تلگرام :</label>
        <input type="text" class="input" name="telegram" value="<?= $cus['telegram'] ?>" style="direction: ltr !important;">
    </div>
    <div class="attr">
        <label for="" class="lable"> ایمیل :</label>
        <input type="text" class="input" name="email" value="<?= $cus['email'] ?>" style="direction: ltr !important;">
    </div>
    <div class="attr">
        <label for="" class="lable">آدرس :</label>
        <input type="text" class="input" name="address" value="<?= $cus['address'] ?>">
    </div>

    <div class="attr">
        <input type="submit" class="submit sub3" value="اعمال تغییرات">
    </div>

</form>