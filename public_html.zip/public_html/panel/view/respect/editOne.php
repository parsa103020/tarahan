<script src="<?= U ?>view/assets/uploadfile/jquery.uploadfile.min.js"></script>
<?php
$orders = $data[0];
$level = $data[1];
$order = $orders['orders'];

@$lev = unserialize($orders['level']);
@$nameLev = $lev[0][2];

$servic = unserialize($orders['servic']);
if (is_array($servic)) {
    $servicValus = array_values($servic);
    $servic = implode(' ،  ', $servicValus);
}

$special = unserialize($orders['special']);
if (is_array($special)) {
    $specialValus = array_values($special);
    $special = implode(' ،  ', $specialValus);
}
$mony = $orders['mony'];
if (!empty($mony) && is_numeric($mony)) {
    $mony = number_format($mony);
}
$dis = unserialize($orders['dis']);
$ok = 0;
$go=1;
if (is_array($dis)) {
    $ok=1;
}
?>
<div class="option">
    <style>
        .option {
            width: 100%;
            min-width: 1300px !important;
            margin: 10px auto;
        }

        .option * {
            text-align: right;
            direction: rtl;
        }

        .mainOption {
            width: 80%;
            min-width: 1000px;
            float: left;
            margin-left: 10px;
            margin-top: 10px;
        }

    </style>
    <style>
        .page {
            padding: 20px 10px;
            position: relative;
        }

        #order {
            width: 694px;
            margin: 10px auto;
            min-width: 400px;
            height: 86px;
            font-size: 13px;
            font-family: mapnoS;
            border: 1px solid #c0e6e3;
            box-sizing: border-box;
            padding: 8px 10px;
            border-radius: 4px;
            resize: none;
        }

        .laborder {
            display: block;
            margin-bottom: 5px;
        }

        .attr {
            width: 300px;
            height: 60px;
            margin-top: 24px;
            display: inline-block;
            margin-left: 25px;
        }

        .label {
            display: block;
            margin-right: 5px;
        }

        .input {
            display: block;
            margin-top: 15px;
            width: 300px;
            height: 35px;
            box-sizing: border-box;
            border: 1px solid #c0e6e3;
            border-radius: 5px;
            padding: 4px 10px;
        }

        .attr1 {
            width: 220px;
            height: 60px;
            margin-top: 24px;
            display: inline-block;
            position: relative;
            margin-left: 13px;
        }

        .label1 {
            margin-left: 10px;
            position: absolute;
            right: 0;
            top: 8px;
        }

        .input1 {
            width: 140px;
            height: 35px;
            box-sizing: border-box;
            border: 1px solid #c0e6e3;
            border-radius: 5px;
            padding: 4px 10px;
            position: absolute;
            left: 0;
            top: -4px;
            text-align: center;
            direction: ltr;
        }

        input, select {
            background: white;
        }

        .file {
            position: absolute;
            width: 74px;
            left: 8px;
            top: 3px;
        }

        .line {
            width: 689px;
            border-bottom: 1px dashed #19b5fe;
            position: absolute;
            bottom: 0;
        }

        .in {
            width: 715px;
            position: relative;
            height: 69px;
        }

        .sub {
            border: 1px solid #1d3b3e;
            position: absolute;
            bottom: 12px;
            left: 26px;
            padding-top: 0 !important;
        }

        .img {
            position: absolute;
            left: 30px;
            top: 37px;
            z-index: 33;
            border: 1px solid #8198af;
            border-radius: 4px;
            overflow: hidden;
            height: 317px;
            width: 300px;
        }

        .img img {
            width: 100%;
            height: 100%;
            position: absolute;
            top: 0;
            left: 0;
        }

        .img:hover {
            left: 150px;
            transform: scale(1.8);
            box-shadow: 0 0 10px 1px #1e4561;
            z-index: 99;
            transition: 0.8s;
        }

        .men {
            display: inline-block;
            margin-right: 27px;
            margin-top: 2px;
        }

        .men a {
            color: #f4f8ff !important;
        }

        .men a:hover {
            color: #28e1ff !important;
        }

        .span {
            position: relative;
            width: 44px;
            display: inline-block;
        }

        .span img {
            position: absolute;
            top: -12px;
            right: 10px;
        }
    </style>
    <?php require ('optionList.php'); ?>
    <div class="mainOption">
        <div class="hed">مدیریت سفارشات
            <div class="men">
                <a href="respect/manag">سفارشات</a>
                <span class="span"><img src="view/assets/image/double-arrow.png" width="20" height="20"></span>
                <a>سفارش <?= @$orders['cos'] ?></a>
            </div>
        </div>
        <div class="page">
            <div class="in">
                <form action="respect/setChange/<?= $orders['id'] ?>" method="post" enctype="multipart/form-data">
                    <div class="attr1">
                        <label for="factor" class="label1">استعلام قیمت : </label>
                        <input type="text" class="input1" name="mony" value="<?= @$mony ?>">
                    </div>
                    <div class="attr1">
                        <label for="factor" class="label1">مرحله ی بعد : </label>
                        <select name="next" id="next" name="next" class="input1" required>
                            <option value=""></option>
                            <?php foreach ($level as $row) { ?>
                            <option value="<?= $row['name'] ?>" <?php if (isset($nameLev) && $nameLev == $row['name']) {
                            echo "selected";
                            } ?>><?= $row['name'] ?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <input type="submit" value="اعمال تغییرات" class="submit sub">
                </form>
                <div class="line"></div>
            </div>
            <div class="left">
                <div id="fileuploader">Upload</div>
            </div>
            <style>
                .left {
                    width: 350px;
                    position: absolute;
                    display: inline-block;
                    height: 260px;
                    left: 10px;
                    top: 10px;
                    padding-top: 20px;
                    overflow: auto;
                }

                #fileuploader, .ajax-upload-dragdrop, .ajax-file-upload-statusbar {
                    width: 300px !important;
                }
            </style>

            <!--
            <?php if (!empty($orders['img'])) { ?>
                <div class="img"><img src="image/order/<?= $orders['id'] ?>/<?= $orders['img'] ?>" width="300"
                                      height="317"></div>
            <?php } ?>
            -->
            <div class="attr1">
                <label for="factor" class="label1">شماره فاکتور : </label>
                <input type="text" class="input1" value="<?= @$orders['factor'] ?>" disabled>
            </div>

            <div class="attr1">
                <label for="start" class="label1">تاریخ سفارش : </label>
                <input type="text" class="input1" name="start" value="<?= @$orders['start_d'] ?>" disabled>
            </div>

            <div class="attr1">
                <label for="factor" class="label1">تاریخ تحویل : </label>
                <input type="text" class="input1" value="<?= @$orders['end_d'] ?>" disabled>
            </div>

            <div>
                <label for="order" class="laborder">متن سفارش : </label>
                <textarea name="order" id="order" cols="100" rows="10" readonly><?= @$order ?></textarea>
            </div>
            <div class="attr">
                <label for="cos" class="label">مشتری : </label>
                <input type="text" class="input" value="<?= @$orders['cos'] ?>" name="special" disabled>
            </div>
            <div class="attr">
                <label for="servic" class="label">خدمات : </label>
                <input type="text" class="input" value="<?= @$servic ?>" name="servic" disabled>
            </div>
            <div class="attr">
                <label for="special" class="label">خدمات ویژه : </label>
                <input type="text" class="input" value="<?= @$special ?>" name="special" disabled>
            </div>

        </div>
    </div>

</div>
<div class="clear"></div>

<script>
    $('#manag').addClass('liActiv');
    $('#manag a').addClass('aActiv');

</script>
<script>
    $(document).ready(function () {
        $("#fileuploader").uploadFile({
            url: "<?= U ?>respect/upload/<?= $orders['id'] ?>",
            fileName: "myfile"
        });
    });
</script>

