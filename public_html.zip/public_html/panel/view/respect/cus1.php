<?php
$result = $data[0];
?>
<?php foreach ($result as $row) { ?>
    <li data-h="<?= $row['id'] ?>" class="li1"><?= $row['company'] ?><span></span></li>
<?php } ?>
<script>
    var li1 = $('.li1');
    li1.click(function () {
        li1.removeClass('lihover');
        li1.find('span').removeClass('chekd');
        $(this).addClass('lihover');
        $(this).find('span').addClass('chekd');
        $('.textss1').text("1 مورد انتخاب شده");
        $('.img1').attr("src", "view/assets/image/angle-arrow-down.png");
        $('.textss1').removeClass('hovers');
        $('.s222').slideUp(100);
        // in cus2
        $('.textss2').text("انتخاب مشتری حقیقی");
        $('.li2').removeClass('lihover');
        $('.li2').find('span').removeClass('chekd');
    })
</script>






