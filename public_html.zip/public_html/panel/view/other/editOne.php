<?php
$orders = $data[0];
$level = $data[1];
$kagaz = $data[3];
$order = $orders['orders'];

$lev = unserialize($orders['level']);
$nameLev = $orders['now'];

$servic = unserialize($orders['servic']);
if (is_array($servic)) {
    $servicValus = array_values($servic);
    $servic = implode(' ،  ', $servicValus);
}

$special = unserialize($orders['special']);
if (is_array($special)) {
    $specialValus = array_values($special);
    $special = implode(' ،  ', $specialValus);
}
$mony = $orders['price_design'];
if (!empty($mony) && is_numeric($mony)) {
    $mony = number_format($mony);
}
@$mony_out = $orders['price_out'];
if (!empty($mony_out) && is_numeric($mony_out)) {
    $mony_out = number_format($mony_out);
}
@$mony_design = $orders['price_design'];
if (!empty($mony_design) && is_numeric($mony_design)) {
    $mony_design = number_format($mony_design);
}
$mony_respect = $orders['mony'];
if (!empty($mony_respect) && is_numeric($mony_respect)) {
    $mony_respect = number_format($mony_respect);
}

$digital = $data[4];

$dis = unserialize($orders['dis']);
$ok = 0;
if (is_array($dis)) {
    foreach ($dis as $key => $row) {
        if ($row[0] == 'چاپ دیجیتال') {
            $description = $row[4];
            $monyy = $row[3];
            if (!empty($monyy) && is_numeric($monyy)) {
                $monyy = number_format($monyy);
                $ok = 1;
            }
        }
    }
}
?>
<div class="option">
    <style>

        .payvast {
            background: #fff7f7;
            padding: 20px 20px;
            color: red;
        }

        .option {
            width: 100%;
            min-width: 1300px !important;
            margin: 10px auto;
        }

        .option * {
            text-align: right;
            direction: rtl;
        }

        .mainOption {
            width: 80%;
            min-width: 1000px;
            float: left;
            margin-left: 10px;
            margin-top: 10px;
        }

    </style>
    <style>
        .page {
            padding: 20px 10px;
            position: relative;
        }

        #order {
            width: 694px;
            margin: 10px auto;
            min-width: 400px;
            height: 86px;
            font-size: 13px;
            font-family: mapnoS;
            border: 1px solid #c0e6e3;
            box-sizing: border-box;
            padding: 8px 10px;
            border-radius: 4px;
            resize: none;
        }

        .laborder {
            display: block;
            margin-bottom: 5px;
        }

        .attr {
            width: 300px;
            height: 60px;
            margin-top: 24px;
            display: inline-block;
            margin-left: 25px;
        }

        .label {
            display: block;
            margin-right: 5px;
        }

        .input {
            display: block;
            margin-top: 15px;
            width: 300px;
            height: 35px;
            box-sizing: border-box;
            border: 1px solid #c0e6e3;
            border-radius: 5px;
            padding: 4px 10px;
        }

        .attr1 {
            width: 220px;
            height: 60px;
            margin-top: 24px;
            display: inline-block;
            position: relative;
            margin-left: 13px;
        }

        .label1 {
            margin-left: 10px;
            position: absolute;
            right: 0;
            top: 8px;
        }

        .input1 {
            width: 132px;
            height: 35px;
            box-sizing: border-box;
            border: 1px solid #c0e6e3;
            border-radius: 5px;
            padding: 4px 10px;
            position: absolute;
            left: 0;
            top: -4px;
            text-align: center;
            direction: ltr;
        }

        input, select {
            background: white;
        }

        .file {
            position: absolute;
            width: 74px;
            left: 8px;
            top: 3px;
        }

        .line {
            width: 689px;
            border-bottom: 1px dashed #19b5fe;
            position: absolute;
            bottom: 0;
        }

        .line2 {
            width: 689px;
            border-bottom: 1px dashed #19b5fe;
            bottom: 0;
        }

        .in {
            width: 760px;
            position: relative;
            height: 180px;
        }

        .sub {
            border: 1px solid #1d3b3e;
            position: absolute;
            bottom: 125px;
            left: 366px;
            padding-top: 0 !important;
        }

        .img {
            position: absolute;
            left: 30px;
            top: 37px;
            z-index: 33;
            border: 1px solid #8198af;
            border-radius: 4px;
            overflow: hidden;
            height: 317px;
            width: 300px;
        }

        .img img {
            width: 100%;
            height: 100%;
            position: absolute;
            top: 0;
            left: 0;
        }

        .img:hover {
            left: 150px;
            transform: scale(1.8);
            box-shadow: 0 0 10px 1px #1e4561;
            z-index: 99;
            transition: 0.8s;
        }

        .men {
            display: inline-block;
            margin-right: 27px;
            margin-top: 2px;
        }

        .men a {
            color: #f4f8ff !important;
        }

        .men a:hover {
            color: #28e1ff !important;
        }

        .span {
            position: relative;
            width: 44px;
            display: inline-block;
        }

        .span img {
            position: absolute;
            top: -12px;
            right: 10px;
        }

        .don {
            width: 200px;
            margin: 25px 0 10px 10px;
        }

        .don2 {
            width: 200px;
            margin: 25px 0 10px 10px;
        }

        #dis,#dis9 {
            width: 737px;
            height: 88px;
            border: 1px solid #EEE;
            resize: none;
            border-radius: 4px;
            padding: 10px 20px;
            box-sizing: border-box;
            font-size: 13px;
            font-family: mapno;
        }

        .lab {
            font-family: mapno;
            margin: 13px 2px 8px 0;
        }

        .subDis {
            padding-top: 0 !important;
            position: absolute;
            bottom: 30px;
            right: 637px;
        }

        .line2 {
            width: 689px;
            border-bottom: 1px dashed #19b5fe;
            position: absolute;
            bottom: 95px;
        }

        .baner {
            display: inline-block;
            width: 108px;
            text-align: center;
            border: 1px solid #c0e6e3;
            border-radius: 3px;
            height: 30px;
            box-sizing: border-box;
            margin: 20px 0 0px 6px;
        }

        .subBaner {
            padding-bottom: 10px;
            position: absolute;
            bottom: 23px;
            left: 26px;
        }

        .item {
            font-size: 14px;
            font-family: mapno;
            display: inline-block;
            width: 370px;
            text-align: center;
            background: #00adfe;
            height: 100%;
            box-sizing: border-box;
            padding-top: 9px;
            color: white;
            border-left: 1px solid #fff;
            cursor: pointer;
            position: relative;
        }

        .active {
            background: blue;
        }

        .do {
            display: none;
        }

        .activeSpan{
            width: 0;
            height: 0;
            border-style: solid;
            border-width: 13px 20px 0 20px;
            border-color: #00f transparent transparent;
            position: absolute;
            bottom: -13px;
            right: 50%;
            margin-right: -20px;
        }
    </style>
    <?php require('optionList.php'); ?>
    <div class="mainOption">
        <div class="hed">مدیریت سفارشات
            <div class="men">
                <a href="other/manag">سفارشات</a>
                <span class="span"><img src="view/assets/image/double-arrow.png" width="20" height="20"></span>
                <a>سفارش <?= @$orders['cos'] ?></a>
            </div>
        </div>

        <?php if (!empty($orders['payvast'])) { ?>
            <div class="payvast">
                <?= $orders['payvast'] ?>
            </div>
        <?php } ?>

        <div class="page">
            <div class="in">
                <form action="other/setChange/<?= $orders['id'] ?>" method="post" enctype="multipart/form-data">
                    <div class="attr1">
                        <label for="factor" class="label1">مرحله ی بعد : </label>
                        <select name="next" id="next" name="next" class="input1" required>
                            <option value=""></option>
                            <?php foreach ($level as $row) { ?>
                                <?php if ($row['name'] != 'چاپ دیجیتال') { ?>
                                    <option value="<?= $row['name'] ?>" <?php if (isset($nameLev) && $nameLev == $row['name']) {
                                        echo "selected";
                                    } ?>><?= $row['name'] ?></option>
                                <?php }
                            } ?>
                        </select>
                    </div>
                    <div class="line2"></div>
                    <div></div>
                    <?php if (!empty($orders['img'])) { ?>
                        <a class="submit don" href="image/order/<?= @$orders['id'] ?>/<?= @$orders['img'] ?>"
                           rel="nofollow"
                           download target="_blank">دانلود پیوست پذریش</a>
                    <?php } ?>
                    <?php if (!empty($orders['file_design'])) { ?>
                        <a class="submit don2" href="image/order/<?= @$orders['id'] ?>/<?= @$orders['file_design'] ?>"
                           rel="nofollow"
                           download target="_blank">دانلود پیوست طراحی</a>
                    <?php } ?>
                    <?php if ($ok == 1) { ?>
                        <input type="submit" value="اعمال تغییرات" class="submit sub">
                    <?php } ?>
                </form>
                <div class="line"></div>
            </div>

            <div class="in" style="height: 570px !important;">

                <div style="height: 35px;position: relative">
                    <ul style="height: 100%">
                        <li data-id="1" class="item active">
                            دیجیتال
                        <span class="activeSpan"></span>
                        </li>
                        <li data-id="2" class="item">ریسو
                        <span></span>
                        </li>
                    </ul>
                </div>

                <form class="yek" method="post" action="other/des/<?= $orders['id'] ?>">
                    <div class="attr1" style="width: 280px !important;">
                        <label for="" class="label1">تعرفه : </label>
                        <select name="paper" id="kagaz" class="input1" style="width: 240px" required>
                            <option value=""></option>
                            <?php foreach ($digital as $row) { ?>
                                <option value="<?= $row['price'] . " , " . $row['name'] . " , " . $row['paper'] ?>"><?= $row['name'] ?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="attr1" style="width: 180px !important;">
                        <label for="" class="label1">تعداد : </label>
                        <input type="text" name="tedad" class="input1 tedad" value="" required>
                    </div>
                    <div></div>
                    <div class="attr1" style="width: 235px !important;">
                        <label for="" class="label1">صحافی چسب گرم : </label>
                        <input type="text" name="" class="input1 tag tag1" value=0 required>
                    </div>
                    <div class="attr1" style="width: 235px !important;">
                        <label for="" class="label1">صحافی جلد سخت : </label>
                        <input type="text" name="" class="input1 tag tag2" value=0 required>
                    </div>
                    <div class="attr1" style="width: 235px !important;">
                        <label for="" class="label1">سرچسب : </label>
                        <input type="text" name="" class="input1 tag tag3" value=0 required>
                    </div>
                    <div class="attr1" style="width: 235px !important;">
                        <label for="" class="label1">پر فراژ : </label>
                        <input type="text" name="" class="input1 tag tag4" value=0 required>
                    </div>
                    <div class="attr1" style="width: 235px !important;">
                        <label for="" class="label1">شماره زنی : </label>
                        <input type="text" name="" class="input1 tag tag5" value=0 required>
                    </div>
                    <div class="attr1" style="width: 235px !important;">
                        <label for="" class="label1">خط تا : </label>
                        <input type="text" name="" class="input1 tag tag6" value=0 required>
                    </div>
                    <div class="attr1" style="width: 235px !important;">
                        <label for="" class="label1">روکش سلفونی : </label>
                        <input type="text" name="" class="input1 tag tag7" value=0 required>
                    </div>
                    <div class="attr1" style="width: 235px !important;">
                        <label for="" class="label1">برش : </label>
                        <input type="text" name="" class="input1 tag tag8" value=0 required>
                    </div>
                    <div class="attr1" style="width: 235px !important;">
                        <label for="" class="label1">صحافی سیمی : </label>
                        <input type="text" name="" class="input1 tag tag9" value=0 required>
                    </div>
                    <input type="hidden" name="text" class="text2">
                    <div class="lab">توضیحات :</div>
                    <textarea name="des" id="dis" cols="30" rows="10"><?= @$description ?></textarea>
                    <div class="attr1">
                        <label for="mony" class="label1">مجموع هزینه ها :</label>
                        <input type="text" name="mony" class="input1 mony" placeholder="به ریال بنویسید"
                               value="<?= @$monyy ?>" required>
                        <?php if ($ok == 0) { ?>
                            <input type="submit" class="submit subDis" value="اعمال تغییرات">
                        <?php } ?>
                    </div>
                </form>

                <form class="do" method="post" action="other/des2/<?= $orders['id'] ?>">
                    <div class="attr1" style="width: 280px !important;">
                        <label for="" class="label1">نوع کاغذ : </label>
                        <select name="paper" id="kagaz9" class="input1" style="width: 200px" required>
                            <option value=""></option>
                            <option value="تحریر 80 گرم">تحریر 80 گرم</option>
                            <option value="الوان 70 گرم">الوان 70 گرم</option>
                        </select>
                    </div>
                    <div class="attr1" style="width: 189px !important;">
                        <label for="" class="label1">تعداد : </label>
                        <input type="text" name="tedad" class="input1 tedad9" value="" required>
                    </div>
                    <div class="attr1" style="width: 238px !important;">
                        <label for="" class="label1">قیمت چاپ : </label>
                        <input type="text" name="price1" class="input1 price99" value="" required>
                    </div>
                    <div></div>
                    <div class="attr1" style="width: 235px !important;">
                        <label for="" class="label1">صحافی چسب گرم : </label>
                        <input type="text" name="" class="input1 tag9 tag91" value=0 required>
                    </div>
                    <div class="attr1" style="width: 235px !important;">
                        <label for="" class="label1">صحافی جلد سخت : </label>
                        <input type="text" name="" class="input1 tag9 tag92" value=0 required>
                    </div>
                    <div class="attr1" style="width: 235px !important;">
                        <label for="" class="label1">سرچسب : </label>
                        <input type="text" name="" class="input1 tag9 tag93" value=0 required>
                    </div>
                    <div class="attr1" style="width: 235px !important;">
                        <label for="" class="label1">پر فراژ : </label>
                        <input type="text" name="" class="input1 tag9 tag94" value=0 required>
                    </div>
                    <div class="attr1" style="width: 235px !important;">
                        <label for="" class="label1">شماره زنی : </label>
                        <input type="text" name="" class="input1 tag9 tag95" value=0 required>
                    </div>
                    <div class="attr1" style="width: 235px !important;">
                        <label for="" class="label1">خط تا : </label>
                        <input type="text" name="" class="input1 tag9 tag96" value=0 required>
                    </div>
                    <div class="attr1" style="width: 235px !important;">
                        <label for="" class="label1">روکش سلفونی : </label>
                        <input type="text" name="" class="input1 tag9 tag97" value=0 required>
                    </div>
                    <div class="attr1" style="width: 235px !important;">
                        <label for="" class="label1">برش : </label>
                        <input type="text" name="" class="input1 tag9 tag98" value=0 required>
                    </div>
                    <div class="attr1" style="width: 235px !important;">
                        <label for="" class="label1">صحافی سیمی : </label>
                        <input type="text" name="" class="input1 tag9 tag99" value=0 required>
                    </div>
                    <input type="hidden" name="text" class="text92">
                    <div class="lab">توضیحات :</div>
                    <textarea name="des" id="dis9" cols="30" rows="10"><?= @$description ?></textarea>
                    <div class="attr1">
                        <label for="mony" class="label1">مجموع هزینه ها :</label>
                        <input type="text" name="mony9" class="input1 mony9" placeholder="به ریال بنویسید"
                               value="<?= @$monyy ?>" required>
                        <?php if ($ok == 0) { ?>
                            <input type="submit" class="submit subDis" value="اعمال تغییرات">
                        <?php } ?>
                    </div>
                </form>

                <div class="line"></div>
            </div>
            <script>
                var item = $('.item');
                item.click(function () {
                    item.removeClass('active');
                    item.find('span').removeClass('activeSpan');
                    $(this).addClass('active');
                    $(this).find('span').addClass('activeSpan');
                    var id = $(this).attr('data-id');
                    if (id == 1) {
                        $('.yek').fadeIn(100);
                        $('.do').fadeOut(100);
                    } else {
                        $('.do').fadeIn(100);
                        $('.yek').fadeOut(100);

                    }
                })
            </script>
            <script>
                function cal9() {
                    var option = $("#kagaz9").find('option:selected');
                    var item = option.val();
                    var tedad = $(".tedad9").val();
                    var price = $(".price99").val();
                    var tag1 = $(".tag91").val();
                    var tag2 = $(".tag92").val();
                    var tag3 = $(".tag93").val();
                    var tag4 = $(".tag94").val();
                    var tag5 = $(".tag95").val();
                    var tag6 = $(".tag96").val();
                    var tag7 = $(".tag97").val();
                    var tag8 = $(".tag98").val();
                    var tag9 = $(".tag99").val();
                    var text = 'صحافی چسب گرم :' + tag1 + ' , صحافی جلد سخت : ' + tag2 +
                        ' , سرچسب :' + tag3 + ' , پرفراژ : ' + tag4 + ' , شماره زنی :' + tag5
                        + ' , خط تا : ' + tag6 + ' , روکش سلفون : ' + tag7 + ' , برش :' + tag8 + ' , صحافی سیمی :' + tag9;

                    $(".text92").val(text);
                    var allPrice = parseInt(price, 10) + parseInt(tag1, 10) + parseInt(tag2, 10) + parseInt(tag3, 10) +
                        parseInt(tag4, 10) + parseInt(tag5, 10) + parseInt(tag6, 10) + parseInt(tag7, 10) + parseInt(tag8, 10) + parseInt(tag9, 10);
                    if (price.length > 0 && tedad.length > 0) {
                        $('.mony9').val(allPrice);
                    }
                }

                $('.price99').keyup(function () {
                    cal9()
                });

                $('.tag9').change(function () {
                    cal9();
                });
            </script>

            <script>
                function cal() {
                    var option = $("#kagaz").find('option:selected');
                    var item = option.val();
                    var array = item.split(",");
                    var price = array[0];
                    var tedad = $(".tedad").val();
                    var tag1 = $(".tag1").val();
                    var tag2 = $(".tag2").val();
                    var tag3 = $(".tag3").val();
                    var tag4 = $(".tag4").val();
                    var tag5 = $(".tag5").val();
                    var tag6 = $(".tag6").val();
                    var tag7 = $(".tag7").val();
                    var tag8 = $(".tag8").val();
                    var tag9 = $(".tag9").val();
                    var text = 'صحافی چسب گرم :' + tag1 + ' , صحافی جلد سخت : ' + tag2 +
                        ' , سرچسب :' + tag3 + ' , پرفراژ : ' + tag4 + ' , شماره زنی :' + tag5
                        + ' , خط تا : ' + tag6 + ' , روکش سلفون : ' + tag7 + ' , برش :' + tag8 + ' , صحافی سیمی :' + tag9;

                    $(".text2").val(text);
                    var allTag = parseInt(tag1, 10) + parseInt(tag2, 10) + parseInt(tag3, 10) +
                        parseInt(tag4, 10) + parseInt(tag5, 10) + parseInt(tag6, 10) + parseInt(tag7, 10) + parseInt(tag8, 10) + parseInt(tag9, 10);
                    if (price.length > 0 && tedad.length > 0) {
                        var gole = parseInt((price * tedad) + allTag, 10);
                        $('.mony').val(gole);
                    }
                }

                $('.tedad').keyup(function () {
                    cal()
                });
                $('#kagaz').change(function () {
                    cal();
                });
                $('.tag').change(function () {
                    cal();
                });
            </script>
            <div class="line2"></div>
            <!--
            <?php if (!empty($orders['img'])) { ?>
                <div class="img"><img src="image/order/<?= $orders['id'] ?>/<?= $orders['img'] ?>" width="300"
                                      height="317"></div>
            <?php } ?>
            -->
            <div class="attr1">
                <label for="factor" class="label1">شماره فاکتور : </label>
                <input type="text" class="input1" value="<?= @$orders['factor'] ?>" disabled>
            </div>

            <div class="attr1">
                <label for="start" class="label1">تاریخ سفارش : </label>
                <input type="text" class="input1" name="start" value="<?= @$orders['start_d'] ?>" disabled>
            </div>

            <div class="attr1">
                <label for="factor" class="label1">تاریخ تحویل : </label>
                <input type="text" class="input1" value="<?= @$orders['end_d'] ?>" disabled>
            </div>

            <div>
                <style>

                    .table {
                        width: 100%;
                        position: relative;
                        min-width: 700px;
                        background-color: #f7feff;
                        border: 1px solid #3da6ff;
                        box-sizing: border-box;
                        margin: 20px auto -2px auto;
                    }

                    .table tr:first-child td {
                        background-color: #53a3c6;
                        padding: 13px 8px;
                        text-align: center;
                        font-size: 12px;
                        min-width: 80px;
                        display: table-cell;
                        color: white;
                        font-family: mapno !important;
                    }

                    .table tr:nth-child(even) {
                        background-color: white;
                    }

                    .table tr td {
                        padding: 13px 8px;
                        text-align: center;
                        font-size: 12px;
                        min-width: 52px;
                        color: #030375;
                        line-height: 18px;
                        font-family: mapnoS;

                    }

                    .one {
                        padding: 15px 10px;
                        color: #00007f;
                        font-family: mapnoS;
                    }

                    .price {
                        display: inline-block;
                        width: 260px;
                        background: #f6fcff;
                        padding: 15px 10px;
                        border: 1px solid #3da6ff;
                        text-align: left;
                        margin-bottom: 23px;
                        border-top: none;
                        z-index: 999;
                    }

                    .show {
                        display: inline-block;
                        color: white;
                        position: absolute;
                        left: 40px;
                        margin-top: 1px;
                    }

                    .show2 {
                        display: inline-block;
                        color: white;
                        position: absolute;
                        left: 110px;
                        margin-top: 1px;
                    }

                    .show:hover, .show2:hover {
                        color: #25f5ff;
                        transition: 0.4s;
                    }
                </style>
                <table class="table">
                    <tr>
                        <td>ردیف</td>
                        <td>مرحله</td>
                        <td>جزئیات</td>
                        <td>تاریخ دریافت</td>
                        <td>تاریخ ارسال</td>
                        <td>کاربر</td>
                        <td>هزینه</td>
                    </tr>
                    <tr>
                        <td>1</td>
                        <td>پذیرش</td>
                        <td><?= $order ?></td>
                        <td> <?= $orders['start_d'] ?> </td>
                        <td><?= $orders['respect_out'] ?></td>
                        <td> واحد پذیرش</td>
                        <td>0</td>
                    </tr>
                    <?php
                    $allMony = 0;
                    if (is_array($dis)) {
                        foreach ($dis as $key => $row) {
                            $i = $key + 2;
                            $mony = $row[3];
                            $allMony += $mony;
                            if (!empty($mony) && is_numeric($mony)) {
                                $mony = number_format($mony);
                            }
                            //$arr = [$nowtime, $id, $next];
                            $start = $lev[$key][0];
                            $send = @$lev[$key + 1][0];
                            ?>
                            <tr>
                                <td><?= $i ?></td>
                                <td><?= $row[0] ?></td>
                                <td><?= $row[4] ?></td>
                                <td> <?= $start ?> </td>
                                <td><?= $send ?></td>
                                <td><?= $row[2] ?></td>
                                <td><?= $mony ?></td>
                            </tr>
                        <?php }
                    }
                    ?>
                </table>
            </div>
            <div class="attr">
                <label for="cos" class="label">مشتری : </label>
                <input type="text" class="input" value="<?= @$orders['cos'] ?>" name="special" disabled>
            </div>
            <div class="attr">
                <label for="servic" class="label">خدمات : </label>
                <input type="text" class="input" value="<?= @$servic ?>" name="servic" disabled>
            </div>
            <div class="attr">
                <label for="special" class="label">خدمات ویژه : </label>
                <input type="text" class="input" value="<?= @$special ?>" name="special" disabled>
            </div>

        </div>
    </div>

</div>
<div class="clear"></div>

<script>
    $('#manag').addClass('liActiv');
    $('#manag a').addClass('aActiv');

</script>

