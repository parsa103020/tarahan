<?php
$user = $data[0];
$tahrir = $data[1];
$glase = $data[2];
$koted = $data[3];
$katan = $data[4];
$graf = $data[5];
$foc = $data[6];
$err = ' ';
if (isset($_SESSION['anbar'])) {
    $err = $_SESSION['anbar'];
    unset($_SESSION['anbar']);
}

?>
<div class="option">
    <style>

                     .table {
                         width: 100%;
                         position: relative;
                         min-width: 700px;
                         background-color: #f7feff;
                         border: 1px solid #3da6ff;
                         box-sizing: border-box;
                         margin: 20px auto -2px auto;
                     }

                     .table tr:first-child td {
                         background-color: #53a3c6;
                         padding: 13px 8px;
                         text-align: center;
                         font-size: 12px;
                         min-width: 80px;
                         display: table-cell;
                         color: white;
                         font-family: mapno !important;
                     }

                     .table tr:nth-child(even) {
                         background-color: white;
                     }

                     .table tr td {
                         padding: 13px 8px;
                         text-align: center;
                         font-size: 12px;
                         min-width: 52px;
                         color: #030375;
                         line-height: 18px;
                         font-family: mapnoS;

                     }

                     .one {
                         padding: 15px 10px;
                         color: #00007f;
                         font-family: mapnoS;
                     }

                     .price {
                         display: inline-block;
                         width: 260px;
                         background: #f6fcff;
                         padding: 15px 10px;
                         border: 1px solid #3da6ff;
                         text-align: left;
                         margin-bottom: 23px;
                         border-top: none;
                         z-index: 999;
                     }

                     .show {
                         display: inline-block;
                         color: white;
                         position: absolute;
                         left: 40px;
                         margin-top: 1px;
                     }

                     .show2 {
                         display: inline-block;
                         color: white;
                         position: absolute;
                         left: 110px;
                         margin-top: 1px;
                     }

                     .show:hover, .show2:hover {
                         color: #25f5ff;
                         transition: 0.4s;
                     }
                 </style>
    <style>
        .option {
            width: 100%;
            min-width: 1300px !important;
            margin: 10px auto;
        }

        .option * {
            text-align: right;
            direction: rtl;
        }

        .mainOption {
            width: 80%;
            min-width: 1000px;
            float: left;
            margin-left: 10px;
            margin-top: 10px;
        }

        .tim {
            position: absolute;
            left: 40px;
            bottom: 0;
            font-size: 12px;
            color: #494972;
        }
    </style>
    <style>
        .in {
            width: 97%;
            height: 100px;
            box-sizing: border-box;
            padding: 10px 0;
            position: relative;
            margin: auto;
        }

        .in2 {
            margin-top: 10px;
            border-top: 1px dashed #00ebeb;
            padding-top: 20px !important;
        }

        .heder {
            font-family: mapno;
        }

        .attr {
            width: 215px;
            position: relative;
            margin: 20px 0 0 30px;
            display: inline-block;
        }

        .input {
            width: 170px;
            position: absolute;
            left: 0;
            top: 0;
            height: 30px;
            box-sizing: border-box;
            border: 1px solid #b7d6ea;
            border-radius: 4px;
            text-align: center;
        }

        .label {
            position: absolute;
            top: 9px;
            right: 0;
            font-family: mapnoS;
        }

        .sub1 {
            display: inline-block;
            padding-top: 0;
            position: absolute;
            margin-top: 19px;
            height: 32px;
            margin-right: 31px;
            font-family: mapno;
        }

        .err {
            display: block;
            position: relative;
            margin: 25px auto;
            color: #346fa2;
            font-family: mapno;
            text-align: center;
            border-bottom: 1px dashed #11c5cf;
            padding-bottom: 24px;
        }

        .line {
            width: 95%;
            display: block;
            margin: 20px auto;
            border: 1px dashed #11c5cf;
        }

    </style>
    <?php require('optionList.php'); ?>
    <div class="mainOption">
        <div class="hed">انبار
        </div>
        <div class="cont">
            <?php if (isset($err) && !empty($err) && $err != " ") { ?>
                <span class="err"><?= @$err ?></span>
            <?php } ?>
            <form action="other/adAnbar/1" method="post">
                <div class="in">
                    <div class="heder">وارد کردن گلاسه :</div>
                    <div class="attr">
                        <label for="height" class="label">نوع : </label>
                        <select name="gm" id="gm" class="input" required>
                            <option value=""> انتاخب کنید </option>
                            <?php foreach ($glase as $item) { ?>
                                <option value="<?= $item['name'] ?>"><?= $item['name'] ?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="attr">
                        <label for="num" class="label">تعداد : </label>
                        <input type="number" name="num" class="input" step="1" required>
                    </div>
                    <input type="submit" value="ثبت اطلاعات" class="submit sub1">
                </div>
            </form>
            <div class="line"></div>
            <form action="other/adAnbar/2" method="post">
                <div class="in">
                    <div class="heder">وارد کردن تحریر :</div>
                    <div class="attr">
                        <label for="height" class="label">نوع : </label>
                        <select name="gm" id="gm" class="input" required>
                            <option value=""> انتاخب کنید </option>
                            <?php foreach ($tahrir as $item) { ?>
                                <option value="<?= $item['name'] ?>"><?= $item['name'] ?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="attr">
                        <label for="num" class="label">تعداد : </label>
                        <input type="number" name="num" class="input" step="1" required>
                    </div>
                    <input type="submit" value="ثبت اطلاعات" class="submit sub1">
                </div>
            </form>
            <div class="line"></div>
            <form action="other/adAnbar/3" method="post">
                <div class="in">
                    <div class="heder">وارد کردن کتد :</div>
                    <div class="attr">
                        <label for="height" class="label">نوع : </label>
                        <select name="gm" id="gm" class="input" required>
                            <option value=""> انتاخب کنید </option>
                            <?php foreach ($koted as $item) { ?>
                                <option value="<?= $item['name'] ?>"><?= $item['name'] ?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="attr">
                        <label for="num" class="label">تعداد : </label>
                        <input type="number" name="num" class="input" step="1" required>
                    </div>
                    <input type="submit" value="ثبت اطلاعات" class="submit sub1">
                </div>
            </form>
            <div class="line"></div>
            <form action="other/adAnbar/4" method="post">
                <div class="in">
                    <div class="heder">وارد کردن کتان :</div>
                    <div class="attr">
                        <label for="height" class="label">نوع : </label>
                        <select name="gm" id="gm" class="input" required>
                            <option value=""> انتاخب کنید </option>
                            <?php foreach ($katan as $item) { ?>
                                <option value="<?= $item['name'] ?>"><?= $item['name'] ?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="attr">
                        <label for="num" class="label">تعداد : </label>
                        <input type="number" name="num" class="input" step="1" required>
                    </div>
                    <input type="submit" value="ثبت اطلاعات" class="submit sub1">
                </div>
            </form>
            <div class="line"></div>
            <form action="other/adAnbar/5" method="post">
                <div class="in">
                    <div class="heder">وارد کردن گراف :</div>
                    <div class="attr">
                        <label for="height" class="label">نوع : </label>
                        <select name="gm" id="gm" class="input" required>
                            <option value=""> انتاخب کنید </option>
                            <?php foreach ($graf as $item) { ?>
                                <option value="<?= $item['name'] ?>"><?= $item['name'] ?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="attr">
                        <label for="num" class="label">تعداد : </label>
                        <input type="number" name="num" class="input" step="1" required>
                    </div>
                    <input type="submit" value="ثبت اطلاعات" class="submit sub1">
                </div>
            </form>
            <?php if(is_array($foc) && count($foc)>0){ ?>
            <div class="line"></div>
            <div class="in">
                <table class="table">
                    <tr>
                        <td>کد فاکتور</td>
                        <td>نوع</td>
                        <td>تعداد</td>
                        <td>تاریخ</td>
                        <td>ثبت کننده</td>
                    </tr>
                    <?php foreach ($foc as $item) {?>
                    <tr>
                        <td><?= $item['id'] ?></td>
                        <td><?= $item['noe'] ?></td>
                        <td><?= $item['tedad'] ?></td>
                        <td><?= $item['tim_d'] ?></td>
                        <td><?= $item['user'] ?></td>
                    </tr>
                    <?php } ?>
                </table>
            </div>
            <?php  } ?>
        </div>
    </div>
    <div class="clear"></div>
    <script>
        $('#anbar').addClass('liActiv');
        $('#anbar a').addClass('aActiv');
    </script>