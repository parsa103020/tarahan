<?php
$user = $data[0];
$msg = $data[1];
?>
<div class="option">
    <style>
        .image {
            position: absolute;
            display: inline-block;
            top: 26px;
            left: 46px;
            border-radius: 100%;
            overflow: hidden;
        }

        .end {
            display: inline-block;
            position: absolute;
            top: 147px;
            left: 35px;
            font-size: 14px;
        }

        .start {
            display: inline-block;
            position: absolute;
            top: 117px;
            left: 35px;
            font-size: 14px;
        }

        .sheme {
            display: inline-block;
            position: absolute;
            top: 87px;
            left: 35px;
            font-size: 14px;
        }

        .country {
            display: inline-block;
            position: absolute;
            top: 57px;
            right: 27px;
            font-size: 13px;
            font-family: Byekan;
        }

        .charj {
            display: inline-block;
            position: absolute;
            top: 88px;
            right: 27px;
            font-size: 13px;
            font-family: Byekan;
        }

        .name {
            display: inline-block;
            position: absolute;
            font-size: 13px;
            color: #213148;
            top: 40px;
            right: 33px;
            font-family: mapno;
            font-weight: 500;
        }

        .last {
            display: inline-block;
            position: absolute;
            font-size: 13px;
            color: #213148;
            top: 68px;
            right: 33px;
            font-family: mapno;
        }

        .personel {
            display: inline-block;
            position: absolute;
            font-size: 13px;
            color: #213148;
            top: 97px;
            right: 33px;
            font-family: mapno;
        }

        .msg {
            display: block;
            position: absolute;
            top: 181px;
            width: 334px;
            right: 33px;
            background: rgba(234, 242, 255, 0.8);
            height: 218px;
            box-sizing: border-box;
            padding: 16px 10px;
            border-radius: 14px;
            line-height: 20px;
            overflow: auto;
        }

        .headmsg {
            text-align: center !important;
            display: block;
            padding-bottom: 6px;
            color: #063958;
        }

        .textmsg {
            overflow: auto;
            max-height: 125px;
            padding: 13px 13px 22px 13px;
            color: #063958;
            position: relative;

        }

        .textno {
            max-height: 125px;
            padding: 13px 13px 22px 13px;
            color: #063958;
            position: relative;
            text-align: center !important;
        }

        .daletmsg {
            position: absolute;
            top: 21px;
            right: 17px;
            font-family: Tahoma;
            color: white;
            cursor: pointer;
            font-weight: bold;
            font-size: 14px;
        }

        .daletmsg:hover {
            color: #3385a4;
        }

    </style>
    <style>
        .option {
            width: 100%;
            min-width: 1300px !important;
            margin: 10px auto;
        }

        .option * {
            text-align: right;
            direction: rtl;
        }

        .mainOption {
            width: 80%;
            min-width: 1000px;
            float: left;
            margin-left: 10px;
            margin-top: 10px;
        }

        .tim {
            position: absolute;
            left: 40px;
            bottom: 0;
            font-size: 12px;
            color: #494972;
        }
    </style>

    <?php require('optionList.php'); ?>
    <div class="mainOption">
        <div class="hed">داشبورد
        </div>
        <div class="user"
             style="display: inline-block;width: 422px;height: 400px;position: relative;direction: rtl;text-align: right;">
            <span class="name wow bounceIn" data-wow-offset="100"
                  data-wow-delay="500ms">  حساب کاربری واحد چاپ دیجیتال </span>
            <span class="last wow bounceIn" data-wow-offset="100"
                  data-wow-delay="500ms"> <?= ' ' . $user['name'] . ' ' . $user['last'] ?></span>
            <span class="personel wow bounceIn" data-wow-offset="100"
                  data-wow-delay="500ms">کد پرسنلی : <?= $user['id'] ?></span>
            <span class="personel wow bounceIn" style="top: 126px !important;" data-wow-offset="100"
                  data-wow-delay="500ms">سفارش جدید : <?= $data[3] ?></span>
            <span class="personel wow bounceIn" style="top: 155px !important;" data-wow-offset="100"
                  data-wow-delay="500ms">در دست چاپ : <?= $data[4] ?></span>
            <span class="image wow bounceIn" data-wow-offset="100" data-wow-delay="500ms">
                  <img class="image1"
                      <?php if (!empty($user['image'])) { ?>
                          src="image/user/<?= $user['id'] ?>/100_<?= $user['image'] ?>" width="120" height="120"
                      <?php } else { ?>
                          src="<?= U ?>view/assets/image/profile.png" width="120" height="120"
                      <?php } ?>
                  >
              </span>

            <div class="msg wow bounceIn" data-wow-offset="100"
                 data-wow-delay="500ms">
                <span class="headmsg"> پیام مدیر </span>
                <div class="contmsg">
                    <span class="daletmsg" onclick="seen()">X</span>
                    <div class="textno no" style="display: none">شما هیچ پیام جدیدی ندارید :)</div>
                    <input type="hidden" value="<?= count($msg) ?>" class="count">
                    <?php
                    if (count($msg)>0) {
                        foreach ($msg as $row) { ?>
                            <div class="textmsg"><?= $row['msg'] ?><span class="tim"><?= $row['date'] ?></span></div>
                        <?php }
                    } else { ?>
                        <div class="textno errNo">شما هیچ پیام جدیدی ندارید :)</div>
                    <?php } ?>
                </div>
            </div>

        </div>
        <div class="nemodar" style="display: inline-block;width: 600px">
            <?php
            require 'nemodar.php';
            ?>
        </div>
    </div>

</div>
<div class="clear"></div>


<script>
    function seen() {
        var count = $('.count').val();
        var data = {seen:1};
        var url = "<?= U ?>other/seen";
        $.post(url, data, function () {
            $('.textmsg').text("");
            if(count > 0){
                $('.no').fadeIn(100);
            }
        })
    }

    $('#dashbord').addClass('liActiv');
    $('#dashbord a').addClass('aActiv');
</script>