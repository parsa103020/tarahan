<script src="<?= U ?>view/assets/highcharts/highcharts.js"></script>
<script src="<?= U ?>view/assets/highcharts/variable-pie.js"></script>


<?php
$data= $data[2];
$moon = $data[0];
$tedad =$data[1];
$values_moon = array_values($moon);
$values_moon = implode(',', $values_moon);
$values_tedad = array_values($tedad);
$values_tedad = implode(',', $values_tedad);
?>

<script type="text/javascript">
    $(function () {
        $('#container').highcharts({
            title: {
                text: 'نمودار نمایش تعداد سفارشات انجام شده توسط شما در شش ماه اخیر',
                x: 0 //center
            },
            subtitle: {
                text: 'مپنو',
                x: 0
            },
            xAxis: {
                categories: [<?= $values_moon ?>]
            },
            yAxis: {
                title: {
                    text: 'تعداد سفارش'
                },
                plotLines: [{
                    value: 0,
                    width: 1,
                    color: '#f00'
                }]
            },
            tooltip: {
                valueSuffix: '',
                enabled: true,
                useHTML: true,
                padding : 20
            },

            legend: {
                layout: 'vertical',
                align: 'right',
                verticalAlign: 'middle',
                borderWidth: 0
            },

            series: [{
                name: 'تعداد سفارش',
                data: [<?= $values_tedad ?>]
            }
            ]
        });

    });

</script>
<div id="container" style="min-width: 600px;width: 100%; height: 400px; margin: 0 auto"></div>


<style>
    #container * {
        direction: ltr !important;
        text-align: left !important;
        font-family: mapno;
    }


</style>


