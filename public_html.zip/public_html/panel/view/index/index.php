<style>
    body {
        margin: 0;
        padding: 0;
        background: url('view/assets/image/log4.jpg') fixed;
        background-size: cover;
        background-repeat: no-repeat;
        width: 100%;
        height: 100%;
        position: fixed;
    }

    body * {
        font-family: mapno;

    }

    img {
        position: absolute;
        width: 100px;
        border-radius: 50%;
    }

    .loginbox {
        position: absolute;
        top: 54%;
        left: 50%;
        transform: translate(-50%, -50%);
        width: 350px;
        height: 420px;
        padding: 80px 40px;
        box-sizing: border-box;
        background: rgba(0, 0, 0, 0.55);
    }

    .user {
        height: 100px;
        overflow: hidden;
        position: absolute;
        top: calc(-100px / 2);
        left: calc(50% - 50px);
    }

    .sp {
        margin: 0;
        padding: 0 0 20px;
        color: #00cc00;
        text-shadow: 1px 1px 1px #262626;
        text-align: center;
        letter-spacing: 1px;
        display: block;
    }

    .loginbox label {
        margin: 0;
        padding: 0;
        color: #fff
    }

    .loginbox input {
        width: 100%;
        margin-bottom: 20px;
    }

    .loginbox input[type="text"],
    .loginbox input[type="password"] {
        border: none;
        border-bottom: 1px solid #fff;
        background-color: transparent;
        outline: none;
        height: 40px;
        color: #fff;
        font-size: 16px
    }

    ::placeholder {
        color: rgba(255, 255, 255, .5)
    }

    .sub {
        display: block;
        border: none;
        outline: none;
        height: 40px;
        color: #fff;
        font-size: 16px;
        background: #ff5c33;
        cursor: pointer;
        border-radius: 20px;
        transition: .5s;
        letter-spacing: 1px;
        text-align: center;
        box-sizing: border-box;
        padding-top: 14px;

    }

    .sub:hover {
        background: #00cc00;
        color: #262626
    }

    .loginbox a {
        color: #fff;
        font-size: 14px;
        text-decoration: none;
        opacity: .8
    }
    .err7, .err *, .err{
        color: white;
        text-align: center;
        width: 100%;
        display: block;
        margin-top: 24px;
    }
</style>
<div class="loginbox">
    <img src="view/assets/image/man.jpg"
         class="user">
    <span class="sp">ورود به سامانه</span>
    <form method="post" action="index/login">
        <label for="user">نام کاربری :</label>
        <input type="text" name="user" id="user" placeholder="نام کاربری">
        <label for="pass">رمز ورود :</label>
        <input type="password" name="pass" id="pass" placeholder="*******">
        <a class="sub" onclick="submitReq()" type="submit">ورود</a>
        <div class="err"></div>
    </form>
</div>
<script>
    function submitReq() {
        var err = "";
        var user = $('#user').val();
        var pass = $('#pass').val();
        if (user.length > 2) {
            var data = {
                'user': user,
                'pass': pass
            };
            var url = "index/login";
            console.log(url);
            console.log(data);
            $.post(url, data, function (msq) {
                $('.err').fadeIn(100).html(msq).delay(2000).fadeOut(500);
            })
        } else {
            err = "نام کاربری یا رمز ورود اشتباه است !";
            $('.err').fadeIn(200).text(err).delay(2000).fadeOut(500);
        }

    }

    $('.submitLog').click(function () {
        submitReq();
    });
    $('#user').keypress(function (e) {
            if (e.keyCode == 13 && !e.shiftKey) {
                submitReq();
            }
        }
    );
    $('#pass').keypress(function (e) {
            if (e.keyCode == 13 && !e.shiftKey) {
                submitReq();
            }
        }
    );
</script>







