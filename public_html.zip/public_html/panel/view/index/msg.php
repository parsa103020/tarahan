<?php
$data = $data[0];
$ok = $data[0];
$msg = $data[1];
?>

<?php if ($ok == 0) { ?>
    <span class="err7"><?= $msg ?></span>
<?php } elseif ($ok == 1) { ?>
    <span class="err7">درحال انتقال</span>
    <script>
        window.location = 'respect';
    </script>
<?php } elseif ($ok == 2) { ?>
    <span class="err7">درحال انتقال</span>
    <script>
        window.location = 'manag/index';
    </script>
<?php } elseif ($ok == 3) { ?>
    <span class="err7">درحال انتقال</span>
    <script>
        window.location = 'design/index';
    </script>
<?php } elseif ($ok == 4) { ?>
    <span class="err7">درحال انتقال</span>
    <script>
        window.location = 'other/index';
    </script>
<?php } elseif ($ok == 5) { ?>
    <span class="err7">درحال انتقال</span>
    <script>
        window.location = 'baner/index';
    </script>
<?php } elseif ($ok == 6) { ?>
    <span class="err7">درحال انتقال</span>
    <script>
        window.location = 'laser/index';
    </script>
<?php } elseif ($ok == 7) { ?>
    <span class="err7">درحال انتقال</span>
    <script>
        window.location = 'out/index';
    </script>
<?php } elseif ($ok == 8) { ?>
    <span class="err7">درحال انتقال</span>
    <script>
        window.location = 'hesab/index';
    </script>
<?php } ?>
