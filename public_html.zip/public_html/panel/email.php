<?php
mail("khabarchain@gmail.com","My subject",'Test');
echo "Email Sent";
?>