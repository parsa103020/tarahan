<?php

/**
 * Article Model
 * مدل مقالات وبلاگ
 */
class model_article extends Model
{
    function __construct()
    {
        parent::__construct();
    }

    /**
     * دریافت مقالات منتشر شده
     */
    function getPublishedArticles($limit = 10, $offset = 0)
    {
        $sql = "SELECT id, title, slug, excerpt, featured_image, views, reading_time, published_at
                FROM articles
                WHERE status = 'published'
                ORDER BY published_at DESC
                LIMIT :limit OFFSET :offset";
        return $this->doSelect($sql, [':limit' => (int)$limit, ':offset' => (int)$offset]);
    }

    /**
     * شمارش مقالات منتشر شده
     */
    function countPublishedArticles()
    {
        $sql = "SELECT COUNT(*) as total FROM articles WHERE status = 'published'";
        $result = $this->doSelect($sql);
        return $result[0]['total'] ?? 0;
    }

    /**
     * دریافت مقاله با slug
     */
    function getArticleBySlug($slug)
    {
        $sql = "SELECT * FROM articles WHERE slug = :slug AND status = 'published'";
        $result = $this->doSelect($sql, [':slug' => $slug]);
        return $result[0] ?? null;
    }

    /**
     * دریافت مقاله با ID
     */
    function getArticleById($id)
    {
        $sql = "SELECT * FROM articles WHERE id = :id";
        $result = $this->doSelect($sql, [':id' => (int)$id]);
        return $result[0] ?? null;
    }

    /**
     * دریافت همه مقالات (برای ادمین)
     */
    function getAllArticles()
    {
        $sql = "SELECT id, title, slug, excerpt, featured_image, status, views, reading_time, created_at, published_at
                FROM articles
                ORDER BY created_at DESC";
        return $this->doSelect($sql);
    }

    /**
     * افزایش بازدید
     */
    function incrementViews($id)
    {
        $sql = "UPDATE articles SET views = views + 1 WHERE id = ?";
        return $this->doQuery($sql, [(int)$id]);
    }

    /**
     * مقالات مرتبط
     */
    function getRelatedArticles($excludeId, $limit = 3)
    {
        $sql = "SELECT id, title, slug, excerpt, featured_image, published_at, reading_time
                FROM articles
                WHERE status = 'published' AND id != :id
                ORDER BY published_at DESC
                LIMIT :limit";
        return $this->doSelect($sql, [':id' => (int)$excludeId, ':limit' => (int)$limit]);
    }

    /**
     * ذخیره مقاله
     */
    function saveArticle($data)
    {
        // محاسبه زمان مطالعه
        $readingTime = $this->calculateReadingTime($data['content'] ?? '');

        // تولید slug اگر خالی است
        if (empty($data['slug'])) {
            $data['slug'] = $this->generateUniqueSlug($data['title'], $data['id'] ?? null);
        }

        if (empty($data['id'])) {
            // ایجاد جدید
            $sql = "INSERT INTO articles (title, slug, excerpt, content, featured_image,
                    meta_title, meta_description, meta_keywords, status, reading_time, published_at)
                    VALUES (:title, :slug, :excerpt, :content, :featured_image,
                    :meta_title, :meta_description, :meta_keywords, :status, :reading_time, :published_at)";
        } else {
            // ویرایش
            $sql = "UPDATE articles SET
                    title = :title, slug = :slug, excerpt = :excerpt, content = :content,
                    featured_image = :featured_image, meta_title = :meta_title,
                    meta_description = :meta_description, meta_keywords = :meta_keywords,
                    status = :status, reading_time = :reading_time, published_at = :published_at
                    WHERE id = :id";
        }

        $publishedAt = null;
        if ($data['status'] === 'published') {
            // اگر قبلا منتشر نشده، تاریخ انتشار را تنظیم کن
            if (!empty($data['id'])) {
                $existing = $this->getArticleById($data['id']);
                $publishedAt = $existing['published_at'] ?? date('Y-m-d H:i:s');
            } else {
                $publishedAt = date('Y-m-d H:i:s');
            }
        }

        $params = [
            ':title' => $this->sanitizeInput($data['title']),
            ':slug' => $this->sanitizeSlug($data['slug']),
            ':excerpt' => $this->sanitizeInput($data['excerpt'] ?? ''),
            ':content' => $data['content'], // HTML مجاز
            ':featured_image' => $data['featured_image'] ?? null,
            ':meta_title' => $this->sanitizeInput($data['meta_title'] ?? ''),
            ':meta_description' => $this->sanitizeInput($data['meta_description'] ?? ''),
            ':meta_keywords' => $this->sanitizeInput($data['meta_keywords'] ?? ''),
            ':status' => $data['status'],
            ':reading_time' => $readingTime,
            ':published_at' => $publishedAt
        ];

        if (!empty($data['id'])) {
            $params[':id'] = (int)$data['id'];
        }

        return $this->doQuery($sql, $params);
    }

    /**
     * حذف مقاله
     */
    function deleteArticle($id)
    {
        $sql = "DELETE FROM articles WHERE id = :id";
        return $this->doQuery($sql, [':id' => (int)$id]);
    }

    /**
     * تولید slug یکتا
     */
    function generateUniqueSlug($title, $excludeId = null)
    {
        $slug = $this->slugify($title);

        // اگر slug خالی شد، از timestamp استفاده کن
        if (empty($slug)) {
            $slug = 'article-' . time();
        }

        $originalSlug = $slug;
        $counter = 1;

        while ($this->slugExists($slug, $excludeId)) {
            $slug = $originalSlug . '-' . $counter;
            $counter++;
        }

        return $slug;
    }

    /**
     * بررسی وجود slug
     */
    function slugExists($slug, $excludeId = null)
    {
        $sql = "SELECT id FROM articles WHERE slug = :slug";
        $params = [':slug' => $slug];

        if ($excludeId) {
            $sql .= " AND id != :id";
            $params[':id'] = (int)$excludeId;
        }

        $result = $this->doSelect($sql, $params);
        return !empty($result);
    }

    /**
     * تبدیل عنوان به slug
     */
    private function slugify($text)
    {
        // تبدیل فاصله به خط تیره
        $text = preg_replace('/\s+/', '-', trim($text));
        // فقط حروف انگلیسی، اعداد و خط تیره
        $text = preg_replace('/[^a-zA-Z0-9\-]/', '', $text);
        // حذف خط تیره‌های تکراری
        $text = preg_replace('/-+/', '-', $text);
        // حذف خط تیره از ابتدا و انتها
        $text = trim($text, '-');

        return strtolower($text);
    }

    /**
     * پاکسازی slug
     */
    private function sanitizeSlug($slug)
    {
        $slug = preg_replace('/[^a-z0-9\-]/', '', strtolower($slug));
        $slug = preg_replace('/-+/', '-', $slug);
        return trim($slug, '-');
    }

    /**
     * محاسبه زمان مطالعه
     */
    private function calculateReadingTime($content)
    {
        $text = strip_tags($content);
        // شمارش کلمات فارسی و انگلیسی
        $wordCount = count(preg_split('/\s+/u', $text, -1, PREG_SPLIT_NO_EMPTY));
        // 200 کلمه در دقیقه
        $readingTime = ceil($wordCount / 200);
        return max(1, $readingTime); // حداقل 1 دقیقه
    }

    /**
     * پاکسازی ورودی
     */
    private function sanitizeInput($input)
    {
        if (is_array($input)) {
            return array_map([$this, 'sanitizeInput'], $input);
        }
        return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
    }
}
