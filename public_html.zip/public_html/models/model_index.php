<?php

/**
 * Index Model - Home page data
 */
class model_index extends Model
{
    function __construct()
    {
        parent::__construct();
        Model::sessionInit();
    }

    /**
     * Get hero section content
     * @return array Hero data
     */
    function getHeroContent()
    {
        $sql = "SELECT content_key, content_value FROM page_content WHERE page = 'home' AND section = 'hero'";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $hero = [];
        foreach ($results as $row) {
            $hero[$row['content_key']] = $row['content_value'];
        }

        return $hero;
    }

    /**
     * Get stats for home page
     * @return array Stats data
     */
    function getStats()
    {
        $sql = "SELECT stat_value,
                       stat_suffix as suffix,
                       stat_prefix as prefix,
                       stat_label,
                       stat_icon as icon
                FROM stats WHERE page = 'home' AND is_active = 1 ORDER BY sort_order";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Get services list for home page
     * @return array Services
     */
    function getServices()
    {
        $sql = "SELECT slug, title, short_description, icon FROM services WHERE is_active = 1 ORDER BY sort_order";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Get featured project content
     * @return array Featured project data
     */
    function getFeaturedProject()
    {
        $sql = "SELECT content_key, content_value FROM page_content WHERE page = 'home' AND section = 'featured'";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $featured = [];
        foreach ($results as $row) {
            $featured[$row['content_key']] = $row['content_value'];
        }

        return $featured;
    }

    /**
     * Get Why Us / Benefits section
     * @return array Benefits data
     */
    function getBenefits()
    {
        $sql = "SELECT number, title, description, icon FROM benefits WHERE page = 'home' AND is_active = 1 ORDER BY sort_order";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Get testimonials for home page
     * @return array Testimonials
     */
    function getTestimonials()
    {
        $sql = "SELECT content, author_name, author_position, author_avatar, rating
                FROM testimonials WHERE page = 'home' AND is_active = 1 ORDER BY sort_order";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Get process steps for home page
     * @return array Process steps
     */
    function getProcessSteps()
    {
        $sql = "SELECT step_number, title, description, icon FROM process_steps WHERE page = 'home' AND is_active = 1 ORDER BY sort_order";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Get CTA content
     * @return array CTA data
     */
    function getCTAContent()
    {
        $sql = "SELECT content_key, content_value FROM page_content WHERE page = 'home' AND section = 'cta'";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $cta = [];
        foreach ($results as $row) {
            $cta[$row['content_key']] = $row['content_value'];
        }

        return $cta;
    }

    /**
     * Get all home page data at once
     * @return array All home page data
     */
    function getAllHomeData()
    {
        return [
            'hero' => $this->getHeroContent(),
            'stats' => $this->getStats(),
            'services' => $this->getServices(),
            'featured' => $this->getFeaturedProject(),
            'benefits' => $this->getBenefits(),
            'testimonials' => $this->getTestimonials(),
            'process' => $this->getProcessSteps(),
            'cta' => $this->getCTAContent(),
        ];
    }
}
