<?php

/**
 * Admin Model - مدل پنل مدیریت
 * تمام عملیات دیتابیس برای پنل ادمین
 */
class model_admin extends Model
{
    function __construct()
    {
        parent::__construct();
        Model::sessionInit();
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // احراز هویت
    // ═══════════════════════════════════════════════════════════════════════════

    function checkLogin($username, $password)
    {
        $sql = "SELECT * FROM admins WHERE username = ? AND is_active = 1";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute([$username]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user && password_verify($password, $user['password'])) {
            return $user;
        }
        return false;
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // داشبورد
    // ═══════════════════════════════════════════════════════════════════════════

    function getDashboardStats()
    {
        $stats = [];

        // تعداد پیام‌های جدید
        $sql = "SELECT COUNT(*) as count FROM contact_messages WHERE is_read = 0";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $stats['newMessages'] = $stmt->fetch()['count'];

        // تعداد کل پیام‌ها
        $sql = "SELECT COUNT(*) as count FROM contact_messages";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $stats['totalMessages'] = $stmt->fetch()['count'];

        // تعداد خدمات
        $sql = "SELECT COUNT(*) as count FROM services WHERE is_active = 1";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $stats['services'] = $stmt->fetch()['count'];

        // تعداد نظرات
        $sql = "SELECT COUNT(*) as count FROM testimonials WHERE is_active = 1";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $stats['testimonials'] = $stmt->fetch()['count'];

        return $stats;
    }

    function getRecentMessages($limit = 5)
    {
        $sql = "SELECT * FROM contact_messages ORDER BY created_at DESC LIMIT ?";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute([$limit]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // تنظیمات
    // ═══════════════════════════════════════════════════════════════════════════

    function getAllSettings()
    {
        $sql = "SELECT * FROM settings ORDER BY setting_group, id";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // گروه‌بندی تنظیمات
        $grouped = [];
        foreach ($results as $row) {
            $grouped[$row['setting_group']][$row['setting_key']] = $row;
        }
        return $grouped;
    }

    function saveSettings($data)
    {
        try {
            // Handle settings array format from form
            if (isset($data['settings']) && is_array($data['settings'])) {
                foreach ($data['settings'] as $key => $value) {
                    $sql = "UPDATE settings SET setting_value = ? WHERE setting_key = ?";
                    $stmt = self::$conn->prepare($sql);
                    $stmt->execute([$value, $key]);
                }
            }
            // Handle old format for backward compatibility
            foreach ($data as $key => $value) {
                if (strpos($key, 'setting_') === 0) {
                    $settingKey = substr($key, 8);
                    $sql = "UPDATE settings SET setting_value = ? WHERE setting_key = ?";
                    $stmt = self::$conn->prepare($sql);
                    $stmt->execute([$value, $settingKey]);
                }
            }
            return true;
        } catch (Exception $e) {
            error_log("saveSettings Error: " . $e->getMessage());
            return false;
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // خدمات
    // ═══════════════════════════════════════════════════════════════════════════

    function getAllServices()
    {
        $sql = "SELECT * FROM services ORDER BY sort_order";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    function getServiceById($id)
    {
        $sql = "SELECT * FROM services WHERE id = ?";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    function getServiceFeatures($serviceId)
    {
        $sql = "SELECT * FROM service_features WHERE service_id = ? ORDER BY sort_order";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute([$serviceId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    function getServiceProcess($serviceId)
    {
        $sql = "SELECT * FROM service_process WHERE service_id = ? ORDER BY sort_order";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute([$serviceId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    function getServiceFAQ($serviceId)
    {
        $sql = "SELECT * FROM service_faq WHERE service_id = ? ORDER BY sort_order";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute([$serviceId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    function getServiceStats($serviceId)
    {
        $sql = "SELECT * FROM service_stats WHERE service_id = ? ORDER BY sort_order";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute([$serviceId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    function getServiceItems($serviceId)
    {
        $sql = "SELECT * FROM service_items WHERE service_id = ? ORDER BY sort_order";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute([$serviceId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    function saveService($id, $data)
    {
        try {
            // ذخیره اطلاعات اصلی سرویس
            $sql = "UPDATE services SET
                    title = ?,
                    slug = ?,
                    icon = ?,
                    short_description = ?,
                    hero_badge = ?,
                    hero_badge_icon = ?,
                    hero_title_line1 = ?,
                    hero_title_line2 = ?,
                    hero_subtitle = ?,
                    cta_primary_text = ?,
                    cta_primary_link = ?,
                    cta_secondary_text = ?,
                    cta_secondary_link = ?,
                    featured_project_title = ?,
                    featured_project_image = ?,
                    featured_project_description = ?,
                    cta_final_title = ?,
                    cta_final_subtitle = ?,
                    cta_final_button = ?,
                    meta_title = ?,
                    meta_description = ?,
                    is_active = ?,
                    updated_at = NOW()
                    WHERE id = ?";
            $stmt = self::$conn->prepare($sql);
            $stmt->execute([
                $data['title'] ?? '',
                $data['slug'] ?? '',
                $data['icon'] ?? '',
                $data['short_description'] ?? '',
                $data['hero_badge'] ?? '',
                $data['hero_badge_icon'] ?? '',
                $data['hero_title_line1'] ?? '',
                $data['hero_title_line2'] ?? '',
                $data['hero_subtitle'] ?? '',
                $data['cta_primary_text'] ?? '',
                $data['cta_primary_link'] ?? '',
                $data['cta_secondary_text'] ?? '',
                $data['cta_secondary_link'] ?? '',
                $data['featured_project_title'] ?? '',
                $data['featured_project_image'] ?? '',
                $data['featured_project_description'] ?? '',
                $data['cta_final_title'] ?? '',
                $data['cta_final_subtitle'] ?? '',
                $data['cta_final_button'] ?? '',
                $data['meta_title'] ?? '',
                $data['meta_description'] ?? '',
                isset($data['is_active']) && $data['is_active'] ? 1 : 0,
                $id
            ]);

            // ذخیره ویژگی‌ها
            if (isset($data['features'])) {
                $this->saveServiceFeatures($id, $data['features']);
            }

            // ذخیره فرآیند کار
            if (isset($data['process'])) {
                $this->saveServiceProcess($id, $data['process']);
            }

            // ذخیره سوالات متداول
            if (isset($data['faq'])) {
                $this->saveServiceFAQItems($id, $data['faq']);
            }

            // ذخیره آمار
            if (isset($data['stats'])) {
                $this->saveServiceStatsItems($id, $data['stats']);
            }

            // ذخیره زیرخدمات
            if (isset($data['items'])) {
                $this->saveServiceItemsList($id, $data['items']);
            }

            return true;
        } catch (Exception $e) {
            error_log("saveService Error: " . $e->getMessage());
            return false;
        }
    }

    function saveServiceFeatures($serviceId, $features)
    {
        // حذف موارد قبلی که در لیست جدید نیستند
        $existingIds = [];
        foreach ($features as $feature) {
            if (!empty($feature['id'])) {
                $existingIds[] = $feature['id'];
            }
        }

        if (!empty($existingIds)) {
            $placeholders = implode(',', array_fill(0, count($existingIds), '?'));
            $sql = "DELETE FROM service_features WHERE service_id = ? AND id NOT IN ($placeholders)";
            $stmt = self::$conn->prepare($sql);
            $stmt->execute(array_merge([$serviceId], $existingIds));
        } else {
            $sql = "DELETE FROM service_features WHERE service_id = ?";
            $stmt = self::$conn->prepare($sql);
            $stmt->execute([$serviceId]);
        }

        // بروزرسانی یا درج موارد
        $sortOrder = 0;
        foreach ($features as $feature) {
            if (empty($feature['title'])) continue;
            $sortOrder++;

            if (!empty($feature['id'])) {
                $sql = "UPDATE service_features SET title = ?, description = ?, icon = ?, sort_order = ? WHERE id = ? AND service_id = ?";
                $stmt = self::$conn->prepare($sql);
                $stmt->execute([
                    $feature['title'],
                    $feature['description'] ?? '',
                    $feature['icon'] ?? '',
                    $sortOrder,
                    $feature['id'],
                    $serviceId
                ]);
            } else {
                $sql = "INSERT INTO service_features (service_id, title, description, icon, sort_order) VALUES (?, ?, ?, ?, ?)";
                $stmt = self::$conn->prepare($sql);
                $stmt->execute([
                    $serviceId,
                    $feature['title'],
                    $feature['description'] ?? '',
                    $feature['icon'] ?? '',
                    $sortOrder
                ]);
            }
        }
    }

    function saveServiceProcess($serviceId, $processSteps)
    {
        $existingIds = [];
        foreach ($processSteps as $step) {
            if (!empty($step['id'])) {
                $existingIds[] = $step['id'];
            }
        }

        if (!empty($existingIds)) {
            $placeholders = implode(',', array_fill(0, count($existingIds), '?'));
            $sql = "DELETE FROM service_process WHERE service_id = ? AND id NOT IN ($placeholders)";
            $stmt = self::$conn->prepare($sql);
            $stmt->execute(array_merge([$serviceId], $existingIds));
        } else {
            $sql = "DELETE FROM service_process WHERE service_id = ?";
            $stmt = self::$conn->prepare($sql);
            $stmt->execute([$serviceId]);
        }

        $sortOrder = 0;
        foreach ($processSteps as $step) {
            if (empty($step['title'])) continue;
            $sortOrder++;

            if (!empty($step['id'])) {
                $sql = "UPDATE service_process SET step_number = ?, title = ?, description = ?, icon = ?, sort_order = ? WHERE id = ? AND service_id = ?";
                $stmt = self::$conn->prepare($sql);
                $stmt->execute([
                    $step['step_number'] ?? $sortOrder,
                    $step['title'],
                    $step['description'] ?? '',
                    $step['icon'] ?? '',
                    $sortOrder,
                    $step['id'],
                    $serviceId
                ]);
            } else {
                $sql = "INSERT INTO service_process (service_id, step_number, title, description, icon, sort_order) VALUES (?, ?, ?, ?, ?, ?)";
                $stmt = self::$conn->prepare($sql);
                $stmt->execute([
                    $serviceId,
                    $step['step_number'] ?? $sortOrder,
                    $step['title'],
                    $step['description'] ?? '',
                    $step['icon'] ?? '',
                    $sortOrder
                ]);
            }
        }
    }

    function saveServiceFAQItems($serviceId, $faqItems)
    {
        $existingIds = [];
        foreach ($faqItems as $item) {
            if (!empty($item['id'])) {
                $existingIds[] = $item['id'];
            }
        }

        if (!empty($existingIds)) {
            $placeholders = implode(',', array_fill(0, count($existingIds), '?'));
            $sql = "DELETE FROM service_faq WHERE service_id = ? AND id NOT IN ($placeholders)";
            $stmt = self::$conn->prepare($sql);
            $stmt->execute(array_merge([$serviceId], $existingIds));
        } else {
            $sql = "DELETE FROM service_faq WHERE service_id = ?";
            $stmt = self::$conn->prepare($sql);
            $stmt->execute([$serviceId]);
        }

        $sortOrder = 0;
        foreach ($faqItems as $item) {
            if (empty($item['question'])) continue;
            $sortOrder++;

            if (!empty($item['id'])) {
                $sql = "UPDATE service_faq SET question = ?, answer = ?, sort_order = ? WHERE id = ? AND service_id = ?";
                $stmt = self::$conn->prepare($sql);
                $stmt->execute([
                    $item['question'],
                    $item['answer'] ?? '',
                    $sortOrder,
                    $item['id'],
                    $serviceId
                ]);
            } else {
                $sql = "INSERT INTO service_faq (service_id, question, answer, sort_order) VALUES (?, ?, ?, ?)";
                $stmt = self::$conn->prepare($sql);
                $stmt->execute([
                    $serviceId,
                    $item['question'],
                    $item['answer'] ?? '',
                    $sortOrder
                ]);
            }
        }
    }

    function saveServiceStatsItems($serviceId, $statsItems)
    {
        $existingIds = [];
        foreach ($statsItems as $item) {
            if (!empty($item['id'])) {
                $existingIds[] = $item['id'];
            }
        }

        if (!empty($existingIds)) {
            $placeholders = implode(',', array_fill(0, count($existingIds), '?'));
            $sql = "DELETE FROM service_stats WHERE service_id = ? AND id NOT IN ($placeholders)";
            $stmt = self::$conn->prepare($sql);
            $stmt->execute(array_merge([$serviceId], $existingIds));
        } else {
            $sql = "DELETE FROM service_stats WHERE service_id = ?";
            $stmt = self::$conn->prepare($sql);
            $stmt->execute([$serviceId]);
        }

        $sortOrder = 0;
        foreach ($statsItems as $item) {
            if (empty($item['stat_value']) && empty($item['stat_label'])) continue;
            $sortOrder++;

            if (!empty($item['id'])) {
                $sql = "UPDATE service_stats SET stat_value = ?, stat_label = ?, sort_order = ? WHERE id = ? AND service_id = ?";
                $stmt = self::$conn->prepare($sql);
                $stmt->execute([
                    $item['stat_value'] ?? '',
                    $item['stat_label'] ?? '',
                    $sortOrder,
                    $item['id'],
                    $serviceId
                ]);
            } else {
                $sql = "INSERT INTO service_stats (service_id, stat_value, stat_label, sort_order) VALUES (?, ?, ?, ?)";
                $stmt = self::$conn->prepare($sql);
                $stmt->execute([
                    $serviceId,
                    $item['stat_value'] ?? '',
                    $item['stat_label'] ?? '',
                    $sortOrder
                ]);
            }
        }
    }

    function saveServiceItemsList($serviceId, $items)
    {
        $existingIds = [];
        foreach ($items as $item) {
            if (!empty($item['id'])) {
                $existingIds[] = $item['id'];
            }
        }

        if (!empty($existingIds)) {
            $placeholders = implode(',', array_fill(0, count($existingIds), '?'));
            $sql = "DELETE FROM service_items WHERE service_id = ? AND id NOT IN ($placeholders)";
            $stmt = self::$conn->prepare($sql);
            $stmt->execute(array_merge([$serviceId], $existingIds));
        } else {
            $sql = "DELETE FROM service_items WHERE service_id = ?";
            $stmt = self::$conn->prepare($sql);
            $stmt->execute([$serviceId]);
        }

        $sortOrder = 0;
        foreach ($items as $item) {
            if (empty($item['title'])) continue;
            $sortOrder++;

            if (!empty($item['id'])) {
                $sql = "UPDATE service_items SET title = ?, description = ?, icon = ?, sort_order = ? WHERE id = ? AND service_id = ?";
                $stmt = self::$conn->prepare($sql);
                $stmt->execute([
                    $item['title'],
                    $item['description'] ?? '',
                    $item['icon'] ?? '',
                    $sortOrder,
                    $item['id'],
                    $serviceId
                ]);
            } else {
                $sql = "INSERT INTO service_items (service_id, title, description, icon, sort_order) VALUES (?, ?, ?, ?, ?)";
                $stmt = self::$conn->prepare($sql);
                $stmt->execute([
                    $serviceId,
                    $item['title'],
                    $item['description'] ?? '',
                    $item['icon'] ?? '',
                    $sortOrder
                ]);
            }
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // محتوای صفحات
    // ═══════════════════════════════════════════════════════════════════════════

    function getPageContent($page, $section)
    {
        $sql = "SELECT * FROM page_content WHERE page = ? AND section = ?";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute([$page, $section]);
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $content = [];
        foreach ($results as $row) {
            $content[$row['content_key']] = $row['content_value'];
        }
        return $content;
    }

    function savePageContent($page, $section, $data)
    {
        try {
            foreach ($data as $key => $value) {
                // بررسی وجود رکورد
                $sql = "SELECT id FROM page_content WHERE page = ? AND section = ? AND content_key = ?";
                $stmt = self::$conn->prepare($sql);
                $stmt->execute([$page, $section, $key]);
                $exists = $stmt->fetch();

                if ($exists) {
                    $sql = "UPDATE page_content SET content_value = ? WHERE page = ? AND section = ? AND content_key = ?";
                    $stmt = self::$conn->prepare($sql);
                    $stmt->execute([$value, $page, $section, $key]);
                } else {
                    $sql = "INSERT INTO page_content (page, section, content_key, content_value) VALUES (?, ?, ?, ?)";
                    $stmt = self::$conn->prepare($sql);
                    $stmt->execute([$page, $section, $key, $value]);
                }
            }
            return true;
        } catch (Exception $e) {
            return false;
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // آمار و ارقام
    // ═══════════════════════════════════════════════════════════════════════════

    function getStats($page)
    {
        $sql = "SELECT * FROM stats WHERE page = ? AND is_active = 1 ORDER BY sort_order";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute([$page]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    function saveStat($data)
    {
        try {
            if (!empty($data['id'])) {
                $sql = "UPDATE stats SET stat_value = ?, stat_label = ?, stat_suffix = ?, stat_prefix = ?, icon = ?, sort_order = ? WHERE id = ?";
                $stmt = self::$conn->prepare($sql);
                $stmt->execute([
                    $data['stat_value'],
                    $data['stat_label'],
                    $data['stat_suffix'] ?? '',
                    $data['stat_prefix'] ?? '',
                    $data['icon'] ?? '',
                    $data['sort_order'] ?? 0,
                    $data['id']
                ]);
            } else {
                $sql = "INSERT INTO stats (page, stat_key, stat_value, stat_label, stat_suffix, stat_prefix, icon, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                $stmt = self::$conn->prepare($sql);
                $stmt->execute([
                    $data['page'],
                    $data['stat_key'] ?? uniqid(),
                    $data['stat_value'],
                    $data['stat_label'],
                    $data['stat_suffix'] ?? '',
                    $data['stat_prefix'] ?? '',
                    $data['icon'] ?? '',
                    $data['sort_order'] ?? 0
                ]);
            }
            return ['success' => true];
        } catch (Exception $e) {
            error_log("saveStat Error: " . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    function deleteStat($id)
    {
        try {
            $sql = "DELETE FROM stats WHERE id = ?";
            $stmt = self::$conn->prepare($sql);
            $stmt->execute([$id]);
            return true;
        } catch (Exception $e) {
            return false;
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // نظرات مشتریان
    // ═══════════════════════════════════════════════════════════════════════════

    function getAllTestimonials()
    {
        $sql = "SELECT * FROM testimonials ORDER BY sort_order";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    function getTestimonials($page)
    {
        $sql = "SELECT * FROM testimonials WHERE page = ? AND is_active = 1 ORDER BY sort_order";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute([$page]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    function saveTestimonial($data)
    {
        try {
            if (!empty($data['id'])) {
                $sql = "UPDATE testimonials SET content = ?, author_name = ?, author_position = ?, rating = ?, is_active = ?, sort_order = ? WHERE id = ?";
                $stmt = self::$conn->prepare($sql);
                $stmt->execute([
                    $data['content'],
                    $data['author_name'],
                    $data['author_position'],
                    $data['rating'] ?? 5,
                    isset($data['is_active']) ? 1 : 0,
                    $data['sort_order'] ?? 0,
                    $data['id']
                ]);
            } else {
                $sql = "INSERT INTO testimonials (page, content, author_name, author_position, rating, is_active, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?)";
                $stmt = self::$conn->prepare($sql);
                $stmt->execute([
                    $data['page'] ?? 'home',
                    $data['content'],
                    $data['author_name'],
                    $data['author_position'],
                    $data['rating'] ?? 5,
                    isset($data['is_active']) ? 1 : 0,
                    $data['sort_order'] ?? 0
                ]);
            }
            return true;
        } catch (Exception $e) {
            return false;
        }
    }

    function deleteTestimonial($id)
    {
        try {
            $sql = "DELETE FROM testimonials WHERE id = ?";
            $stmt = self::$conn->prepare($sql);
            $stmt->execute([$id]);
            return true;
        } catch (Exception $e) {
            return false;
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // تاریخچه (Timeline)
    // ═══════════════════════════════════════════════════════════════════════════

    function getTimeline()
    {
        $sql = "SELECT * FROM timeline ORDER BY sort_order";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    function saveTimelineItem($data)
    {
        try {
            if (!empty($data['id'])) {
                $sql = "UPDATE timeline SET year = ?, title = ?, description = ?, sort_order = ? WHERE id = ?";
                $stmt = self::$conn->prepare($sql);
                $stmt->execute([
                    $data['year'],
                    $data['title'],
                    $data['description'],
                    $data['sort_order'] ?? 0,
                    $data['id']
                ]);
            } else {
                $sql = "INSERT INTO timeline (year, title, description, sort_order) VALUES (?, ?, ?, ?)";
                $stmt = self::$conn->prepare($sql);
                $stmt->execute([
                    $data['year'],
                    $data['title'],
                    $data['description'],
                    $data['sort_order'] ?? 0
                ]);
            }
            return true;
        } catch (Exception $e) {
            return false;
        }
    }

    function deleteTimelineItem($id)
    {
        try {
            $sql = "DELETE FROM timeline WHERE id = ?";
            $stmt = self::$conn->prepare($sql);
            $stmt->execute([$id]);
            return true;
        } catch (Exception $e) {
            return false;
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // ارزش‌ها
    // ═══════════════════════════════════════════════════════════════════════════

    function getValues()
    {
        $sql = "SELECT * FROM company_values ORDER BY sort_order";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    function saveValue($data)
    {
        try {
            if (!empty($data['id'])) {
                $sql = "UPDATE company_values SET title = ?, description = ?, icon = ?, sort_order = ? WHERE id = ?";
                $stmt = self::$conn->prepare($sql);
                $stmt->execute([
                    $data['title'],
                    $data['description'],
                    $data['icon'] ?? '',
                    $data['sort_order'] ?? 0,
                    $data['id']
                ]);
            } else {
                $sql = "INSERT INTO company_values (title, description, icon, sort_order) VALUES (?, ?, ?, ?)";
                $stmt = self::$conn->prepare($sql);
                $stmt->execute([
                    $data['title'],
                    $data['description'],
                    $data['icon'] ?? '',
                    $data['sort_order'] ?? 0
                ]);
            }
            return true;
        } catch (Exception $e) {
            return false;
        }
    }

    function deleteValue($id)
    {
        try {
            $sql = "DELETE FROM company_values WHERE id = ?";
            $stmt = self::$conn->prepare($sql);
            $stmt->execute([$id]);
            return true;
        } catch (Exception $e) {
            return false;
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // FAQ
    // ═══════════════════════════════════════════════════════════════════════════

    function getAllFAQ()
    {
        $sql = "SELECT * FROM faq ORDER BY page, sort_order";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    function getFAQ($page)
    {
        $sql = "SELECT * FROM faq WHERE page = ? AND is_active = 1 ORDER BY sort_order";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute([$page]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    function saveFAQ($data)
    {
        try {
            if (!empty($data['id'])) {
                $sql = "UPDATE faq SET question = ?, answer = ?, is_active = ?, sort_order = ? WHERE id = ?";
                $stmt = self::$conn->prepare($sql);
                $stmt->execute([
                    $data['question'],
                    $data['answer'],
                    isset($data['is_active']) ? 1 : 0,
                    $data['sort_order'] ?? 0,
                    $data['id']
                ]);
            } else {
                $sql = "INSERT INTO faq (page, question, answer, is_active, sort_order) VALUES (?, ?, ?, ?, ?)";
                $stmt = self::$conn->prepare($sql);
                $stmt->execute([
                    $data['page'] ?? 'contact',
                    $data['question'],
                    $data['answer'],
                    isset($data['is_active']) ? 1 : 0,
                    $data['sort_order'] ?? 0
                ]);
            }
            return true;
        } catch (Exception $e) {
            return false;
        }
    }

    function deleteFAQ($id)
    {
        try {
            $sql = "DELETE FROM faq WHERE id = ?";
            $stmt = self::$conn->prepare($sql);
            $stmt->execute([$id]);
            return true;
        } catch (Exception $e) {
            return false;
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // فرآیند کار
    // ═══════════════════════════════════════════════════════════════════════════

    function getProcessSteps($page)
    {
        $sql = "SELECT * FROM process_steps WHERE page = ? ORDER BY sort_order";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute([$page]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    function saveProcessStep($data)
    {
        try {
            $stepNumber = $data['step_number'] ?? ($data['sort_order'] ?? 0);

            if (!empty($data['id'])) {
                $sql = "UPDATE process_steps SET step_number = ?, title = ?, description = ?, icon = ?, sort_order = ? WHERE id = ?";
                $stmt = self::$conn->prepare($sql);
                $stmt->execute([
                    $stepNumber,
                    $data['title'],
                    $data['description'] ?? '',
                    $data['icon'] ?? '',
                    $stepNumber,
                    $data['id']
                ]);
            } else {
                $sql = "INSERT INTO process_steps (page, step_number, title, description, icon, sort_order) VALUES (?, ?, ?, ?, ?, ?)";
                $stmt = self::$conn->prepare($sql);
                $stmt->execute([
                    $data['page'] ?? 'home',
                    $stepNumber,
                    $data['title'],
                    $data['description'] ?? '',
                    $data['icon'] ?? '',
                    $stepNumber
                ]);
            }
            return true;
        } catch (Exception $e) {
            error_log("saveProcessStep Error: " . $e->getMessage());
            return false;
        }
    }

    function deleteProcessStep($id)
    {
        try {
            $sql = "DELETE FROM process_steps WHERE id = ?";
            $stmt = self::$conn->prepare($sql);
            $stmt->execute([$id]);
            return true;
        } catch (Exception $e) {
            return false;
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // پیام‌های تماس
    // ═══════════════════════════════════════════════════════════════════════════

    function getAllMessages()
    {
        $sql = "SELECT * FROM contact_messages ORDER BY created_at DESC";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    function getMessage($id)
    {
        $sql = "SELECT * FROM contact_messages WHERE id = ?";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    function markMessageAsRead($id)
    {
        $sql = "UPDATE contact_messages SET is_read = 1 WHERE id = ?";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute([$id]);
    }

    function deleteMessage($id)
    {
        try {
            $sql = "DELETE FROM contact_messages WHERE id = ?";
            $stmt = self::$conn->prepare($sql);
            $stmt->execute([$id]);
            return true;
        } catch (Exception $e) {
            return false;
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // عمومی
    // ═══════════════════════════════════════════════════════════════════════════

    function getItemById($table, $id)
    {
        // لیست جداول مجاز
        $allowedTables = ['stats', 'testimonials', 'timeline', 'company_values', 'faq', 'process_steps', 'services'];
        if (!in_array($table, $allowedTables)) {
            return null;
        }

        $sql = "SELECT * FROM $table WHERE id = ?";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    function saveHomeData($data)
    {
        // ذخیره محتوای hero
        if (isset($data['hero'])) {
            $this->savePageContent('home', 'hero', $data['hero']);
        }
        // ذخیره محتوای cta
        if (isset($data['cta'])) {
            $this->savePageContent('home', 'cta', $data['cta']);
        }
        return true;
    }

    function saveAboutData($data)
    {
        if (isset($data['hero'])) {
            $this->savePageContent('about', 'hero', $data['hero']);
        }
        if (isset($data['manifesto'])) {
            $this->savePageContent('about', 'manifesto', $data['manifesto']);
        }
        if (isset($data['cta'])) {
            $this->savePageContent('about', 'cta', $data['cta']);
        }
        return true;
    }

    function saveContactData($data)
    {
        if (isset($data['hero'])) {
            $this->savePageContent('contact', 'hero', $data['hero']);
        }
        return true;
    }
}
