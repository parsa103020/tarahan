<?php

/**
 * Service Model - All services data
 */
class model_service extends Model
{
    function __construct()
    {
        parent::__construct();
        Model::sessionInit();
    }

    /**
     * Get all services list
     * @return array All services
     */
    function getAllServices()
    {
        $sql = "SELECT id, slug, title, short_description, icon FROM services WHERE is_active = 1 ORDER BY sort_order";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Get service by slug
     * @param string $slug Service slug
     * @return array|null Service data
     */
    function getServiceBySlug($slug)
    {
        $sql = "SELECT * FROM services WHERE slug = ? AND is_active = 1";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute([$slug]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    /**
     * Get service stats
     * @param int $serviceId Service ID
     * @return array Stats
     */
    function getServiceStats($serviceId)
    {
        $sql = "SELECT stat_value, stat_label FROM service_stats WHERE service_id = ? ORDER BY sort_order";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute([$serviceId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Get service features
     * @param int $serviceId Service ID
     * @return array Features
     */
    function getServiceFeatures($serviceId)
    {
        $sql = "SELECT title, description, icon FROM service_features WHERE service_id = ? AND is_active = 1 ORDER BY sort_order";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute([$serviceId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Get service items/sub-services
     * @param int $serviceId Service ID
     * @return array Service items
     */
    function getServiceItems($serviceId)
    {
        $sql = "SELECT title, description, icon, features, cta_text FROM service_items WHERE service_id = ? AND is_active = 1 ORDER BY sort_order";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute([$serviceId]);
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Convert features string to array
        foreach ($results as &$item) {
            if (!empty($item['features'])) {
                $item['features'] = explode('|', $item['features']);
            } else {
                $item['features'] = [];
            }
        }

        return $results;
    }

    /**
     * Get service process steps
     * @param int $serviceId Service ID
     * @return array Process steps
     */
    function getServiceProcess($serviceId)
    {
        $sql = "SELECT step_number, title, description, icon FROM service_process WHERE service_id = ? ORDER BY sort_order";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute([$serviceId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Get service FAQ
     * @param int $serviceId Service ID
     * @return array FAQ items
     */
    function getServiceFAQ($serviceId)
    {
        $sql = "SELECT question, answer FROM service_faq WHERE service_id = ? AND is_active = 1 ORDER BY sort_order";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute([$serviceId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Get service testimonials
     * @param int $serviceId Service ID
     * @return array Testimonials
     */
    function getServiceTestimonials($serviceId)
    {
        $sql = "SELECT content, author_name, author_position, author_avatar, rating
                FROM testimonials WHERE service_id = ? AND is_active = 1 ORDER BY sort_order";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute([$serviceId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Get service portfolio
     * @param int $serviceId Service ID
     * @return array Portfolio items
     */
    function getServicePortfolio($serviceId)
    {
        $sql = "SELECT title, subtitle, description, image, link FROM portfolio WHERE service_id = ? AND is_active = 1 ORDER BY sort_order";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute([$serviceId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Get locations (for ads service)
     * @param int $serviceId Service ID
     * @return array Locations
     */
    function getLocations($serviceId)
    {
        $sql = "SELECT name FROM locations WHERE service_id = ? AND is_active = 1 ORDER BY sort_order";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute([$serviceId]);
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    }

    /**
     * Get packages (for idea service)
     * @param int $serviceId Service ID
     * @return array Packages
     */
    function getPackages($serviceId)
    {
        $sql = "SELECT title, subtitle, description, cta_text, is_popular FROM packages WHERE service_id = ? AND is_active = 1 ORDER BY sort_order";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute([$serviceId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Get equipment (for content service)
     * @param int $serviceId Service ID
     * @return array Equipment names
     */
    function getEquipment($serviceId)
    {
        $sql = "SELECT name FROM equipment WHERE service_id = ? ORDER BY sort_order";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute([$serviceId]);
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    }

    /**
     * Get paper types (for print service)
     * @return array Paper types
     */
    function getPaperTypes()
    {
        $sql = "SELECT name, description FROM paper_types ORDER BY sort_order";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Get related services
     * @param string $currentSlug Current service slug
     * @param int $limit Number of related services
     * @return array Related services
     */
    function getRelatedServices($currentSlug, $limit = 3)
    {
        $sql = "SELECT slug, title, short_description, icon FROM services WHERE slug != ? AND is_active = 1 ORDER BY sort_order LIMIT ?";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute([$currentSlug, $limit]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Get all data for a specific service page
     * @param string $slug Service slug
     * @return array|null All service data or null if not found
     */
    function getFullServiceData($slug)
    {
        // Get basic service info
        $service = $this->getServiceBySlug($slug);
        if (!$service) {
            return null;
        }

        $serviceId = $service['id'];

        // Build complete data array
        $data = [
            'service' => $service,
            'stats' => $this->getServiceStats($serviceId),
            'features' => $this->getServiceFeatures($serviceId),
            'items' => $this->getServiceItems($serviceId),
            'process' => $this->getServiceProcess($serviceId),
            'faq' => $this->getServiceFAQ($serviceId),
            'testimonials' => $this->getServiceTestimonials($serviceId),
            'portfolio' => $this->getServicePortfolio($serviceId),
            'related' => $this->getRelatedServices($slug),
        ];

        // Add service-specific data
        switch ($slug) {
            case 'ads':
                $data['locations'] = $this->getLocations($serviceId);
                break;
            case 'idea':
                $data['packages'] = $this->getPackages($serviceId);
                break;
            case 'content':
                $data['equipment'] = $this->getEquipment($serviceId);
                break;
            case 'print':
                $data['paper_types'] = $this->getPaperTypes();
                break;
        }

        return $data;
    }
}
