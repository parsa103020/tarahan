<?php

/**
 * Index Model - Home page data
 */
class model_initial extends Model
{
    function __construct()
    {
        parent::__construct();
        Model::sessionInit();
    }


}
