<?php

/**
 * About Model - About page data
 */
class model_about extends Model
{
    function __construct()
    {
        parent::__construct();
        Model::sessionInit();
    }

    /**
     * Get hero section content
     * @return array Hero data
     */
    function getHeroContent()
    {
        $sql = "SELECT content_key, content_value FROM page_content WHERE page = 'about' AND section = 'hero'";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $hero = [];
        foreach ($results as $row) {
            $hero[$row['content_key']] = $row['content_value'];
        }

        return $hero;
    }

    /**
     * Get stats for about page
     * @return array Stats data
     */
    function getStats()
    {
        $sql = "SELECT stat_value, stat_suffix, stat_prefix, stat_label, stat_icon
                FROM stats WHERE page = 'about' AND is_active = 1 ORDER BY sort_order";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Get company timeline
     * @return array Timeline milestones
     */
    function getTimeline()
    {
        $sql = "SELECT year, title, description FROM timeline WHERE is_active = 1 ORDER BY sort_order";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Get company values
     * @return array Values
     */
    function getValues()
    {
        $sql = "SELECT title, description, icon FROM company_values WHERE is_active = 1 ORDER BY sort_order";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Get manifesto/promise content
     * @return array Manifesto data
     */
    function getManifesto()
    {
        $sql = "SELECT content_key, content_value FROM page_content WHERE page = 'about' AND section = 'manifesto'";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $manifesto = [];
        foreach ($results as $row) {
            $manifesto[$row['content_key']] = $row['content_value'];
        }

        return $manifesto;
    }

    /**
     * Get CTA content
     * @return array CTA data
     */
    function getCTAContent()
    {
        $sql = "SELECT content_key, content_value FROM page_content WHERE page = 'about' AND section = 'cta'";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $cta = [];
        foreach ($results as $row) {
            $cta[$row['content_key']] = $row['content_value'];
        }

        return $cta;
    }

    /**
     * Get all about page data at once
     * @return array All about page data
     */
    function getAllAboutData()
    {
        return [
            'hero' => $this->getHeroContent(),
            'stats' => $this->getStats(),
            'timeline' => $this->getTimeline(),
            'values' => $this->getValues(),
            'manifesto' => $this->getManifesto(),
            'cta' => $this->getCTAContent(),
        ];
    }
}
