<?php

/**
 * Contact Model - Contact page data
 */
class model_contact extends Model
{
    function __construct()
    {
        parent::__construct();
        Model::sessionInit();
    }

    /**
     * Get hero section content
     * @return array Hero data
     */
    function getHeroContent()
    {
        $sql = "SELECT content_key, content_value FROM page_content WHERE page = 'contact' AND section = 'hero'";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $hero = [];
        foreach ($results as $row) {
            $hero[$row['content_key']] = $row['content_value'];
        }

        return $hero;
    }

    /**
     * Get form section content
     * @return array Form data
     */
    function getFormContent()
    {
        $sql = "SELECT content_key, content_value FROM page_content WHERE page = 'contact' AND section = 'form'";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $form = [];
        foreach ($results as $row) {
            $form[$row['content_key']] = $row['content_value'];
        }

        return $form;
    }

    /**
     * Get contact information from settings
     * @return array Contact info
     */
    function getContactInfo()
    {
        $sql = "SELECT setting_key, setting_value FROM settings WHERE setting_group IN ('contact', 'hours', 'social', 'map')";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $info = [];
        foreach ($results as $row) {
            $info[$row['setting_key']] = $row['setting_value'];
        }

        return $info;
    }

    /**
     * Get FAQ items for contact page
     * @return array FAQ items
     */
    function getFAQ()
    {
        $sql = "SELECT question, answer FROM faq WHERE page = 'contact' AND is_active = 1 ORDER BY sort_order";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Save contact form submission to database
     * @param array $data Form data
     * @return bool|string Success status or error message
     */
    function saveContactMessage($data)
    {
        // Sanitize input
        $name = Model::sanitize($data['name'] ?? '');
        $phone = Model::sanitize($data['phone'] ?? '');
        $email = filter_var($data['email'] ?? '', FILTER_SANITIZE_EMAIL);
        $subject = Model::sanitize($data['subject'] ?? '');
        $message = Model::sanitize($data['message'] ?? '');

        // Validate required fields
        if (empty($name) || empty($phone) || empty($message)) {
            return 'لطفا فیلدهای الزامی را پر کنید.';
        }

        try {
            $sql = "INSERT INTO contact_messages (name, phone, email, subject, message) VALUES (?, ?, ?, ?, ?)";
            $stmt = self::$conn->prepare($sql);
            $stmt->execute([$name, $phone, $email, $subject, $message]);
            return true;
        } catch (PDOException $e) {
            return 'خطا در ثبت پیام. لطفا دوباره تلاش کنید.';
        }
    }

    /**
     * Get all contact page data at once
     * @return array All contact page data
     */
    function getAllContactData()
    {
        return [
            'hero' => $this->getHeroContent(),
            'form' => $this->getFormContent(),
            'info' => $this->getContactInfo(),
            'faq' => $this->getFAQ(),
        ];
    }
}
