<?php

/**
 * Common Model - Shared data across all pages
 * این مدل برای داده‌های مشترک همه صفحات استفاده می‌شود
 */
class model_common extends Model
{
    function __construct()
    {
        parent::__construct();
        Model::sessionInit();
    }

    /**
     * Get all settings
     * @param string|null $group Filter by group (brand, contact, social, etc.)
     * @return array Settings key-value pairs
     */
    function getSettings($group = null)
    {
        $sql = "SELECT setting_key, setting_value FROM settings";
        $params = [];

        if ($group) {
            $sql .= " WHERE setting_group = ?";
            $params[] = $group;
        }

        $stmt = self::$conn->prepare($sql);
        $stmt->execute($params);
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $settings = [];
        foreach ($results as $row) {
            $settings[$row['setting_key']] = $row['setting_value'];
        }

        return $settings;
    }

    /**
     * Get single setting value
     * @param string $key Setting key
     * @param string $default Default value if not found
     * @return string Setting value
     */
    function getSetting($key, $default = '')
    {
        $sql = "SELECT setting_value FROM settings WHERE setting_key = ?";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute([$key]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        return $result ? $result['setting_value'] : $default;
    }

    /**
     * Get brand information
     * @return array Brand data
     */
    function getBrandInfo()
    {
        return $this->getSettings('brand');
    }

    /**
     * Get contact information
     * @return array Contact data
     */
    function getContactInfo()
    {
        $contact = $this->getSettings('contact');
        $hours = $this->getSettings('hours');
        $social = $this->getSettings('social');
        $map = $this->getSettings('map');

        return [
            'phone_mobile' => $contact['phone_mobile'] ?? '',
            'phone_landline' => $contact['phone_landline'] ?? '',
            'email' => $contact['email'] ?? '',
            'address' => $contact['address'] ?? '',
            'postal_code' => $contact['postal_code'] ?? '',
            'working_days' => $hours['working_days'] ?? '',
            'working_hours' => $hours['working_hours'] ?? '',
            'support_hours' => $hours['support_hours'] ?? '',
            'instagram' => $social['instagram'] ?? '',
            'telegram' => $social['telegram'] ?? '',
            'whatsapp' => $social['whatsapp'] ?? '',
            'linkedin' => $social['linkedin'] ?? '',
            'map_embed' => $map['map_embed'] ?? '',
            'map_lat' => $map['map_lat'] ?? '',
            'map_lng' => $map['map_lng'] ?? '',
        ];
    }

    /**
     * Get all services for navigation/footer
     * @return array Services list
     */
    function getServicesMenu()
    {
        $sql = "SELECT slug, title, icon FROM services WHERE is_active = 1 ORDER BY sort_order";
        $stmt = self::$conn->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
