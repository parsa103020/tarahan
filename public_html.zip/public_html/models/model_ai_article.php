<?php

/**
 * AI Article Generator Model - Version 3.0
 * Intelligent Automated Article Generation System
 *
 * Features:
 * - State Machine Workflow with database-backed states
 * - Smart API key rotation with rate limiting
 * - Database-level locking
 * - Comprehensive content validation
 * - Intelligent topic selection
 * - Complete SEO schema markup
 * - Flexible backlink strategy
 * - Content uniqueness verification
 * - Enhanced quality assurance
 *
 * @version 3.0.0
 * @author Tarahan Bastan
 */
class model_ai_article extends Model
{
    // =========================================================================
    // CONFIGURATION
    // =========================================================================

    private $apiKeys = [];
    private $apiKeyStatus = []; // Track status per key
    private $config = [];
    private $logger;

    // Workflow states
    const STATE_PENDING = 'pending';
    const STATE_TOPIC_SELECTED = 'topic_selected';
    const STATE_CONTENT_GENERATING = 'content_generating';
    const STATE_CONTENT_GENERATED = 'content_generated';
    const STATE_REVIEWING = 'reviewing';
    const STATE_REVIEWED = 'reviewed';
    const STATE_IMAGE_GENERATING = 'image_generating';
    const STATE_IMAGE_GENERATED = 'image_generated';
    const STATE_VALIDATING = 'validating';
    const STATE_VALIDATED = 'validated';
    const STATE_PUBLISHING = 'publishing';
    const STATE_PUBLISHED = 'published';
    const STATE_FAILED = 'failed';

    // Rate limiting
    private $apiRequestDelay = 3000; // 3 seconds between API requests (ms)
    private $lastApiCallTime = 0;

    // Forced service code (optional override)
    private $forcedServiceCode = null;

    // Services configuration
    private $services = [
        'booth' => [
            'name' => 'غرفه نمایشگاهی',
            'name_en' => 'Exhibition Booth',
            'url' => '/service/booth',
            'keywords' => ['غرفه سازی', 'طراحی غرفه', 'غرفه نمایشگاه', 'ساخت غرفه', 'غرفه سازی همدان'],
            'related_services' => ['event', 'ads', 'tandis'],
            'pillar_topics' => ['طراحی غرفه', 'انواع غرفه نمایشگاهی', 'هزینه غرفه سازی'],
        ],
        'ads' => [
            'name' => 'تبلیغات محیطی',
            'name_en' => 'Outdoor Advertising',
            'url' => '/service/ads',
            'keywords' => ['بیلبورد', 'بنر تبلیغاتی', 'تابلو تبلیغاتی', 'تبلیغات محیطی', 'تبلیغات همدان'],
            'related_services' => ['print', 'content', 'idea'],
            'pillar_topics' => ['تبلیغات محیطی موثر', 'انواع رسانه محیطی', 'طراحی بیلبورد'],
        ],
        'tandis' => [
            'name' => 'تندیس و المان',
            'name_en' => 'Statue and Element',
            'url' => '/service/tandis',
            'keywords' => ['ساخت تندیس', 'المان شهری', 'مجسمه تبلیغاتی', 'تندیس همدان'],
            'related_services' => ['booth', 'event', 'idea'],
            'pillar_topics' => ['طراحی تندیس', 'المان شهری', 'مجسمه سازی تبلیغاتی'],
        ],
        'event' => [
            'name' => 'برگزاری همایش',
            'name_en' => 'Event Management',
            'url' => '/service/event',
            'keywords' => ['برگزاری رویداد', 'همایش', 'کنفرانس', 'سمینار', 'رویداد همدان'],
            'related_services' => ['booth', 'content', 'print'],
            'pillar_topics' => ['مدیریت رویداد', 'برنامه‌ریزی همایش', 'اجرای کنفرانس'],
        ],
        'content' => [
            'name' => 'تیزر و محتوا',
            'name_en' => 'Content Production',
            'url' => '/service/content',
            'keywords' => ['تولید محتوا', 'تیزر تبلیغاتی', 'ویدیو مارکتینگ', 'تولید محتوا همدان'],
            'related_services' => ['ads', 'idea', 'print'],
            'pillar_topics' => ['تولید محتوای ویدیویی', 'تیزر تبلیغاتی', 'ویدیو مارکتینگ'],
        ],
        'print' => [
            'name' => 'چاپ افست و دیجیتال',
            'name_en' => 'Printing Services',
            'url' => '/service/print',
            'keywords' => ['چاپ دیجیتال', 'چاپ افست', 'چاپ بنر', 'چاپ همدان'],
            'related_services' => ['ads', 'content', 'booth'],
            'pillar_topics' => ['انواع چاپ', 'چاپ دیجیتال vs افست', 'طراحی برای چاپ'],
        ],
        'idea' => [
            'name' => 'ایده نو',
            'name_en' => 'Creative Consulting',
            'url' => '/service/idea',
            'keywords' => ['مشاوره تبلیغات', 'ایده‌پردازی', 'خلاقیت', 'برندینگ', 'مشاوره همدان'],
            'related_services' => ['content', 'ads', 'event'],
            'pillar_topics' => ['خلاقیت در تبلیغات', 'برندینگ', 'استراتژی تبلیغاتی'],
        ],
    ];

    // Anchor text variations for diversity
    private $anchorVariations = [
        'service' => [
            'خدمات %s طراحان باستان',
            'مشاوره رایگان %s',
            'اطلاعات بیشتر درباره %s',
            'سفارش %s',
            '%s حرفه‌ای در همدان',
        ],
        'contact' => [
            'تماس با کارشناسان ما',
            'دریافت مشاوره رایگان',
            'ارتباط با تیم طراحان باستان',
            'درخواست قیمت',
            'تماس با ما',
        ],
        'cta' => [
            'همین حالا مشاوره بگیرید',
            'با ما تماس بگیرید',
            'پروژه‌تان را به ما بسپارید',
            'درخواست استعلام قیمت',
        ],
    ];

    /**
     * Constructor
     */
    function __construct()
    {
        parent::__construct();
        $this->loadConfig();
        $this->initLogger();
        $this->loadApiKeyStatus();
    }

    /**
     * Load configuration from file
     */
    private function loadConfig()
    {
        $configFile = dirname(__DIR__) . '/data/api_keys.json';

        if (file_exists($configFile)) {
            $config = json_decode(file_get_contents($configFile), true);
            $this->apiKeys = $config['gemini_keys'] ?? [];
            $this->config = $config['settings'] ?? [];
        }

        // Default values
        $this->config = array_merge([
            'max_retries' => 3,
            'timeout' => 120,
            'image_timeout' => 180,
            'min_word_count' => 1500,
            'target_word_count' => 2000,
            'api_request_delay_ms' => 3000,
            'max_similarity_percent' => 30,
            'auth_token' => 'tarahan_ai_2024_secure_token',
        ], $this->config);

        $this->apiRequestDelay = $this->config['api_request_delay_ms'];
    }

    /**
     * Initialize logger
     */
    private function initLogger()
    {
        $this->logger = new class {
            private $logFile;

            public function __construct() {
                $logDir = dirname(__DIR__) . '/data/logs';
                if (!is_dir($logDir)) {
                    mkdir($logDir, 0755, true);
                }
                $this->logFile = $logDir . '/ai_article_' . date('Y-m') . '.log';
            }

            public function log($level, $message, $context = []) {
                $entry = [
                    'time' => date('Y-m-d H:i:s'),
                    'level' => $level,
                    'message' => $message,
                    'context' => $context
                ];
                file_put_contents(
                    $this->logFile,
                    json_encode($entry, JSON_UNESCAPED_UNICODE) . "\n",
                    FILE_APPEND | LOCK_EX
                );
            }

            public function info($msg, $ctx = []) { $this->log('INFO', $msg, $ctx); }
            public function error($msg, $ctx = []) { $this->log('ERROR', $msg, $ctx); }
            public function warning($msg, $ctx = []) { $this->log('WARNING', $msg, $ctx); }
            public function debug($msg, $ctx = []) { $this->log('DEBUG', $msg, $ctx); }
        };
    }

    /**
     * Load API key status from file
     */
    private function loadApiKeyStatus()
    {
        $statusFile = dirname(__DIR__) . '/data/api_key_status.json';

        if (file_exists($statusFile)) {
            $this->apiKeyStatus = json_decode(file_get_contents($statusFile), true) ?? [];
        }

        // Initialize status for each key
        foreach ($this->apiKeys as $index => $key) {
            if (!isset($this->apiKeyStatus[$index])) {
                $this->apiKeyStatus[$index] = [
                    'requests_today' => 0,
                    'last_request' => null,
                    'last_error' => null,
                    'error_count' => 0,
                    'is_exhausted' => false,
                    'cooldown_until' => null,
                ];
            }
        }
    }

    /**
     * Save API key status to file
     */
    private function saveApiKeyStatus()
    {
        $statusFile = dirname(__DIR__) . '/data/api_key_status.json';
        file_put_contents($statusFile, json_encode($this->apiKeyStatus, JSON_PRETTY_PRINT));
    }

    // =========================================================================
    // AUTHENTICATION
    // =========================================================================

    /**
     * Verify authentication token
     */
    public function verifyAuth($token)
    {
        return $token === $this->config['auth_token'];
    }

    // =========================================================================
    // DATABASE-LEVEL LOCKING
    // =========================================================================

    /**
     * Acquire database lock for generation
     */
    private function acquireLock($workflowId)
    {
        try {
            // Create lock table if not exists
            $this->doQuery("CREATE TABLE IF NOT EXISTS ai_workflow_locks (
                id INT AUTO_INCREMENT PRIMARY KEY,
                workflow_id VARCHAR(50) UNIQUE NOT NULL,
                process_id VARCHAR(100) NOT NULL,
                locked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                expires_at TIMESTAMP NOT NULL,
                INDEX idx_expires (expires_at)
            ) ENGINE=InnoDB");

            // Clean expired locks
            $this->doQuery("DELETE FROM ai_workflow_locks WHERE expires_at < NOW()");

            // Try to acquire lock
            $processId = uniqid('proc_', true) . '_' . getmypid();
            $expiresAt = date('Y-m-d H:i:s', time() + 900); // 15 minutes

            $sql = "INSERT INTO ai_workflow_locks (workflow_id, process_id, expires_at)
                    VALUES (?, ?, ?)
                    ON DUPLICATE KEY UPDATE
                    process_id = IF(expires_at < NOW(), VALUES(process_id), process_id),
                    locked_at = IF(expires_at < NOW(), NOW(), locked_at),
                    expires_at = IF(expires_at < NOW(), VALUES(expires_at), expires_at)";

            $this->doQuery($sql, [$workflowId, $processId, $expiresAt]);

            // Verify we got the lock
            $result = $this->doSelect(
                "SELECT process_id FROM ai_workflow_locks WHERE workflow_id = ?",
                [$workflowId]
            );

            if ($result && $result[0]['process_id'] === $processId) {
                $this->logger->info('Lock acquired', ['workflow_id' => $workflowId, 'process_id' => $processId]);
                return $processId;
            }

            return false;

        } catch (Exception $e) {
            $this->logger->error('Failed to acquire lock', ['error' => $e->getMessage()]);
            return false;
        }
    }

    /**
     * Release database lock
     */
    private function releaseLock($workflowId, $processId)
    {
        try {
            $this->doQuery(
                "DELETE FROM ai_workflow_locks WHERE workflow_id = ? AND process_id = ?",
                [$workflowId, $processId]
            );
            $this->logger->info('Lock released', ['workflow_id' => $workflowId]);
            return true;
        } catch (Exception $e) {
            $this->logger->error('Failed to release lock', ['error' => $e->getMessage()]);
            return false;
        }
    }

    /**
     * Check if workflow is locked
     */
    public function isLocked($workflowId = 'article_generation')
    {
        try {
            $result = $this->doSelect(
                "SELECT * FROM ai_workflow_locks WHERE workflow_id = ? AND expires_at > NOW()",
                [$workflowId]
            );
            return !empty($result);
        } catch (Exception $e) {
            return false;
        }
    }

    // =========================================================================
    // STATE MACHINE WORKFLOW
    // =========================================================================

    /**
     * Create workflow record in database
     */
    private function createWorkflowRecord()
    {
        // Create workflow states table if not exists
        $this->doQuery("CREATE TABLE IF NOT EXISTS ai_workflow_states (
            id INT AUTO_INCREMENT PRIMARY KEY,
            state VARCHAR(50) NOT NULL DEFAULT 'pending',
            service_code VARCHAR(50) NULL,
            topic_id INT NULL,
            topic_title VARCHAR(500) NULL,
            article_id INT NULL,
            content_data LONGTEXT NULL,
            image_path VARCHAR(500) NULL,
            validation_result TEXT NULL,
            quality_score INT DEFAULT 0,
            error_message TEXT NULL,
            retry_count INT DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            completed_at TIMESTAMP NULL,
            INDEX idx_state (state),
            INDEX idx_created (created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci");

        $sql = "INSERT INTO ai_workflow_states (state) VALUES (?)";
        $this->doQuery($sql, [self::STATE_PENDING]);

        return self::$conn->lastInsertId();
    }

    /**
     * Update workflow state
     */
    private function updateWorkflowState($workflowId, $state, $data = [])
    {
        $sets = ['state = ?', 'updated_at = NOW()'];
        $params = [$state];

        foreach ($data as $key => $value) {
            if ($key === 'content_data' && is_array($value)) {
                $value = json_encode($value, JSON_UNESCAPED_UNICODE);
            }
            $sets[] = "{$key} = ?";
            $params[] = $value;
        }

        if ($state === self::STATE_PUBLISHED || $state === self::STATE_FAILED) {
            $sets[] = 'completed_at = NOW()';
        }

        $params[] = $workflowId;
        $sql = "UPDATE ai_workflow_states SET " . implode(', ', $sets) . " WHERE id = ?";
        $this->doQuery($sql, $params);

        $this->logger->info('Workflow state updated', ['id' => $workflowId, 'state' => $state]);
    }

    /**
     * Get workflow state
     */
    private function getWorkflowState($workflowId)
    {
        $result = $this->doSelect("SELECT * FROM ai_workflow_states WHERE id = ?", [$workflowId]);
        return $result[0] ?? null;
    }

    /**
     * Get incomplete workflows that can be resumed
     */
    public function getResumableWorkflows()
    {
        $sql = "SELECT * FROM ai_workflow_states
                WHERE state NOT IN (?, ?)
                AND created_at > DATE_SUB(NOW(), INTERVAL 24 HOUR)
                ORDER BY created_at DESC";
        return $this->doSelect($sql, [self::STATE_PUBLISHED, self::STATE_FAILED]);
    }

    /**
     * Resume workflow from last state
     */
    public function resumeWorkflow($workflowId)
    {
        $workflow = $this->getWorkflowState($workflowId);

        if (!$workflow) {
            throw new Exception("Workflow not found: {$workflowId}");
        }

        $this->logger->info('Resuming workflow', ['id' => $workflowId, 'state' => $workflow['state']]);

        // Resume from current state
        return $this->executeFromState($workflowId, $workflow);
    }

    /**
     * Execute workflow from a specific state
     */
    private function executeFromState($workflowId, $workflow)
    {
        $state = $workflow['state'];

        try {
            switch ($state) {
                case self::STATE_PENDING:
                    return $this->executeSelectTopic($workflowId);

                case self::STATE_TOPIC_SELECTED:
                    return $this->executeGenerateContent($workflowId);

                case self::STATE_CONTENT_GENERATED:
                    return $this->executeReviewContent($workflowId);

                case self::STATE_REVIEWED:
                    return $this->executeGenerateImage($workflowId);

                case self::STATE_IMAGE_GENERATED:
                    return $this->executeValidate($workflowId);

                case self::STATE_VALIDATED:
                    return $this->executePublish($workflowId);

                case self::STATE_PUBLISHED:
                    return $this->getWorkflowResult($workflowId);

                default:
                    throw new Exception("Unknown state: {$state}");
            }
        } catch (Exception $e) {
            $this->handleWorkflowError($workflowId, $state, $e);
            throw $e;
        }
    }

    /**
     * Handle workflow error
     */
    private function handleWorkflowError($workflowId, $state, Exception $e)
    {
        $workflow = $this->getWorkflowState($workflowId);
        $retryCount = ($workflow['retry_count'] ?? 0) + 1;

        if ($retryCount >= $this->config['max_retries']) {
            $this->updateWorkflowState($workflowId, self::STATE_FAILED, [
                'error_message' => $e->getMessage(),
                'retry_count' => $retryCount
            ]);
        } else {
            $this->updateWorkflowState($workflowId, $state, [
                'error_message' => $e->getMessage(),
                'retry_count' => $retryCount
            ]);
        }

        $this->logger->error('Workflow error', [
            'id' => $workflowId,
            'state' => $state,
            'error' => $e->getMessage(),
            'retry_count' => $retryCount
        ]);
    }

    // =========================================================================
    // MAIN WORKFLOW EXECUTION
    // =========================================================================

    /**
     * Run complete workflow
     * @param string|null $forcedServiceCode - Force specific service (optional)
     */
    public function runWorkflow($forcedServiceCode = null)
    {
        $lockId = 'article_generation';
        $processId = $this->acquireLock($lockId);

        if (!$processId) {
            return [
                'success' => false,
                'message' => 'Another generation process is running. Please wait.'
            ];
        }

        $startTime = microtime(true);
        $workflowId = null;
        $this->forcedServiceCode = $forcedServiceCode; // Store for use in topic selection

        try {
            $this->logger->info('Starting new workflow', ['forced_service' => $forcedServiceCode]);

            // Create workflow record
            $workflowId = $this->createWorkflowRecord();
            $logId = $this->startLog();

            // Execute all steps
            $result = $this->executeFromState($workflowId, ['state' => self::STATE_PENDING]);

            // Complete log
            $elapsedTime = round((microtime(true) - $startTime) * 1000);
            $this->completeLog($logId, $result['article_id'], $elapsedTime);

            $this->releaseLock($lockId, $processId);

            return [
                'success' => true,
                'message' => 'Article generated and published successfully',
                'data' => $result
            ];

        } catch (Exception $e) {
            $this->releaseLock($lockId, $processId);
            $this->logger->error('Workflow failed', ['error' => $e->getMessage()]);

            return [
                'success' => false,
                'message' => 'Workflow failed: ' . $e->getMessage(),
                'workflow_id' => $workflowId
            ];
        }
    }

    // =========================================================================
    // STEP 1: INTELLIGENT TOPIC SELECTION
    // =========================================================================

    private function executeSelectTopic($workflowId)
    {
        $this->updateWorkflowState($workflowId, self::STATE_TOPIC_SELECTED);

        // Select service with intelligent balancing
        $service = $this->selectServiceIntelligently();
        $this->logger->info('Service selected', ['service' => $service['code']]);

        // Select topic with priority consideration
        $topic = $this->selectTopicIntelligently($service['code']);
        $this->logger->info('Topic selected', ['topic' => $topic['title']]);

        $this->updateWorkflowState($workflowId, self::STATE_TOPIC_SELECTED, [
            'service_code' => $service['code'],
            'topic_id' => $topic['id'],
            'topic_title' => $topic['title']
        ]);

        return $this->executeGenerateContent($workflowId);
    }

    /**
     * Select service with intelligent balancing
     */
    private function selectServiceIntelligently()
    {
        // Check if a specific service is forced
        if (!empty($this->forcedServiceCode) && isset($this->services[$this->forcedServiceCode])) {
            $this->logger->info('Using forced service', ['service' => $this->forcedServiceCode]);
            return array_merge(['code' => $this->forcedServiceCode], $this->services[$this->forcedServiceCode]);
        }

        $counts = $this->getArticleCountByService();
        $performance = $this->getServicePerformance();

        $scores = [];

        foreach ($this->services as $code => $service) {
            $articleCount = $counts[$code] ?? 0;
            $viewsPerArticle = $performance[$code]['avg_views'] ?? 0;

            // Score = inverse of article count + performance bonus
            $score = (1 / max(1, $articleCount)) * 100;

            // Add performance bonus (services with higher views get slight priority)
            $score += min(20, $viewsPerArticle / 100);

            // Add randomness to prevent patterns
            $score += rand(0, 10);

            $scores[$code] = $score;
        }

        // Select service with highest score
        arsort($scores);
        $selectedCode = array_key_first($scores);

        return array_merge(['code' => $selectedCode], $this->services[$selectedCode]);
    }

    /**
     * Get service performance metrics
     */
    private function getServicePerformance()
    {
        $sql = "SELECT service_code,
                AVG(views) as avg_views,
                COUNT(*) as article_count
                FROM articles
                WHERE service_code IS NOT NULL
                GROUP BY service_code";

        $results = $this->doSelect($sql);
        $performance = [];

        foreach ($results as $row) {
            $performance[$row['service_code']] = [
                'avg_views' => (float)$row['avg_views'],
                'article_count' => (int)$row['article_count']
            ];
        }

        return $performance;
    }

    /**
     * Select topic with intelligent prioritization
     */
    private function selectTopicIntelligently($serviceCode)
    {
        // First, try to get unused topic from database
        $topic = $this->getUnusedTopicFromDb($serviceCode);

        if (!$topic) {
            // Generate new topic with AI if none available
            $this->enforceApiDelay();
            $topic = $this->generateNewTopicWithAI($serviceCode);
        }

        return $topic;
    }

    /**
     * Get unused topic from database with priority
     */
    private function getUnusedTopicFromDb($serviceCode)
    {
        $sql = "SELECT id, topic_title as title, primary_keyword, service_code, priority
                FROM ai_article_topics
                WHERE service_code = ? AND is_used = 0
                ORDER BY priority ASC, RAND()
                LIMIT 1";

        $result = $this->doSelect($sql, [$serviceCode]);
        return $result[0] ?? null;
    }

    /**
     * Generate new topic with AI
     */
    private function generateNewTopicWithAI($serviceCode)
    {
        $service = $this->services[$serviceCode];
        $existingTopics = $this->getAllTopicsForService($serviceCode);

        $prompt = "شما یک متخصص سئو و تولید محتوا هستید.
برای خدمات \"{$service['name']}\" یک موضوع مقاله جدید و جذاب پیشنهاد بده که:

1. با موضوعات زیر تکراری نباشد:
" . implode("\n", array_slice($existingTopics, 0, 15)) . "

2. پتانسیل جستجوی بالایی در گوگل داشته باشد
3. به خدمات شرکت طراحان باستان در همدان مرتبط باشد
4. برای کاربران ایرانی مفید و کاربردی باشد
5. موضوع آموزشی یا راهنما باشد (نه تبلیغاتی صرف)

موضوعات پیلار این خدمت: " . implode('، ', $service['pillar_topics']) . "

فقط یک عنوان موضوع برگردان، بدون هیچ توضیح اضافی. عنوان باید:
- بین 40 تا 80 کاراکتر باشد
- شامل کلمه کلیدی اصلی باشد
- جذاب و کلیک‌خور باشد";

        $topic = trim($this->callGeminiApi($prompt));
        $topic = trim($topic, '"\'');

        // Save to database
        $sql = "INSERT INTO ai_article_topics (service_code, topic_title, priority) VALUES (?, ?, 99)";
        $this->doQuery($sql, [$serviceCode, $topic]);
        $topicId = self::$conn->lastInsertId();

        return ['id' => $topicId, 'title' => $topic];
    }

    /**
     * Get all topics for a service
     */
    private function getAllTopicsForService($serviceCode)
    {
        $sql = "SELECT topic_title FROM ai_article_topics WHERE service_code = ?";
        $results = $this->doSelect($sql, [$serviceCode]);
        return array_column($results, 'topic_title');
    }

    // =========================================================================
    // STEP 2: CONTENT GENERATION
    // =========================================================================

    private function executeGenerateContent($workflowId)
    {
        $this->updateWorkflowState($workflowId, self::STATE_CONTENT_GENERATING);

        $workflow = $this->getWorkflowState($workflowId);
        $service = array_merge(['code' => $workflow['service_code']], $this->services[$workflow['service_code']]);
        $topic = ['id' => $workflow['topic_id'], 'title' => $workflow['topic_title']];

        $this->logger->info('Generating content', ['topic' => $topic['title']]);

        // Generate content with API delay
        $this->enforceApiDelay();
        $content = $this->generateArticleContent($service, $topic);

        // Add intelligent backlinks
        $content['body'] = $this->addIntelligentBacklinks($content['body'], $service);

        // Add related articles links
        $content['body'] = $this->addRelatedArticlesLinks($content['body'], $service);

        $this->logger->info('Content generated', ['word_count' => $this->countPersianWords($content['body'])]);

        $this->updateWorkflowState($workflowId, self::STATE_CONTENT_GENERATED, [
            'content_data' => $content
        ]);

        return $this->executeReviewContent($workflowId);
    }

    /**
     * Generate article content with comprehensive prompt
     */
    private function generateArticleContent($service, $topic)
    {
        $prompt = $this->buildComprehensivePrompt($service, $topic);
        $response = $this->callGeminiApiWithRetry($prompt);

        return $this->parseArticleResponse($response, $service, $topic);
    }

    /**
     * Build comprehensive content generation prompt
     */
    private function buildComprehensivePrompt($service, $topic)
    {
        $serviceUrl = URL . ltrim($service['url'], '/');
        $contactUrl = URL . 'contact';
        $keywords = implode('، ', $service['keywords']);
        $relatedServicesText = $this->getRelatedServicesText($service);

        return <<<PROMPT
شما یک متخصص محتوای سئو با ۱۵ سال تجربه هستید که برای شرکت "طراحان باستان" (آژانس تبلیغاتی پیشرو در همدان، تأسیس ۱۳۹۷) مقاله می‌نویسید.

═══════════════════════════════════════════════════════════════════
                        اطلاعات برند
═══════════════════════════════════════════════════════════════════

🏢 نام شرکت: طراحان باستان (آرین طراحان باستان)
📍 موقعیت: همدان، ایران
🎯 شعار: "با ما غیرممکن وجود نداره"
📅 سابقه: فعال از سال ۱۳۹۷
🏆 دستاورد شاخص: اجرای موفق همایش بین‌المللی همدان ۲۰۱۸ در ۴۰ روز

داستان برند: وقتی همه گفتند "غیرممکن است"، طراحان باستان در ۴۰ روز همایش بین‌المللی همدان ۲۰۱۸ را با موفقیت اجرا کرد - غرفه‌ها، بنرها، تندیس یادبود، فیلم معرفی - و نمایندگان ۱۵ کشور را تحت تأثیر قرار داد.

═══════════════════════════════════════════════════════════════════
                        موضوع مقاله
═══════════════════════════════════════════════════════════════════

📝 عنوان: {$topic['title']}
🔧 خدمت: {$service['name']} ({$service['name_en']})
🔗 URL خدمت: {$serviceUrl}
🏷️ کلمات کلیدی: {$keywords}

═══════════════════════════════════════════════════════════════════
                    ساختار اجباری مقاله
═══════════════════════════════════════════════════════════════════

▸ بخش ۱: عنوان و مقدمه
  • یک <h1> جذاب با کلمه کلیدی (حداکثر ۶۰ کاراکتر)
  • Hook قوی در جمله اول (سوال، آمار شگفت‌انگیز، یا چالش مشتری)
  • مقدمه ۲۵۰-۳۰۰ کلمه‌ای با:
    - کلمه کلیدی در ۵۰ کلمه اول
    - معرفی مشکل/چالش خواننده
    - وعده حل مشکل در این مقاله
    - ذکر "همدان" و موقعیت جغرافیایی

▸ بخش ۲-۶: بدنه اصلی (حداقل ۵ سرفصل H2)
  • هر H2 یک موضوع کامل را پوشش دهد
  • زیر هر H2 حداقل ۲ پاراگراف (هر کدام ۱۰۰+ کلمه)
  • استفاده از H3 برای زیرموضوعات
  • حداقل یک لیست (ul/ol) یا جدول در هر بخش

▸ بخش ۷: مقایسه یا جدول
  • یک جدول مقایسه‌ای (<table>) با:
    - حداقل ۳ ردیف و ۳ ستون
    - عناوین در <th>
    - مقایسه گزینه‌ها، انواع، یا مراحل

▸ بخش ۸: نکات کلیدی یا چک‌لیست
  • لیست شماره‌دار از نکات مهم
  • ۵-۷ آیتم کاربردی و عملی

▸ بخش ۹: سوالات متداول (FAQ)
  • ۴-۵ سوال رایج با ساختار:
    <h3>سوال با علامت سوال؟</h3>
    <p>پاسخ کامل و مفید (۵۰-۱۰۰ کلمه)</p>
  • سوالات باید طبیعی و واقعی باشند

▸ بخش ۱۰: نتیجه‌گیری و CTA
  • خلاصه نکات کلیدی
  • تأکید بر ارزش پیشنهادی
  • دعوت به اقدام واضح

═══════════════════════════════════════════════════════════════════
                       محتوا و لحن
═══════════════════════════════════════════════════════════════════

✅ الزامات محتوا:
• طول: حداقل ۲۵۰۰ کلمه (ترجیحاً ۳۰۰۰+)
• لحن: حرفه‌ای اما صمیمی، مثل یک مشاور دلسوز
• مخاطب: صاحبان کسب‌وکار و مدیران بازاریابی در همدان و غرب ایران
• زبان: فارسی رسمی، بدون لغات عامیانه

📊 اطلاعات فنی که باید بگنجانید:
• آمار و ارقام واقعی (می‌توانید تخمین بزنید)
• مثال‌های عملی از پروژه‌های فرضی در همدان
• مقایسه قیمت‌ها و هزینه‌ها (بازه‌ای)
• زمان‌بندی اجرای پروژه‌ها
• نکات فنی تخصصی حوزه {$service['name']}

💡 تکنیک‌های نوشتن:
• از Power Words استفاده کنید: رایگان، تضمینی، حرفه‌ای، فوری، ویژه
• Bucket Brigades: "اما صبر کنید..."، "حالا می‌رسیم به بخش جالب..."
• سوالات رتوریکال برای درگیر کردن خواننده
• داستان‌سرایی کوتاه از تجربیات

═══════════════════════════════════════════════════════════════════
                         سئو
═══════════════════════════════════════════════════════════════════

🎯 کلمه کلیدی اصلی: {$topic['title']}
📍 موقعیت جغرافیایی: همدان (حداقل ۵ بار ذکر شود)

📈 الزامات سئو:
• تراکم کلمه کلیدی: ۱.۵-۲%
• LSI Keywords: استفاده از مترادف‌ها و کلمات مرتبط
• Featured Snippet: یک پاراگراف یا لیست قابل نمایش در Position Zero
• طول پاراگراف‌ها: ۱۰۰-۱۵۰ کلمه (نه بیشتر)
• جملات کوتاه و خوانا

═══════════════════════════════════════════════════════════════════
                        لینک‌ها
═══════════════════════════════════════════════════════════════════

🔗 لینک‌های اجباری:
1. لینک به صفحه خدمت (در پاراگراف ۲ یا ۳):
   <a href="{$serviceUrl}">[متن طبیعی درباره خدمت]</a>

2. لینک به صفحه تماس (در نتیجه‌گیری):
   <a href="{$contactUrl}">تماس با کارشناسان طراحان باستان</a>

{$relatedServicesText}

═══════════════════════════════════════════════════════════════════
                     فرمت خروجی HTML
═══════════════════════════════════════════════════════════════════

تگ‌های مجاز:
<h1> <h2> <h3> <h4> <p> <ul> <ol> <li> <strong> <em> <a> <table> <thead> <tbody> <tr> <th> <td> <blockquote>

قوانین:
• هر پاراگراف در <p> جداگانه
• Bold با <strong> برای نکات مهم
• لیست‌ها حتماً در <ul> یا <ol>
• لینک‌ها با href کامل
• بدون تگ <div> یا <span>
• بدون class یا style

═══════════════════════════════════════════════════════════════════
                      متا (انتهای مقاله)
═══════════════════════════════════════════════════════════════════

در انتهای مقاله، دقیقاً با این فرمت بنویسید:

---META---
title: [عنوان سئو ۵۰-۶۰ کاراکتر، شامل کلمه کلیدی + همدان]
description: [متا دیسکریپشن ۱۵۰-۱۶۰ کاراکتر، جذاب، شامل CTA]
keywords: [۵-۷ کلمه کلیدی فارسی، جدا شده با کاما]
excerpt: [خلاصه ۸۰-۱۲۰ کلمه‌ای برای نمایش در لیست مقالات]

═══════════════════════════════════════════════════════════════════

🚀 شروع کنید! مقاله‌ای بنویسید که خواننده را مجذوب کند و در گوگل رتبه اول بگیرد.
PROMPT;
    }

    /**
     * Get related services text for prompt
     */
    private function getRelatedServicesText($service)
    {
        $relatedServices = $service['related_services'] ?? [];
        $text = "";

        if (!empty($relatedServices)) {
            $text = "3. لینک به خدمات مرتبط (در بدنه مقاله طبیعی قرار دهید):\n";
            foreach ($relatedServices as $relatedCode) {
                if (isset($this->services[$relatedCode])) {
                    $related = $this->services[$relatedCode];
                    $url = URL . ltrim($related['url'], '/');
                    $text .= "   - <a href=\"{$url}\">{$related['name']}</a>\n";
                }
            }
        }

        return $text;
    }

    /**
     * Parse article response from AI
     */
    private function parseArticleResponse($response, $service, $topic)
    {
        // Split content and meta
        $parts = explode('---META---', $response);

        if (count($parts) < 2) {
            $this->logger->warning('META section not found in response');
            $body = trim($response);
            $meta = [];
        } else {
            $body = trim($parts[0]);
            $metaSection = trim($parts[1]);

            // Extract meta
            $meta = [];
            if (preg_match('/title:\s*(.+)/i', $metaSection, $m)) $meta['title'] = trim($m[1]);
            if (preg_match('/description:\s*(.+)/i', $metaSection, $m)) $meta['description'] = trim($m[1]);
            if (preg_match('/keywords:\s*(.+)/i', $metaSection, $m)) $meta['keywords'] = trim($m[1]);
            if (preg_match('/excerpt:\s*(.+)/is', $metaSection, $m)) $meta['excerpt'] = trim($m[1]);
        }

        // Extract H1 from content
        preg_match('/<h1[^>]*>(.+?)<\/h1>/is', $body, $h1Match);
        $title = strip_tags($h1Match[1] ?? $meta['title'] ?? $topic['title']);

        // Sanitize HTML
        $body = $this->sanitizeHtml($body);

        // Generate unique slug
        $this->enforceApiDelay();
        $slug = $this->generateUniqueSlug($title);

        // Clean meta description and excerpt
        $metaDesc = $meta['description'] ?? mb_substr(strip_tags($body), 0, 160);
        $metaDesc = $this->cleanMetaText($metaDesc);

        $excerpt = $meta['excerpt'] ?? mb_substr(strip_tags($body), 0, 200);
        $excerpt = $this->cleanMetaText($excerpt);

        return [
            'title' => $title,
            'body' => $body,
            'meta_title' => $meta['title'] ?? $title . ' | طراحان باستان همدان',
            'meta_description' => $metaDesc,
            'meta_keywords' => $meta['keywords'] ?? implode('، ', $service['keywords']),
            'excerpt' => $excerpt,
            'slug' => $slug,
            'service_code' => $service['code'],
        ];
    }

    /**
     * Clean text for meta tags (remove markdown, extra whitespace, etc.)
     */
    private function cleanMetaText($text)
    {
        // Remove markdown code blocks
        $text = preg_replace('/```\w*\s*/i', '', $text);
        $text = preg_replace('/```\s*/i', '', $text);

        // Remove HTML tags
        $text = strip_tags($text);

        // Normalize whitespace (convert multiple spaces/newlines to single space)
        $text = preg_replace('/\s+/', ' ', $text);

        // Trim
        $text = trim($text);

        return $text;
    }

    /**
     * Sanitize HTML content
     */
    private function sanitizeHtml($html)
    {
        // Remove markdown code blocks (```html, ```css, etc.)
        $html = preg_replace('/```\w*\s*/i', '', $html);
        $html = preg_replace('/```\s*/i', '', $html);

        // Remove markdown formatting artifacts
        $html = preg_replace('/^\s*---\s*$/m', '', $html);

        $allowedTags = '<h1><h2><h3><h4><p><ul><ol><li><strong><em><a><table><tr><td><th><thead><tbody><br><blockquote>';
        $html = strip_tags($html, $allowedTags);

        // Remove event handlers
        $html = preg_replace('/\s+on\w+="[^"]*"/i', '', $html);
        $html = preg_replace("/\s+on\w+='[^']*'/i", '', $html);

        // Remove javascript: links
        $html = preg_replace('/href\s*=\s*["\']javascript:[^"\']*["\']/i', 'href="#"', $html);

        // Trim whitespace
        $html = trim($html);

        return $html;
    }

    /**
     * Generate unique slug using AI
     */
    private function generateUniqueSlug($title)
    {
        $prompt = "Convert this Persian title to a short English SEO-friendly slug.
Title: {$title}

Rules:
- Lowercase only
- Use hyphens to separate words
- Maximum 50 characters
- No special characters
- Transliterate Persian words to English (e.g., غرفه = booth, تبلیغات = advertising)

Return ONLY the slug, nothing else.";

        $slug = trim($this->callGeminiApi($prompt));

        // Clean slug
        $slug = strtolower($slug);
        $slug = preg_replace('/[^a-z0-9-]/', '', $slug);
        $slug = preg_replace('/-+/', '-', $slug);
        $slug = trim($slug, '-');

        if (strlen($slug) > 50) {
            $slug = substr($slug, 0, 50);
            $slug = rtrim($slug, '-');
        }

        // Ensure uniqueness
        $baseSlug = $slug;
        $counter = 1;
        while ($this->slugExists($slug)) {
            $slug = $baseSlug . '-' . $counter;
            $counter++;
        }

        return $slug;
    }

    /**
     * Check if slug exists
     */
    private function slugExists($slug)
    {
        $sql = "SELECT COUNT(*) as count FROM articles WHERE slug = ?";
        $result = $this->doSelect($sql, [$slug]);
        return ($result[0]['count'] ?? 0) > 0;
    }

    // =========================================================================
    // STEP 3: CONTENT REVIEW (DOUBLE-CHECK)
    // =========================================================================

    private function executeReviewContent($workflowId)
    {
        $this->updateWorkflowState($workflowId, self::STATE_REVIEWING);

        $workflow = $this->getWorkflowState($workflowId);
        $content = json_decode($workflow['content_data'], true);
        $service = array_merge(['code' => $workflow['service_code']], $this->services[$workflow['service_code']]);

        $this->logger->info('Reviewing content with AI');

        // Perform structured review
        $this->enforceApiDelay();
        $reviewResult = $this->performStructuredReview($content, $service);

        if ($reviewResult['needs_improvement']) {
            $this->logger->info('Content needs improvement', ['issues' => $reviewResult['issues']]);

            // Improve content
            $this->enforceApiDelay();
            $content = $this->improveContentFromReview($content, $service, $reviewResult);

            // Re-add intelligent backlinks (lost during AI improvement)
            $content['body'] = $this->addIntelligentBacklinks($content['body'], $service);
            $content['body'] = $this->addRelatedArticlesLinks($content['body'], $service);
            $this->logger->debug('Re-added backlinks after content improvement');
        }

        $this->updateWorkflowState($workflowId, self::STATE_REVIEWED, [
            'content_data' => $content
        ]);

        return $this->executeGenerateImage($workflowId);
    }

    /**
     * Perform structured content review
     */
    private function performStructuredReview($content, $service)
    {
        $wordCount = $this->countPersianWords($content['body']);
        $prompt = <<<PROMPT
شما یک ویراستار ارشد سئو هستید. مقاله زیر را با معیارهای زیر بررسی کنید و نتیجه را به فرمت JSON برگردانید.

## مقاله:
{$content['body']}

## معیارهای بررسی:

1. **word_count_ok**: آیا مقاله حداقل 1500 کلمه دارد؟ (فعلی: {$wordCount} کلمه)
2. **keyword_in_intro**: آیا کلمه کلیدی در 100 کلمه اول آمده؟
3. **h2_structure_ok**: آیا حداقل 4 تیتر H2 با ساختار منطقی دارد؟
4. **h3_present**: آیا زیرتیترهای H3 وجود دارد؟
5. **internal_links_ok**: آیا حداقل 2 لینک داخلی دارد؟
6. **hamadan_mention**: آیا کلمه "همدان" حداقل 2 بار آمده؟
7. **cta_present**: آیا دعوت به اقدام (CTA) در انتها هست؟
8. **faq_present**: آیا بخش سوالات متداول وجود دارد؟
9. **lists_present**: آیا لیست‌های شماره‌دار یا بولت وجود دارد؟
10. **readability_ok**: آیا متن روان و خوانا است؟

## فرمت پاسخ (فقط JSON، بدون توضیح):
{
    "word_count_ok": true/false,
    "keyword_in_intro": true/false,
    "h2_structure_ok": true/false,
    "h3_present": true/false,
    "internal_links_ok": true/false,
    "hamadan_mention": true/false,
    "cta_present": true/false,
    "faq_present": true/false,
    "lists_present": true/false,
    "readability_ok": true/false,
    "overall_score": 0-100,
    "issues": ["مشکل 1", "مشکل 2"],
    "suggestions": ["پیشنهاد 1", "پیشنهاد 2"]
}
PROMPT;

        try {
            $response = trim($this->callGeminiApi($prompt));

            // Extract JSON from response
            if (preg_match('/\{[\s\S]*\}/m', $response, $matches)) {
                $review = json_decode($matches[0], true);

                if ($review) {
                    $issues = $review['issues'] ?? [];
                    $score = $review['overall_score'] ?? 50;

                    return [
                        'needs_improvement' => $score < 70 || !empty($issues),
                        'score' => $score,
                        'issues' => $issues,
                        'suggestions' => $review['suggestions'] ?? [],
                        'details' => $review
                    ];
                }
            }
        } catch (Exception $e) {
            $this->logger->warning('Review parsing failed', ['error' => $e->getMessage()]);
        }

        // Fallback to basic validation
        return [
            'needs_improvement' => $wordCount < 1500,
            'score' => min(100, ($wordCount / 2000) * 100),
            'issues' => $wordCount < 1500 ? ['تعداد کلمات کافی نیست'] : [],
            'suggestions' => [],
            'details' => []
        ];
    }

    /**
     * Improve content based on review
     */
    private function improveContentFromReview($content, $service, $reviewResult)
    {
        $issuesText = implode("\n- ", $reviewResult['issues']);
        $suggestionsText = implode("\n- ", $reviewResult['suggestions']);

        $prompt = <<<PROMPT
مقاله زیر مشکلاتی دارد که باید اصلاح شوند.

## مشکلات شناسایی شده:
- {$issuesText}

## پیشنهادات بهبود:
- {$suggestionsText}

## مقاله فعلی:
{$content['body']}

## دستورالعمل:
لطفاً مقاله را اصلاح و بهبود دهید:
1. تمام مشکلات ذکر شده را رفع کنید
2. حداقل 1800 کلمه باشد
3. ساختار H2/H3 مناسب داشته باشد
4. لینک‌های داخلی حفظ شوند
5. بخش FAQ اضافه کنید (اگر ندارد)
6. کلمه "همدان" حداقل 3 بار ذکر شود
7. CTA واضح در انتها داشته باشد

فقط مقاله اصلاح‌شده را به فرمت HTML برگردانید.
PROMPT;

        try {
            $improved = $this->callGeminiApi($prompt);
            $content['body'] = $this->sanitizeHtml($improved);
            $this->logger->info('Content improved after review');
        } catch (Exception $e) {
            $this->logger->warning('Content improvement failed', ['error' => $e->getMessage()]);
        }

        return $content;
    }

    // =========================================================================
    // STEP 4: IMAGE GENERATION
    // =========================================================================

    private function executeGenerateImage($workflowId)
    {
        $this->updateWorkflowState($workflowId, self::STATE_IMAGE_GENERATING);

        $workflow = $this->getWorkflowState($workflowId);
        $service = array_merge(['code' => $workflow['service_code']], $this->services[$workflow['service_code']]);

        // Use default service image (AI image generation disabled)
        // Images can be updated manually via admin panel
        $imagePath = $this->getDefaultImage($service);

        $this->logger->info('Using default image', ['path' => $imagePath]);

        $this->updateWorkflowState($workflowId, self::STATE_IMAGE_GENERATED, [
            'image_path' => $imagePath
        ]);

        return $this->executeValidate($workflowId);
    }

    /**
     * Generate featured image with fallback strategies
     */
    private function generateFeaturedImageWithFallbacks($topicTitle, $service)
    {
        $strategies = [
            'gemini_image' => function() use ($topicTitle, $service) {
                return $this->generateImageWithGemini($topicTitle, $service);
            },
            'gemini_alternative_prompt' => function() use ($topicTitle, $service) {
                return $this->generateImageWithAlternativePrompt($topicTitle, $service);
            },
            'default_image' => function() use ($service) {
                return $this->getDefaultImage($service);
            }
        ];

        foreach ($strategies as $name => $strategy) {
            try {
                $this->logger->debug("Trying image strategy: {$name}");
                $result = $strategy();

                if ($result && file_exists($result)) {
                    $this->logger->info("Image generated with strategy: {$name}");
                    return $result;
                }
            } catch (Exception $e) {
                $this->logger->warning("Image strategy {$name} failed", ['error' => $e->getMessage()]);
                if ($name !== 'default_image') {
                    $this->enforceApiDelay();
                }
            }
        }

        return null;
    }

    /**
     * Generate image with Gemini
     */
    private function generateImageWithGemini($topicTitle, $service)
    {
        $prompt = "Create a professional, modern, clean illustration for a blog article about: {$topicTitle}

Style requirements:
- Corporate and professional design
- Minimalist and clean aesthetic
- Color palette: dark brown (#2D1810), cream (#F5E6D3), gold (#C9A066)
- NO text, words, letters, or numbers on the image
- Suitable for an advertising agency in Iran
- Clean gradient or solid background
- Related to {$service['name_en']}
- Abstract or symbolic representation
- High quality, suitable for web use";

        $imageData = $this->callGeminiImageApi($prompt);

        if ($imageData) {
            $filename = 'ai_' . date('Ymd_His') . '_' . uniqid() . '.png';
            $directory = dirname(__DIR__) . '/public/uploads/ai_articles/';

            if (!is_dir($directory)) {
                mkdir($directory, 0755, true);
            }

            $fullPath = $directory . $filename;
            file_put_contents($fullPath, base64_decode($imageData));

            // Verify image was created
            if (file_exists($fullPath) && filesize($fullPath) > 1000) {
                return 'public/uploads/ai_articles/' . $filename;
            }
        }

        return null;
    }

    /**
     * Generate image with alternative prompt
     */
    private function generateImageWithAlternativePrompt($topicTitle, $service)
    {
        $prompt = "Simple professional icon illustration for {$service['name_en']}.
Flat design, brown and gold colors, white background, no text, minimalist.";

        $imageData = $this->callGeminiImageApi($prompt);

        if ($imageData) {
            $filename = 'ai_' . date('Ymd_His') . '_' . uniqid() . '.png';
            $directory = dirname(__DIR__) . '/public/uploads/ai_articles/';

            if (!is_dir($directory)) {
                mkdir($directory, 0755, true);
            }

            $fullPath = $directory . $filename;
            file_put_contents($fullPath, base64_decode($imageData));

            if (file_exists($fullPath) && filesize($fullPath) > 1000) {
                return 'public/uploads/ai_articles/' . $filename;
            }
        }

        return null;
    }

    /**
     * Get default image for service
     */
    private function getDefaultImage($service)
    {
        $extensions = ['jpg', 'jpeg', 'png', 'svg', 'webp'];
        $baseDir = dirname(__DIR__) . '/public/uploads/defaults/';

        // Try service-specific image
        foreach ($extensions as $ext) {
            $path = 'public/uploads/defaults/' . $service['code'] . '.' . $ext;
            if (file_exists($baseDir . $service['code'] . '.' . $ext)) {
                return $path;
            }
        }

        // Try generic default
        foreach ($extensions as $ext) {
            $path = 'public/uploads/defaults/default.' . $ext;
            if (file_exists($baseDir . 'default.' . $ext)) {
                return $path;
            }
        }

        return null;
    }

    // =========================================================================
    // STEP 5: COMPREHENSIVE VALIDATION
    // =========================================================================

    private function executeValidate($workflowId)
    {
        $this->updateWorkflowState($workflowId, self::STATE_VALIDATING);

        $workflow = $this->getWorkflowState($workflowId);
        $content = json_decode($workflow['content_data'], true);

        $this->logger->info('Validating article');

        // Perform comprehensive validation
        $validation = $this->performComprehensiveValidation($content, $workflow['image_path']);

        // Check content uniqueness
        $uniquenessScore = $this->checkContentUniqueness($content['body']);
        $validation['uniqueness_score'] = $uniquenessScore;

        if ($uniquenessScore < (100 - $this->config['max_similarity_percent'])) {
            $validation['warnings'][] = 'Content similarity too high with existing articles';
        }

        // Calculate overall quality score
        $qualityScore = $this->calculateQualityScore($content, $workflow['image_path'], $validation);

        $this->logger->info('Validation complete', [
            'status' => $validation['status'],
            'score' => $qualityScore,
            'uniqueness' => $uniquenessScore
        ]);

        $this->updateWorkflowState($workflowId, self::STATE_VALIDATED, [
            'validation_result' => json_encode($validation),
            'quality_score' => $qualityScore
        ]);

        return $this->executePublish($workflowId);
    }

    /**
     * Perform comprehensive content validation
     */
    private function performComprehensiveValidation($content, $imagePath)
    {
        $validation = [
            'status' => 'PASS',
            'checks' => [],
            'warnings' => [],
            'errors' => []
        ];

        $body = $content['body'];
        $wordCount = $this->countPersianWords($body);

        // 1. Word count check
        $validation['checks']['word_count'] = $wordCount >= $this->config['min_word_count'];
        if (!$validation['checks']['word_count']) {
            $validation['errors'][] = "Word count too low: {$wordCount} (min: {$this->config['min_word_count']})";
        }

        // 2. H2 structure check
        preg_match_all('/<h2/i', $body, $h2Matches);
        $h2Count = count($h2Matches[0]);
        $validation['checks']['h2_structure'] = $h2Count >= 3;
        if (!$validation['checks']['h2_structure']) {
            $validation['warnings'][] = "Only {$h2Count} H2 headings found (recommended: 3+)";
        }

        // 3. H3 presence check
        preg_match_all('/<h3/i', $body, $h3Matches);
        $validation['checks']['h3_present'] = count($h3Matches[0]) >= 1;

        // 4. Internal links check
        preg_match_all('/<a[^>]*href\s*=\s*["\'][^"\']*["\'][^>]*>/i', $body, $linkMatches);
        $validation['checks']['internal_links'] = count($linkMatches[0]) >= 2;
        if (!$validation['checks']['internal_links']) {
            $validation['warnings'][] = 'Insufficient internal links';
        }

        // 5. Meta description check
        $metaLength = mb_strlen($content['meta_description'] ?? '');
        $validation['checks']['meta_description'] = $metaLength >= 100 && $metaLength <= 160;
        if (!$validation['checks']['meta_description']) {
            $validation['warnings'][] = "Meta description length: {$metaLength} (ideal: 100-160)";
        }

        // 6. Hamadan mention check
        preg_match_all('/همدان/u', $body, $hamadanMatches);
        $validation['checks']['hamadan_mention'] = count($hamadanMatches[0]) >= 2;
        if (!$validation['checks']['hamadan_mention']) {
            $validation['warnings'][] = 'Hamadan not mentioned enough times';
        }

        // 7. Image check
        $validation['checks']['has_image'] = !empty($imagePath);

        // 8. CTA check
        $validation['checks']['has_cta'] = preg_match('/تماس|مشاوره|سفارش|ارتباط/u', $body) > 0;
        if (!$validation['checks']['has_cta']) {
            $validation['warnings'][] = 'No clear CTA found';
        }

        // 9. List check
        $validation['checks']['has_lists'] = preg_match('/<[uo]l/i', $body) > 0;

        // 10. FAQ check
        $validation['checks']['has_faq'] = preg_match('/سوالات?\s*(متداول|رایج)|FAQ/ui', $body) > 0;

        // Determine overall status
        if (!empty($validation['errors'])) {
            $validation['status'] = 'FAIL';
        } elseif (count($validation['warnings']) > 3) {
            $validation['status'] = 'REVIEW';
        }

        $validation['word_count'] = $wordCount;

        return $validation;
    }

    /**
     * Check content uniqueness against existing articles
     */
    private function checkContentUniqueness($newContent)
    {
        // Get recent articles
        $sql = "SELECT id, content FROM articles
                WHERE status = 'published'
                ORDER BY published_at DESC
                LIMIT 20";

        $existingArticles = $this->doSelect($sql);

        if (empty($existingArticles)) {
            return 100; // No articles to compare, 100% unique
        }

        // Extract text content
        $newText = strip_tags($newContent);
        $newWords = preg_split('/\s+/u', mb_strtolower($newText));
        $newWordSet = array_flip(array_filter($newWords));

        $maxSimilarity = 0;

        foreach ($existingArticles as $article) {
            $existingText = strip_tags($article['content']);
            $existingWords = preg_split('/\s+/u', mb_strtolower($existingText));
            $existingWordSet = array_flip(array_filter($existingWords));

            // Calculate Jaccard similarity
            $intersection = count(array_intersect_key($newWordSet, $existingWordSet));
            $union = count($newWordSet) + count($existingWordSet) - $intersection;

            $similarity = $union > 0 ? ($intersection / $union) * 100 : 0;
            $maxSimilarity = max($maxSimilarity, $similarity);
        }

        // Return uniqueness (inverse of similarity)
        return round(100 - $maxSimilarity);
    }

    /**
     * Calculate overall quality score
     */
    private function calculateQualityScore($content, $imagePath, $validation)
    {
        $score = 0;

        // Word count (30 points)
        $wordCount = $validation['word_count'] ?? $this->countPersianWords($content['body']);
        $score += min(30, ($wordCount / 2000) * 30);

        // Structure (25 points)
        $checksPass = array_filter($validation['checks'] ?? [], function($v) { return $v === true; });
        $score += (count($checksPass) / 10) * 25;

        // Image (10 points)
        $score += $imagePath ? 10 : 0;

        // Meta data (15 points)
        $score += (mb_strlen($content['meta_description'] ?? '') >= 100) ? 8 : 3;
        $score += !empty($content['meta_keywords']) ? 7 : 0;

        // Uniqueness (20 points)
        $uniqueness = $validation['uniqueness_score'] ?? 100;
        $score += ($uniqueness / 100) * 20;

        return min(100, round($score));
    }

    // =========================================================================
    // STEP 6: PUBLISH ARTICLE
    // =========================================================================

    private function executePublish($workflowId)
    {
        $this->updateWorkflowState($workflowId, self::STATE_PUBLISHING);

        $workflow = $this->getWorkflowState($workflowId);
        $content = json_decode($workflow['content_data'], true);
        $validation = json_decode($workflow['validation_result'] ?? '{}', true);
        $service = array_merge(['code' => $workflow['service_code']], $this->services[$workflow['service_code']]);

        $this->logger->info('Publishing article');

        // Create comprehensive schema markup
        $schemaMarkup = $this->createComprehensiveSchemaMarkup($content, $workflow['image_path'], $service);

        // Determine status based on validation
        $status = ($validation['status'] ?? 'PASS') === 'PASS' ? 'published' : 'draft';
        $publishedAt = $status === 'published' ? date('Y-m-d H:i:s') : null;

        // Generate random views between 2000-5000 for better social proof
        $initialViews = rand(2000, 5000);

        // Insert article
        $sql = "INSERT INTO articles
                (title, slug, excerpt, content, featured_image, meta_title, meta_description,
                 meta_keywords, schema_markup, service_code, is_ai_generated, quality_score,
                 status, reading_time, views, published_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?, ?, ?)";

        $readingTime = ceil($this->countPersianWords($content['body']) / 200);

        $this->doQuery($sql, [
            $content['title'],
            $content['slug'],
            $content['excerpt'],
            $content['body'],
            $workflow['image_path'],
            $content['meta_title'],
            $content['meta_description'],
            $content['meta_keywords'],
            $schemaMarkup,
            $service['code'],
            $workflow['quality_score'],
            $status,
            $readingTime,
            $initialViews,
            $publishedAt
        ]);

        $articleId = self::$conn->lastInsertId();

        // Extract and save tags
        $tags = $this->extractAndSaveTags($articleId, $content, $service);

        // Mark topic as used
        $this->markTopicAsUsed($workflow['topic_id'], $articleId);

        // Update SEO notes
        $this->updateSeoNotes($service, ['title' => $workflow['topic_title']], $validation);

        // Update sitemap with new article (only if published)
        if ($status === 'published') {
            $this->updateSitemap($articleId, $content, $workflow['image_path']);
        }

        $this->logger->info('Article published', ['article_id' => $articleId, 'status' => $status]);

        $this->updateWorkflowState($workflowId, self::STATE_PUBLISHED, [
            'article_id' => $articleId
        ]);

        return $this->getWorkflowResult($workflowId);
    }

    /**
     * Get final workflow result
     */
    private function getWorkflowResult($workflowId)
    {
        $workflow = $this->getWorkflowState($workflowId);
        $content = json_decode($workflow['content_data'], true);

        return [
            'article_id' => $workflow['article_id'],
            'title' => $content['title'] ?? '',
            'slug' => $content['slug'] ?? '',
            'service' => $this->services[$workflow['service_code']]['name'] ?? '',
            'service_code' => $workflow['service_code'],
            'validation' => $workflow['validation_result'],
            'quality_score' => $workflow['quality_score'],
            'word_count' => $this->countPersianWords($content['body'] ?? ''),
            'workflow_id' => $workflowId
        ];
    }

    // =========================================================================
    // COMPREHENSIVE SCHEMA MARKUP
    // =========================================================================

    /**
     * Create comprehensive schema markup
     */
    private function createComprehensiveSchemaMarkup($content, $imagePath, $service)
    {
        $articleUrl = URL . 'article/show/' . $content['slug'];
        $imageUrl = $imagePath ? URL . $imagePath : URL . 'public/images/default-article.jpg';
        $serviceUrl = URL . ltrim($service['url'], '/');

        $schemas = [];

        // 1. Article Schema (enhanced)
        $schemas[] = [
            '@context' => 'https://schema.org',
            '@type' => 'Article',
            '@id' => $articleUrl . '#article',
            'mainEntityOfPage' => [
                '@type' => 'WebPage',
                '@id' => $articleUrl
            ],
            'headline' => $content['title'],
            'description' => $content['meta_description'],
            'image' => [
                '@type' => 'ImageObject',
                'url' => $imageUrl,
                'width' => 1200,
                'height' => 630
            ],
            'author' => [
                '@type' => 'Organization',
                '@id' => URL . '#organization',
                'name' => 'طراحان باستان',
                'url' => URL
            ],
            'publisher' => [
                '@type' => 'Organization',
                '@id' => URL . '#organization',
                'name' => 'شرکت آرین طراحان باستان',
                'logo' => [
                    '@type' => 'ImageObject',
                    'url' => URL . 'public/images/logo.png',
                    'width' => 200,
                    'height' => 60
                ]
            ],
            'datePublished' => date('c'),
            'dateModified' => date('c'),
            'articleSection' => $service['name'],
            'keywords' => $content['meta_keywords'],
            'inLanguage' => 'fa-IR',
            'isPartOf' => [
                '@type' => 'Blog',
                '@id' => URL . 'article#blog',
                'name' => 'وبلاگ طراحان باستان'
            ]
        ];

        // 2. Breadcrumb Schema
        $schemas[] = [
            '@context' => 'https://schema.org',
            '@type' => 'BreadcrumbList',
            '@id' => $articleUrl . '#breadcrumb',
            'itemListElement' => [
                [
                    '@type' => 'ListItem',
                    'position' => 1,
                    'name' => 'صفحه اصلی',
                    'item' => URL
                ],
                [
                    '@type' => 'ListItem',
                    'position' => 2,
                    'name' => 'وبلاگ',
                    'item' => URL . 'article'
                ],
                [
                    '@type' => 'ListItem',
                    'position' => 3,
                    'name' => $service['name'],
                    'item' => $serviceUrl
                ],
                [
                    '@type' => 'ListItem',
                    'position' => 4,
                    'name' => $content['title'],
                    'item' => $articleUrl
                ]
            ]
        ];

        // 3. Organization Schema
        $schemas[] = [
            '@context' => 'https://schema.org',
            '@type' => 'LocalBusiness',
            '@id' => URL . '#organization',
            'name' => 'شرکت آرین طراحان باستان',
            'alternateName' => 'Tarahan Bastan',
            'description' => 'شرکت تبلیغاتی طراحان باستان - ارائه دهنده خدمات غرفه سازی، تبلیغات محیطی و برگزاری رویداد در همدان',
            'image' => URL . 'public/images/logo.png',
            'telephone' => '+989183333368',
            'email' => 'info@tarahanbastan.ir',
            'address' => [
                '@type' => 'PostalAddress',
                'streetAddress' => 'بلوار شهید مدنی، ساختمان پارسیان، طبقه ۳',
                'addressLocality' => 'همدان',
                'addressRegion' => 'همدان',
                'addressCountry' => 'IR'
            ],
            'geo' => [
                '@type' => 'GeoCoordinates',
                'latitude' => '34.7988',
                'longitude' => '48.5146'
            ],
            'url' => URL,
            'sameAs' => [
                'https://instagram.com/tarahanbastan',
                'https://t.me/tarahanbastan'
            ],
            'priceRange' => '$$',
            'openingHoursSpecification' => [
                '@type' => 'OpeningHoursSpecification',
                'dayOfWeek' => ['Saturday', 'Sunday', 'Monday', 'Tuesday', 'Wednesday'],
                'opens' => '08:00',
                'closes' => '17:00'
            ]
        ];

        // 4. FAQ Schema (if FAQ exists)
        $faqSchema = $this->extractFaqSchema($content['body']);
        if ($faqSchema) {
            $schemas[] = $faqSchema;
        }

        // 5. HowTo Schema (if applicable)
        $howToSchema = $this->extractHowToSchema($content['body']);
        if ($howToSchema) {
            $schemas[] = $howToSchema;
        }

        // 6. WebPage Schema with Speakable
        $schemas[] = [
            '@context' => 'https://schema.org',
            '@type' => 'WebPage',
            '@id' => $articleUrl,
            'url' => $articleUrl,
            'name' => $content['title'],
            'description' => $content['meta_description'],
            'inLanguage' => 'fa-IR',
            'isPartOf' => [
                '@type' => 'WebSite',
                '@id' => URL . '#website',
                'url' => URL,
                'name' => 'طراحان باستان',
                'publisher' => ['@id' => URL . '#organization']
            ],
            'breadcrumb' => ['@id' => $articleUrl . '#breadcrumb'],
            'mainEntity' => ['@id' => $articleUrl . '#article'],
            'speakable' => [
                '@type' => 'SpeakableSpecification',
                'cssSelector' => ['.article-content h1', '.article-content h2', '.article-content p:first-of-type']
            ]
        ];

        return json_encode($schemas, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }

    /**
     * Extract FAQ schema from content
     */
    private function extractFaqSchema($body)
    {
        $faqs = [];

        // Pattern: H3 question followed by P answer
        if (preg_match_all('/<h3[^>]*>([^<]*\?)<\/h3>\s*<p>([^<]+)<\/p>/iu', $body, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $match) {
                $faqs[] = [
                    '@type' => 'Question',
                    'name' => trim(strip_tags($match[1])),
                    'acceptedAnswer' => [
                        '@type' => 'Answer',
                        'text' => trim(strip_tags($match[2]))
                    ]
                ];
            }
        }

        if (empty($faqs)) {
            return null;
        }

        return [
            '@context' => 'https://schema.org',
            '@type' => 'FAQPage',
            'mainEntity' => $faqs
        ];
    }

    /**
     * Extract HowTo schema from content
     */
    private function extractHowToSchema($body)
    {
        // Check if content has numbered steps
        if (!preg_match('/مراحل|گام|قدم|step/ui', $body)) {
            return null;
        }

        // Extract ordered list items
        if (preg_match('/<ol[^>]*>(.*?)<\/ol>/is', $body, $olMatch)) {
            if (preg_match_all('/<li[^>]*>(.*?)<\/li>/is', $olMatch[1], $liMatches)) {
                $steps = [];
                foreach ($liMatches[1] as $index => $stepText) {
                    $steps[] = [
                        '@type' => 'HowToStep',
                        'position' => $index + 1,
                        'text' => trim(strip_tags($stepText))
                    ];
                }

                if (count($steps) >= 3) {
                    return [
                        '@context' => 'https://schema.org',
                        '@type' => 'HowTo',
                        'step' => $steps
                    ];
                }
            }
        }

        return null;
    }

    // =========================================================================
    // INTELLIGENT BACKLINKS
    // =========================================================================

    /**
     * Add intelligent backlinks with styled CTA boxes
     */
    private function addIntelligentBacklinks($content, $service)
    {
        $serviceUrl = URL . ltrim($service['url'], '/');
        $contactUrl = URL . 'contact';
        $serviceName = $service['name'];

        // Styled CTA box variations
        $ctaBoxes = [
            [
                'title' => "آیا می‌دانستید؟",
                'text' => "طراحان باستان با بیش از ۱۰ سال تجربه، خدمات {$serviceName} را به صورت حرفه‌ای ارائه می‌دهد.",
                'cta' => "مشاهده خدمات {$serviceName}"
            ],
            [
                'title' => "نیاز به مشاوره دارید؟",
                'text' => "تیم متخصص ما در همدان آماده ارائه خدمات {$serviceName} با کیفیت برتر است.",
                'cta' => "درخواست مشاوره رایگان"
            ],
            [
                'title' => "خدمات حرفه‌ای {$serviceName}",
                'text' => "با تجربه همایش بین‌المللی همدان ۲۰۱۸، طراحان باستان بهترین خدمات {$serviceName} را ارائه می‌دهد.",
                'cta' => "کلیک کنید و ببینید"
            ],
        ];

        // Select two different CTA boxes
        $selectedBoxes = array_rand($ctaBoxes, 2);

        // First styled CTA box - after paragraph 3
        $box1 = $ctaBoxes[$selectedBoxes[0]];
        $ctaBox1 = <<<HTML

<div class="service-cta-box">
    <div class="cta-box-icon">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path stroke-linecap="round" stroke-linejoin="round" d="M13 10V3L4 14h7v7l9-11h-7z"/>
        </svg>
    </div>
    <div class="cta-box-content">
        <h4>{$box1['title']}</h4>
        <p>{$box1['text']}</p>
        <a href="{$serviceUrl}" class="cta-box-link">{$box1['cta']} ←</a>
    </div>
</div>

HTML;

        // Second styled CTA box - after paragraph 6
        $box2 = $ctaBoxes[$selectedBoxes[1]];
        $ctaBox2 = <<<HTML

<div class="service-cta-box cta-box-alt">
    <div class="cta-box-icon">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path stroke-linecap="round" stroke-linejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
        </svg>
    </div>
    <div class="cta-box-content">
        <h4>{$box2['title']}</h4>
        <p>{$box2['text']}</p>
        <a href="{$serviceUrl}" class="cta-box-link">اطلاعات بیشتر ←</a>
    </div>
</div>

HTML;

        // Insert CTA boxes at strategic positions
        $paragraphCount = 0;
        $box1Inserted = false;
        $box2Inserted = false;

        $content = preg_replace_callback(
            '/<\/p>/i',
            function($match) use (&$paragraphCount, $ctaBox1, $ctaBox2, &$box1Inserted, &$box2Inserted) {
                $paragraphCount++;
                $result = $match[0];

                // Insert first box after paragraph 3
                if ($paragraphCount === 3 && !$box1Inserted) {
                    $result .= $ctaBox1;
                    $box1Inserted = true;
                }

                // Insert second box after paragraph 7
                if ($paragraphCount === 7 && !$box2Inserted) {
                    $result .= $ctaBox2;
                    $box2Inserted = true;
                }

                return $result;
            },
            $content
        );

        // Final CTA at the end with contact link
        $finalCta = <<<HTML

<div class="article-final-cta">
    <div class="final-cta-content">
        <h3>آماده شروع پروژه خود هستید؟</h3>
        <p>تیم طراحان باستان در همدان آماده همکاری با شماست. <strong>با ما غیرممکن وجود نداره!</strong></p>
        <div class="final-cta-buttons">
            <a href="{$serviceUrl}" class="btn-primary">مشاهده خدمات {$serviceName}</a>
            <a href="{$contactUrl}" class="btn-secondary">تماس با ما</a>
        </div>
    </div>
</div>

HTML;

        $content .= $finalCta;

        // Add related services links in body (contextually)
        $relatedServices = $service['related_services'] ?? [];
        foreach ($relatedServices as $relatedCode) {
            if (isset($this->services[$relatedCode]) && strpos($content, $this->services[$relatedCode]['url']) === false) {
                $related = $this->services[$relatedCode];
                $relatedUrl = URL . ltrim($related['url'], '/');

                // Find mentions of related service name and link them
                $pattern = '/(' . preg_quote($related['name'], '/') . ')(?![^<]*>)/u';
                $replacement = '<a href="' . $relatedUrl . '" class="inline-service-link">$1</a>';
                $content = preg_replace($pattern, $replacement, $content, 1);
            }
        }

        return $content;
    }

    /**
     * Add related articles links
     */
    private function addRelatedArticlesLinks($content, $service)
    {
        // Get published articles from same service
        $sql = "SELECT title, slug FROM articles
                WHERE service_code = ? AND status = 'published'
                ORDER BY published_at DESC LIMIT 3";

        $relatedArticles = $this->doSelect($sql, [$service['code']]);

        if (empty($relatedArticles)) {
            return $content;
        }

        // Build related articles section
        $relatedHtml = "\n<div class=\"related-articles\">\n";
        $relatedHtml .= "<h3>مقالات مرتبط در این زمینه</h3>\n<ul>\n";

        foreach ($relatedArticles as $article) {
            $url = URL . 'article/show/' . $article['slug'];
            $relatedHtml .= "<li><a href=\"{$url}\">{$article['title']}</a></li>\n";
        }

        $relatedHtml .= "</ul>\n</div>";

        // Insert before CTA if exists
        if (strpos($content, 'cta-paragraph') !== false) {
            $content = preg_replace(
                '/(<p class="cta-paragraph">)/i',
                $relatedHtml . "\n$1",
                $content,
                1
            );
        } else {
            $content .= $relatedHtml;
        }

        return $content;
    }

    // =========================================================================
    // SMART API KEY ROTATION
    // =========================================================================

    /**
     * Get best available API key
     */
    private function getBestApiKey()
    {
        if (empty($this->apiKeys)) {
            throw new Exception('No API keys configured');
        }

        // Filter valid keys
        $validKeys = [];
        foreach ($this->apiKeys as $index => $key) {
            if (empty($key) || $key === 'YOUR_API_KEY_1' || strlen($key) < 20) {
                continue;
            }

            $status = $this->apiKeyStatus[$index] ?? [];

            // Skip if in cooldown
            if (!empty($status['cooldown_until']) && strtotime($status['cooldown_until']) > time()) {
                continue;
            }

            // Skip if exhausted and not yet reset (daily reset)
            if (!empty($status['is_exhausted'])) {
                $lastRequest = $status['last_request'] ?? null;
                if ($lastRequest && date('Y-m-d', strtotime($lastRequest)) === date('Y-m-d')) {
                    continue;
                }
                // Reset exhausted status for new day
                $this->apiKeyStatus[$index]['is_exhausted'] = false;
            }

            $validKeys[$index] = [
                'key' => $key,
                'requests' => $status['requests_today'] ?? 0,
                'errors' => $status['error_count'] ?? 0
            ];
        }

        if (empty($validKeys)) {
            throw new Exception('All API keys are exhausted or in cooldown. Please try again later.');
        }

        // Sort by least used and least errors
        uasort($validKeys, function($a, $b) {
            $scoreA = $a['requests'] + ($a['errors'] * 10);
            $scoreB = $b['requests'] + ($b['errors'] * 10);
            return $scoreA - $scoreB;
        });

        $selectedIndex = array_key_first($validKeys);
        return ['index' => $selectedIndex, 'key' => $validKeys[$selectedIndex]['key']];
    }

    /**
     * Record API key usage
     */
    private function recordApiKeyUsage($keyIndex, $success = true, $tokensIn = 0, $tokensOut = 0)
    {
        if (!isset($this->apiKeyStatus[$keyIndex])) {
            $this->apiKeyStatus[$keyIndex] = [];
        }

        $this->apiKeyStatus[$keyIndex]['last_request'] = date('Y-m-d H:i:s');
        $this->apiKeyStatus[$keyIndex]['requests_today'] = ($this->apiKeyStatus[$keyIndex]['requests_today'] ?? 0) + 1;

        if (!$success) {
            $this->apiKeyStatus[$keyIndex]['error_count'] = ($this->apiKeyStatus[$keyIndex]['error_count'] ?? 0) + 1;
            $this->apiKeyStatus[$keyIndex]['last_error'] = date('Y-m-d H:i:s');

            // Set cooldown after multiple errors
            if ($this->apiKeyStatus[$keyIndex]['error_count'] >= 3) {
                $this->apiKeyStatus[$keyIndex]['cooldown_until'] = date('Y-m-d H:i:s', time() + 3600); // 1 hour
            }
        } else {
            // Reset error count on success
            $this->apiKeyStatus[$keyIndex]['error_count'] = 0;
        }

        $this->saveApiKeyStatus();
        $this->trackApiUsage($keyIndex, $tokensIn, $tokensOut);
    }

    /**
     * Mark API key as exhausted
     */
    private function markKeyExhausted($keyIndex)
    {
        $this->apiKeyStatus[$keyIndex]['is_exhausted'] = true;
        $this->apiKeyStatus[$keyIndex]['cooldown_until'] = date('Y-m-d H:i:s', time() + 3600);
        $this->saveApiKeyStatus();
        $this->logger->warning('API key marked as exhausted', ['key_index' => $keyIndex]);
    }

    /**
     * Enforce delay between API calls
     */
    private function enforceApiDelay()
    {
        $now = microtime(true) * 1000;
        $elapsed = $now - $this->lastApiCallTime;

        if ($elapsed < $this->apiRequestDelay && $this->lastApiCallTime > 0) {
            $sleepMs = (int)($this->apiRequestDelay - $elapsed);
            $this->logger->debug("Enforcing API delay: {$sleepMs}ms");
            usleep($sleepMs * 1000);
        }

        $this->lastApiCallTime = microtime(true) * 1000;
    }

    // =========================================================================
    // API CALLS
    // =========================================================================

    /**
     * Call Gemini API with retry and rate limiting
     */
    private function callGeminiApiWithRetry($prompt, $maxRetries = null)
    {
        $maxRetries = $maxRetries ?? $this->config['max_retries'];
        $attempt = 0;
        $lastError = null;

        while ($attempt < $maxRetries) {
            try {
                $this->enforceApiDelay();
                return $this->callGeminiApi($prompt);
            } catch (Exception $e) {
                $lastError = $e;
                $attempt++;
                $this->logger->warning("API attempt {$attempt} failed", ['error' => $e->getMessage()]);

                // Check for rate limit error
                if (strpos($e->getMessage(), 'RATE_LIMIT') !== false || strpos($e->getMessage(), '429') !== false) {
                    // Longer delay for rate limit
                    sleep(10);
                } else if ($attempt < $maxRetries) {
                    sleep(pow(2, $attempt)); // Exponential backoff
                }
            }
        }

        throw new Exception("API failed after {$maxRetries} attempts: " . $lastError->getMessage());
    }

    /**
     * Call Gemini API for text generation
     */
    private function callGeminiApi($prompt)
    {
        $keyData = $this->getBestApiKey();
        $apiKey = $keyData['key'];
        $keyIndex = $keyData['index'];

        $url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=" . $apiKey;

        $data = [
            'contents' => [
                ['parts' => [['text' => $prompt]]]
            ],
            'generationConfig' => [
                'temperature' => 0.7,
                'topK' => 40,
                'topP' => 0.95,
                'maxOutputTokens' => 8192,
            ],
        ];

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, $this->config['timeout']);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError = curl_error($ch);
        curl_close($ch);

        if ($curlError) {
            $this->recordApiKeyUsage($keyIndex, false);
            throw new Exception("cURL Error: " . $curlError);
        }

        if ($httpCode === 429) {
            $this->markKeyExhausted($keyIndex);
            throw new Exception("Rate limit exceeded for API key");
        }

        if ($httpCode !== 200) {
            $this->recordApiKeyUsage($keyIndex, false);
            $errorData = json_decode($response, true);
            $errorMessage = $errorData['error']['message'] ?? "HTTP Error: {$httpCode}";
            throw new Exception($errorMessage);
        }

        $result = json_decode($response, true);

        // Track usage
        $tokensIn = $result['usageMetadata']['promptTokenCount'] ?? 0;
        $tokensOut = $result['usageMetadata']['candidatesTokenCount'] ?? 0;
        $this->recordApiKeyUsage($keyIndex, true, $tokensIn, $tokensOut);

        if (isset($result['candidates'][0]['content']['parts'][0]['text'])) {
            return $result['candidates'][0]['content']['parts'][0]['text'];
        }

        throw new Exception('Invalid response from API');
    }

    /**
     * Call image generation API with multi-provider fallback
     * Order: 1. Gemini Flash Image, 2. Pollinations.ai
     */
    private function callGeminiImageApi($prompt)
    {
        // Try Gemini first
        $result = $this->callGeminiFlashImageApi($prompt);
        if ($result) {
            return $result;
        }

        // Fallback to Pollinations.ai
        $this->logger->info("Trying Pollinations.ai as fallback...");
        $result = $this->callPollinationsApi($prompt);
        if ($result) {
            return $result;
        }

        return null;
    }

    /**
     * Call Pollinations.ai free image generation API
     * No API key required - completely free and unlimited
     */
    private function callPollinationsApi($prompt)
    {
        $encodedPrompt = urlencode($prompt);
        $url = "https://image.pollinations.ai/prompt/{$encodedPrompt}?width=1200&height=630&nologo=true&model=flux";

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, $this->config['image_timeout']);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_MAXREDIRS, 5);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $contentType = curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
        curl_close($ch);

        // Check if we got an image (not JSON error)
        if ($httpCode === 200 && strpos($contentType, 'image/') !== false) {
            $this->logger->info("Pollinations.ai success - image generated");
            return base64_encode($response);
        }

        // Try alternative Pollinations endpoint
        $url2 = "https://pollinations.ai/p/{$encodedPrompt}";
        $ch = curl_init($url2);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, $this->config['image_timeout']);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $contentType = curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
        curl_close($ch);

        if ($httpCode === 200 && strpos($contentType, 'image/') !== false) {
            $this->logger->info("Pollinations.ai (alt) success - image generated");
            return base64_encode($response);
        }

        $this->logger->warning("Pollinations.ai failed", ['http_code' => $httpCode]);
        return null;
    }

    /**
     * Call Gemini Flash API with image generation
     * Uses gemini-2.5-flash-image (Nano Banana) - Free tier available
     * Rate limit resets at midnight UTC
     */
    private function callGeminiFlashImageApi($prompt)
    {
        // Try all API keys
        for ($keyTry = 0; $keyTry < count($this->apiKeys); $keyTry++) {
            $keyData = $this->getBestApiKey();
            $apiKey = $keyData['key'];
            $keyIndex = $keyData['index'];

            // Free tier models (Imagen requires billing)
            $models = [
                'gemini-2.5-flash-image-preview',
                'gemini-2.5-flash-image',
                'gemini-3-pro-image-preview'
            ];

            foreach ($models as $model) {
                $url = "https://generativelanguage.googleapis.com/v1beta/models/{$model}:generateContent?key=" . $apiKey;

                $data = [
                    'contents' => [
                        ['parts' => [['text' => $prompt]]]
                    ],
                    'generationConfig' => [
                        'responseModalities' => ['IMAGE', 'TEXT']
                    ]
                ];

                $this->logger->debug("Trying {$model} with key {$keyIndex}");

                $ch = curl_init($url);
                curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($ch, CURLOPT_TIMEOUT, $this->config['image_timeout']);

                $response = curl_exec($ch);
                $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                curl_close($ch);

                if ($httpCode === 200) {
                    $result = json_decode($response, true);

                    if (isset($result['candidates'][0]['content']['parts'])) {
                        foreach ($result['candidates'][0]['content']['parts'] as $part) {
                            if (isset($part['inlineData']['data'])) {
                                $this->recordApiKeyUsage($keyIndex, true);
                                $this->logger->info("{$model} success - image generated");
                                return $part['inlineData']['data'];
                            }
                        }
                    }
                } elseif ($httpCode === 429) {
                    $this->logger->warning("{$model} rate limited (key {$keyIndex})", ['http_code' => $httpCode]);
                    $this->recordApiKeyUsage($keyIndex, false);
                    // Try next key
                    break;
                } else {
                    $this->logger->warning("{$model} failed", ['http_code' => $httpCode]);
                }
            }
        }

        $this->logger->warning('All image generation attempts failed');
        return null;
    }

    // =========================================================================
    // LOGGING & TRACKING
    // =========================================================================

    /**
     * Start generation log
     */
    private function startLog()
    {
        $sql = "INSERT INTO ai_generation_logs (service_code, topic, status) VALUES ('', '', 'started')";
        $this->doQuery($sql);
        return self::$conn->lastInsertId();
    }

    /**
     * Complete generation log
     */
    private function completeLog($logId, $articleId, $elapsedTime)
    {
        $sql = "UPDATE ai_generation_logs
                SET article_id = ?, status = 'published',
                    generation_time_ms = ?, completed_at = NOW()
                WHERE id = ?";
        $this->doQuery($sql, [$articleId, $elapsedTime, $logId]);
    }

    /**
     * Track API usage
     */
    private function trackApiUsage($keyIndex, $tokensIn = 0, $tokensOut = 0)
    {
        $usageFile = dirname(__DIR__) . '/data/api_usage.json';

        $usage = [];
        if (file_exists($usageFile)) {
            $usage = json_decode(file_get_contents($usageFile), true) ?? [];
        }

        $today = date('Y-m-d');
        if (!isset($usage[$today])) {
            $usage[$today] = [
                'requests' => 0,
                'tokens_input' => 0,
                'tokens_output' => 0,
                'by_key' => []
            ];
        }

        $usage[$today]['requests']++;
        $usage[$today]['tokens_input'] += $tokensIn;
        $usage[$today]['tokens_output'] += $tokensOut;

        if (!isset($usage[$today]['by_key'][$keyIndex])) {
            $usage[$today]['by_key'][$keyIndex] = 0;
        }
        $usage[$today]['by_key'][$keyIndex]++;

        // Keep only last 30 days
        $usage = array_slice($usage, -30, 30, true);

        file_put_contents($usageFile, json_encode($usage, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }

    /**
     * Mark topic as used
     */
    private function markTopicAsUsed($topicId, $articleId)
    {
        $sql = "UPDATE ai_article_topics SET is_used = 1, used_at = NOW(), article_id = ? WHERE id = ?";
        $this->doQuery($sql, [$articleId, $topicId]);
    }

    /**
     * Update SEO notes
     */
    private function updateSeoNotes($service, $topic, $validation)
    {
        $notesFile = dirname(__DIR__) . '/data/seo_notes.md';

        $note = "\n\n## " . date('Y-m-d H:i:s') . "\n";
        $note .= "- **Service:** {$service['name']}\n";
        $note .= "- **Topic:** {$topic['title']}\n";
        $note .= "- **Status:** " . ($validation['status'] ?? 'N/A') . "\n";

        if (isset($validation['word_count'])) {
            $note .= "- **Word Count:** {$validation['word_count']}\n";
        }

        if (!empty($validation['warnings'])) {
            $note .= "- **Warnings:** " . implode(', ', $validation['warnings']) . "\n";
        }

        file_put_contents($notesFile, $note, FILE_APPEND);
    }

    /**
     * Update sitemap.xml with new article
     * Adds article URL with image data and pings search engines
     */
    private function updateSitemap($articleId, $content, $imagePath)
    {
        $sitemapFile = dirname(__DIR__) . '/sitemap.xml';

        if (!file_exists($sitemapFile)) {
            $this->logger->warning('Sitemap file not found');
            return false;
        }

        try {
            $articleUrl = URL . 'article/show/' . $content['slug'];
            $imageUrl = $imagePath ? URL . $imagePath : null;
            $lastmod = date('Y-m-d');

            // Build new URL entry
            $newEntry = "\n    <!-- Article: {$content['title']} -->\n";
            $newEntry .= "    <url>\n";
            $newEntry .= "        <loc>{$articleUrl}</loc>\n";
            $newEntry .= "        <lastmod>{$lastmod}</lastmod>\n";
            $newEntry .= "        <changefreq>weekly</changefreq>\n";
            $newEntry .= "        <priority>0.7</priority>\n";

            // Add image if exists
            if ($imageUrl) {
                $imageTitle = htmlspecialchars($content['title'], ENT_XML1, 'UTF-8');
                $newEntry .= "        <image:image>\n";
                $newEntry .= "            <image:loc>{$imageUrl}</image:loc>\n";
                $newEntry .= "            <image:title>{$imageTitle}</image:title>\n";
                $newEntry .= "        </image:image>\n";
            }

            $newEntry .= "    </url>\n";

            // Read current sitemap
            $sitemap = file_get_contents($sitemapFile);

            // Check if article already exists in sitemap
            if (strpos($sitemap, $content['slug']) !== false) {
                $this->logger->info('Article already in sitemap', ['slug' => $content['slug']]);
                return true;
            }

            // Insert before closing </urlset>
            $sitemap = str_replace('</urlset>', $newEntry . '</urlset>', $sitemap);

            // Save updated sitemap
            file_put_contents($sitemapFile, $sitemap);

            $this->logger->info('Sitemap updated', ['article' => $content['slug']]);

            // Ping search engines (async, don't wait)
            $this->pingSearchEngines();

            return true;

        } catch (Exception $e) {
            $this->logger->error('Sitemap update failed', ['error' => $e->getMessage()]);
            return false;
        }
    }

    /**
     * Ping search engines about sitemap update
     */
    private function pingSearchEngines()
    {
        $sitemapUrl = URL . 'sitemap.xml';

        $pingUrls = [
            'https://www.google.com/ping?sitemap=' . urlencode($sitemapUrl),
            'https://www.bing.com/ping?sitemap=' . urlencode($sitemapUrl),
        ];

        foreach ($pingUrls as $pingUrl) {
            try {
                // Non-blocking ping
                $ch = curl_init($pingUrl);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_TIMEOUT, 5);
                curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 3);
                curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
                curl_exec($ch);
                curl_close($ch);
            } catch (Exception $e) {
                // Ignore ping errors - not critical
            }
        }

        $this->logger->info('Search engines pinged');
    }

    /**
     * Extract and save tags
     */
    private function extractAndSaveTags($articleId, $content, $service)
    {
        // Extract from keywords
        $keywords = explode('،', $content['meta_keywords'] ?? '');
        $tags = array_map('trim', $keywords);

        // Add service keywords
        $tags = array_merge($tags, $service['keywords'] ?? []);

        // Remove duplicates
        $tags = array_unique(array_filter($tags));

        // Save to database
        $sql = "INSERT IGNORE INTO article_tags (article_id, tag) VALUES (?, ?)";
        foreach ($tags as $tag) {
            if (!empty(trim($tag))) {
                try {
                    $this->doQuery($sql, [$articleId, trim($tag)]);
                } catch (Exception $e) {
                    // Ignore duplicate errors
                }
            }
        }

        return $tags;
    }

    /**
     * Count Persian words
     */
    private function countPersianWords($text)
    {
        $text = strip_tags($text);
        $text = preg_replace('/\s+/', ' ', $text);
        $words = preg_split('/\s+/u', trim($text));
        return count(array_filter($words));
    }

    // =========================================================================
    // PUBLIC METHODS FOR CONTROLLER
    // =========================================================================

    /**
     * Regenerate complete sitemap with all articles
     * Call this to sync all published articles to sitemap
     */
    public function regenerateSitemap()
    {
        $sitemapFile = dirname(__DIR__) . '/sitemap.xml';

        // Get all published articles
        $sql = "SELECT slug, title, featured_image, published_at
                FROM articles
                WHERE status = 'published'
                ORDER BY published_at DESC";
        $articles = $this->doSelect($sql);

        // Start building sitemap
        $sitemap = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
        $sitemap .= '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"' . "\n";
        $sitemap .= '        xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"' . "\n";
        $sitemap .= '        xmlns:image="http://www.google.com/schemas/sitemap-image/1.1"' . "\n";
        $sitemap .= '        xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9' . "\n";
        $sitemap .= '                            http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd">' . "\n\n";

        // Static pages
        $staticPages = [
            ['url' => '', 'priority' => '1.0', 'freq' => 'weekly', 'title' => 'Homepage'],
            ['url' => 'about', 'priority' => '0.8', 'freq' => 'monthly', 'title' => 'About Page'],
            ['url' => 'contact', 'priority' => '0.8', 'freq' => 'monthly', 'title' => 'Contact Page'],
            ['url' => 'article', 'priority' => '0.9', 'freq' => 'daily', 'title' => 'Blog'],
            ['url' => 'service/booth', 'priority' => '0.9', 'freq' => 'monthly', 'title' => 'Service: Booth'],
            ['url' => 'service/ads', 'priority' => '0.9', 'freq' => 'monthly', 'title' => 'Service: Ads'],
            ['url' => 'service/tandis', 'priority' => '0.9', 'freq' => 'monthly', 'title' => 'Service: Tandis'],
            ['url' => 'service/event', 'priority' => '0.9', 'freq' => 'monthly', 'title' => 'Service: Event'],
            ['url' => 'service/content', 'priority' => '0.9', 'freq' => 'monthly', 'title' => 'Service: Content'],
            ['url' => 'service/print', 'priority' => '0.9', 'freq' => 'monthly', 'title' => 'Service: Print'],
            ['url' => 'service/idea', 'priority' => '0.9', 'freq' => 'monthly', 'title' => 'Service: Idea'],
        ];

        foreach ($staticPages as $page) {
            $sitemap .= "    <!-- {$page['title']} -->\n";
            $sitemap .= "    <url>\n";
            $sitemap .= "        <loc>" . URL . $page['url'] . "</loc>\n";
            $sitemap .= "        <lastmod>" . date('Y-m-d') . "</lastmod>\n";
            $sitemap .= "        <changefreq>{$page['freq']}</changefreq>\n";
            $sitemap .= "        <priority>{$page['priority']}</priority>\n";
            $sitemap .= "    </url>\n\n";
        }

        // Add articles
        foreach ($articles as $article) {
            $articleUrl = URL . 'article/show/' . $article['slug'];
            $lastmod = $article['published_at'] ? date('Y-m-d', strtotime($article['published_at'])) : date('Y-m-d');
            $imageUrl = $article['featured_image'] ? URL . $article['featured_image'] : null;

            $sitemap .= "    <!-- Article: {$article['title']} -->\n";
            $sitemap .= "    <url>\n";
            $sitemap .= "        <loc>{$articleUrl}</loc>\n";
            $sitemap .= "        <lastmod>{$lastmod}</lastmod>\n";
            $sitemap .= "        <changefreq>weekly</changefreq>\n";
            $sitemap .= "        <priority>0.7</priority>\n";

            if ($imageUrl) {
                $imageTitle = htmlspecialchars($article['title'], ENT_XML1, 'UTF-8');
                $sitemap .= "        <image:image>\n";
                $sitemap .= "            <image:loc>{$imageUrl}</image:loc>\n";
                $sitemap .= "            <image:title>{$imageTitle}</image:title>\n";
                $sitemap .= "        </image:image>\n";
            }

            $sitemap .= "    </url>\n\n";
        }

        $sitemap .= "</urlset>\n";

        // Save sitemap
        file_put_contents($sitemapFile, $sitemap);

        // Ping search engines
        $this->pingSearchEngines();

        $this->logger->info('Sitemap regenerated', ['articles_count' => count($articles)]);

        return [
            'success' => true,
            'articles_count' => count($articles),
            'static_pages' => count($staticPages)
        ];
    }

    /**
     * Get article count by service
     */
    public function getArticleCountByService()
    {
        $sql = "SELECT service_code, COUNT(*) as count
                FROM articles
                WHERE service_code IS NOT NULL
                GROUP BY service_code";

        $results = $this->doSelect($sql);
        $counts = [];

        foreach ($results as $row) {
            $counts[$row['service_code']] = $row['count'];
        }

        return $counts;
    }

    /**
     * Get total AI articles count
     */
    public function getTotalAiArticles()
    {
        $sql = "SELECT COUNT(*) as count FROM articles WHERE is_ai_generated = 1";
        $result = $this->doSelect($sql);
        return $result[0]['count'] ?? 0;
    }

    /**
     * Get last generation time
     */
    public function getLastGenerationTime()
    {
        $sql = "SELECT completed_at FROM ai_generation_logs
                WHERE status = 'published'
                ORDER BY completed_at DESC LIMIT 1";
        $result = $this->doSelect($sql);
        return $result[0]['completed_at'] ?? null;
    }

    /**
     * Get generation logs
     */
    public function getGenerationLogs($limit = 50)
    {
        $sql = "SELECT * FROM ai_generation_logs ORDER BY created_at DESC LIMIT ?";
        return $this->doSelect($sql, [$limit]);
    }

    /**
     * Get API usage stats
     */
    public function getApiUsageStats()
    {
        $usageFile = dirname(__DIR__) . '/data/api_usage.json';
        if (file_exists($usageFile)) {
            return json_decode(file_get_contents($usageFile), true);
        }
        return [];
    }

    /**
     * Health check
     */
    public function healthCheck()
    {
        $checks = [];

        // Database check
        try {
            $this->doSelect("SELECT 1");
            $checks['database'] = ['status' => true, 'message' => 'Connected'];
        } catch (Exception $e) {
            $checks['database'] = ['status' => false, 'message' => $e->getMessage()];
        }

        // API keys check
        $validKeys = array_filter($this->apiKeys, function($key) {
            return !empty($key) && $key !== 'YOUR_API_KEY_1' && strlen($key) > 20;
        });
        $checks['api_keys'] = [
            'status' => count($validKeys) > 0,
            'message' => count($validKeys) . ' valid keys found'
        ];

        // Disk space check
        $freeSpace = disk_free_space(dirname(__DIR__));
        $checks['disk_space'] = [
            'status' => $freeSpace > 100000000,
            'message' => round($freeSpace / 1000000000, 2) . ' GB free'
        ];

        // Upload directory check
        $uploadDir = dirname(__DIR__) . '/public/uploads/ai_articles';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }
        $checks['upload_dir'] = [
            'status' => is_writable($uploadDir),
            'message' => is_writable($uploadDir) ? 'Writable' : 'Not writable'
        ];

        // Lock status
        $checks['lock_status'] = [
            'status' => !$this->isLocked(),
            'message' => $this->isLocked() ? 'System is locked' : 'System is available'
        ];

        return $checks;
    }

    /**
     * Get incomplete workflows that can be resumed
     */
    public function getIncompleteWorkflows()
    {
        $sql = "SELECT id, topic_id, state, data, created_at, updated_at
                FROM ai_workflow_states
                WHERE state NOT IN (?, ?, ?)
                ORDER BY created_at ASC
                LIMIT 10";

        try {
            $result = $this->doSelect($sql, [self::STATE_PUBLISHED, self::STATE_FAILED, self::STATE_VALIDATED]);
            return $result ?: [];
        } catch (Exception $e) {
            $this->logger->error("Error getting incomplete workflows", ['error' => $e->getMessage()]);
            return [];
        }
    }

    /**
     * Get system status
     */
    public function getSystemStatus()
    {
        return [
            'is_running' => $this->isLocked(),
            'total_ai_articles' => $this->getTotalAiArticles(),
            'last_generation' => $this->getLastGenerationTime(),
            'articles_by_service' => $this->getArticleCountByService(),
            'topics' => [
                'total' => $this->getTotalTopics(),
                'unused' => $this->getUnusedTopicsCount(),
            ],
            'api_keys_configured' => count(array_filter($this->apiKeys, fn($k) => strlen($k) > 20)),
            'api_key_status' => $this->getApiKeyStatusSummary(),
        ];
    }

    /**
     * Get API key status summary
     */
    private function getApiKeyStatusSummary()
    {
        $summary = [];
        foreach ($this->apiKeyStatus as $index => $status) {
            $summary[$index] = [
                'requests_today' => $status['requests_today'] ?? 0,
                'errors' => $status['error_count'] ?? 0,
                'is_exhausted' => $status['is_exhausted'] ?? false,
                'in_cooldown' => !empty($status['cooldown_until']) && strtotime($status['cooldown_until']) > time()
            ];
        }
        return $summary;
    }

    /**
     * Get total topics count
     */
    private function getTotalTopics()
    {
        $sql = "SELECT COUNT(*) as count FROM ai_article_topics";
        $result = $this->doSelect($sql);
        return $result[0]['count'] ?? 0;
    }

    /**
     * Get unused topics count
     */
    private function getUnusedTopicsCount()
    {
        $sql = "SELECT COUNT(*) as count FROM ai_article_topics WHERE is_used = 0";
        $result = $this->doSelect($sql);
        return $result[0]['count'] ?? 0;
    }

    /**
     * Get topics list
     */
    public function getTopics($serviceCode = null)
    {
        if ($serviceCode) {
            $sql = "SELECT * FROM ai_article_topics WHERE service_code = ? ORDER BY is_used ASC, priority ASC";
            return $this->doSelect($sql, [$serviceCode]);
        }

        $sql = "SELECT * FROM ai_article_topics ORDER BY service_code, is_used ASC, priority ASC";
        return $this->doSelect($sql);
    }

    /**
     * Get services stats
     */
    public function getServicesStats()
    {
        $counts = $this->getArticleCountByService();
        $result = [];

        foreach ($this->services as $code => $service) {
            $topicSql = "SELECT COUNT(*) as total,
                         SUM(CASE WHEN is_used = 0 THEN 1 ELSE 0 END) as unused
                         FROM ai_article_topics WHERE service_code = ?";
            $topics = $this->doSelect($topicSql, [$code])[0] ?? ['total' => 0, 'unused' => 0];

            $result[$code] = [
                'name' => $service['name'],
                'url' => $service['url'],
                'article_count' => $counts[$code] ?? 0,
                'topics_total' => (int)$topics['total'],
                'topics_unused' => (int)$topics['unused'],
            ];
        }

        return $result;
    }

    /**
     * Reset topic
     */
    public function resetTopic($topicId)
    {
        $sql = "UPDATE ai_article_topics SET is_used = 0, used_at = NULL, article_id = NULL WHERE id = ?";
        $this->doQuery($sql, [$topicId]);
        return true;
    }

    /**
     * Add new topic
     */
    public function addTopic($serviceCode, $title, $keyword = '')
    {
        if (!isset($this->services[$serviceCode])) {
            throw new Exception("Invalid service code: {$serviceCode}");
        }

        $sql = "INSERT INTO ai_article_topics (service_code, topic_title, primary_keyword, priority) VALUES (?, ?, ?, 50)";
        $this->doQuery($sql, [$serviceCode, $title, $keyword]);
        return true;
    }

    /**
     * Force unlock
     */
    public function forceUnlock()
    {
        try {
            $this->doQuery("DELETE FROM ai_workflow_locks WHERE workflow_id = 'article_generation'");
            $this->logger->info('Force unlock executed');
            return true;
        } catch (Exception $e) {
            return false;
        }
    }

    /**
     * Test API connection
     */
    public function testApiConnection()
    {
        try {
            $this->enforceApiDelay();
            $response = $this->callGeminiApi("Say 'API connection successful' in Persian.");
            return [
                'success' => true,
                'message' => 'API connection successful',
                'details' => [
                    'response' => $response,
                    'key_count' => count(array_filter($this->apiKeys, fn($k) => strlen($k) > 20)),
                ]
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => $e->getMessage()
            ];
        }
    }

    /**
     * Test content generation (without saving)
     */
    public function testContentGeneration($serviceCode = null)
    {
        try {
            // Select service
            if ($serviceCode && isset($this->services[$serviceCode])) {
                $service = array_merge(['code' => $serviceCode], $this->services[$serviceCode]);
            } else {
                $service = $this->selectServiceIntelligently();
            }

            // Select topic
            $topic = $this->selectTopicIntelligently($service['code']);

            // Generate content
            $this->enforceApiDelay();
            $content = $this->generateArticleContent($service, $topic);

            // Validate
            $validation = $this->performComprehensiveValidation($content, null);

            return [
                'success' => true,
                'message' => 'Test generation successful',
                'preview' => [
                    'service' => $service['name'],
                    'topic' => $topic['title'],
                    'title' => $content['title'],
                    'meta_description' => $content['meta_description'],
                    'excerpt' => $content['excerpt'],
                    'body_preview' => mb_substr(strip_tags($content['body']), 0, 500) . '...',
                    'validation' => $validation,
                ],
                'word_count' => $this->countPersianWords($content['body']),
            ];

        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Test generation failed: ' . $e->getMessage(),
            ];
        }
    }

    /**
     * Check if another process is running (legacy method)
     */
    public function isRunning()
    {
        return $this->isLocked();
    }
}
