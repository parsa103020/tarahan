    // Ultra Premium Counter Animation (از صفر شروع می‌کنه)
    function animateCounters() {
        const counters = document.querySelectorAll('.stat-number');

        const observerOptions = {
            threshold: 0.5,
            rootMargin: '0px'
        };

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting && !entry.target.classList.contains('counted')) {
                    entry.target.classList.add('counted');

                    const counter = entry.target;
                    const target = parseInt(counter.getAttribute('data-count'));
                    const duration = 2500; // 2.5 ثانیه برای counter
                    const frameDuration = 1000 / 60; // 60 FPS
                    const totalFrames = Math.round(duration / frameDuration);
                    const easeOutQuad = t => t * (2 - t);

                    let frame = 0;
                    const counterInterval = setInterval(() => {
                        frame++;
                        const progress = easeOutQuad(frame / totalFrames);
                        const currentCount = Math.round(target * progress);

                        if (target === 100) {
                            counter.textContent = currentCount + '%';
                        } else {
                            counter.textContent = currentCount + '+';
                        }

                        if (frame === totalFrames) {
                            clearInterval(counterInterval);
                            if (target === 100) {
                                counter.textContent = '100%';
                            } else {
                                counter.textContent = target + '+';
                            }
                        }
                    }, frameDuration);
                }
            });
        }, observerOptions);

        counters.forEach(counter => observer.observe(counter));
    }

    // Fade-in on Scroll با Intersection Observer
    function fadeInOnScroll() {
        const elements = document.querySelectorAll('.fade-in');
        const observer = new IntersectionObserver((entries) => {
            entries.forEach((entry, index) => {
                if (entry.isIntersecting) {
                    setTimeout(() => {
                        entry.target.classList.add('visible');
                    }, index * 100);
                }
            });
        }, {
            threshold: 0.15,
            rootMargin: '0px 0px -50px 0px'
        });

        elements.forEach(el => observer.observe(el));
    }

    // Smooth Scroll
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });

    // Parallax Effect for Hero
    window.addEventListener('scroll', () => {
        const scrolled = window.pageYOffset;
        const heroContent = document.querySelector('.hero-content');
        if (heroContent && scrolled < window.innerHeight) {
            heroContent.style.transform = `translateY(${scrolled * 0.5}px)`;
            heroContent.style.opacity = Math.max(0, 1 - (scrolled / 600));
        }
    });

    // Initialize all animations
    window.addEventListener('load', () => {
        animateCounters();
        fadeInOnScroll();
    });

    // Initialize on DOM ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => {
            animateCounters();
            fadeInOnScroll();
        });
    } else {
        animateCounters();
        fadeInOnScroll();
    }
