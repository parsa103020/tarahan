<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>

<style>
    body{
        background: #32323c;
    }
    div{
        display: block;
        width: 300px;
        margin: auto;
    }
    img{
        display: block;
        width: 300px;
        margin:20px auto;
        position: relative;

    }
</style>

<div>
    <img src="public/icon/404.jpg" alt="404 Not Found">
</div>
</body>
</html>


