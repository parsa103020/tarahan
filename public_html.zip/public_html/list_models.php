<?php
// List available models
$configFile = __DIR__ . '/data/api_keys.json';
$config = json_decode(file_get_contents($configFile), true);
$apiKey = $config['gemini_keys'][2] ?? $config['gemini_keys'][0];

$url = "https://generativelanguage.googleapis.com/v1beta/models?key=" . $apiKey;

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_TIMEOUT, 30);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

header('Content-Type: application/json; charset=utf-8');

if ($httpCode === 200) {
    $result = json_decode($response, true);
    $models = [];
    foreach ($result['models'] ?? [] as $model) {
        // Filter to only show models with 'image' in name or methods
        $name = $model['name'] ?? '';
        $methods = $model['supportedGenerationMethods'] ?? [];
        if (strpos($name, 'image') !== false || strpos($name, 'imagen') !== false || in_array('generateImage', $methods)) {
            $models[] = [
                'name' => $name,
                'displayName' => $model['displayName'] ?? '',
                'methods' => $methods
            ];
        }
    }
    echo json_encode([
        'http_code' => $httpCode,
        'image_models' => $models,
        'total_models' => count($result['models'] ?? [])
    ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
} else {
    echo json_encode([
        'http_code' => $httpCode,
        'error' => $response
    ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
}
