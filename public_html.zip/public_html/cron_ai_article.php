<?php
/**
 * Cron Job for Automatic Article Generation
 * Version 3.0 - With State Machine Workflow Support
 *
 * Run this file with cron job:
 * Windows Task Scheduler:
 *   php C:\xampp\htdocs\tarahan\cron_ai_article.php
 *
 * Linux crontab:
 *   0 6,12,18,0 * * * /usr/bin/php /path/to/cron_ai_article.php >> /var/log/ai_article.log 2>&1
 *
 * Recommendation: Run every 6 hours
 *
 * Environment Variables (optional):
 *   AI_ARTICLE_SERVICE - Force specific service (booth, ads, tandis, event, content, print, idea)
 */

// CLI environment setup
if (php_sapi_name() !== 'cli') {
    die('This script must be run from command line');
}

// Execution time setup
set_time_limit(600);
ini_set('memory_limit', '256M');

// Parse command line arguments
$options = getopt('', ['service:', 'force', 'verbose', 'help']);

if (isset($options['help'])) {
    echo "Usage: php cron_ai_article.php [options]\n";
    echo "Options:\n";
    echo "  --service=CODE  Force specific service (booth, ads, tandis, event, content, print, idea)\n";
    echo "  --force         Force run even if recently executed\n";
    echo "  --verbose       Show detailed output\n";
    echo "  --help          Show this help message\n";
    exit(0);
}

$verbose = isset($options['verbose']);
$forceRun = isset($options['force']);
$serviceCode = $options['service'] ?? getenv('AI_ARTICLE_SERVICE') ?: null;

// Load required files
require_once __DIR__ . '/core/model.php';
require_once __DIR__ . '/core/config.php';
require_once __DIR__ . '/models/model_ai_article.php';

// Log start
$startTime = date('Y-m-d H:i:s');
echo "[{$startTime}] Starting AI Article Generation (v3.0)...\n";

if ($serviceCode) {
    echo "  - Forced Service: {$serviceCode}\n";
}

try {
    // Create model
    $model = new model_ai_article();

    // Check system health
    echo "[INFO] Running health check...\n";
    $health = $model->healthCheck();
    $allHealthy = true;

    foreach ($health as $key => $check) {
        $status = $check['status'] ? 'OK' : 'FAILED';
        if ($verbose || !$check['status']) {
            echo "  - {$key}: {$status}" . (!$check['status'] ? " ({$check['message']})" : '') . "\n";
        }
        if (!$check['status']) {
            $allHealthy = false;
        }
    }

    if (!$allHealthy && !$forceRun) {
        echo "[ERROR] System health check failed. Use --force to override.\n";
        exit(1);
    }

    // Check for incomplete workflows that can be resumed
    echo "[INFO] Checking for incomplete workflows...\n";
    $incompleteWorkflows = $model->getIncompleteWorkflows();
    if (!empty($incompleteWorkflows)) {
        echo "[INFO] Found " . count($incompleteWorkflows) . " incomplete workflow(s).\n";
        foreach ($incompleteWorkflows as $wf) {
            echo "  - Workflow #{$wf['id']}: {$wf['state']} (topic: {$wf['topic_id']})\n";
        }
        echo "[INFO] Attempting to resume oldest workflow...\n";
    }

    // Run workflow
    echo "[INFO] Starting workflow...\n";
    $workflowStart = microtime(true);
    $result = $model->runWorkflow($serviceCode);
    $workflowTime = round((microtime(true) - $workflowStart) * 1000);

    if ($result['success']) {
        echo "\n[SUCCESS] Article generated successfully!\n";
        echo "  +------------------------------------------\n";
        echo "  | Article ID    : {$result['data']['article_id']}\n";
        echo "  | Title         : {$result['data']['title']}\n";
        echo "  | Service       : {$result['data']['service']}\n";
        echo "  | Word Count    : {$result['data']['word_count']}\n";
        echo "  | Validation    : {$result['data']['validation']}\n";
        echo "  | Quality Score : " . ($result['data']['quality_score'] ?? 'N/A') . "\n";
        echo "  | Time Taken    : {$workflowTime}ms\n";
        echo "  +------------------------------------------\n";

        if ($verbose && isset($result['data']['slug'])) {
            echo "\n[INFO] Article URL: " . URL . "article/" . $result['data']['slug'] . "\n";
        }
    } else {
        echo "\n[FAILED] {$result['message']}\n";
        if ($verbose && isset($result['data']['errors'])) {
            echo "[DEBUG] Errors:\n";
            foreach ($result['data']['errors'] as $error) {
                echo "  - {$error}\n";
            }
        }
        exit(1);
    }

} catch (Exception $e) {
    echo "\n[ERROR] Exception: " . $e->getMessage() . "\n";
    if ($verbose) {
        echo "[DEBUG] Stack trace:\n" . $e->getTraceAsString() . "\n";
    }
    exit(1);
}

$endTime = date('Y-m-d H:i:s');
$totalTime = strtotime($endTime) - strtotime($startTime);
echo "\n[{$endTime}] Completed in {$totalTime} seconds.\n";
exit(0);
